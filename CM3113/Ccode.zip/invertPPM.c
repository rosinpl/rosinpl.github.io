/* inverts an image
 *
 * Paul Rosin
 */

#include <stdio.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE !FALSE

#define MAX_SIZE 5000

#include "ppmio.h"

unsigned char image[MAX_SIZE][MAX_SIZE][3];
unsigned char image2[MAX_SIZE][MAX_SIZE][3];
int height,width,depth;

main(argc,argv)
int argc;
char **argv;
{
    int x,y,i,j;
    
    if (argc != 3) {
        printf("usage: %s input_image output_image\n",argv[0]);
        exit(-1);
    }

    read_ppm(image,argv[1],&width,&height,&depth);

    for (y=0;y<height;y++)
        for (x=0;x<width;x++)
            for (i=0;i<3;i++)
                image2[x][y][i] = 255-image[x][y][i];

    write_ppm(image2,argv[2],width,height);
}
