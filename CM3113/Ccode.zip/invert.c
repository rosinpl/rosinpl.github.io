/* inverts an image
 *
 * Paul Rosin
 */

#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 20000

#include "pgmio.h"

unsigned char image[MAX_SIZE][MAX_SIZE];
int height,width,depth;

main(argc,argv)
int argc;
char **argv;
{
    int x,y,i,j;
    int x1,x2,y1,y2;
    int value;
    
    if (argc != 3) {
        printf("usage: %s input_image output_image\n",argv[0]);
        exit(-1);
    }

    read_pgm(image,argv[1],&width,&height,&depth);

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            image[x][y] = (unsigned char)(255-image[x][y]);

    write_pgm(image,argv[2],width,height);
}
