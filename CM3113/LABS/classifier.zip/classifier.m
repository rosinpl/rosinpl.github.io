% demonstrate classification using global shape features and a basic linear classifier
%
% NOTE: the code is not written in a "good" style, and is full of global variables and inefficient hacks
% also there are some problems/limitations:
% 1/ after clicking the reset button one of the images is not re-displayed
% 2/ ginput seems to have a slow startup time
% 3/ given the problem with clearing the feature plot it doesn't work properly if multiple selection rounds are done without resets
% 4/ feature plotting assumes the range of feature values is in [0,1]
% 5/ assumes a single connected component
% 6/ assumes (for plotting) that images are a fixed size
% 7/ etc.
%
% Circularity is sensitive to boundary noise, and can be replaced
%
% Paul Rosin
% Cardiff University
% 2022

clear all
close all

% create GUI window
width = 1130;
height = 480;
window = figure('Name', 'Shape Classification Demo',...
                'Color', [0.9255 0.9137 0.8471],...
                'DockControl', 'off',...
                'Units', 'Pixels',...
                'Position', [10 10 width height]);

% add buttons to window
select_button = uicontrol('Parent', window,...
                'Style', 'pushbutton',...
                'String', 'select',...
                'FontSize', 18,...
                'Units', 'Pixels',...
                'Position', [10,height-50,100,50],...
                'Callback', @selectCallback);

classify_button = uicontrol('Parent', window,...
                'Style', 'pushbutton',...
                'String', 'classify',...
                'FontSize', 18,...
                'Units', 'Pixels',...
                'Position', [2*75,height-50,100,50],...
                'Callback', @classifyCallback);

reset_button = uicontrol('Parent', window,...
                'Style', 'pushbutton',...
                'String', 'reset',...
                'FontSize', 18,...
                'Units', 'Pixels',...
                'Position', [4*75,height-50,100,50],...
                'Callback', @resetCallback);

quit_button = uicontrol('Parent', window,...
                'Style', 'pushbutton',...
                'String', 'quit',...
                'FontSize', 18,...
                'Units', 'Pixels',...
                'Position', [6*75,height-50,100,50],...
                'Callback', @quitCallback);

global numberClasses % parts of the code only work if numberClasses=2
global numberImages
global images
global width2
global height2
global stats
global ax
global axFeatures

% read and plot images
numberClasses = 2;
numberImages = 5;
images = false(numberClasses,numberImages,200,130);
width2 = 130;
height2 = 200;

% set axis handle variables to have the correct data type
axFeatures = gobjects;
ax = gobjects(numberClasses,numberImages);

for c = 1:numberClasses
    for i = 1:numberImages
        ax(c,i) = axes('Parent', window,...
                     'Units', 'Pixels',...
                     'Position', [(i-1)*width2 (c-1)*height2 width2 height2]);
        n1 = num2str(c);
        n2 = num2str(i);
        filename = strcat(n1,'-',n2,'.png');
        tmp = imread(filename);
        % not necessary with binary png format
        %level = graythresh(tmp);
        %tmp = imbinarize(tmp,level);
        imshow(tmp,'Parent',ax(c,i));
        images(c,i,:,:) = tmp;
    end
end

% extract shape features from images
for c = 1:numberClasses
    for i = 1:numberImages
        tmp = squeeze(images(c,i,:,:));
        % foreground in matlab is 1 (white)
        stats0(c,i) = regionprops(~tmp,'Circularity','Eccentricity');
    end
end
stats = cell2mat(struct2cell(stats0)); % array = #features x #classes x #images

% plot image as a point in feature space
axFeatures = axes('Parent', window,...
                  'Units', 'Pixels',...
                  'Position', [700 40 400 400]);

hold on
for c = 1:numberClasses
    f1 = squeeze(stats(1,c,:));
    f2 = squeeze(stats(2,c,:));
    plot(axFeatures,f1,f2,'.','MarkerSize',6,'LineWidth',2);
end
xlim([0 1])
ylim([0 1])

xlabel(axFeatures, 'Eccentricity','FontSize',16);
ylabel(axFeatures, 'Circularity','FontSize',16);
title(axFeatures, 'Features','FontSize',16);

% callback functions
function quitCallback(hObj, event)
    close
end

% select images for training
function selectCallback(hObj, event)
    global images
    global width2
    global height2
    global ax
    global axFeatures
    global stats
    global keep
    global keepFlags
    global numberClasses
    global numberImages
    global plotHandles

    disp('click on shapes; right click when finished')
    waitingRightClick = true;

    keepFlags = false(numberClasses,numberImages);
    plotHandles = [];

    while waitingRightClick
        [~,~,button] = ginput(1);
        if (button == 3)
            waitingRightClick = false;
        else
            % find which axis has been clicked
            t = gca;
            tt = t.Position;
            left = tt(1);
            bottom = tt(2);
            ii = left / width2 + 1;
            cc = bottom / height2 + 1;

            % invert selected image
            tmp = squeeze(images(cc,ii,:,:));
            tmp = 255 * repmat(uint8(~tmp), 1, 1, 3);
            imshow(tmp,'Parent',ax(cc,ii));

            % replot corresponding point in feature space for emphasis
            f1 = squeeze(stats(1,cc,ii));
            f2 = squeeze(stats(2,cc,ii));
            axFeatures.ColorOrderIndex = cc;  % set colour index
            h = plot(axFeatures,f1,f2,'o','MarkerSize',10,'LineWidth',1);
            plotHandles = [plotHandles h];

            % record selection
            keep = [keep; cc, ii];
            keepFlags(cc, ii) = true;
        end
     end
end

function classifyCallback(hObj, event)
    global keep
    global keepFlags
    global stats
    global ax
    global axFeatures
    global numberClasses
    global numberImages
    global images
    global plotHandles

    c1 = keep(:,1) == 1;
    c2 = keep(:,1) == 2;

    if sum(c1) == 0
        error('no images for class 1 have been selected');
    elseif sum(c2) == 0
        error('no images for class 2 have been selected');
    end

    i1 = keep(c1,:); i1 = i1(:,2);
    i2 = keep(c2,:); i2 = i2(:,2);

    meanClass1Feature1 = mean(stats(1,1,i1));
    meanClass1Feature2 = mean(stats(2,1,i1));

    meanClass2Feature1 = mean(stats(1,2,i2));
    meanClass2Feature2 = mean(stats(2,2,i2));

    F1mean = (meanClass1Feature1 + meanClass2Feature1) / 2;
    F2mean = (meanClass1Feature2 + meanClass2Feature2) / 2;
    grad = (meanClass1Feature2 - meanClass2Feature2) / (meanClass1Feature1 - meanClass2Feature1);

    x1 = 0;
    y1 = -1 / grad * (x1 - F1mean) + F2mean;
    x2 = 1;
    y2 = -1 / grad * (x2 - F1mean) + F2mean;

    % midpoint between class means 
    %plot(axFeatures,F1mean,F2mean,'k+');
    h = plot(axFeatures,[x1 x2],[y1 y2],'r','LineWidth',2);
    plotHandles = [plotHandles h];

    % compute another point on perpendicular bisector
    % used for signed distance calculation (although this is probably uneccessary)
    f1p = F1mean + (meanClass1Feature2 - meanClass2Feature2);
    f2p = F2mean - (meanClass1Feature1 - meanClass2Feature1);

    colours = colororder;

    % perform classification
    for c = 1:numberClasses
        for i = 1:numberImages
            % signed distance to decision line
            label(c,i) = (stats(1,c,i) - F1mean) * (f2p - F2mean) - (stats(2,c,i) - F2mean) * (f1p - F1mean);

            if label(c,i) < 0
                label(c,i) = 1;
            else
                label(c,i) = 2;
            end

            % colour image according to classification label
            tmp = squeeze(images(c,i,:,:));
            if keepFlags(c,i)
                tmp = 255 * repmat(uint8(~tmp), 1, 1, 3);
            else
                tmp = 255 * repmat(uint8(tmp), 1, 1, 3);
            end
            tmp = double(tmp);
            tmp(:,:,1) = tmp(:,:,1) .* colours(label(c,i),1);
            tmp(:,:,2) = tmp(:,:,2) .* colours(label(c,i),2);
            tmp(:,:,3) = tmp(:,:,3) .* colours(label(c,i),3);
            tmp = uint8(tmp);
            imshow(tmp,'Parent',ax(c,i));
        end
    end
    correct = sum(label(1,:) == 1) + sum(label(2,:) == 2);
    fprintf('accuracy = %.1f%%\n',100*correct/(numberClasses*numberImages));
end

% unselect images and reset display etc
function resetCallback(hObj, event)
    global images
    global ax
    global axFeatures
    global stats
    global keep
    global keepFlags
    global numberClasses
    global numberImages
    global plotHandles

    keep = [];
    keepFlags = false;
    for c = 1:numberClasses
        for i = 1:numberImages
            tmp = squeeze(images(c,i,:,:));
            tmp = 255 * repmat(uint8(tmp), 1, 1, 3);
            imshow(tmp,'Parent',ax(c,i));
        end
    end

    % I can't get clf to work - it seems to clear all the other figures except for the specified one!
    % so I am saving handles to all the plotted objects and then deleting them
    delete(plotHandles);
    axFeatures.ColorOrderIndex = 1;  % reset colour index
    for c = 1:numberClasses
        f1 = squeeze(stats(1,c,:));
        f2 = squeeze(stats(2,c,:));
        plot(axFeatures,f1,f2,'.','MarkerSize',6,'LineWidth',2);
    end
end
