/* Perform change detection by thresholding a difference image
 *
 * This version is substantially more efficient than the original
 * For an image with N pixels and G graylevels the computation time is
 * improved from O(N x G) to O(N + G) 
 *
 * input:  PGM (unsigned) difference image
 * output: PGM thresholded difference image
 *
 * Two methods available:
 *      1/ compute graph of Euler number versus threshold
 *         find corner in graph 
 *         i.e. point of maximum deviation from line between maximum peak and end of graph
 *      2/ maximise relative variance at different thresholds
 *         i.e. reduce randomness of spatial distribution
 *         computed over local windows
 *         i.e. Poisson distribution model
 *
 * for details see
 *      P.L. Rosin,
 *      "Thresholding for Change Detection"
 *      Computer Vision and Image Understanding, vol. 86, no. 2, pp. 79-95, 2002. 
 * an updated version of
 *      P.L. Rosin
 *      "Thresholding for Change Detection"
 *      Int. Conf. Computer Vision, pp. 274-279, 1998 
 * which extends previous work in
 *      P.L. Rosin and T. Ellis
 *      "Image difference threshold strategies and shadow detection"
 *      British Machine Vision Conf., pp. 347-356 1995. 
 *
 * Paul Rosin
 * Cardiff University
 * August 1998 / updated February 2013
 */

#include <stdio.h>
#include <stdlib.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define MAX_SIZE 5000
#define MAX_DIV  8

#include "pgmio.h"

#define SQR(x)    ((x)*(x))
#define ABS(x)    (((x)<0.0)? (-(x)): (x))

unsigned char image[MAX_SIZE][MAX_SIZE];
int height,width,depth;

void smooth(double values[]);
void fast_euler(unsigned char image[MAX_SIZE][MAX_SIZE], int values[256]);
int find_corner(int Y[], int no_pts);
void sort_int(int n, int ra[]);
void fast_euler(unsigned char image[MAX_SIZE][MAX_SIZE], int values[256]);
int find_peak(double values[]);
void options(char *progname);

main(argc,argv)
int argc;
char **argv;
{
    int x,y,xx,yy,tx,ty;
    int i;
    int t,thresh;
    char *outfile,*infile;
    int do_Euler = TRUE;                  // default method
    int do_relVar = FALSE;

    int euler_values[256];                           // Euler stuff

    int win_div = 8;                      // for the Poisson model approach the image is divided
    int xwin_size,ywin_size;              // win_div*win_div windows of this size
    int num_windows = win_div * win_div;
    double var,mean;
    int cumulative[MAX_DIV][MAX_DIV][256];
    double rel_var[256];

    outfile = infile = NULL;

    /* parse command line */
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            switch(argv[i][1]) {
                case 'e':
                    do_Euler = TRUE;
                    do_relVar = FALSE;
                    break;
                case 'p':
                    do_relVar = TRUE;
                    do_Euler = FALSE;
                    break;
                case 'i':
                    i++;
                    infile = argv[i];
                    break;
                case 'o':
                    i++;
                    outfile = argv[i];
                    break;
                default:
                    printf("unknown option %s\n",argv[i]);
                    options(argv[0]);
            }
        }
        else {
            printf("unknown option %s\n",argv[i]);
            options(argv[0]);
        }
    }

    if ((infile == NULL) || (outfile == NULL)) {
        fprintf(stderr,"ERROR: need difference-image and outfile\n");
        options(argv[0]);
    }

    read_pgm(image,infile,&width,&height,&depth);

    /* ------------------------------------------------------------ */

    if (do_Euler) {
        fast_euler(image,euler_values);

        // for some reason this was set to 253 not 255 in the old program
        thresh = find_corner(euler_values,255);
    }

    /* ------------------------------------------------------------ */

    else if (do_relVar) {
        xwin_size = width / win_div;
        ywin_size = height / win_div;

        // count how many pixels in each window are above threshold
        // new version is much made faster by using cumulative count
        // NOTE: the old version counted # pixels >= threshold
        // and so the sequence of relative variances was offset by one threshold
        // although this is compensated now by thresholding at >= rather than >
        // it still very occasionally gives slightly different results due to
        // differences due to the single value at t=255
        // However, this is NOT an issue

        for (yy = 0; yy < win_div; yy++)
            for (xx = 0; xx < win_div; xx++)
                for (t = 0; t < 256; t++)
                    cumulative[xx][yy][t] = 0;

        // for each (win_div X win_div) window create cumulative count of pixel intensities
        for (yy = 0; yy < win_div; yy++) {
            for (xx = 0; xx < win_div; xx++) {
                for (y = 0; y < ywin_size; y++) {
                    for (x = 0; x < xwin_size; x++) {
                        tx = x + xx * xwin_size;
                        ty = y + yy * ywin_size;

                        cumulative[xx][yy][image[tx][ty]]++;
                    }
                }
            }
        }

        // i.e. how many pixels in window are above each threshold
        for (yy = 0; yy < win_div; yy++) {
            for (xx = 0; xx < win_div; xx++) {
                for (t = 254; t >= 0; t--)
                    cumulative[xx][yy][t] += cumulative[xx][yy][t+1];
            }
        }

        for (t = 0; t < 256; t++)
            rel_var[t] = 0;

        // for each possible threshold
        for (t = 0; t < 256; t++) {

            // compute relative variance
            mean = 0;
            for (yy = 0; yy < win_div; yy++)
                for (xx = 0; xx < win_div; xx++)
                    mean += cumulative[xx][yy][t];
            mean /= (double)num_windows;

            if (mean == 0) break;

            var = 0;
            for (yy = 0; yy < win_div; yy++)
                for (xx = 0; xx < win_div; xx++)
                    var += SQR(mean - cumulative[xx][yy][t]);

            rel_var[t] = var / mean;
        }

        // smooth sequence of relative variances
        smooth(rel_var);

        // return threshold that maximises relative variance
        thresh = find_peak(rel_var);
    }

    printf("thresholding difference of intensity images at %d\n",thresh);

    // to make this program consistent with the old one then do this:
    if (do_Euler) thresh++;

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            if (image[x][y] >= thresh)
                image[x][y] = 0;
            else
                image[x][y] = 255;

    write_pgm(image,outfile,width,height);
}

// smooth the sequence of relative variance values
void smooth(double values[])
{
    int i,t;
    double tmpData[256];

    tmpData[0] = values[0];
    tmpData[255] = values[255];
    for (i = 0; i < 5; i++) {
        for (t = 1; t < 255; t++)
            tmpData[t] = (values[t-1] + values[t] + values[t+1]) / 3.0;
        tmpData[0] = (values[0] + values[1] ) / 2.0;
        tmpData[255] = (values[254] + values[255] ) / 2.0;

        for (t = 1; t < 255; t++)
            values[t] = (tmpData[t-1] + tmpData[t] + tmpData[t+1]) / 3.0;
        values[0] = (tmpData[0] + tmpData[1] ) / 2.0;
        values[255] = (tmpData[254] + tmpData[255] ) / 2.0;
    }
}

/* find `corner' in Euler curve */
/* try to overcome problems if the start is not the top of the main peak */
int find_corner(int Y[], int no_pts)
{
    int X[1000];
    int st,i;
    float dist;
    float max_dist = -1;
    int thresh = -1;
    int max;

    for (i = 1; i < no_pts; i++){
        X[i] = i;
        // for some reason absolute Euler numbers were used in the old program
        //Y[i] = ABS(Y[i]);
    }

    /* find largest peak */
    st = 1; max = Y[1];
    for (i = 1; i < no_pts; i++)
        if (Y[i] > max) {
            max = Y[i];
            st = i;
        }

    for (i = st; i < no_pts; i++) {
        dist = (Y[st] - Y[no_pts-1]) * X[i] -
               (X[st] - X[no_pts-1]) * Y[i] -
                X[no_pts-1] * Y[st] +
                X[st] * Y[no_pts-1];
        dist = SQR(dist) /
             (double)(SQR(X[st] - X[no_pts-1]) + SQR(Y[st] - Y[no_pts-1]));

        /* ADDED - PLR 8/98 */
        dist = ABS(dist);

        if (dist > max_dist) {
            max_dist = dist;
            thresh = i;
        }
    }

    return thresh;
}

// return the threshold corresponding to the peak value of array
int find_peak(double values[])
{
    int t;
    double max;
    int thresh = 0;

    max = values[0];
    for (t = 1; t < 256; t++)
        if (values[t] > max) {
            max = values[t];
            thresh = t;
        }
    return(thresh);
}

/* ------------------------------------------------------------ */

/* fast computation of Euler number of image at all thresholds
 * Snidaro & Foresti, Pattern Recognition Letters, 2003
 * NOTE: the description in the paper contains some errors
 *       the algorithm has been revised according to Lauro Snidaro [personal communication]
 */
void fast_euler(unsigned char image[MAX_SIZE][MAX_SIZE], int values[256])
{
    int t,x,y;
    int tmpData[10];
    int q1start[256],q1end[256],q3start[256],q3end[256],qDstart[256],qDend[256];
    int q1[256],q3[256],qD[256];
    int a,b,c,d;
    int p1,p2,p3,p4;

    for (t = 0; t < 256; t++)
        q1start[t] = q1end[t] = q3start[t] = q3end[t] = qDstart[t] = qDend[t] = 0;

    for (y = 0; y < height-1; y++) {
        for (x = 0; x < width-1; x++) {
            p1 = image[x][y];
            p3 = image[x+1][y];
            p2 = image[x][y+1];
            p4 = image[x+1][y+1];

            tmpData[1] = image[x][y];
            tmpData[2] = image[x+1][y];
            tmpData[3] = image[x][y+1];
            tmpData[4] = image[x+1][y+1];
            sort_int(4,tmpData);

            a = tmpData[1];
            b = tmpData[2];
            c = tmpData[3];
            d = tmpData[4];

            if (c < d) {
                q1start[c]++;
                q1end[d]++;
            }

            if (a < b) {
                q3start[a]++;
                q3end[b]++;
            }

            /* diagonal check */
            if  ( (b < c) && (c <= d) &&
                  ( ((c <= p1 && p1 <= d) && (c <= p4 && p4 <= d)) ||
                    ((c <= p2 && p2 <= d) && (c <= p3 && p3 <= d))))

            {
                qDstart[b]++;
                qDend[c]++;
            }
        }
    }

    q1[0] = q1start[0];
    q3[0] = q3start[0];
    qD[0] = qDstart[0];
    values[0] = (q1[0] - q3[0] - 2*qD[0]) / 4;
    for (t = 1; t < 256; t++) {
        q1[t] = q1[t-1] + q1start[t] - q1end[t];
        q3[t] = q3[t-1] + q3start[t] - q3end[t];
        qD[t] = qD[t-1] + qDstart[t] - qDend[t];
        values[t] = (q1[t] - q3[t] - 2*qD[t]) / 4;
    }
}

/* from numerical recipes in C */
void sort_int(int n, int ra[])
{
    int l,j,ir,i;
    int rra;

    l=(n >> 1)+1;
    ir=n;
    for (;;) {
        if (l > 1)
            rra=ra[--l];
        else {
            rra=ra[ir];
            ra[ir]=ra[1];
            if (--ir == 1) {
                ra[1]=rra;
                return;
            }
        }
        i=l;
        j=l << 1;
        while (j <= ir) {
            if (j < ir && ra[j] < ra[j+1]) ++j;
            if (rra < ra[j]) {
                ra[i]=ra[j];
                j += (i=j);
            }
            else j=ir+1;
        }
        ra[i]=rra;
    }
}

void options(char *progname)
{
    printf("usage: %s [options]\n",progname);
    printf("     -i file   difference image\n");
    printf("     -o file   output image\n");
    printf("     -e        test Euler connectivity - corner\n");
    printf("     -p        test Poisson randomness \n");
    exit(-1);
}
