/* read/write an image
 *
 * modified to use fopen with "rb" and "wb" instead of just "r"/"w"
 * hopefully this will make it more portable w.r.t. PC platforms
 *
 * check for correct code (P6) in input image
 *
 * copes with MATLAB style headers
 *
 * indexing swapped so that the band is indexed first
 *
 * Paul Rosin
 * October 2014
 * Cardiff University
 */

#include <string.h>

void read_ppm(unsigned char image[3][MAX_SIZE][MAX_SIZE],char filename[],int *width,int *height, int *depth)
{
    FILE *fp_in;
    int i,x,y;
    char c,str[1000];
    char image_type[1000];

    if ((fp_in=fopen(filename,"rb")) == NULL) {
        fprintf(stderr,"cant open %s\n",filename);
        exit(-2);
    }

    /* skip image type and comments in header */
    fgets(str,255,fp_in);
    i = sscanf(str,"%s %d %d %d",image_type,width,height,depth);
    if (i == 4) {
        /*
        printf("MATLAB style header\n");
        printf("width x height = %d x %d\n",*width,*height);
        */
        if (strcmp(image_type,"P6") != 0) {
            fprintf(stderr,"ERROR: image is not correct PPM format\n");
            exit(-1);
        }
    }
    else {
        //printf("regular style header\n");
        sscanf(str,"%s",image_type);
        if (strcmp(image_type,"P6") != 0) {
            fprintf(stderr,"ERROR: image is not correct PPM format\n");
            exit(-1);
        }
        do
            fgets(str,255,fp_in);
        while (str[0] == '#');

        /* read image parameters */
        /* the first line has already been read */
        i = sscanf(str,"%d %d",width,height);
        // cope with blank lines in header after comment
        while (i != 2) {
            fgets(str,255,fp_in);
            i = sscanf(str,"%d %d",width,height);
        }
        fscanf(fp_in,"%d",depth);
        /* skip CR */
        getc(fp_in);
    }

    if ((*width > MAX_SIZE) || (*height > MAX_SIZE)) {
        fprintf(stderr,"ERROR: Maximum image size is %d x %d\n",
            MAX_SIZE,MAX_SIZE);
        exit(-1);
    }

    if (*depth != 255) {
        fprintf(stderr,"ERROR: depth = %d; (instead of 255)\n",*depth);
        exit(-1);
    }

    for (y = 0; y < *height; y++)
        for (x = 0; x < *width; x++)
            for (i = 0; i < 3; i++)
               image[i][x][y] = getc(fp_in);

    fclose(fp_in);
}

void write_ppm(unsigned char image[3][MAX_SIZE][MAX_SIZE],char filename[],int width,int height)
{
    FILE *fp_out;
    int i,x,y;

    if ((fp_out = fopen(filename,"wb")) == NULL) {
        fprintf(stderr,"cant open %s\n",filename);
        exit(-1);
    }
    fprintf(fp_out,"P6\n");
    fprintf(fp_out,"#created by Paul Rosin\n");
    fprintf(fp_out,"%d %d\n",width,height);
    fprintf(fp_out,"255\n");

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            for (i = 0; i < 3; i++)
                putc(image[i][x][y],fp_out);
    fclose(fp_out);
}
