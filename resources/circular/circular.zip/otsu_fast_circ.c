/* fast CIRCULAR thresholding of an image into 2 classes using Otsu's criterion
 * (linear rather than circular variance is used)
 *
 * limit search: class size = 128
 * incrementally update variances
 *
 * for details see:
 *    Yukun Lai and Paul Rosin,
 *    Efficient Circular Thresholding,
 *    IEEE Trans. on Image Processing
 *    vol. 23, no. 3, pp. 992-1001, 2014.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define SQR(a)    ((a)*(a))

#define MAX_SIZE 5000

#include "pgmio.h"

unsigned char image[MAX_SIZE][MAX_SIZE];
int height,width,depth;

main(argc,argv)
int argc;
char **argv;
{
    int x,y,i,t,tt;
    int thr;
    // NOTE: sigma_1,sigma_2 are actually WEIGHTED variances
    double sigma_W,sigma_1,sigma_2;
    double mean_1,mean_2,omega_1,omega_2;
    double min_sigma_W;
    double count,hist[256];
    double sum_1,sum_sqr_1;
    double sum_2,sum_sqr_2;

    if (argc != 3) {
        printf("usage: %s input_image output_image\n",argv[0]);
        exit(-1);
    }

    read_pgm(image,argv[1],&width,&height,&depth);

    /* calculate histogram */
    for (t = 0; t < 256; t++)
        hist[t] = 0;

    for (y = 0; y < height; y++) {
        for (x = 0; x < width; x++) {
            t = image[x][y];
            hist[t]++;
        }
    }
    count = width*height;

    /* normalise so that histogram sums to 1 */
    for (t = 0; t < 256; t++)
        hist[t] /= count;

    thr = -1;
    min_sigma_W = 9e20;
    sum_sqr_1 = sum_1 = 0;
    sum_sqr_2 = sum_2 = 0;
    // consider all shifts of histogram
    for (t = 0; t < 128; t++) {
        if (t == 0) {
            sigma_1 = omega_1 = mean_1 = 0;
            for (i = 0; i <= 127; i++) {
                omega_1 += hist[i];
                mean_1 += i * hist[i];
                sum_sqr_1 += SQR(i) * hist[i];
                sum_1 += i * hist[i];
            }
            mean_1 /= omega_1;
            for (i = 0; i <= 127; i++)
                sigma_1 += hist[i] * SQR(i - mean_1);

            sigma_2 = omega_2 = mean_2 = 0;
            for (i = 128; i <= 255; i++) {
                omega_2 += hist[i];
                mean_2 += i * hist[i];
                sum_sqr_2 += SQR(i) * hist[i];
                sum_2 += i * hist[i];
            }
            mean_2 /= omega_2;
            for (i = 128; i <= 255; i++)
                sigma_2 += hist[i] * SQR(i - mean_2);

        }
        // incrementally update
        else {
            // remove lower histogram bin from class 1
            tt = t - 1;
            omega_1 -= hist[tt];
            sum_sqr_1 -= SQR(tt) * hist[tt];
            sum_1 -= tt * hist[tt];

            // add middle histogram bin to class 1
            tt = t + 127;
            omega_1 += hist[tt];
            sum_sqr_1 += SQR(tt) * hist[tt];
            sum_1 += tt * hist[tt];

            mean_1 = sum_1 / omega_1;

            // actually use WEIGHTED variances
            sigma_1 = sum_sqr_1 - SQR(sum_1)/omega_1;

            // ---------------------------------------

            // remove middle histogram bin from class 2
            tt = t + 127;
            omega_2 -= hist[tt];
            sum_sqr_2 -= SQR(tt) * hist[tt];
            sum_2 -= tt * hist[tt];

            // add lower histogram bin to class 2 - but shifted up
            tt = t + 255;
            omega_2 += hist[t-1];
            sum_sqr_2 += SQR(tt) * hist[t-1];
            sum_2 += tt * hist[t-1];

            mean_2 = sum_2 / omega_2;

            // actually use WEIGHTED variances
            sigma_2 = sum_sqr_2 - SQR(sum_2)/omega_2;
        }

        /* skip if the image is uniform at this threshold */
        if (omega_1 == 0) continue;
        if (omega_2 == 0) continue;

        /* within class variance */
        sigma_W = sigma_1 + sigma_2;

        if (sigma_W < min_sigma_W) {
            min_sigma_W = sigma_W;
            thr = t;
        }
    }

    /* actually threshold image now */
    printf("thresholding at %d\n",thr);
    printf("sigma_W %f\n",min_sigma_W);

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            if ((((unsigned int)image[x][y] - thr + 256)%256) <= 127)
                image[x][y] = 0;
            else
                image[x][y] = 255;

    write_pgm(image,argv[2],width,height);
}
