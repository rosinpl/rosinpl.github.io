/*
 * multilevel version of Otsu's image thresholding
 * very efficient version - see Luessi paper
 *
 * modified by Paul Rosin into stand-alone program
 * May 2007
 *
 * modified by Yukun Lai to provide circular thresholding (with linear statistics)
 * October 2013
 *
 * for details see:
 *    Yukun Lai and Paul Rosin,
 *    Efficient Circular Thresholding,
 *    IEEE Trans. on Image Processing
 *    vol. 23, no. 3, pp. 992-1001, 2014.
 */

/*
Copyright notice:

Copyright (c) 2008 Martin Luessi, Marco Eichmann.  All rights reserved.

Developed by: Martin Luessi, Marco Eichmann
              Northwestern University (USA) / Hochschule fuer Technik Rapperswil (Switzerland)
              http://ivpl.eecs.northwestern.edu

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal with the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimers.
  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimers in the
     documentation and/or other materials provided with the distribution.
  3. Neither the names of Martin Luessi, Marco Eichmann, Northwestern University, 
     Hochschule fuer Technik Rapperswil, nor the names of its contributors may 
     be used to endorse or promote products derived from this Software without 
     specific prior written permission.
  4. When the Software is used for research purposes, the publications listed
     in the file readme.txt accompaning this file should be referenced.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
WITH THE SOFTWARE.
*/

/*****************************************************************************************************/
/*  Project:      Diploma Thesis 2005                                                                */
/*  Title:        Efficient Multilevel Image Thresholding                                            */
/*  Autors:       Marco Eichmann     eichmann@gmail.com                                              */
/*                Martin Luessi      mluessi@gmail.com                                               */
/*                                                                                                   */
/*  Describtion:  This algorithm employs dynamic programming and the SMAWK algorithm by A. Aggarwal  */
/*                et al, to find the obtimal thresholds for the criterion proposed by N. Otsu.       */
/*****************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>

#define DTYPE double

struct ROWELEMENT {
    unsigned int col;                 
    struct ROWELEMENT* p_lastnext;     
};

DTYPE otsuSmawkDP(int M, int L, DTYPE* p, int* thresholds);
void msearch(unsigned int m, unsigned int p, unsigned int rowM, unsigned int rowO, 
             struct ROWELEMENT* myMatrix, struct ROWELEMENT* lastMatrix);
struct ROWELEMENT* reduce(unsigned int m, unsigned int p, unsigned int rowM, unsigned int rowO, struct ROWELEMENT* myMatrix);
void mfill(unsigned int m, unsigned int rowM, unsigned int rowO, struct ROWELEMENT* reducedMatrix);

struct NODE {
    DTYPE O;                 /* old amount of obj. function up to prev. class */
    struct NODE* p_back;     /* back pointer */
};

struct NODE** trellis;      /* trellis structure MxL */
DTYPE* N;                   /* numerator of objective function length: L */
DTYPE* D;                   /* denominator of objective function length: L */
unsigned int * maxcols;     /* needed by the smawkalgorithm to store the maxima positions */
unsigned int c;             /* current class */
DTYPE Ntemp,Dtemp,Otemp; 

#define MAX_SIZE 5000
#include "pgmio.h"
unsigned char image[MAX_SIZE][MAX_SIZE];
unsigned char image2[MAX_SIZE][MAX_SIZE];
int height,width,depth;

/* segment the normalized histogram p into M classes using the simplified otsu          */
/* threshold criterium proposed in "A Fast Algorithm for Multilevel Thresholding 2001"  */
/* L is the number of gray levels (= num of elements in p)                              */
/* this is the implementation which uses the smawk algorithm, complexity O(ML)          */
                                                               
double otsuSmawkDP(int M, int L, DTYPE* p, int* thresholds)
{
    unsigned int i,j;
    unsigned int Q = L - M + 1;          /* nodes per class */
    struct NODE* searchNODE;             /* used for the backtracking */
    DTYPE Omax = 0;
    unsigned int   Omaxpos = 0;
    unsigned int thisSize;
    unsigned int colmemSize;
    struct ROWELEMENT* colMem;           /* memory for the smawk algorithm */
    DTYPE within = 0.0;

    /* calculate the size of the memory needed by the smawk algorithm */
    thisSize = Q;
    colmemSize = Q + 1;   
    while (thisSize>=2){
        colmemSize+= thisSize + 1;
        thisSize = thisSize / 2;
    }
    /* allocate the memory for the smawk algorithm */
    if ((colMem = malloc(colmemSize*sizeof(struct ROWELEMENT))) == NULL){
        printf("malloc for colMem failed\n");
    }

    if ((maxcols = malloc(Q*sizeof(unsigned int))) == NULL){
        printf("malloc for maxcols failed\n");
    }

    /* allocate memory for the trellis structure */
    if ((trellis = malloc(M*sizeof(struct NODE*))) == NULL){
        printf("malloc for trellis M-dim falied\n");
    }
    for (i=0;i<M;i++){
        if ((trellis[i] = malloc(L*sizeof(struct NODE))) == NULL){
            printf("malloc for trellis L-dim failed\n");
        }
        memset(trellis[i], 0, L*sizeof(struct NODE));
    }

    /* allocate memory for the N and D array */
    if ((N = malloc(L*sizeof(DTYPE))) == NULL){
        printf("malloc for N array failed\n");
    }
    if ((D = malloc(L*sizeof(DTYPE))) == NULL){
        printf("malloc for D array failed\n");
    }

    /* initialize N and D array*/
    N[0] = 0;
    D[0] = p[0];
    for (i=1; i<L; i++){
        N[i] = N[i-1] + i*p[i];
        D[i] = D[i-1] + p[i];
    }
    /* initialize the trellis structure for the lowest level (class = 0) */
    if (D[0]==0)            /* to avoid division by zero */
        trellis[0][0].O = 0;
    else
        trellis[0][0].O = N[0]*N[0]/D[0];
    for (i=1; i<Q; i++){
        if (D[i]==0)
            trellis[0][i].O = trellis[0][i-1].O;
        else
            trellis[0][i].O = N[i]*N[i]/D[i];
    }

    /* begin shortest (here longest) path algorithm */
    for (c=1;c<(M-1);c++){
        msearch(Q, Q, 1, 0, colMem, NULL);
    }   

    c=M-1; i=L-1; Omax = 0;       
    for (j=M-2;j<(L-1);j++){
        Ntemp = N[i]-N[j];
        Dtemp = D[i]-D[j];
        if (Dtemp == 0)
            Otemp = trellis[c-1][j].O;
        else
            Otemp = trellis[c-1][j].O + Ntemp*Ntemp/Dtemp;
        if (Otemp > Omax){
            Omax = Otemp;
            Omaxpos = j;
        }
    }

    // printf("Omax = %g\n", Omax);
    trellis[c][i].O = Omax;
    trellis[c][i].p_back = &trellis[c-1][Omaxpos];

    /* backtrack */
    searchNODE = &(trellis[M-1][L-1]);
    for (c=M-1;c>0;c--){
        searchNODE = searchNODE->p_back;
        thresholds[c-1] = (searchNODE - trellis[c-1]);
    }

    free(colMem);
    free(maxcols);
    for (i=0;i<M;i++){
        free(trellis[i]);
    }   
    free(trellis);
    free(N);
    free(D);

    // calculate within class totals
    for (i = M-1; i > 0; i--)
        thresholds[i] = thresholds[i-1];
    thresholds[0] = -1;
    thresholds[M] = L-1;
    // for (i = thresholds[4]; i < thresholds[5]; i++)
    //    printf("%g\n", p[i]);
    {
        DTYPE* pMeans = (DTYPE*)malloc(sizeof(DTYPE) * M);
        DTYPE* pSums = (DTYPE*)malloc(sizeof(DTYPE) * M);
        memset(pMeans, 0, sizeof(DTYPE) * M);
        memset(pSums, 0, sizeof(DTYPE) * M);
        for (i = 0; i < M; i++)
        {
            for (j = thresholds[i]+1; j <= thresholds[i+1]; j++)
            {
                pSums[i] += p[j];
                pMeans[i] += p[j] * j;
            }
            pMeans[i] /= pSums[i];
            // printf("%g\n", pMeans[i]);
        }
        for (i = 0; i < M; i++)
        {
            DTYPE cls = 0.0;
            for (j = thresholds[i]+1; j <= thresholds[i+1]; j++)
            {
                DTYPE tmp = j - pMeans[i];
                cls += tmp * tmp * p[j];
            }
            // printf("%g\n", cls);
            within += cls;
        }
        // printf("Within = %g\n", within);

        free(pMeans);
        free(pSums);
    }


    return within;
}

/* mfill: Find positions of the maxima in the odd rows (0,2,4..), positions in      */
/*        the even rows (1,3,5..) are already known, due to the recursive msearch   */
/*        call. The functions finds the maximas starting from the bottom right      */                                                  
/*        corner of the matrix, like this the pointers don't have to be reversed    */
/*        after the reduce step                                                     */
/* m: numbers of rows (matrix is always m*m)                                        */                       
/* rowM: row multiplier, must be 1 for the first call                               */
/* rowO: row offset, must be 0 for the first call                                   */
/* reducedMatrix: pointer to the rightmost column element of the current matrix     */
/* needs globals: c, trellis, maxcols, N, D, Ntemp, Dtemp                           */ 
void mfill(unsigned int m, unsigned int rowM, unsigned int rowO, struct ROWELEMENT* reducedMatrix)
{
    struct ROWELEMENT* pCol;
    unsigned int evenMaxPos;
    unsigned int maxCol;
    unsigned int row;
    DTYPE max;
    DTYPE temp;    
     
    if ((m % 2) == 0){
        /* even number of rows, the last row of the matrix is even, we know the position of this maxima */        
        row = rowO + (m-2)*rowM; 
        evenMaxPos = maxcols[row+rowM];
        pCol = reducedMatrix;
        while (pCol->col > evenMaxPos){
            pCol = pCol->p_lastnext;
        }
    }
    else{
        /* odd number off rows, the last row of the matrix is odd */
        row = rowO + (m-1)*rowM;
        pCol = reducedMatrix;
    }

    /* pCol points now to the column where the first maximum in an odd row could be */
    /* do this for all odd rows, except for the first one                           */
    while (row > rowO){
        evenMaxPos = maxcols[row-rowM];
        max = 0;
        while (pCol->col > evenMaxPos){
            if (pCol->col > row){
                temp = 0;
            }
            else{
                Dtemp = D[c+row]-D[c-1+pCol->col];
                if (Dtemp == 0){
                    temp = trellis[c-1][c-1 +pCol->col].O;
                }
                else{
                    Ntemp = N[c+row]-N[c-1+pCol->col];
                    temp = trellis[c-1][c-1+pCol->col].O + Ntemp*Ntemp/Dtemp;
                }
            }
            if (temp >= max){
                max    = temp;
                maxCol = pCol->col;
            }
            pCol = pCol->p_lastnext;
        }
        if (pCol->col > row){
            temp = 0;
        }
        else{
            Dtemp = D[c+row]-D[c-1+pCol->col];
            if (Dtemp == 0){
                temp = trellis[c-1][c-1+pCol->col].O;
            }
            else{
                Ntemp = N[c+row]-N[c-1+pCol->col];
                temp = trellis[c-1][c-1+pCol->col].O + Ntemp*Ntemp/Dtemp;
            }
        }
        if (temp >= max){
            maxcols[row] = pCol->col;
            trellis[c][c+row].O      = temp;
            trellis[c][c+row].p_back = &trellis[c-1][c-1+pCol->col];   
        }
        else{
            maxcols[row] = maxCol;
            trellis[c][c+row].O      = max;
            trellis[c][c+row].p_back = &trellis[c-1][c-1+maxCol];
        }
        row = row - 2 * rowM;      
    }
    /* for the first row */
    max = 0;
    while (pCol->p_lastnext != NULL){
        if (pCol->col > row){
            temp = 0;
        }
        else{
            Dtemp = D[c+row]-D[c-1+pCol->col];
            if (Dtemp == 0){
                temp = trellis[c-1][c-1+pCol->col].O;
            }
            else{
                Ntemp = N[c+row]-N[c-1+pCol->col];
                temp = trellis[c-1][c-1+pCol->col].O + Ntemp*Ntemp/Dtemp;
            }
        }
        if (temp >= max){
            max    = temp;
            maxCol = pCol->col;
        }
        pCol = pCol->p_lastnext;      
    }
    if (pCol->col > row){
        temp = 0;
    }
    else{
        Dtemp = D[c+row]-D[c-1+pCol->col];
        if (Dtemp == 0){
            temp = trellis[c-1][c-1+pCol->col].O;
        }
        else{
            Ntemp = N[c+row]-N[c-1+pCol->col];
            temp = trellis[c-1][c-1+pCol->col].O + Ntemp*Ntemp/Dtemp;
        }
    }
    if (temp >= max){
        maxcols[row] = pCol->col;
        trellis[c][c+row].O      = temp;
        trellis[c][c+row].p_back = &trellis[c-1][c-1+pCol->col];   
    }
    else{
        maxcols[row] = maxCol;
        trellis[c][c+row].O      = max;
        trellis[c][c+row].p_back = &trellis[c-1][c-1+maxCol];
    }
return;
}


/* reduce: reduce step of the smawk algorithm: delete columns so that  m*p matrix   */
/*         becomes m*m                                                              */
/* m: numbers of rows                                                               */
/* p: number of columns                                                             */
/* rowM: row multiplier, must be 1 for the first call                               */
/* rowO: row offset, must be 0 for the first call                                   */
/* myMatrix: pointer to the first element of the array of column elements           */
/* needs globals: c, trellis, N, D, Ntemp, Dtemp                                    */ 
/* returns: pointer to the rightmost column element of the reduced matrix           */
struct ROWELEMENT* reduce(unsigned int m, unsigned int p, unsigned int rowM, unsigned int rowO, struct ROWELEMENT* myMatrix)
{
    unsigned int j = 1;
    unsigned int k = 0;
    unsigned int x;
    unsigned int y;
    unsigned int ncols = p;
    DTYPE val1;
    DTYPE val2; 

    /* go trough matrix columns from left to right, delete columns until matrix is square */
    while (ncols > m){
        x = rowO+k*rowM;
        y = (myMatrix[j].p_lastnext)->col;
        if (y > x){
            val1 = 0;
        }
        else{
            Dtemp = D[c+x]-D[c-1+y];
            if (Dtemp == 0){
                val1 = trellis[c-1][c-1+y].O;
            }
            else{
                Ntemp = N[c+x]-N[c-1+y];
                val1 = trellis[c-1][c-1+y].O + Ntemp*Ntemp/Dtemp;
            }
        }
        y = myMatrix[j].col;
        if (y > x){
            val2 = 0;
        }
        else{
            Dtemp = D[c+x]-D[c-1+y];
            if (Dtemp == 0){
                val2 = trellis[c-1][c-1+y].O;
            }
            else{
                Ntemp = N[c+x]-N[c-1+y];
                val2 = trellis[c-1][c-1+y].O + Ntemp*Ntemp/Dtemp;
            }
        }

        if (val1 >= val2){
            if (k < (m-1)){
                k++;
            }
            else{
                /* delete column j */
                myMatrix[j+1].p_lastnext = myMatrix[j].p_lastnext;
                ncols--;
            }
            j++;
        }
        else{
            /* delete column j - 1 */
            myMatrix[j].p_lastnext = (myMatrix[j].p_lastnext)->p_lastnext;
            ncols--;
            if (k!=0)
                k--;
            else
                j++;
        }       
    }
    /* the rightmost element (dummy) in the column array points to the rightmost              */
    /* column element of our matrix, return this pointer.                                     */  
    return myMatrix[p].p_lastnext;
}

/* msearch: perform smawk matrix search of totally monotone m*p matrix (p>=m)       */ 
/* m: numbers of rows                                                               */
/* p: number of columns                                                             */
/* rowM: row multiplier, must be 1 for the first call                               */
/* rowO: row offset, must be 0 for the first call                                   */
/* myMatrix: pointer to the first element of the array of column elements, where    */
/*           this step can store the information.                                   */
/* lastMatrix: pointer to the rightmost column element of the previous call, msut   */
/*             be NULL for the first call                                           */
/* needs globals: c, trellis, maxcols, N, D, Ntemp, Dtemp                           */ 
void msearch(unsigned int m, unsigned int p, unsigned int rowM, unsigned int rowO, 
             struct ROWELEMENT* myMatrix, struct ROWELEMENT* lastMatrix)
{
    struct ROWELEMENT* temp;
    struct ROWELEMENT* reducedMatrix;
    unsigned int i;

    /* if lastMatrix is NULL, we are not in a recursion, the col-indices are initialized with global values */
    /* there is one column element more than the matrix has rows, this is needed for reduce                 */
    if (lastMatrix==NULL){
        myMatrix[0].col = 0;
        myMatrix[0].p_lastnext = NULL;
        for (i=1;i<p+1;i++){
            myMatrix[i].col = i;
            myMatrix[i].p_lastnext = &myMatrix[i-1];
        }
    }
    /* otherwise we have to initialize our matrix with the values of the last matrix */
    /* lastMatrix points to the rightmost column element of the previous matrix      */
    /* this means we fill our matrix from right to left                              */
    else{
        /* rightmost element, dummy for reduce */
        myMatrix[p].col = 0;
        myMatrix[p].p_lastnext = &myMatrix[p-1];
        temp = lastMatrix;
        i = p-1;
        do{
            /* traversing backward, matrix has always more than one column */                 
            myMatrix[i].col = temp->col;
            myMatrix[i].p_lastnext = &myMatrix[i-1]; 
            temp = temp->p_lastnext;
            i--;
        } while(temp->p_lastnext != NULL);
        myMatrix[0].col = temp->col;
        myMatrix[0].p_lastnext = NULL;
    }
    /* reduce the matrix to a m*m matrix */
    reducedMatrix = reduce(m, p, rowM, rowO, myMatrix);
    /* check if the reduced matrix has size 1x1, if yes we are at the lowest point of the recursion */
    /* fill in the column number & the value in the result array, then return                       */
    if (reducedMatrix->p_lastnext == NULL){
        maxcols[rowO] = reducedMatrix->col;
        trellis[c][c+rowO].p_back = &trellis[c-1][c-1+reducedMatrix->col];
        Dtemp = D[c+rowO]-D[c-1+reducedMatrix->col];        
        if (Dtemp == 0)
            trellis[c][c+rowO].O = trellis[c-1][c-1+reducedMatrix->col].O;
        else{
            Ntemp = N[c+rowO]-N[c-1+reducedMatrix->col];
            trellis[c][c+rowO].O = trellis[c-1][c-1+reducedMatrix->col].O + Ntemp*Ntemp/Dtemp;
        }
        /* this recursion is finished, return */
        return;
    }
    /* call msearch recursively, reduced matrix is m * m, we pass only even rows */
    msearch(m/2,m,2*rowM,rowM+rowO,myMatrix + p + 1, reducedMatrix);
    /* call mfill to fill in the values of the odd rows */
    mfill(m,rowM,rowO,reducedMatrix);
    return;
}

main(argc,argv)
int argc;
char **argv;
{
    int M, L;
    int i,x,y;
    DTYPE * parr;
    int * thresh;
    int * best_thresh;
    DTYPE best_within = 1e+10;
    int k;
    int z;
    L = 256;

    if (argc != 4) {
        printf("usage: %s input_file output_file number-of-thresholds (i.e. classes)\n", argv[0]);
        exit(-1);
    }

    M = atof(argv[3]);
    // M++; // M is actually the number of classes, which is one more than # thresholds --- NOT FOR CIRCULAR!

    /* allocate memory for histogram & thresholds */
    if ((parr = malloc(L*sizeof(DTYPE) * 2)) == NULL){
        printf("malloc failed\n");
    }  
    if ((thresh = malloc((M+1)*sizeof(int))) == NULL){
        printf("malloc failed\n");
    }  
    if ((best_thresh = malloc((M+1)*sizeof(int))) == NULL){
        printf("malloc failed\n");
    }  

    read_pgm(image, argv[1], &width, &height, &depth);
  
    for (i = 0; i < L; i++)
        parr[i] = 0;
    for (y = 0; y < height; y++) {
        for (x = 0; x < width; x++) {
            parr[image[x][y]]++;
        }
    }
    for (i = 0; i < L; i++)
        parr[i] /= (width*height);
  
    memcpy(parr + L, parr, sizeof(DTYPE) * L);

    {
        for (k = 0; k < L; k++)
        {
            DTYPE ww = otsuSmawkDP(M, L, parr + k, thresh);
            if (ww < best_within)
            {
                best_within = ww;
                for (i = 0; i <= M; i++)
                {
                    best_thresh[i] = (thresh[i] + k) % L;
                }
            }
        }
    }

    printf("Best error = %g\n", best_within);
    for (i = 0; i < M; i++) {
        printf("THRESHOLD %d\n",best_thresh[i]);
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                if (
                    ((image[x][y] > best_thresh[i]) && (image[x][y] <= best_thresh[i+1])) // not crossing the end
                || ((best_thresh[i] > best_thresh[i+1]) && (image[x][y] > best_thresh[i] || image[x][y] <= best_thresh[i+1]))  // crossing the end 
                    )
                    image2[x][y] = ((i+1)%M) * (double)(L-1)/(M-1);
    }
    write_pgm(image2,argv[2],width,height);

    // freeing
    free(parr);
    free(thresh);
    free(best_thresh);
}
