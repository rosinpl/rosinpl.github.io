#define MAX_SIZE 7000
