/*
 *  blob labelling - extracted from label.c
 *  modified to produce an integer output so that >255 labels are allowed
 *  removed optional addition of constant
 *
 *  add temporary border to avoid problems with blobs touching border
 *
 *  Paul Rosin
 *  January 2017
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX(a,b)        (((a) > (b)) ? (a) : (b) )
#define MIN(a,b)        (((a) < (b)) ? (a) : (b) )

extern int width,height;

#include "imagesize.h"

#define MAX_LABELS 1000000

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define CONNECTIVITY 8
#if CONNECTIVITY == 8
int x_o[CONNECTIVITY] = {-1, 0, 1,  -1,1,  -1,0,1};
int y_o[CONNECTIVITY] = {-1,-1,-1,   0,0,   1,1,1};
#else
int x_o[CONNECTIVITY] = { 0,1,0,-1};
int y_o[CONNECTIVITY] = {-1,0,1, 0};
#endif

extern int width,height;

void remap(int image1[MAX_SIZE][MAX_SIZE], int image2[MAX_SIZE][MAX_SIZE]);
int relabel(unsigned char char_image[MAX_SIZE][MAX_SIZE], int label_image[MAX_SIZE][MAX_SIZE], int *p_no_labels,int *p_no_relabels);
void new_relabelling(int label_image[MAX_SIZE][MAX_SIZE], int new_mapping[MAX_LABELS]);
int get_min_label(int i,int mapping[MAX_LABELS]);

void do_labelling(unsigned char image_in[MAX_SIZE][MAX_SIZE], int image_out[MAX_SIZE][MAX_SIZE])
{
    int no_labels,no_relabels;
    int colour[MAX_LABELS];
    static int label_image[MAX_SIZE][MAX_SIZE];
    static unsigned char image_in2[MAX_SIZE][MAX_SIZE];
    int x,y;
    int i;
    int pix1,pix2,pix3,pix4;
    int lab1,lab2,lab3,lab4;
    int count;

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            image_in2[x+1][y+1] = image_in[x][y];
    // add white border
    for (x = 0; x < width+2; x++)
        image_in2[x][0] = image_in2[x][height+1] = 255;
    for (y = 0; y < height+2; y++)
        image_in2[0][y] = image_in2[width+1][y] = 255;
    width += 2;
    height += 2;

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            label_image[x][y] = -1;

    /* ######## create initial set of labels ######## */

    label_image[0][0] = 0;
    no_labels = 1;
    /* do top row */
    y = 0;
    for (x = 1; x < width; x++) {
        pix1 = image_in2[x][y];
        pix4 = image_in2[x-1][y];
        lab4 = label_image[x-1][y];
        if (pix1 == pix4) {
            label_image[x][y] = lab4;
        }
        else {
            label_image[x][y] = no_labels;
            no_labels++;
        }
    }
    /* do left column */
    x = 0;
    for (y = 1; y < height; y++) {
        pix1 = image_in2[x][y];
        pix3 = image_in2[x][y-1];
        lab3 = label_image[x][y-1];
        if (pix1 == pix3) {
            label_image[x][y] = lab3;
        }
        else {
            label_image[x][y] = no_labels;
            no_labels++;
        }
    }

    for (y = 1; y < height; y++) {
        for (x = 1; x < width; x++) {
            pix1 = image_in2[x][y];
#if CONNECTIVITY == 8
            pix2 = image_in2[x-1][y-1];
            lab2 = label_image[x-1][y-1];
            if (pix1 == pix2) {
                label_image[x][y] = lab2;
            }
#endif
            pix3 = image_in2[x][y-1];
            lab3 = label_image[x][y-1];
            pix4 = image_in2[x-1][y];
            lab4 = label_image[x-1][y];
            if (pix1 == pix3) {
                label_image[x][y] = lab3;
            }
            else if (pix1 == pix4) {
                label_image[x][y] = lab4;
            }
            else {
                label_image[x][y] = no_labels;
                no_labels++;
            }
        }
    }
    //printf("number of labels after first pass = %6d\n",no_labels);
    if (no_labels >= MAX_LABELS) {
        fprintf(stderr,"ERROR: too many labels (max = %d)\n",MAX_LABELS);
        exit(-1);
    }

    /* ############## relabelling ############## */

    count = 0;
    do {
        relabel(image_in2,label_image,&no_labels,&no_relabels);
        count++;
        //printf("ITERATION: %d;   %6d labels\n",count,no_labels);
    } while (no_relabels > 0);

    /* ==================================================================== */

    /* find out if blob is white or black */
    for (y=0;y<height;y++)
        for (x=0;x<width;x++)
            colour[ label_image[x][y] ] = image_in2[x][y] ;

    count = 0;
    for (i = 1; i < no_labels; i++)
        if (colour[i] != 0) {
            //printf("relabelling label %d (a hole?) as 0\n",i);
            count++;
            for (y=0;y<height;y++)
                for (x=0;x<width;x++)
                    if (label_image[x][y] == i)
                        label_image[x][y] = 0;
        }

    no_labels -= count;
    //printf("final number of labels (including background) = %6d\n",no_labels);

    remap(label_image,image_out);

    // remove border
    width -= 2;
    height -= 2;
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++) 
            image_out[x][y] = image_out[x+1][y+1];
}

/*
 * remap image to 0 (background), 1, 2, 3, ...
 */
void remap(int image1[MAX_SIZE][MAX_SIZE], int image2[MAX_SIZE][MAX_SIZE])
{
    int i;
    int temp,n;
    int hist[256*256][2];
    int count;
    int x,y;

    for (i = 0; i < 256*256; i++)
        hist[i][0] = hist[i][1] = 0;

    for (x = 0; x < width; x++)
        for (y = 0; y < height; y++)
            hist[image1[x][y]][0]++;

    count = 0;
    for (i = 0; i < 256*256; i++) {
        if (hist[i][0] > 0) {
            hist[i][1] = count;
            count++;
        }
    }

    //printf("NO LABELS %d\n",count);

    for (x = 0; x < width; x++)
        for (y = 0; y < height; y++)
            image2[x][y] = hist[image1[x][y]][1];
}

/* checks labels for equivalence classes and relabels to lowest class
 * returns number of relabellings
 */
int relabel(unsigned char char_image[MAX_SIZE][MAX_SIZE], int label_image[MAX_SIZE][MAX_SIZE], int *p_no_labels,int *p_no_relabels)
{
    int i,x,y;
    int xn,yn;
    int pix1,pix2,pix3,pix4;
    int lab1,lab2,lab3,lab4;
    int no_new_labels;
    int no_labels,no_relabels;
    static int mapping[MAX_LABELS];
    static int new_mapping[MAX_LABELS];

    no_labels = *p_no_labels;
    no_relabels = *p_no_relabels;

    for (i = 0; i < no_labels; i++)
        mapping[i] = i;

    /* printf("getting region remappings\n"); */

    for (y = 1; y < height-1; y++) {
        for (x = 1; x < width-1; x++) {
            pix1 = char_image[x][y];
            lab1 = label_image[x][y];
            for (i = 0; i < CONNECTIVITY; i++) {
                xn = x + x_o[i];
                yn = y + y_o[i];
                pix2 = char_image[xn][yn];
                lab2 = label_image[xn][yn];
                if ((pix1 == pix2) && (lab1 != lab2)) {
                    mapping[MAX(lab1,lab2)] = MIN(lab1,lab2);
                }
            }
        }
    }

    /* check boundaries along top and bottom of image */
    for (y = 0; y < height; y += height-1) {
        for (x = 0; x < width; x++) {
            pix1 = char_image[x][y];
            lab1 = label_image[x][y];
            for (i = 0; i < CONNECTIVITY; i++) {
                xn = x + x_o[i];
                yn = y + y_o[i];
                if ((xn >= 0) && (xn < width) &&
                    (yn >= 0) && (yn < height))
                {
                    pix2 = char_image[xn][yn];
                    lab2 = label_image[xn][yn];
                    if ((pix1 == pix2) && (lab1 != lab2)) {
                        mapping[MAX(lab1,lab2)] = MIN(lab1,lab2);
                    }
                }
            }
        }
    }

    /* check boundaries along sides of image */
    for (x = 0; x < width; x += width-1) {
        for (y = 0; y < height; y++) {
            pix1 = char_image[x][y];
            lab1 = label_image[x][y];
            for (i = 0; i < CONNECTIVITY; i++) {
                xn = x + x_o[i];
                yn = y + y_o[i];
                if ((xn >= 0) && (xn < width) &&
                    (yn >= 0) && (yn < height))
                {
                    pix2 = char_image[xn][yn];
                    lab2 = label_image[xn][yn];
                    if ((pix1 == pix2) && (lab1 != lab2)) {
                        mapping[MAX(lab1,lab2)] = MIN(lab1,lab2);
                    }
                }
            }
        }
    }

    /* printf("making mappings unique\n"); */
    for (i = 0; i < no_labels; i++)
        mapping[i] = get_min_label(i,mapping);

    /* printf("making labels sequential\n"); */
    no_new_labels = no_relabels = 0;
    for (i = 0; i < no_labels; i++)
        if (mapping[i] == i) {
            new_mapping[i] = no_new_labels;
            no_new_labels++;
        }
        else {
            new_mapping[i] = new_mapping[mapping[i]];
            no_relabels++;
        }

    if (no_relabels > 0) {
        new_relabelling(label_image,new_mapping);
        no_labels = no_new_labels;
    }

    *p_no_labels = no_labels;
    *p_no_relabels = no_relabels;
}

void new_relabelling(int label_image[MAX_SIZE][MAX_SIZE], int new_mapping[MAX_LABELS])
{
    int x,y;
    int current_label,new_label;

    for (y = 0; y < height; y++) {
        for (x = 0; x < width; x++) {
            current_label = label_image[x][y];
            new_label = new_mapping[current_label];
            label_image[x][y] = new_label;
        }
    }
}

int get_min_label(int i,int mapping[MAX_LABELS])
{
    if (mapping[i] == i)
        return(i);
    else
        return(get_min_label(mapping[i],mapping));
}
