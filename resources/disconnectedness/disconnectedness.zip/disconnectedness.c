/* calculate a measure of disconnectedness for a multi-component binary shape
 *
 * for details see:
 * Jovisa Zunic, Paul L. Rosin, Vladimir Ilic
 * Disconnectedness: A New Moment Invariant for Multi-Component Shapes
 * Pattern Recognition, vol. 78, pp. 91-102, 2018.
 *
 * input: binary image
 * output: disconnectedness measure
 *
 * performs connected component labelling and computes moments
 *
 * Paul Rosin
 * January 2017
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define ABS(x)       (((x)<0.0)? (-(x)): (x))
#define SQR(x)       ((x)*(x))
#define CUBE(x)      ((x)*(x)*(x))
#define MAX(a,b)  (((a) > (b)) ? (a) : (b))

#include "imagesize.h"

#define MAX_LABELS 1000000

#include "pgmio.h"

unsigned char image[MAX_SIZE][MAX_SIZE];
int labelled_image[MAX_SIZE][MAX_SIZE];

int height,width,depth;

double m00,m01,m10,x_bar,y_bar;
double mu00,mu02,mu20;
double phi1;

double phi1ALL[MAX_LABELS];

double m(int p,int q,int label);
double mu(int p,int q,int label);
void options(char *progname);
void do_labelling(unsigned char image_in[MAX_SIZE][MAX_SIZE], int image_out[MAX_SIZE][MAX_SIZE]);

main(argc,argv)
int argc;
char *argv[];
{
    int x,y,i;
    char *infile;
    int label,no_labels;
    double sum;
    double disconnectedness;

    infile = NULL;

    /* parse command line */
    for(i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            switch(argv[i][1]) {
                case 'i':
                    i++;
                    infile = argv[i];
                    break;
                default:
                    printf("unknown option %s\n",argv[i]);
                    options(argv[0]);
            }
        }
        else {
            printf("unknown option %s\n",argv[i]);
            options(argv[0]);
        }
    }

    if (infile == NULL)
        options(argv[0]);

    read_pgm(image,infile,&width,&height,&depth);

    do_labelling(image,labelled_image);

    no_labels = 0;
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            no_labels = MAX(no_labels,labelled_image[x][y]);
    printf("%d components\n",no_labels);
    if (no_labels >= MAX_LABELS) {
        fprintf(stderr,"ERROR: %d too many labels (components)\n",no_labels);
        exit(-1);
    }

    // for each label
    sum = 0;
    for (label = 1; label <= no_labels; label++) {
        //printf("label %3d\n",label);

        m00 = m(0,0,label);
        m01 = m(0,1,label);
        m10 = m(1,0,label);
        x_bar = m10 / m00;
        y_bar = m01 / m00;

        /* central moments */
        mu00 = mu(0,0,label);
        mu02 = mu(0,2,label);
        mu20 = mu(2,0,label);

        /* use mu for translation & orientation invariance; nu also adds scale */
        phi1 = mu20 + mu02;
        phi1 /= SQR(m00);
        //printf("phi1 %f   m00 %f\n",phi1,m00);
        phi1ALL[label] = phi1;

        sum += CUBE(m00) * phi1;
    }

    // now give all components the same label
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            if (labelled_image[x][y] > 0)
                labelled_image[x][y] = 1;

    label = 1;

    m00 = m(0,0,label);
    m01 = m(0,1,label);
    m10 = m(1,0,label);
    x_bar = m10 / m00;
    y_bar = m01 / m00;

    /* central moments */
    mu00 = mu(0,0,label);
    mu02 = mu(0,2,label);
    mu20 = mu(2,0,label);

    /* use mu for translation & orientation invariance; nu also adds scale */
    phi1 = mu20 + mu02;
    phi1 /= SQR(m00);
    //printf("GLOBAL phi1   %f   m00 %f\n",phi1,m00);
    //printf("sum/CUBE(m00) %f         \n",sum / CUBE(m00));

    disconnectedness = phi1 - sum / CUBE(m00);
    printf("disconnectedness %f\n",disconnectedness);
}

// moments
double m(int p,int q,int label)
{
    int x,y;
    double r = 0;

    for (y = 0; y < height; y++)
       for (x = 0; x < width; x++)
          if (labelled_image[x][y] == label)
             r += pow((double)x,(double)p) *
                  pow((double)y,(double)q);

    return r;
}

// central moments
double mu(int p,int q,int label)
{
    int x,y;
    double r = 0;

    for (y = 0; y < height; y++)
       for (x = 0; x < width; x++)
          if (labelled_image[x][y] == label)
              r += pow((double)(x-x_bar),(double)p) *
                   pow((double)(y-y_bar),(double)q);

    return r;
}

void options(char *progname)
{
    printf("usage: %s [options]\n",progname);
    printf("     -i file    input image\n");
    exit(-1);
}
