/*    Optimal polygonal segmentation of OPEN curves using dynamic programming
 *
 *    choice of error metrics:
 *        L1                absolute error
 *        L2                integral square error
 *        Linfinity         maximum error
 *        Length            maximise length
 *        Length_1          L1 / length - calculated locally for each line
 *        Length_2          L2 / length - calculated locally for each line
 *        Length_8          Linfy / length - calculated locally for each line
 *        LengthISEglobal   ISE / length - calculated globally over polygon
 *        AngleDiff         difference in angles
 *        Angle8            difference in angles * Linfy
 *        AngleInt          minimises interior angles
 *        Length_R          weighted summed ratio of line lengths
 *        linearityIVC      Jovisa's IVC moments based measure, actually: (1-linearity)*(curve length)
 *        linearityPR       Jovisa's endpoint to centre distance measure, actually: (1-linearity)*(curve length)
 *
 * For more details see:
 *    P.L. Rosin
 *    "Techniques for assessing polygonal approximations of curves"
 *    IEEE Transactions Pattern Analysis and Machine Intelligence
 *    vol. 19, no. 6, pp. 659-666, 1997.
 *
 *    Paul Rosin
 *    Brunel University
 *    January 1996
 *    Paul.Rosin@brunel.ac.uk
 *
 *    update March 2010
 *    Paul Rosin
 *    Cardiff University
 *    Paul.Rosin@cs.cf.ac.uk
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

/* specify error metric for minimisation */
#define L1               0
#define L2               1
#define Linfinity        2
#define Length           3
#define Length_1         4
#define Length_2         5
#define Length_8         6
#define LengthISEglobal  7
#define AngleDiff        8
#define Angle8           9
#define AngleInt         10
#define Length_R         11
#define LinearityIVC     12
#define LinearityPR      13

#define METRIC LinearityIVC

/*
#define EVALUATE
*/

#define PI 3.141591

#define MAX_PIXELS 3000
#define MAX_BREAKS 301

#define ABS(x)    (((x)<0.0)? (-(x)): (x))
#define MAX(a,b)  (((a) > (b)) ? (a) : (b))
#define MIN(a,b)  (((a) < (b)) ? (a) : (b))
#define SQR(a)    ((a)*(a))

/* pixel data */
int x[MAX_PIXELS],y[MAX_PIXELS];
int no_pixels;

double error[MAX_BREAKS][MAX_PIXELS];
double length[MAX_BREAKS][MAX_PIXELS];
int best[MAX_BREAKS][MAX_PIXELS];
double all_errors[MAX_PIXELS][MAX_PIXELS];
double all_lengths[MAX_PIXELS][MAX_PIXELS];
int no_bkpts = 4;

int pts[100];
int no_pts;

FILE *fp1,*fp2;

char *i_file;
FILE *fpi;
int print_indices = FALSE;
int chop = 0;

double d[MAX_PIXELS];

void chop_pixels(int chop,int *number_pixels);
void calc_errors();
void print_table();
void dp();
double angle(int x1, int y1, int x2, int y2, int a1, int b1, int a2, int b2);
void read_link_data(FILE *fp, int *endoffile);
void read_points();
void evaluate();
double calc_moment2(double p, double q, int start, int end);
double ncomb1(int n, int m);
void options(char *progname);

main(argc,argv)
int argc;
char *argv[];
{
    char file_type[50];
    char *infile,*outfile;
    int i,j;
    int endoffile;

    infile = outfile = NULL;

    /* parse command line */
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            switch(argv[i][1]) {
                case 'i':
                    i++;
                    infile = argv[i];
                    break;
                case 'c':
                    i++;
                    chop = atoi(argv[i]);
                    break;
                case 'p':
                    i++;
                    i_file = argv[i];
                    print_indices = TRUE;
                    break;
                case 'n':
                    i++;
                    no_bkpts = atoi(argv[i]) - 1;
                    break;
                case 'o':
                    i++;
                    outfile = argv[i];
                    break;
                default:
                    printf("unknown option %s\n",argv[i]);
                    options(argv[0]);
            }
        }
        else {
            printf("unknown option %s\n",argv[i]);
            options(argv[0]);
        }
    }

    if ((infile == NULL) || (outfile == NULL))
       options(argv[0]);

    if (no_bkpts >= MAX_BREAKS) {
        fprintf(stderr,"ERROR: %d is too many breakpoints\n",no_bkpts);
        exit(-1);
    }

    printf("segmenting with %d breakpoints\n",no_bkpts);
#if (METRIC == L1)
    printf("using L1 error norm\n");
#elif (METRIC == L2)
    printf("using L2 error norm\n");
#elif (METRIC == Linfinity)
    printf("using L-infinity error norm\n");
#elif (METRIC == Length)
    printf("using Length error norm\n");
#elif (METRIC == Length_1)
    printf("using local L1/Length error norm\n");
#elif (METRIC == Length_2)
    printf("using local L2/Length error norm\n");
#elif (METRIC == Length_8)
    printf("using local L8/Length error norm\n");
#elif (METRIC == LengthISEglobal)
    printf("using global ISE/Length error norm\n");
#elif (METRIC == AngleDiff)
    printf("using angle difference error norm\n");
#elif (METRIC == Angle8)
    printf("using angle difference * L-infinity error norm\n");
#elif (METRIC == AngleInt)
    printf("using interior angle error norm\n");
#elif (METRIC == Length_R)
    printf("using summed Length ratio error norm\n");
#elif (METRIC == LinearityIVC)
    printf("using IVC Linearity error norm\n");
#elif (METRIC == LinearityPR)
    printf("using PR Linearity error norm\n");
#else
    printf("ERROR: %d = wrong metric\n",METRIC);
    exit(-1);
#endif

    if ((fp1=fopen(infile,"r")) == NULL){
        printf("cant open %s\n",infile);
        exit(-1);
    }

    if ((fp2=fopen(outfile,"w")) == NULL){
        printf("cant open %s\n",outfile);
        exit(-1);
    }
    fprintf(fp2,"super\nlist: 0\n");

    /* read magic word for format of file */
    fscanf(fp1,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0){
        printf("not pixel data file - aborting\n");
        exit(-1);
    }

    read_link_data(fp1,&endoffile);

    /* remove some of the data */
    if (chop != 0)
        chop_pixels(chop,&no_pixels);

    if (no_bkpts >= (no_pixels-2)) {
        fprintf(stderr,"ERROR: cannot find %d breakpoints with only %d free points\n",
                no_bkpts,no_pixels-2);
        // just output the input data - PLR 9/14
        for (i = 0; i < no_pixels-1; i++)
            fprintf(fp2,"line: 0 %d %d  %d %d\n",x[i],y[i],x[i+1],y[i+1]);
        fprintf(fp2,"endl:\nendf:\n");
        fclose(fp2);
        exit(-1);
    }

    dp();

    fprintf(fp2,"endl:\nendf:\n");
    fclose(fp2);
}

void chop_pixels(int chop,int *number_pixels)
{
    int i;

    for (i = 1; i <= *number_pixels-chop; i++) {
        x[i] = x[i+chop];
        y[i] = y[i+chop];
    }
    *number_pixels -= chop;
}

#if (METRIC == L1)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = ABS(dist);
                all_errors[i][j] += dist;
            }
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            if (factor_squared == 0)
                all_errors[i][j] = 0;
            else
                all_errors[i][j] /= sqrt(factor_squared);
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == L2)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = SQR(dist);
                all_errors[i][j] += dist;
            }
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            if (factor_squared == 0)
                all_errors[i][j] = 0;
            else
                all_errors[i][j] /= factor_squared;
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == Linfinity)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist,prev_dist;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            prev_dist = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = MAX(prev_dist,ABS(dist));
                prev_dist = dist;
            }
            all_errors[i][j] = dist;
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            if (factor_squared == 0)
                all_errors[i][j] = 0;
            else
                all_errors[i][j] /= sqrt(factor_squared);
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == Length)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double dist_sqr;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            dist_sqr = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);
            all_errors[i][j] = -sqrt(dist_sqr);
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == Length_1)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = ABS(dist);
                all_errors[i][j] += dist;
            }
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            if (factor_squared == 0)
                all_errors[i][j] = 0;
            else {
                /* normalise & divide by length of straight line */
                all_errors[i][j] /= factor_squared;
            }
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == Length_2)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = SQR(dist);
                all_errors[i][j] += dist;
            }
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            if (factor_squared == 0)
                all_errors[i][j] = 0;
            else {
                all_errors[i][j] /= factor_squared;
                /* divide by length of straight line */
                all_errors[i][j] /= sqrt(factor_squared);
            }
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == Length_8)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist,prev_dist;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            prev_dist = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = MAX(prev_dist,ABS(dist));
                prev_dist = dist;
            }
            all_errors[i][j] = dist;
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            if (factor_squared == 0)
                all_errors[i][j] = 0;
            else {
                /* ERROR: all_errors[i][j] /= factor_squared; */
                /* divide by length of straight line */
                all_errors[i][j] /= sqrt(factor_squared);
            }
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == LengthISEglobal)
/* calculate all errors & lengths for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = SQR(dist);
                all_errors[i][j] += dist;
            }
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            if (factor_squared == 0) {
                all_errors[i][j] = 0;
                all_lengths[i][j] = 0;
            }
            else {
                all_errors[i][j] /= factor_squared;
                all_lengths[i][j] = sqrt(factor_squared);
            }
            all_errors[j][i] = all_errors[i][j];
            all_lengths[j][i] = all_lengths[i][j];
        }
    }
}
#elif (METRIC == AngleDiff)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double a;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            for (k = i+1; k < j+1; k++) {
                a = angle(x[i],y[i],x[j],y[j],
                          x[k-1],y[k-1],x[k],y[k]);
                a *= 180.0 / PI;
                all_errors[i][j] += a;
            }
            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == Angle8)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double factor_squared,dist,prev_dist,a,sum_angle_diff;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            prev_dist = 0;
            sum_angle_diff = 0;
            for (k = i+1; k < j; k++) {
                dist = (y[j] - y[i]) * x[k] -
                       (x[j] - x[i]) * y[k] -
                        x[i] * y[j] +
                        x[j] * y[i];
                dist = MAX(prev_dist,ABS(dist));
                prev_dist = dist;

                a = angle(x[i],y[i],x[j],y[j],
                          x[k-1],y[k-1],x[k],y[k]);
                sum_angle_diff += a;
            }
            all_errors[i][j] = dist;
            factor_squared = SQR(x[i] - x[j]) + SQR(y[i] - y[j]);

            all_errors[i][j] *= sum_angle_diff;

            if (factor_squared == 0)
                all_errors[i][j] = 0;
            else {
                /* ERROR: all_errors[i][j] /= factor_squared; */
                /* divide by length of straight line */
                all_errors[i][j] /= sqrt(factor_squared);
            }

            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == Length_R)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j,k;
    double dx,dy,length_p,length_l;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            all_errors[i][j] = 0;
            length_p = 0;
            for (k = i+1; k <= j; k++) {
                dx = x[k] - x[k-1];
                dy = y[k] - y[k-1];
                length_p += sqrt(dx*dx + dy*dy);
            }
            dx = x[i] - x[j];
            dy = y[i] - y[j];
            length_l = sqrt(dx*dx + dy*dy);

            /* ratio of lengths */
            all_errors[i][j] = length_p / length_l;
            /* weight by line length */
            all_errors[i][j] *= length_p;

            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == LinearityIVC)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j;
    double m00,m10,m01,m20,m02;
    double tm10,tm01,tm20,tm02;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            m00 = calc_moment2(0.0,0.0,i,j+1);
            m10 = calc_moment2(1.0,0.0,i,j+1);
            m01 = calc_moment2(0.0,1.0,i,j+1);
            m20 = calc_moment2(2.0,0.0,i,j+1);
            m02 = calc_moment2(0.0,2.0,i,j+1);

            /* effectively rescale data to have unit length */
            tm10 = m10 / SQR(m00);
            tm01 = m01 / SQR(m00);
            tm20 = m20 / pow(m00,3.0);
            tm02 = m02 / pow(m00,3.0);
            all_errors[i][j] = 12 * (tm20 + tm02 - SQR(tm10) - SQR(tm01));
            all_errors[i][j] = 1 - all_errors[i][j];
            // extra scaling of error by weight
            all_errors[i][j] *= m00;

            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#elif (METRIC == LinearityPR)
/* calculate all errors for possible pairs of breakpoints */
void calc_errors()
{
    int i,j;
    double m00,m10,m01;
    double xbar,ybar;
    double dx,dy,d1,d2;

    for (i = 0; i < no_pixels-1; i++) {
        for (j = i+1; j < no_pixels; j++) {
            m00 = calc_moment2(0.0,0.0,i,j+1);
            m10 = calc_moment2(1.0,0.0,i,j+1);
            m01 = calc_moment2(0.0,1.0,i,j+1);
            xbar = m10 / m00;
            ybar = m01 / m00;

            dx = x[i] - xbar;
            dy = y[i] - ybar;
            d1 = sqrt(SQR(dx) + SQR(dy));

            dx = x[j] - xbar;
            dy = y[j] - ybar;
            d2 = sqrt(SQR(dx) + SQR(dy));

            all_errors[i][j] = (d1 + d2) / m00;
            all_errors[i][j] = 1 - all_errors[i][j];
            // extra scaling of error by weight
            all_errors[i][j] *= m00;

            all_errors[j][i] = all_errors[i][j];
        }
    }
}
#endif

void print_table()
{
    int i,j;

    for (i = 0; i < no_pixels; i++) {
        for (j = 0; j < no_pixels; j++) {
            printf("%6.2f ",all_errors[i][j]);
        }
        printf("\n");
    }
}

/* dynamic programming */
void dp()
{
    int i,j,k;
    double e,best_e,best_l;
    int b,best_position;
    int result_list[MAX_BREAKS],count;

    printf("calculating errors\n");
#if (METRIC != AngleInt)
    calc_errors();
#endif
#ifdef EVALUATE
    read_points();
    evaluate();
    exit();
#endif
    printf("starting dynamic programming\n");

    /* initialise for first point with startpoint */
    for (i = 1; i < no_pixels-1; i++) {
#if (METRIC == AngleInt)
        error[0][i] = 0;
#else
        error[0][i] = all_errors[0][i];
#endif
        best[0][i] = 0;
#if (METRIC == LengthISEglobal)
        length[0][i] = all_lengths[0][i];
#endif
    }

    /* loop once for each breakpoint to be determined */
    for (k = 1; k < no_bkpts; k++) {
        /*
        printf("K = %d - showing previous: ######################\n",k);
        for (i = 0; i < no_pixels; i++)
            printf("%7.0e",error[k-1][i]);
        printf("\n");
        for (i = 0; i < no_pixels; i++)
            printf("%7d",best[k-1][i]);
        printf("\n");
        */

        /* impossible positions of new breakpoint */
        for (i = 0; i < k+1; i++) {
            error[k][i] = 9e10;
            best[k][i] = 0;
#if (METRIC == LengthISEglobal)
            length[k][i] = 9e-10;
#endif
        }
        /* for all positions of new breakpoint */
        for (i = k+1; i < no_pixels-1; i++) {
            /* initially set error high */
            best_e = error[k][i] = 9e10;
#if (METRIC == LengthISEglobal)
            length[k][i] = 9e-10;
#endif
            /* consider all possible positions of previous breakpoint */
            for (j = 1; j < i; j++) {
#if ((METRIC == Linfinity) || (METRIC == Length_8))
                e = MAX(error[k-1][j],all_errors[j][i]);
#elif (METRIC == AngleInt)
                b = best[k-1][j];
                e = error[k-1][j] +
                        angle(x[j],y[j],x[b],y[b],
                              x[j],y[j],x[i],y[i]);
#else
                e = error[k-1][j] + all_errors[j][i];
#endif
#if (METRIC == LengthISEglobal)
                e /= (length[k-1][j] + all_lengths[j][i]);
                if (e < best_e) {
                    error[k][i] = error[k-1][j] + all_errors[j][i];
                    length[k][i] = length[k-1][j] + all_lengths[j][i];
                    best[k][i] = j;
                    best_e = e;
                }
#else
                if (e < error[k][i]) {
                    error[k][i] = e;
                    best[k][i] = j;
                }
#endif
            }
        }
    }

    /* finish with last point and endpoint */
    best_e = 9e10;
    for (i = no_bkpts; i < no_pixels-1; i++) {
#if ((METRIC == Linfinity) || (METRIC == Length_8))
        e = MAX(error[no_bkpts-1][i],all_errors[i][no_pixels-1]);
#elif (METRIC == AngleInt)
        b = best[no_bkpts-1][i];
        e = error[no_bkpts-1][i] +
                angle(x[i],y[i],x[b],y[b],
                      x[i],y[i],x[no_pixels-1],y[no_pixels-1]);
#else
        e = error[no_bkpts-1][i] + all_errors[i][no_pixels-1];
#endif
#if (METRIC == LengthISEglobal)
        e /= (length[no_bkpts-1][i] + all_lengths[i][no_pixels-1]);
#endif
        if (e < best_e) {
            best_e = e;
#if (METRIC == LengthISEglobal)
            best_l = length[no_bkpts-1][i] + all_lengths[i][no_pixels-1];
#endif
            best_position = i;
        }
    }

    printf("Final error  = %.2f\n",best_e);
    printf("Final error * #breakpoints = %.2f\n",best_e*no_bkpts);
#if (METRIC == LengthISEglobal)
    printf("Final length  = %.2f\n",best_l);
#endif

    result_list[0] = no_pixels-1;
    result_list[1] = best_position;
    count = 2;

    b = best_position;
    for (k = no_bkpts-1; k >= 0; k--) {
        b = best[k][b];
        result_list[count] = b;
        count++;
    }

    for (k = 0; k < count-1; k++) {
        i = result_list[k];
        j = result_list[k+1];
        fprintf(fp2,"line: 0 %d %d %d %d\n",x[i],y[i],x[j],y[j]);
    }

    if (print_indices) {
        if ((fpi = fopen(i_file,"w")) == NULL) {
            fprintf(stderr,"cant open %s\n",i_file);
            exit(-1);
        }

        /* skip first breakpoint - it seems to be the same as the last
           after a fashion

           -------------------------------------
           added first breakpoint back in
           it is last point, which is different to the first point if it is
           an open curve

           PLR June 2006
         */
        //for (k = 1; k < count; k++) {
        /****
        for (k = 0; k < count; k++) {
            i = result_list[k];
            if (chop == 0)
                fprintf(fpi,"%d %d\n",i,no_bkpts+1);
            else
                fprintf(fpi,"%d %d\n",i+chop,chop);
        }
        ****/
        // print list on forwards order - PLR June 2006
        for (k = count-1; k >= 0; k--) {
            i = result_list[k];
            if (chop == 0)
                fprintf(fpi,"%d %d\n",i,no_bkpts+1);
            else
                fprintf(fpi,"%d %d\n",i+chop,chop);
        }
        fclose(fpi);
    }
}

/* angle between lines (x1,y1)->(x2,y2) and (a1,b1)->(a2,b2) */
double angle(int x1, int y1, int x2, int y2, int a1, int b1, int a2, int b2)
{
    double a,c,dx,dy,da,db,f1,f2;

    dx = x2 - x1; dy = y2 - y1;
    da = a2 - a1; db = b2 - b1;
    f1 = SQR(dx) + SQR(dy);
    f2 = SQR(da) + SQR(db);
    c = (dx * da + dy * db) / (sqrt(f1) * sqrt(f2));
    c = MAX(-1,c);
    c = MIN(1,c);
    a = acos(c);
    return(a);
}

void read_link_data(FILE *fp, int *endoffile)
{
    char dumstring[50];
    int j;
    int list;

    fscanf(fp,"%s %d\n",dumstring,&list);
    j = -1;
    do {
       j++;
       fscanf(fp,"%d %d\n",&x[j],&y[j]);
       /* eliminate duplicate pixels - essential for angle difference */
       if (j > 0) {
           if ((x[j] == x[j-1]) && (y[j] == y[j-1]))
               j--;
       }
    } while(x[j] != -1);
    *endoffile = (y[j] == -1);
    no_pixels = j;
    if (no_pixels >= MAX_PIXELS) {
        fprintf(stderr,"ERROR: %d is too many pixels\n",no_pixels);
        exit(-1);
    }
}


/* read list of index locations to points on curve */
void read_points()
{
    int j,i1,i2,offset;

    printf("Type in point indices\n");
    j = -1;
    do{
       j++;
       scanf("%d",&pts[j]);
    } while(pts[j] != -1);
    no_pts = j;

    printf("Type in offset\n");
    scanf("%d",&offset);
    for (j = 0; j < no_pts; j++)
        pts[j] -= offset;

    printf("super\nlist: 0\n");
    for (j = 0; j < no_pts-1; j++) {
        i1 = pts[j];
        i2 = pts[j+1];
        printf("line: 0 %d %d %d %d\n",x[i1],y[i1],x[i2],y[i2]);
    }
    printf("endl:\nendf:\n");
}

/* calculate error of curve given read points */
void evaluate()
{
    int k,i1,i2;
    double e,sum=0;

    for (k = 0; k < no_pts-1; k++) {
        i1 = pts[k];
        i2 = pts[k+1];
        e = all_errors[i1][i2];
        /*
        printf("err = %.1f\n",e);
        */
        sum += e;
    }
    printf("TOTAL ERROR: %.3f\n",sum);
}

// assumes open curves
// calculate using just part of data
double calc_moment2(double p, double q, int start, int end)
{
    int i,k;
    double sum,moment;
    double a,x1,x2,y1,y2;

    for (i = start; i < end-1; i++)  {
        // vertical line
        if (x[i] == x[i+1]) {
            if (y[i] <= y[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            d[i] = pow(x1,p) * (pow(y2,q+1)-pow(y1,q+1)) / (q+1);
        }
        // horizontal line
        else if (y[i] == y[i+1]) {
            if (x[i] <= x[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            d[i] = pow(y1,q) * (pow(x2,p+1)-pow(x1,p+1)) / (p+1);
        }
        // diagonal line
        else {
            if (x[i] <= x[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            a = (y2 - y1) / (x2 - x1);
            sum = 0;
            for (k = 0; k <= q; k++) {
                sum += ncomb1((int)q,k)
                     * pow(a,(double)k)
                     * pow(y1-a*x1,q-k)
                     * (pow(x2,p+k+1) - pow(x1,p+k+1)) / (p+k+1);

            }
            d[i] = sqrt(1+SQR(a)) * sum;
        }
    }

    moment = 0;
    for (i = start; i < end-1; i++)
        moment += d[i];

    return(moment);
}

/*
** Compute C(n,m) = the number of combinations of n items,
** taken m at a time.
**
** Written by Thad Smith III, Boulder County, CO.
** Released to the Public Domain  10/14/91.
**
** The def of this function is
**      C(n,m)  = n! / (m! * (n-m)!).
** Computing this formula can cause overflow for large values of n,
** even when C(n,m) would be defined.
**
** The first version will not overflow if C(n,m) * (n-m+1) < ULONG_MAX.
** The second version will not overflow if C(n,m) < ULONG_MAX, but
** is slightly more complex.
** Function domain: n >= 0,  0 <= m <= n.
**
** Both versions work by reducing the product as it is computed.  It
** relies on the property that the product on n consecutive integers
** must be evenly divisible by n.
**
** The first version can be changed to make cnm and the return value
** double to extend the range of the function.
*/
double ncomb1(int n, int m)
{
      double cnm = 1;
      int i;

      if (m*2 >n) m = n-m;
      for (i=1 ; i <= m; n--, i++)
            cnm = cnm * n / i;
      return cnm;
}

void options(char *progname)
{
    printf("usage: %s [options]\n",progname);
    printf("     -i file   input pixel file\n");
    printf("     -o file   output line superdata file\n");
    printf("     -n int    number of lines\n");
    printf("     -c int    chop off some data\n");
    printf("     -p file   output indices\n");
    exit(-1);
}
