/*
 * compute linearity of curve using line moments
 * (i.e. moments along polygon - not area moments using Green's theorem)
 * perform computation incrementally
 * apply locally - i.e. piecewise and compute mean
 *
 * assumes open curves
 *
 * input format: pixel list (integer or float format)
 * output:       [0,1], where 1 indicates a perfect straight line
 *
 * For more details see:
 *   Measuring Linearity of Open Planar Curve Segments
 *   Jovisa Zunic and Paul L. Rosin
 *   Image and Vision Computing
 *   vol. 29, no. 12, pp. 873-879, 2011.
 *
 * Paul Rosin
 * March 2010
 * Cardiff University
 * Paul.Rosin@cs.cf.ac.uk
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_PIXELS 40000

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define PI 3.1415926

#define ABS(x)    (((x)<0.0)? (-(x)): (x))
#define SQR(a)    ((a)*(a))
#define MAX(a,b)  (((a) > (b)) ? (a) : (b))
#define MIN(a,b)  (((a) < (b)) ? (a) : (b))

int no_pixels;
double x[MAX_PIXELS],y[MAX_PIXELS];
double d[MAX_PIXELS];

double calc_moment2(double p, double q, int start, int end);
void read_link_data(FILE *fp, int *endoffile);
double ncomb1(int n, int m);

main(argc, argv)
int argc;
char *argv[];
{
    FILE *fp1;
    char file_type[50];
    int i,j,jj;
    int endoffile;
    double m00,m10,m01,m20,m02;
    double tm10,tm01,tm20,tm02;
    double linearity;
    int count;
    int window;

    if (argc != 3) {
        printf("usage: %s input_file window-size\n", argv[0]);
        exit(-1);
    }

    window = atoi(argv[2]);

    if ((fp1 = fopen(argv[1], "r")) == NULL) {
        printf("cant open %s\n", argv[1]);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp1, "%s\n", file_type);
    j = strcmp(file_type, "pixel");
    jj = strcmp(file_type, "pixel_float");
    if ((j != 0) && (jj != 0)) {
        printf("not link data file - aborting\n");
        exit(-1);
    }

    do {
        read_link_data(fp1, &endoffile);

        if (window > no_pixels) {
            fprintf(stderr,"not enough data - aborting\n");
            exit(-1);
        }

        linearity = 0;
        count = 0;
        for (i = 0; i <= no_pixels-window; i++) {
            m00 = calc_moment2(0.0,0.0,i,i+window);
            m10 = calc_moment2(1.0,0.0,i,i+window);
            m01 = calc_moment2(0.0,1.0,i,i+window);
            m20 = calc_moment2(2.0,0.0,i,i+window);
            m02 = calc_moment2(0.0,2.0,i,i+window);

            /* effectively rescale data to have unit length */
            tm10 = m10 / SQR(m00);
            tm01 = m01 / SQR(m00);
            tm20 = m20 / pow(m00,3.0);
            tm02 = m02 / pow(m00,3.0);
            linearity += 12 * (tm20 + tm02 - SQR(tm10) - SQR(tm01));
            //printf("local linearity: %f\n",12 * (tm20 + tm02 - SQR(tm10) - SQR(tm01)));
            count++;
        }
        linearity /= count;
        printf("linearity: %f\n",linearity);
    } while (!endoffile);
    fclose(fp1);
}

// assumes open curves
// calculate using just part of data
double calc_moment2(double p, double q, int start, int end)
{
    int i,k;
    double sum,moment;
    double a,x1,x2,y1,y2;

    for (i = start; i < end-1; i++)  {

        // vertical line
        if (x[i] == x[i+1]) {
            if (y[i] <= y[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            d[i] = pow(x1,p) * (pow(y2,q+1)-pow(y1,q+1)) / (q+1);
        }
        // horizontal line
        else if (y[i] == y[i+1]) {
            if (x[i] <= x[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            d[i] = pow(y1,q) * (pow(x2,p+1)-pow(x1,p+1)) / (p+1);
        }
        // diagonal line
        else {
            if (x[i] <= x[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            a = (y2 - y1) / (x2 - x1);
            sum = 0;
            for (k = 0; k <= q; k++) {
                sum += ncomb1((int)q,k)
                     * pow(a,(double)k)
                     * pow(y1-a*x1,q-k)
                     * (pow(x2,p+k+1) - pow(x1,p+k+1)) / (p+k+1);

            }
            d[i] = sqrt(1+SQR(a)) * sum;
        }
    }

    moment = 0;
    for (i = start; i < end-1; i++)
        moment += d[i];

    return(moment);
}

void read_link_data(FILE *fp, int *endoffile)
{
    char dumstring[50];
    int j;
    double t1,t2;

    fscanf(fp, "%s %d\n", dumstring, &j);
    j = -1;
    do {
        j++;
        fscanf(fp, "%lf %lf\n", &t1,&t2);
        x[j] = t1; y[j] = t2;
    } while (x[j] != -1);
    *endoffile = (y[j] == -1);
    if (feof(fp) && !(*endoffile)) {
        fprintf(stderr, "Incorrectly terminated file - assuming end of list\n");
        *endoffile = TRUE;
    }
    no_pixels = j;
    if (no_pixels >= MAX_PIXELS) {
        fprintf(stderr,"ERROR: Too many pixels\n");
        exit(-1);
    }
}

/*
** Compute C(n,m) = the number of combinations of n items,
** taken m at a time.
**
** Written by Thad Smith III, Boulder County, CO.
** Released to the Public Domain  10/14/91.
**
** The def of this function is
**      C(n,m)  = n! / (m! * (n-m)!).
** Computing this formula can cause overflow for large values of n,
** even when C(n,m) would be defined.
**
** The first version will not overflow if C(n,m) * (n-m+1) < ULONG_MAX.
** The second version will not overflow if C(n,m) < ULONG_MAX, but
** is slightly more complex.
** Function domain: n >= 0,  0 <= m <= n.
**
** Both versions work by reducing the product as it is computed.  It
** relies on the property that the product on n consecutive integers
** must be evenly divisible by n.
**
** The first version can be changed to make cnm and the return value
** double to extend the range of the function.
*/
double ncomb1(int n, int m)
{
      double cnm = 1;
      int i;

      if (m*2 >n) m = n-m;
      for (i=1 ; i <= m; n--, i++)
            cnm = cnm * n / i;
      return cnm;
}
