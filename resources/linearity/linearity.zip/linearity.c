/*
 * compute linearity of curve using line moments
 * (i.e. moments along polygon - not area moments using Green's theorem)
 *
 * copes with open & closed curves
 *
 * input format: pixel list (integer or float format)
 * output:       [0,1], where 1 indicates a perfect straight line
 *
 * For more details see:
 *   Measuring Linearity of Open Planar Curve Segments
 *   Jovisa Zunic and Paul L. Rosin
 *   Image and Vision Computing
 *   vol. 29, no. 12, pp. 873-879, 2011.
 *
 * Paul Rosin
 * June 2009
 * Cardiff University
 * Paul.Rosin@cs.cf.ac.uk
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_PIXELS 2000000

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define PI 3.1415926

#define ABS(x)    (((x)<0.0)? (-(x)): (x))
#define SQR(a)    ((a)*(a))
#define MAX(a,b)  (((a) > (b)) ? (a) : (b))
#define MIN(a,b)  (((a) < (b)) ? (a) : (b))

int no_pixels;
double x[MAX_PIXELS],y[MAX_PIXELS];
double d[MAX_PIXELS];

double calc_moment(double p, double q);
void read_link_data(FILE *fp, int *endoffile, int *closed);
double ncomb1(int n, int m);

main(argc, argv)
int argc;
char *argv[];
{
    FILE *fp1;
    char file_type[50];
    int i,j,jj;
    int endoffile;
    double m00,m10,m01,m11,m20,m02,xbar,ybar;
    double linearity;
    int closed = FALSE;

    if (argc != 2) {
        printf("usage: %s input_file\n", argv[0]);
        exit(-1);
    }

    if ((fp1 = fopen(argv[1], "r")) == NULL) {
        printf("cant open %s\n", argv[1]);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp1, "%s\n", file_type);
    j = strcmp(file_type, "pixel");
    jj = strcmp(file_type, "pixel_float");
    if ((j != 0) && (jj != 0)) {
        printf("not link data file - aborting\n");
        exit(-1);
    }

    do {
        read_link_data(fp1, &endoffile, &closed);

        if (closed)
            printf("curve is CLOSED\n");
        else
            printf("curve is OPEN\n");

        // make sure start/end point is duplicated
        // so that the last edge is included in the moments
        if (closed) {
            x[no_pixels] = x[0];
            y[no_pixels] = y[0];
            no_pixels++;
        }

        m00 = calc_moment(0.0,0.0);
        m10 = calc_moment(1.0,0.0);
        m01 = calc_moment(0.0,1.0);
        xbar = m10 / m00;
        ybar = m01 / m00;

/*
printf("m00,m10,m01, %f %f %f\n",m00,m10,m01);
printf("xbar ybar  %f %f\n",xbar,ybar);
*/
        /* shift data to centroid */
        /* not necessary
        for (i = 0; i < no_pixels; i++) {
            x[i] -= xbar;
            y[i] -= ybar;
        }
        */

        /* rescale data to have unit length */
        for (i = 0; i < no_pixels; i++) {
            x[i] /= m00;
            y[i] /= m00;
        }

        m00 = calc_moment(0.0,0.0);
        m10 = calc_moment(1.0,0.0);
        m01 = calc_moment(0.0,1.0);
        m11 = calc_moment(1.0,1.0);
        m20 = calc_moment(2.0,0.0);
        m02 = calc_moment(0.0,2.0);
/*
printf("m00,m10,m01, %f %f %f\n",m00,m10,m01);
printf("m00,m20,m02, %f %f %f\n",m00,m20,m02);
*/

        linearity = 12 * (m20 + m02 - SQR(m10) - SQR(m01));
        printf("linearity: %f\n",linearity);

        /*
        linearity = m11 / sqrt(m20 * m02);
        printf("correlation: %f\n",linearity);
        */
    } while (!endoffile);
    fclose(fp1);
}

// assumes open curves
double calc_moment(double p, double q)
{
    int i,k;
    double sum,moment;
    double a,x1,x2,y1,y2;

    for (i = 0; i < no_pixels-1; i++)  {

        // vertical line
        if (x[i] == x[i+1]) {
            if (y[i] <= y[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            d[i] = pow(x1,p) * (pow(y2,q+1)-pow(y1,q+1)) / (q+1);
        }
        // horizontal line
        else if (y[i] == y[i+1]) {
            if (x[i] <= x[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            d[i] = pow(y1,q) * (pow(x2,p+1)-pow(x1,p+1)) / (p+1);
        }
        // diagonal line
        else {
            if (x[i] <= x[i+1]) {
                x1 = x[i]; x2 = x[i+1];
                y1 = y[i]; y2 = y[i+1];
            }
            else {
                x1 = x[i+1]; x2 = x[i];
                y1 = y[i+1]; y2 = y[i];
            }
            a = (y2 - y1) / (x2 - x1);
            sum = 0;
            for (k = 0; k <= q; k++) {
                sum += ncomb1((int)q,k)
                     * pow(a,(double)k)
                     * pow(y1-a*x1,q-k)
                     * (pow(x2,p+k+1) - pow(x1,p+k+1)) / (p+k+1);

            }
            d[i] = sqrt(1+SQR(a)) * sum;
        }
    }

    moment = 0;
    for (i = 0; i < no_pixels-1; i++)
        moment += d[i];

    return(moment);
}

void read_link_data(FILE *fp, int *endoffile, int *closed)
{
    char dumstring[50];
    int j;
    double t1,t2;
    double xd,yd;

    fscanf(fp, "%s %d\n", dumstring, &j);
    j = -1;
    do {
        j++;
        fscanf(fp, "%lf %lf\n", &t1,&t2);
        x[j] = t1; y[j] = t2;
    } while (x[j] != -1);
    *endoffile = (y[j] == -1);
    if (feof(fp) && !(*endoffile)) {
        fprintf(stderr, "Incorrectly terminated file - assuming end of list\n");
        *endoffile = TRUE;
    }
    no_pixels = j;
    if (no_pixels >= MAX_PIXELS) {
        fprintf(stderr,"ERROR: Too many pixels\n");
        exit(-1);
    }
    xd = ABS(x[0] - x[j-1]);
    yd = ABS(y[0] - y[j-1]);
    *closed = ((xd <= 1) && (yd <= 1));
}

/*
** Compute C(n,m) = the number of combinations of n items,
** taken m at a time.
**
** Written by Thad Smith III, Boulder County, CO.
** Released to the Public Domain  10/14/91.
**
** The def of this function is
**      C(n,m)  = n! / (m! * (n-m)!).
** Computing this formula can cause overflow for large values of n,
** even when C(n,m) would be defined.
**
** The first version will not overflow if C(n,m) * (n-m+1) < ULONG_MAX.
** The second version will not overflow if C(n,m) < ULONG_MAX, but
** is slightly more complex.
** Function domain: n >= 0,  0 <= m <= n.
**
** Both versions work by reducing the product as it is computed.  It
** relies on the property that the product on n consecutive integers
** must be evenly divisible by n.
**
** The first version can be changed to make cnm and the return value
** double to extend the range of the function.
*/
double ncomb1(int n, int m)
{
      double cnm = 1;
      int i;

      if (m*2 >n) m = n-m;
      for (i=1 ; i <= m; n--, i++)
            cnm = cnm * n / i;
      return cnm;
}
