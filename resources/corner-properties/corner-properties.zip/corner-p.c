/*
 *    code for the most reliable methods described in the paper:
 *    "Measuring corner properties",
 *    Paul L. Rosin,
 *    Computer Vision and Image Understanding,
 *    vol. 73, no. 2, pp. 291-307, 1999
 *
 *    corners are first detected using the Kitchen/Rosenfeld corner detector
 *    followed by non-maximal supression
 *
 *    at these locations the following corner properties are measured:
 *        orientation, subtended angle, contrast, relative colour
 *
 *    NOTE:
 *       This program has gone though many iterations over the last nine
 *       years, and is consequently a mess!
 *
 *       In addition, there are probably many instances of gross inefficiency
 *       which I haven't been concerned about.
 *
 *       Unfortunately there are still a few loose ends floating around which
 *       I never got around to sorting out properly. So I'm not guaranteeing
 *       correct results. If you come across any bugs then let me know.
 *
 *       I've marginally tidied up the program, and eliminated a lot of old,
 *       redundant stuff to produce this substantially cut-down version.
 *
 *    Paul Rosin
 *    Brunel University
 *    February 1999
 *
 *    updated image format and thresholding
 *    Paul Rosin
 *    Cardiff University
 *    May 2019
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define MAX_SIZE 2000

#include "pgmio.h"

#define PI          3.1415926
#define TWO_ROOT2   2.828427124

#define RAD_DEG (180.0/PI)
#define DEG_RAD (PI/180.0)

#define LIGHT 0
#define DARK 255

#define NV 2                /* number of arms in vertex */ 
#define WIN 10              /* window size for angle detection */
#define BIN 36              /* bin size for angle histogram */
#define PEAK 0
#define PIT 1

#define ABS(x)    (((x)<0.0)? -(x): (x))
#define SQR(x)    ((x)*(x))
#define CUBE(x)   ((x)*(x)*(x))
#define POWER4(x) ((x)*(x)*(x)*(x))
#define MIN(a,b)  (((a) < (b)) ? (a) : (b))
#define MAX(a,b)  (((a) > (b)) ? (a) : (b))

int height,width,depth;

int nms_win = 1;

int colour = 255;

unsigned char tmp1[MAX_SIZE][MAX_SIZE];
unsigned char tmp2[MAX_SIZE][MAX_SIZE];
unsigned char image_in[MAX_SIZE][MAX_SIZE];
unsigned char image_out[MAX_SIZE][MAX_SIZE];
double gx[MAX_SIZE][MAX_SIZE];
double gy[MAX_SIZE][MAX_SIZE];
double gxx[MAX_SIZE][MAX_SIZE];
double gyy[MAX_SIZE][MAX_SIZE];
double gxy[MAX_SIZE][MAX_SIZE];

int do_plot_angle1,do_plot_angle4,do_plot_angle6,
    do_plot_angle7,do_plot_angle8,do_plot_angle9;

double cornerity[MAX_SIZE][MAX_SIZE];
#define OK      0
#define DELETE2 2
#define DELETE1 1
#define DELETE0 0
short nms_status[MAX_SIZE][MAX_SIZE];

#define MAX_RADIUS 20
#define MAX_RADIUS2 (MAX_RADIUS*2)
int circle_area;
int circ_x[MAX_RADIUS2*MAX_RADIUS2];
int circ_y[MAX_RADIUS2*MAX_RADIUS2];
unsigned char image_thr[MAX_SIZE][MAX_SIZE];

int do_contrast4,do_contrast5;
int save_whites[MAX_RADIUS2*MAX_RADIUS2];
int save_blacks[MAX_RADIUS2*MAX_RADIUS2];

unsigned char rot_im[MAX_SIZE][MAX_SIZE];

double FOREGROUND,BACKGROUND,ANGLE_SUB,ORIENTATION;

int thresh = 500;

int test_colour(int x,int y);
double get_orientation1(int x,int y);
double get_orientation5(int x,int y);
double angle_subt2(int x,int y);
int count_peaks(double hist[]);
void measure_peaks( double hist[], double *MAG, int *ANG);
void calc_orientation(int x,int y,double *orient);
void calc_derivatives();
int smooth_hist(double old[],double new[]);
double edge_mag(int x,int y);
void perform_nms(double cornerity[MAX_SIZE][MAX_SIZE], short nms_status[MAX_SIZE][MAX_SIZE]);
void delete_neighbourhood(int x,int y, int *sumx,int *sumy,int *count);
void thresh_tsai(int xc,int yc, double *sub_angle,double *orient,int *colour, double *contrast, double *sd);
double moment(int j,int xc,int yc);
double moment_new(int xc,int yc,int p);
double normalise_angle(double a);
void moment_attributes(int x,int y, double *contrast,double *angle, double *f,double *b);
double proportion(int t,int xc,int yc);
void setup_circle(int r);
double check_sum1();
double check_sum2();
double check_sum3();
void rotate(int xc,int yc,double theta);
double get_orientation6(int x,int y);
double get_orientation7(int x,int y,int flag);
void sort(int n, int ra[]);
double angle(double x1,double y1,double x2,double y2);

main(argc,argv)
int argc;
char *argv[];
{
    int x,y;
    int i,j;
    char *filename_in,*filename_out,*filename_out2;
    double val,div;
    int num = 0;
    int do_angle_subt2,do_angle_subt5;
    int do_colour1,do_colour2;
    int plot_corner;
    int plot_thick = TRUE;
    double contrast;
    int border;
    FILE *fp_out2;
    int edge_thresh = 20;
    double sd;
    //double angle_subt2(),edge_mag();

    height = width = 512;
    filename_in = filename_out = filename_out2 = NULL;
    do_angle_subt2 = do_angle_subt5 = FALSE;
    do_plot_angle1 = do_plot_angle4 = do_plot_angle6 = do_plot_angle7 =
    do_plot_angle8 = do_plot_angle9 = FALSE;
    do_contrast4 = do_contrast5 = FALSE;
    do_colour1 = do_colour2 = FALSE;

    /* default method settings */
    do_plot_angle4 = do_angle_subt2 = do_contrast4 = do_colour1 = TRUE;

    /* parse command line */
    for (i = 1; i < (argc); i++) {
        if (argv[i][0] == '-') {
            switch(argv[i][1]) {
                case 'a':
                    do_plot_angle4 = FALSE;
                    switch(argv[i][2]) {
                        case '1':
                            do_plot_angle1 = TRUE;
                            break;
                        case '4':
                            do_plot_angle4 = TRUE;
                            break;
                        case '6':
                            do_plot_angle6 = TRUE;
                            break;
                        case '7':
                            do_plot_angle7 = TRUE;
                            break;
                        case '8':
                            do_plot_angle8 = TRUE;
                            break;
                        case '9':
                            do_plot_angle9 = TRUE;
                            break;
                        default:
                            fprintf(stderr,"ERROR <%c> on -%c flag\n",
                                argv[i][2],argv[i][1]);
                            exit(-1);
                    }
                    break;
                case 'b':
                    do_angle_subt2 = FALSE;
                    switch(argv[i][2]) {
                        case '2':
                            do_angle_subt2 = TRUE;
                            break;
                        case '5':
                            do_angle_subt5 = TRUE;
                            break;
                        default:
                            fprintf(stderr,"ERROR on -%c flag\n",argv[i][1]);
                            exit(-1);
                    }
                    break;
                case 'c':
                    do_contrast4 = FALSE;
                    switch(argv[i][2]) {
                        case '4':
                            do_contrast4 = TRUE;
                            break;
                        case '5':
                            do_contrast5 = TRUE;
                            break;
                        default:
                            fprintf(stderr,"ERROR on -%c flag\n",argv[i][1]);
                            exit(-1);
                    }
                    i++;
                    break;
                case 'e':
                    i++;
                    edge_thresh = atoi(argv[i]);
                    printf("read edge threshold of %d\n",edge_thresh);
                    break;
                case 'h':
                    i++;
                    height = atoi(argv[i]);
                    printf("image height: %d\n",height);
                    break;
                case 'i':
                    i++;
                    filename_in = argv[i];
                    break;
                case 'C':
                    do_colour1 = FALSE;
                    switch(argv[i][2]) {
                        case '1':
                            do_colour1 = TRUE;
                            break;
                        case '2':
                            do_colour2 = TRUE;
                            break;
                        default:
                            fprintf(stderr,"ERROR on -%c flag\n",argv[i][1]);
                            exit(-1);
                    }
                    break;
                case 'o':
                    i++;
                    filename_out = argv[i];
                    break;
                case 'O':
                    i++;
                    filename_out2 = argv[i];
                    break;
                case 't':
                    i++;
                    thresh = atoi(argv[i]);
                    printf("read threshold of %d\n",thresh);
                    break;
                case 'T':
                    plot_thick = FALSE;
                    break;
                case 'w':
                    i++;
                    width = atoi(argv[i]);
                    printf("image width: %d\n",width);
                    break;
                case 'W':
                    i++;
                    nms_win = atoi(argv[i]);
                    printf("read nms window of %d\n",nms_win);
                    break;
                default:
                    printf("unknown option %s\n",argv[i]); exit(-1);
                    exit(-1);
            }
        }
        else {
            printf("unknown option %s\n",argv[i]); exit(-1);
            exit(-1);
        }
    }
    if ((filename_in == NULL) ||
       ((filename_out == NULL) && (filename_out2 == NULL)))
    {
        printf("usage: %s -i input_image -o/O output_image/file [options]\n", argv[0]);
        printf("    options: -a1 orientation      - average orientation\n");
        printf("             -a4      \"           - thresholding (default)\n");
        printf("             -a6      \"           - intensity weighted centroid\n");
        printf("             -a7      \"           - symmetry (pixel diffs)\n");
        printf("             -a8      \"           - symmetry (line diffs)\n");
        printf("             -a9      \"           - symmetry (region diffs)\n");
        printf("             -b2 subtended angle  - multi-scale analysis (default)\n");
        printf("             -b5      \"           - moments\n");
        printf("             -c4 contrast         - thresholding & median (default)\n");
        printf("             -c5      \"           - moments\n");
        printf("             -C1 colour           - median (default)\n");
        printf("             -C2      \"           - thresholding\n");
        printf("             -e edge threshold (default: %d)\n",edge_thresh);
        printf("             -h image height (default: %d)\n",height);
        printf("             -o output image file\n");
        printf("             -O output text file\n");
        printf("             -t cornerity threshold (default: %d)\n",thresh);
        printf("             -T plot corners thin (default: thick)\n");
        printf("             -w image width (default: %d)\n",width);
        printf("             -W halfsize of non-maximal supression window (default: %d)\n",nms_win);
        exit(-1);
    }

    if (filename_out2 != NULL) {
        if ((fp_out2 = fopen(filename_out2,"w")) == NULL) {
            printf("cant open %s\n",filename_out2);
            exit(-1);
        }
    }

    read_pgm(image_in,filename_in,&width,&height,&depth);

    /* if using thresholding or moments setup circle */
    if (do_plot_angle4 || do_colour2 ||
        do_contrast4 || do_contrast5 || do_angle_subt5)
    {
        printf("using %dx%d window for thresholding\n",2*WIN+1,2*WIN+1);
        setup_circle(WIN+1);
        for (y = 0; y < MAX_RADIUS2; y++)
            for (x = 0; x < MAX_RADIUS2; x++)
                image_thr[x][y] = 255;
    }

    /* copy input image */
    for (y=0;y<height-0;y++)
        for (x=0;x<width-0;x++)
{
            image_out[x][y] = image_in[x][y];
tmp1[x][y] = tmp2[x][y] = 5;
}

    calc_derivatives();

    /* calculate corner strength */
    for (y = 3; y < height-3; y++) {
        for (x = 3; x < width-3; x++) {
            val  = gxx[x][y] * gy[x][y] * gy[x][y];
            val += gyy[x][y] * gx[x][y] * gx[x][y];
            val -= gxy[x][y] * gx[x][y] * gy[x][y] * 2.0;
            div  = gx[x][y]  * gx[x][y] + gy[x][y] * gy[x][y];
            val  = (div == 0) ? 0.0 : val/div;
            cornerity[x][y] = ABS(val);
            val  = (div == 0) ? 0.0 : val/sqrt(div);
        }
    }

    border = 3 + nms_win;

    perform_nms(cornerity,nms_status);

    for (y = border; y < height-border; y++)
        for (x = border; x < width-border; x++) {
            if ((nms_status[x][y] == OK) &&
                (cornerity[x][y] > thresh) &&
                (edge_mag(x,y) > edge_thresh))
            {
                plot_corner = TRUE;

                /* use moments */
                if (do_contrast5 || do_angle_subt5)
                    moment_attributes(x,y,&contrast,&FOREGROUND,&BACKGROUND,&ANGLE_SUB);
                /* binarizing versions of attribute estimation */
                if (do_contrast4 || do_colour2 ||
                    do_plot_angle4 ) {
                    thresh_tsai(x,y,&ANGLE_SUB,&ORIENTATION,&colour,&contrast,&sd);
                }

                if (do_colour1)
                    colour = test_colour(x,y);

                if (do_angle_subt2)
                    ANGLE_SUB = angle_subt2(x,y);

                if (plot_corner) {
                    num++;
                    calc_orientation(x,y,&ORIENTATION);

                    if (plot_thick)
                        for (i = -1; i <= 1; i++)
                            for (j = -1; j <= 1; j++)
                                image_out[x+i][y+j] = 255-colour;
                    image_out[x][y] = colour;

                    if (filename_out2 != NULL) {
                    /*
                        fprintf(fp_out2,"position %3d %3d; ",x,y);
                        fprintf(fp_out2,"relative colour %3d; ",colour);
                        fprintf(fp_out2,"contrast %6.2f; ",contrast);
                        fprintf(fp_out2,"orientation %6.2f; ",ORIENTATION);
                        fprintf(fp_out2,"subt-angle %6.2f\n",ANGLE_SUB);
                        */
                        fprintf(fp_out2,"Pos %3d %3d ",x,y);
                        fprintf(fp_out2,"Col %3d ",colour);
                        fprintf(fp_out2,"Ctr %6.2f ",contrast);
                        fprintf(fp_out2,"Ang %6.2f ",ORIENTATION);
                        fprintf(fp_out2,"SA %6.2f\n",ANGLE_SUB);
                    }
                }
            }
        }

    printf("found %d corners\n",num);

    if (filename_out != NULL)
        write_pgm(image_out,filename_out,width,height);

    if (filename_out2 != NULL)
        fclose(fp_out2);
}

/* classify corner as light/dark by comparing average with median */
int test_colour(int x,int y)
{
    int i,j;
    int v[(2*WIN+1)*(2*WIN+1)],median,average,t;
    int window_size = (2*WIN+1) * (2*WIN+1);

    average = t = 0;
    for (i = -WIN; i <= WIN; i++)
        for (j = -WIN; j <= WIN; j++) {
            v[t++] = image_in[x+i][y+j];
            average += image_in[x+i][y+j];
        }
    average /= window_size;

    for (i = 0; i < window_size-1; i++)
        for (j = i+1; j < window_size; j++)
            if (v[i] < v[j]) {
                t = v[i];
                v[i] = v[j];
                v[j] = t;
            }
    median = v[window_size/2];

    if (median > average)
        return(DARK);
    else
        return(LIGHT);
}

/* get corner angle by averaging weighted pixel orientations - single scale */
double get_orientation1(int x,int y)
{
    int i,j;
    double dx,dy,mag,angle,average,sum_mag,dist;

    sum_mag = average = 0;
    for (i = -WIN; i <= WIN; i++)
        for (j = -WIN; j <= WIN; j++) {
            /* swap around - this is messy! */
            dy = gx[x+i][y+j];
            dx = gy[x+i][y+j];
            if (dx != 0) {
                angle = atan(dy/dx);
                angle *= 180.0/PI;
                if (angle < 0) angle += 180;
                mag = sqrt(dx*dx+dy*dy);

                sum_mag += mag;
                average += angle*mag;
            }
        }
    average /= sum_mag;
    if (average > 180) average -= 180;
    return(average);
}

/* get corner angle by gradient magnitude weighted centroid */
double get_orientation5(int x,int y)
{
    int i,j;
    double sum_x,sum_y;
    //double edge_mag();
    double em;
    double orient;

    sum_x = sum_y = 0;
    for (i = -WIN; i <= WIN; i++)
        for (j = -WIN; j <= WIN; j++) {
            em = edge_mag(x+i,y+j);
            sum_x += i * em;
            sum_y += j * em;
        }
    orient = atan2(sum_y,sum_x) * RAD_DEG;
    return(orient);
}

/* +++++++++++++++++++++++++ HISTOGRAMMING +++++++++++++++++++++++++ */

/*
 * examine pixel orientations at multiple scales
 * smooth orientation histogram until only NV peaks remain
 * choose smoothing level at which the peaks are largest
 * return difference between position of peaks
 * i.e. subtended angle
 */
double angle_subt2(int x,int y)
{
    int i,j;
    double dx,dy,mag,max_mag,angle;
    int best_angle,angle2;
    double hist[BIN];
    double histS[BIN];
    int count,prev_count;
    //int count_peaks();

    /* initialise orientation histogram */
    for (i = 0; i < BIN; i++)
        hist[i] = 0;

    /* generate orientation histogram */
    for (i = -WIN; i <= WIN; i++)
        for (j = -WIN; j <= WIN; j++) {
            /* swap around - this is messy! */
            dy = gx[x+i][y+j];
            dx = gy[x+i][y+j];
            if (dx != 0) {
                angle = atan(dy/dx);
                angle *= 180.0/PI;
                /* a hack until I sort it out properly... */
                if (angle < 0) angle += 360;
                if (angle > 360) angle -= 360;
                if (angle > 180) angle -= 180;
                mag = sqrt(dx*dx+dy*dy);
                hist[(int)(angle/180*BIN+0.5)%BIN] += mag;
            }
        }

    /* iteratively smooth orientation histogram to get NV peaks */

    count = prev_count = count_peaks(hist);
    if (count < NV)
        count = -1;
    else
        measure_peaks(hist,&mag,&angle2);

    max_mag = mag;
    best_angle = angle2;

    /* initialise histS for while loop */
    for (i = 0; i < BIN; i++)
        histS[i] = hist[i];

    while (count > NV) {
        for (i = 0; i < BIN; i++)
            hist[i] = histS[i];
        smooth_hist(hist,histS);
        count = count_peaks(histS);
        if ((count > NV)|| (prev_count > NV)) {
            measure_peaks(histS,&mag,&angle2);
            if (mag > max_mag) {
                max_mag = mag;
                best_angle = angle2;
            }
        }
        prev_count = count;
    }

    return((double)best_angle);
}

/* count peaks in orientation histogram */
int count_peaks(double hist[])
{
    int i;
    double val1,val2,val3;
    int count = 0;

    for (i = 0; i < BIN; i++) {
        val1 = hist[(i-1+BIN)%BIN];
        val2 = hist[i];
        val3 = hist[(i+1)%BIN];
        if ((val2 > val1) && (val2 > val3))
            count++;
    }
    return(count);
}

/* smooth orientation histogram */
int smooth_hist(double old[],double new[])
{
    int i;
    double val1,val2,val3;

    for (i = 0; i < BIN; i++) {
        val1 = old[(i-1+BIN)%BIN];
        val2 = old[i];
        val3 = old[(i+1)%BIN];
        new[i] = (val1 +val3) * 0.2236 + val2 * 0.5477;
    }
}

/* measure peaks in orientation histogram */
void measure_peaks(double hist[], double *MAG, int *ANG)
{
    int i,j;
    double val1,val2,val3;
    int no_extrema = 0;
    int no_peaks = 0;
    int extrema_type[BIN];
    int extrema_loc[BIN];
    int peak_loc[BIN];
    double extrema_size[BIN];
    double sizes[BIN],tmp;
    double mag,ratio,angle;
    int prev_i,next_i,loc_prev,loc_next;

    /* store locations of peaks & pits */
    for (i = 0; i < BIN; i++) {
        val1 = hist[(i-1+BIN)%BIN];
        val2 = hist[i];
        val3 = hist[(i+1)%BIN];
        if ((val2 > val1) && (val2 > val3)) {
            extrema_type[no_extrema] = PEAK;
            extrema_loc[no_extrema] = i;
            no_extrema++;
        }
        else if ((val2 < val1) && (val2 < val3)) {
            extrema_type[no_extrema] = PIT;
            extrema_loc[no_extrema] = i;
            no_extrema++;
        }
    }

    /* measure size of hills */
    for (i = 0; i < no_extrema; i++) {
        if (extrema_type[i] == PEAK) {
            if (i == 0)
                prev_i = no_extrema-1;
            else
                prev_i = i-1;
            if (i == no_extrema-1)
                next_i = 0;
            else
                next_i = i+1;

            loc_prev = extrema_loc[prev_i];
            loc_next = extrema_loc[next_i];

            extrema_size[i] = 0;
            for (j = (loc_prev+1)%BIN; j != loc_next; j = (j+1)%BIN)
            {
                extrema_size[i] += hist[j];
            }
        }
    }

    /* copy peak sizes */
    for (i = 0; i < no_extrema; i++) {
        if (extrema_type[i] == PEAK) {
            sizes[no_peaks] = extrema_size[i];
            peak_loc[no_peaks] = extrema_loc[i];
            no_peaks++;
        }
    }
    /* sort peaks by size */
    for (i = 0; i < no_peaks-1; i++) {
        for (j = i+1; j < no_peaks; j++) {
            if (sizes[i] > sizes[j]) {
                tmp = sizes[i];
                sizes[i] = sizes[j];
                sizes[j] = tmp;

                tmp = peak_loc[i];
                peak_loc[i] = peak_loc[j];
                peak_loc[j] = tmp;
            }
        }
    }

    /* sum NV biggest peaks & subtract remaining peaks */
    mag = 0;
    for (i = no_peaks-NV; i < no_peaks; i++) {
        mag += sizes[i];
    }
    for (i = 0; i < no_peaks-NV; i++) {
        mag -= sizes[i];
    }

    /* scale by ratio between largest & smallest main peaks */
    ratio = sizes[no_peaks-NV]/sizes[no_peaks-1];

    mag *= ratio;

    *MAG = mag;
    angle = ABS(peak_loc[no_peaks-1]-peak_loc[no_peaks-NV]);
    angle *= 180;
    angle /= BIN;
    *ANG = angle;
}

/* ------------------------------------------------------------ */

/* calculate orientation */
void calc_orientation(int x,int y,double *orient)
{
    int colour = 251;
    double angle,sub_angle,contrast,sd;
    //double get_orientation1(),get_orientation6(),get_orientation7();

    if (do_plot_angle1) angle = get_orientation1(x,y);
    if (do_plot_angle4) thresh_tsai(x,y,&sub_angle,&angle,&colour,&contrast,&sd);
    if (do_plot_angle6) angle = get_orientation6(x,y);
    if (do_plot_angle7) angle = get_orientation7(x,y,0);
    if (do_plot_angle8) angle = get_orientation7(x,y,1);
    if (do_plot_angle9) angle = get_orientation7(x,y,2);
    *orient = angle;
    if (angle == -1) return;
    angle *= PI/180.0;    
}

/* +++++++++++++++++++++++++ DERIVATIVES +++++++++++++++++++++++++ */

/* calculate 1st & 2nd directional derivatives using Sobel operator */
void calc_derivatives()
{
    int x,y;

    for (y=1;y<height-1;y++) {
        for (x=1;x<width-1;x++) {
           gx[x][y] = (double)image_in[x-1][y-1] +
                      (double)image_in[x][y-1]*2 +
                      (double)image_in[x+1][y-1] -
                      (double)image_in[x-1][y+1] -
                      (double)image_in[x][y+1]*2 -
                      (double)image_in[x+1][y+1];
    
           gy[x][y] = (double)image_in[x-1][y-1] +
                      (double)image_in[x-1][y]*2 +
                      (double)image_in[x-1][y+1] -
                      (double)image_in[x+1][y-1] -
                      (double)image_in[x+1][y]*2 -
                      (double)image_in[x+1][y+1];
        }
    }

    for (y=1;y<height-1;y++) {
        for (x=1;x<width-1;x++) {
           gxx[x][y] = (double)gx[x-1][y-1]+
                       (double)gx[x][y-1]*2+
                       (double)gx[x+1][y-1]-
                       (double)gx[x-1][y+1]-
                       (double)gx[x][y+1]*2-
                       (double)gx[x+1][y+1];
    
           gxy[x][y] = (double)gx[x-1][y-1]+
                       (double)gx[x-1][y]*2+
                       (double)gx[x-1][y+1]-
                       (double)gx[x+1][y-1]-
                       (double)gx[x+1][y]*2-
                       (double)gx[x+1][y+1];

           gyy[x][y] = (double)gy[x-1][y-1]+
                       (double)gy[x-1][y]*2+
                       (double)gy[x-1][y+1]-
                       (double)gy[x+1][y-1]-
                       (double)gy[x+1][y]*2-
                       (double)gy[x+1][y+1];
        }
    }
}

double edge_mag(int x,int y)
{
    return(sqrt(SQR(gx[x][y])+SQR(gy[x][y])));
}

/* +++++++++++++++++++++++++ NMS +++++++++++++++++++++++++ */

/*
 * perform non-maximal supression on "cornerity"
 * returns binary map in "nms_status"
 * handles plateaus of high values by recursively reducing them to
 * single points
 */
void perform_nms(double cornerity[MAX_SIZE][MAX_SIZE], short nms_status[MAX_SIZE][MAX_SIZE])
{
    int x,y;
    int xx,yy;
    int tx,ty;
    int maximum;
    int border = 3 + nms_win;
    int sumx,sumy,count;

    /* delete points with stronger neighbours */
    for (x = border; x < width-border; x++) {
        for (y = border; y < height-border; y++) {
            maximum = TRUE;
            nms_status[x][y] = OK;
            for (xx = -nms_win; xx <= nms_win && maximum; xx++)
                for (yy = -nms_win; yy <= nms_win && maximum; yy++) {
                    if (xx != 0 || yy != 0) {
                        if (cornerity[x+xx][y+yy] > cornerity[x][y]) {
                            nms_status[x][y] = DELETE1;
                            maximum = FALSE;
                        }
                    }
                }
        }
    }

    /* reduces plateaus of equal strenth to single points */
    /* keep 1st point and delete all following ones */
    for (x = border; x < width-border; x++) {
        for (y = border; y < height-border; y++) {
            if (nms_status[x][y] == OK) {
                sumx = sumy = count = 0;
                delete_neighbourhood(x,y,&sumx,&sumy,&count);
                /* reinstate average corner location */
                tx = (sumx + 0.5) / count;
                ty = (sumy + 0.5) / count;
                nms_status[tx][ty] = OK;
            }
        }
    }
}

/* delete plateau of maximal corners and find sum of x & y locations */
void delete_neighbourhood(int x,int y, int *sumx,int *sumy,int *count)
{
    int xx,yy;
    int border = 3 + nms_win;

    if (x < border) return;
    if (y < border) return;
    if (x >= width-border) return;
    if (y >= height-border) return;

    if (nms_status[x][y] == OK) {
        *sumx += x;
        *sumy += y;
        *count += 1;
        nms_status[x][y] = DELETE1;
        for (yy = -1; yy <= 1; yy++) {
            for (xx = -1; xx <= 1; xx++) {
                if ((xx == 0) && (yy == 0)) continue;
                delete_neighbourhood(x+xx,y+yy,sumx,sumy,count);
            }
        }
    }
}

/* +++++++++++++++++++++++++ THRESHOLDING +++++++++++++++++++++++++ */

/* automatically threshold image using:
 *     Tsai, Moment-prserving thresholding: a new approach,
 *     CVGIP, vol 29, 377-393, 1985
 *
 * only processes a circular area at (xc,yc)
 * co-ordinate offsets of area must be pre-calculated
 *
 * calculates corner parameters:
 *     subtended angle in degrees
 *     orientation in degrees
 *     colour
 *
 * calculates standard deviation of locations of foreground and background
 * regions
 */
void thresh_tsai(int xc,int yc, double *sub_angle,double *orient,int *colour, double *contrast, double *sd)
{
    int x,y,x1,y1,x2,y2;
    int i,t;
    int thr;
    //double moment(),proportion();
    double m1,m2,m3,c0,c1,z,z0,p0;
    double val,prev_val;
    int found = FALSE;
    double black_x,black_y;
    int no_black,no_white;
    double white_x,white_y;
    //double angle();
    double avg_black,avg_white;
    double b_sum_x=0, b_sum2_x=0, b_sum_y=0, b_sum2_y=0, b_sum1_x, b_sum1_y;
    double w_sum_x=0, w_sum2_x=0, w_sum_y=0, w_sum2_y=0, w_sum1_x, w_sum1_y;
    double b_sd_x,b_sd_y,w_sd_x,w_sd_y;
    int min,mid,max;

    m1 = moment(1,xc,yc);
    m2 = moment(2,xc,yc);
    m3 = moment(3,xc,yc);
    c0 = (m1*m3 - SQR(m2)) / (m2 - SQR(m1));
    c1 = (m1*m2 - m3) / (m2 - SQR(m1));
    z = (sqrt(SQR(c1)-4*c0) - c1) / 2.0;
    p0 = (z-m1) / sqrt(SQR(c1)-4*c0);
    z0 = (-sqrt(SQR(c1)-4*c0) - c1) / 2.0;

    /*
    printf("chosen p-tile: %f\n",p0);
    printf("intensity values of classes: %.1f %.1f\n",z0,z);
    */

    min = 0; max = 255;
    /* find appropriate threshold to produce p-tile p0 */
    do {
        mid = (max + min) / 2;
        val = proportion((int)mid,xc,yc);
        if (val > p0)
            max = mid;
        else
            min = mid;
    } while (min < (max-1));
    thr = mid;
    if (thr > z) thr = z;                    // hack - ADDED 5/2019 - PLR
    //printf("thresholding at %d\n",thr);

    /*** replaced by above - 5/2019 - PLR
    thr = -1;
    prev_val = 9e99;
    for (t = 0; (t < 256) && (!found); t++) {
        val = proportion(t,xc,yc);

        if (val > p0) {
            found = TRUE;
            if (ABS(p0-val) < ABS(p0-prev_val))
                thr = t;
            else
                thr = t-1;
        }

        prev_val = val;
    }
    if (thr == -1) {
        fprintf(stderr,"ERROR: cannot find appropriate threshold at (%d %d)\n",xc,yc);
        exit(-1);
    }
    ***/

    /* actually threshold image now */
    /* also calculate centroids & sizes */
    no_black = black_x = black_y = no_white = white_x = white_y = 0;
    avg_black = avg_white = 0;
    for (i = 0; i < circle_area; i++) {
        x = circ_x[i]; y = circ_y[i];
        x1 = x + xc; y1 = y + yc;
        x2 = x + MAX_RADIUS; y2 = y + MAX_RADIUS;
        if ((unsigned int)image_in[x1][y1] < thr) {
            image_thr[x2][y2] = 0;
            black_x += x2; black_y += y2;
            save_blacks[no_black] = image_in[x1][y1];
            avg_black += image_in[x1][y1];
            no_black++;

            /* use to calculate SD of position */
            b_sum_x += x;
            b_sum2_x += SQR(x);

            b_sum_y += y;
            b_sum2_y += SQR(y);
        }
        else {
            image_thr[x2][y2] = 128;
            white_x += x2; white_y += y2;
            save_whites[no_white] = image_in[x1][y1];
            avg_white += image_in[x1][y1];
            no_white++;

            /* use to calculate SD of position */
            w_sum_x += x;
            w_sum2_x += SQR(x);

            w_sum_y += y;
            w_sum2_y += SQR(y);
        }
    }
    if ((no_black == 0) || (no_white == 0)) {
        fprintf(stderr,"ERROR: thresholding at (%d %d)\n",xc,yc);
        return;
    }

    black_x /= (double)no_black; black_y /= (double)no_black;
    white_x /= (double)no_white; white_y /= (double)no_white;
    avg_black /= (double)no_black;
    avg_white /= (double)no_white;

    /* calculate SD of position */
    b_sum1_x = SQR(b_sum_x / (double)no_black);
    b_sum2_x /= (double)no_black;
    b_sd_x = sqrt(b_sum2_x - b_sum1_x);

    b_sum1_y = SQR(b_sum_y / (double)no_black);
    b_sum2_y /= (double)no_black;
    b_sd_y = sqrt(b_sum2_y - b_sum1_y);

    w_sum1_x = SQR(w_sum_x / (double)no_white);
    w_sum2_x /= (double)no_white;
    w_sd_x = sqrt(w_sum2_x - w_sum1_x);

    w_sum1_y = SQR(w_sum_y / (double)no_white);
    w_sum2_y /= (double)no_white;
    w_sd_y = sqrt(w_sum2_y - w_sum1_y);

    /* return average SD of X & Y deviations of foreground & background */
    *sd = (b_sd_x + b_sd_y + w_sd_x + w_sd_y) / 4.0;

    if (do_contrast4) {
        sort(no_black,save_blacks);
        sort(no_white,save_whites);
        avg_black = save_blacks[no_black/2];
        avg_white = save_whites[no_white/2];
    }

    *contrast = avg_white - avg_black;
    if (p0 > 0.5) {
        *sub_angle = (1 - p0) * 360;
        *orient = angle(black_x,black_y,white_x,white_y) * RAD_DEG;
        *colour = LIGHT;
    }
    else {
        *sub_angle = p0 * 360;
        *orient = angle(white_x,white_y,black_x,black_y) * RAD_DEG;
        *colour = DARK;
    }
}

/* return j'th grey-level moment of image */
/* I think it is okay according to the paper, but it's rather strange */
double moment(int j,int xc,int yc)
{
    int x,y,x1,y1;
    int i;
    double sum;

    sum = 0;
    for (i = 0; i < circle_area; i++) {
        x = circ_x[i];
        y = circ_y[i];
        x1 = x + xc; y1 = y + yc;
        sum += pow((float)image_in[x1][y1],(float)j);
    }

    return(sum / (double)circle_area);
}

/* ----------------------- new attempt at moments ----------------------- */

double moment_new(int xc,int yc,int p)
{
    int x,y,x1,y1;
    int i;
    double im;
    double sum;

    sum = 0;
    for (i = 0; i < circle_area; i++) {
        x = circ_x[i];
        y = circ_y[i];
        x1 = x + xc; y1 = y + yc;
        im = (unsigned int)image_in[x1][y1];
        sum += pow(im,(double)p);
    }

    return(sum);
}

double normalise_angle(double a)
{
    if ((a >= 0) && (a < 360))
        return(a);
    else {
        if (a >= 360) a -= 360;
        if (a < 0) a += 360;
        return(normalise_angle(a));
    }
}

/* subtended angle using moments */
void moment_attributes(int x,int y, double *contrast,double *angle, double *f,double *b)
{
    double t;
    double m1,m2,m3;
    //double moment_new();
    double ang,m,n = circle_area;

    m1 = moment_new(x,y,1);
    m2 = moment_new(x,y,2);
    m3 = moment_new(x,y,3);

    t = sqrt(
          -3 * SQR(m1) * SQR(m2) + 4 * CUBE(m1) * m3 + 4 * CUBE(m2) * n
          -6 * m1 * m2 * m3 * n + SQR(m3) * SQR(n)
        );

    *contrast = t / (m2 * n - SQR(m1));

    /* subtended angle directly from moments */
    m = ( (SQR(m1) - m2 * n) * m1 - (n / 2)*(m1 * m2 - m3 * n - t) ) / t;
    /* angle in [0,180) */
    if (m > (n-m))
        m = n - m;
    ang = 360 * (m / n);

    /* subtended angle using F & B */
    *f = (m1*m2 - m3 * n - t) / (2 * (SQR(m1) - n * m2));
    *b = (m1*m2 - m3 * n + t) / (2 * (SQR(m1) - n * m2));
     
    /*
    m = (m1 - n * *b) / c;
    ang = 360 * (m / n);
    */

    *angle = ang;
}

/* -------------------- end new attempt at moments -------------------- */

/* return proportion of black in image thresholded at t */
double proportion(int t,int xc,int yc)
{
    int x,y,x1,y1;
    int i;
    int count1;

    count1 = 0;
    for (i = 0; i < circle_area; i++) {
        x = circ_x[i];
        y = circ_y[i];
        x1 = x + xc; y1 = y + yc;
        if ((unsigned int)image_in[x1][y1] < t)
           count1++;
    }

    return(count1 / (double)circle_area);
}

/*
 * store cordinates of points lying within a circle of radius r
 * and centred at origin
 * also calculate area (number of pixels) of circle
 */
void setup_circle(int r)
{
    int x,y;
    double d2,r2;

    circle_area = 0;
    r2 = SQR(r);

    for (y = -r; y <= r; y++) {
        for (x = -r; x <= r; x++) {
            d2 = SQR(x) + SQR(y);
            if (d2 <= r2) {
                circ_x[circle_area] = x;
                circ_y[circle_area] = y;
                circle_area++;
            }
        }
    }
}

/* sum of the differences of the intensities in the top and bottom halves
 * of the image window
 */
double check_sum1()
{
    double sum = 0,i1,i2;
    int x,y;

    for (x = 0; x < WIN*2+1; x++) {
        for (y = 0; y <= WIN; y++) {
            i1 = (unsigned int)rot_im[x][WIN-y];
            i2 = (unsigned int)rot_im[x][WIN+y];
            sum += ABS(i1 - i2);
        }
    }

    return(sum);
}

/* sum of the differences of the summed row intensities in the top and bottom
 * halves of the image window
 */
double check_sum2()
{
    double sum1,sum2,sum3;
    int x,y;

    sum3 = 0;
    for (y = 0; y <= WIN; y++) {
        sum1 = sum2 = 0;
        for (x = 0; x < WIN*2+1; x++) {
            sum1 += (unsigned int)rot_im[x][WIN-y];
            sum2 += (unsigned int)rot_im[x][WIN+y];
        }
        sum3 += ABS(sum2-sum1);
    }

    return(sum3);
}

/* difference of the sums of the intensities in the top and bottom halves
 * of the image window
 */
double check_sum3()
{
    double sum1 = 0, sum2 = 0;
    int x,y;

    for (x = 0; x < WIN*2+1; x++) {
        for (y = 0; y <= WIN; y++) {
            sum1 += rot_im[x][y];
        }
    }

    for (x = 0; x < WIN*2+1; x++) {
        for (y = WIN; y < WIN*2+1; y++) {
            sum2 += rot_im[x][y];
        }
    }

    return(ABS(sum2-sum1));
}

/* rotate image window around detected corner */
/* use bilinear interpolation */
void rotate(int xc,int yc,double theta)
{
    double cosine,sine;
    int x,y,x3,y3;
    double x2,y2;
    double p,q;

    theta = theta * PI / 180.0;
    sine = sin(theta);
    cosine = cos(theta);
    for (y = -WIN; y <= WIN; y++) {
        for (x = -WIN; x <= WIN; x++) {
            x2 = x*cosine - y*sine;
            y2 = x*sine   + y*cosine;
            x2 += xc;
            y2 += yc;

            x3 = floor(x2); y3 = floor(y2);
            q = x2 - x3; p = y2 - y3;

            if ((x3 >= 0) && (x3 < width-1) &&
                (y3 >= 0) && (y3 < height-1))
            {
                rot_im[x+WIN][y+WIN] =
                    (1 - p) * (1 - q) * image_in[x3][y3] +
                    q       * (1 - p) * image_in[x3+1][y3] +
                    p       * (1 - q) * image_in[x3][y3+1] +
                    p       * q       * image_in[x3+1][y3+1];
            }
        }

    }
}

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

double angle(double x1,double y1,double x2,double y2)
{
    double angle_temp;
    double xx,yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if (xx == 0.0)
        angle_temp = PI / 2.0;
    else
        angle_temp = atan(fabs(yy / xx));
    if ((xx < 0.0) && (yy >= 0.0))
        angle_temp = PI - angle_temp;
    else if ((xx < 0.0) && (yy < 0.0))
        angle_temp = PI + angle_temp;
    else if ((xx >= 0.0) && (yy < 0.0))
        angle_temp = PI * 2.0 - angle_temp;
    return (angle_temp);
}

/* from numerical recipes in C */
void sort(int n, int ra[])
{
    int l,j,ir,i;
    int rra;

    l=(n >> 1)+1;
    ir=n;
    for (;;) {
        if (l > 1)
            rra=ra[--l];
        else {
            rra=ra[ir];
            ra[ir]=ra[1];
            if (--ir == 1) {
                ra[1]=rra;
                return;
            }
        }
        i=l;
        j=l << 1;
        while (j <= ir) {
            if (j < ir && ra[j] < ra[j+1]) ++j;
            if (rra < ra[j]) {
                ra[i]=ra[j];
                j += (i=j);
            }
            else j=ir+1;
        }
        ra[i]=rra;
    }
}

/* get corner angle by intensity magnitude weighted centroid */
/* +++++##### STILL NEED TO ACCOUNT FOR COLOUR #####+++++ */
double get_orientation6(int x,int y)
{
    int i,j;
    double sum_x,sum_y;
    int in;
    double orient;

    sum_x = sum_y = 0;
    for (i = -WIN; i <= WIN; i++)
        for (j = -WIN; j <= WIN; j++) {
            in = image_in[x+i][y+j];
            sum_x += i * in;
            sum_y += j * in;
        }
    orient = atan2(sum_y,sum_x) * RAD_DEG;
    return(orient);
}

/* find orientation of corner by finding most symmetrical rotation */
double get_orientation7(int x,int y,int flag)
{
    double i;
    double sym,min_sym,best_ang;
    double check_sum1(),check_sum2(),check_sum3();
    double a;

    /* #### if this is way out, then it leads to problems... #### */
    /* initial estimate of orientation */
    a = get_orientation5(x,y);

    best_ang = 0;
    min_sym = 9e9;
    for (i = floor(a) - 90; i < floor(a) + 90; i += 1) {
    /*
    for (i = 0; i < 360; i += 1) {
    */
        rotate(x,y,i);
        if (flag == 0) sym = check_sum1();
        else if (flag == 1) sym = check_sum2();
        else sym = check_sum3();
        if (sym < min_sym) {
            min_sym = sym;
            best_ang = i;
        }
    }
    return((double)best_ang);
}

