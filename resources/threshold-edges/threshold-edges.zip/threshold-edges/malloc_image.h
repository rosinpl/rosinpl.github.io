//#include <malloc.h>

extern unsigned char ** malloc_char_image(int xres,int yres);
extern int ** malloc_int_image(int xres,int yres);
extern long ** malloc_long_image(int xres,int yres);
extern float ** malloc_float_image(int xres,int yres);
extern double ** malloc_double_image(int xres,int yres);
