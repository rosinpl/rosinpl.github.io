function saliency1=testsaliency(p,t,numface,numscale)
%Input: p is a mx3 vertex matrix; t is the nx3 connectivity matrix;
%       numface is the number of faces of the simplified mesh; 
%numscale is the number of scales used in saliency detection; 
% Suggested settings: numface=3000, numscale=5;
%   The method is based on the following paper
%       Ran Song, Yonghuai Liu, Ralph Martin, Paul Rosin
%       Mesh Saliency via Spectral Processing,
%       ACM Transactions on Graphics, vol. 33, no. 1, article 6, 2014.
%   Copyright (c) 2014 Ran Song

sal=zeros(length(p),numscale);
sali=zeros(length(p),numscale-1);

[p1,t1] = perform_mesh_simplification(p,t,numface);
 A = triangulation2adjacency(t1);
for i=1:numscale
    if i~=1
        alp=1-0.05*(i-1);
        p1=sms(p1,t1,1,alp);
    end

W = my_euclidean_distance(A,p1);
W(W>0) = 1./W(W>0);
W = (W+W')/2;  
L = diag(sum(W,2)) - W;
% L = compute_mesh_laplacian(p1,t1,type,options);
[V,e]=eig(full(L));
% [V,e]=eigs(L,length(L));
e=diag(e);
% e(1)=0.5*e(2);
e1=log(abs(e));

e2=[e1(1); e1(1);e1(1); e1(1);e1;e1(end);e1(end);e1(end);e1(end)];
% e2=e1(5:end-4);

a2=filter(ones(1,9)/9,1,e2);

% a1=[a2(1);a2(1);a2(1);a2(1);a2;a2(end);a2(end);a2(end);a2(end)];
a1=a2(9:end);

s1=abs(e1-a1);

s2=exp(s1);
D=diag(s2);
L1=V*D*V';

f=L1.*W;
sa=sum(f,2);
sa = perform_mesh_smoothing(t1,p1,sum(f,2),A);

  cc=std(sa)/max(sa); %optional thresholding 

if cc<0.07 || cc>2
    sali(:,i:end)=0;
    continue;
end

ptrtree=BuildGLTree3D(p1');
knng=KNNSearch3D(p1',p',ptrtree,1);
DeleteGLTree3D(ptrtree);

sal(:,i)=sa(knng);

if i~=1
    sali(:,i-1)=abs(sal(:,i)-sal(:,i-1));
end
end
salie=sum(sali,2);
% clear p1 t1 L L1 D s2 s1 e e1 e2 a1 a2 sal sali sa f W V knng;
% salie=log(sum(sali,2));
A1=triangulation2adjacency(t);
saliency = perform_mesh_smoothing(t,p,salie,A1); %If the saliency map is not smooth, please run the smoothing for several times.

saliency1=log(saliency);
%   figure,trisurf(t,p(:,1),p(:,2),p(:,3),saliency,'edgecolor','none');axis equal;shading interp;
figure,trisurf(t,p(:,1),p(:,2),p(:,3),saliency1,'edgecolor','none');axis equal;shading interp;view(0,0);axis off;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function W = my_euclidean_distance(A,vertex)

if size(vertex,1)<size(vertex,2)
    vertex = vertex';
end

[i,j,s] = find(sparse(A));
d = sum( (vertex(i,:) - vertex(j,:)).^2, 2);
W = sparse(i,j,d);  
end

function A = triangulation2adjacency(face)
f = double(face);

A = sparse([f(:,1); f(:,1); f(:,2); f(:,2); f(:,3); f(:,3)], ...
           [f(:,2); f(:,3); f(:,1); f(:,3); f(:,1); f(:,2)], ...
           1.0);
% avoid double links
A = double(A>0);
return; 
% nvert = max(max(face));
% nface = size(face,1);
% A = spalloc(nvert,nvert,3*nface);
% 
% for i=1:nface
%     for k=1:3
%         kk = mod(k,3)+1;
%         if nargin<2
%             A(face(i,k),face(i,kk)) = 1;
%         else
%             v = vertex(:,face(i,k))-vertex(:,face(i,kk));
%             A(face(i,k),face(i,kk)) = sqrt( sum(v.^2) );    % euclidean distance
%         end
%     end
% end 
% % make sure that all edges are symmetric
% A = max(A,A');
end

function f = perform_mesh_smoothing(face,vertex,f,A)

if isempty(f)
    f = vertex;
end
if size(f,1)<size(f,2)
    f = f';
end

if size(f,2)>1
    for i=1:size(f,2)
        f(:,i) = perform_mesh_smoothing(face,vertex,f(:,i),A);
    end
    return;
end

n = max(face(:));

% compute normalized averaging matrix

    %add diagonal
    W = A + speye(n);
    D = spdiags(full(sum(W,2).^(-1)),0,n,n);
    W = D*W;


% do averaging to smooth the field
    f = W*f;
 end
