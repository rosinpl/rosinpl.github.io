/*
 *    compute CONVEXITY of curve
 *
 *    input:  pixel list
 *    output: pixel list - this is optional; input curve is rotated to minimise convexity term
 *
 *    when computing perimeter I duplicate the first pixel at the end
 *    i.e. I am assuming (or making) the input curve closed
 *
 *    method:
 *        minimise ratio of perimeter of axis aligned bounding rectangle to
 *        L1 perimeter of shape
 *    sensitive to noise, so it's best to simplify the curve first
 *
 *    only test angles of convex hull edges and input polygon edges
 *
 *    Paul Rosin
 *    March 2002
 *
 *    updated to use convex hull edges
 *    March 2007
 *
 *    please cite:
 *    J. Zunic and P.L. Rosin, "A New Convexity Measure for Polygons",
 *    IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 26, no. 7, pp. 923-934, 2004
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_PIXELS 10000

#define PI 3.1415926

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define ABS(x)       (((x)<0.0)? (-(x)): (x))
#define SQR(a)       ((a)*(a))
#define MAX(a,b)     (((a) > (b)) ? (a) : (b))
#define MIN(a,b)     (((a) < (b)) ? (a) : (b))

int no_pixels;
int xdata[MAX_PIXELS],ydata[MAX_PIXELS];
double xrot[MAX_PIXELS],yrot[MAX_PIXELS];
double thetas[MAX_PIXELS];

void convex_hull(double *p, int n, int *ch, int *p_nch, char *directions, double epsilon);
void read_link_data(FILE *fp, int *endoffile);
void make_rotation_matrix(double cos_theta,double sin_theta,double *m);
double convexity();
void transform(double xshift, double yshift, double theta);
void centroid(double *pts, int n, double *p_cen_x, double *p_cen_y);
void output_pixels();
void usage(char *progname);
int main(int argc, char *argv[]);

FILE *fp_in,*fp_out;

int main(int argc, char *argv[])
{
    char *infile,*outfile,file_type[50];
    int i,j;
    int endoffile;
    double theta,c;
    double min_c,min_t;
    double p[MAX_PIXELS*2];
    int n1,n2;
    int ch[MAX_PIXELS];
    int nch;
    static char directions[] = "norm";
    double epsilon = 0.001;
    double dx,dy,x1,y1,x2,y2;
    int no_angles;
    double xc,yc;

    infile = outfile = NULL;

    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            switch(argv[i][1]) {
                case 'i':
                    i++;
                    infile = argv[i];
                    break;
                case 'o':
                    i++;
                    outfile = argv[i];
                    break;
                default:
                    fprintf(stderr,"ERROR: unknown option %s\n",argv[i]);
                    usage(argv[0]);
                    exit(-1);
            }
        }
        else {
            fprintf(stderr,"ERROR: unknown option %s\n",argv[i]);
            usage(argv[0]);
            exit(-1);
        }
    }

    if (infile == NULL) {
        fprintf(stderr,"need input & output files\n");
        usage(argv[0]);
        exit(-1);
    }

    if ((fp_in=fopen(infile,"r")) == NULL) {
        printf("cant open %s\n",infile);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp_in,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0) {
        printf("not link data file - aborting\n");
        exit(-1);
    }

    if (outfile != NULL) {
        if ((fp_out=fopen(outfile,"w")) == NULL) {
            printf("cant open %s\n",outfile);
            exit(-1);
        }
        fprintf(fp_out,"pixel\n");
    }

    do {
        read_link_data(fp_in,&endoffile);
        if ((xdata[0] == xdata[no_pixels-1]) && (ydata[0] == ydata[no_pixels-1]))
            no_pixels--;

        /* generate convex hull */
        for (i = 0; i < no_pixels; i++) {
            p[i*2] = xdata[i];
            p[i*2+1] = ydata[i];
        }
        n1 = no_pixels;
    
        convex_hull(p,n1,ch,&nch,directions,epsilon);
    
        /* go through all CH edges storing angles */
        no_angles = 0;
        for (i = 0; i < nch; i++) {
            n1 = ch[i];
            n2 = (ch[(i+1) % nch]);
            if (n1 == n2) continue;
            x1 = xdata[n1];
            y1 = ydata[n1];
            x2 = xdata[n2];
            y2 = ydata[n2];
            dx = x2 - x1; dy = y2 - y1;
            thetas[no_angles++] = atan2(dy,dx);
        }
        /* also go through original polygon edges storing angles */
        for (i = 0; i < no_pixels; i++) {
            x1 = xdata[i];
            y1 = ydata[i];
            x2 = xdata[(i+1)%no_pixels];
            y2 = ydata[(i+1)%no_pixels];
            dx = x2 - x1; dy = y2 - y1;
            thetas[no_angles++] = atan2(dy,dx);
        }

        min_c = 9e9;
        for (i = 0; i < no_angles; i++) {
            theta = thetas[i];
            transform(0.0,0.0,theta);
            c = convexity();
            /*
            printf("%f %f\n",theta,c);
            */
            if (c < min_c) {
                min_c = c;
                min_t = theta;
            }
        }
        //printf("min convexity at = %.3f rad = %.1f deg\n",min_t,min_t*180.0/PI);

        c = min_c;

        if (outfile != NULL) {
            xc = yc = 0;
            for (i = 0; i < no_pixels; i++) {
                xc += xdata[i];
                yc += ydata[i];
            }
            xc /= no_pixels;
            yc /= no_pixels;

            transform(-xc,-yc,min_t);
            output_pixels();
        }

        printf("convexity = %f\n",c);
        //printf("convexity = %.3f\n",c);

    } while (!endoffile);

    fclose(fp_in);
    if (outfile != NULL)
        fclose(fp_out);
}

void output_pixels()
{
    int i;

    fprintf(fp_out,"list: 0\n");
    for (i = 0; i < no_pixels; i++)
        fprintf(fp_out,"%.0f %.0f\n",xrot[i],yrot[i]);
    fprintf(fp_out,"-1 0\n");
}

double convexity()
{
    int i;
    double dx,dy,px,py;
    double sum_projections;
    double c;
    double min_x,max_x,min_y,max_y;
    double perim_rectangle;

    /* duplicate first pixel at end */
    xrot[no_pixels] = xrot[0];
    yrot[no_pixels] = yrot[0];

    max_x = min_x = xrot[0];
    max_y = min_y = yrot[0];
    px = py = 0;
    for (i = 0; i < no_pixels; i++) {
        max_x = MAX(max_x,xrot[i]);
        min_x = MIN(min_x,xrot[i]);
        max_y = MAX(max_y,yrot[i]);
        min_y = MIN(min_y,yrot[i]);

        dx = xrot[i+1] - xrot[i];
        dy = yrot[i+1] - yrot[i];
        px += ABS(dx);
        py += ABS(dy);
    }

    sum_projections = px + py;
    perim_rectangle = 2 * (max_x - min_x) + 2 * (max_y - min_y);

    c = perim_rectangle / sum_projections;

    return c;
}

// modified version that shifts back
void transform(double xshift, double yshift, double theta)
{
    int i;
    double temp,xt,yt;
    double sine,cosine;

    /* translate */
    for (i = 0; i < no_pixels; i++) {
        xrot[i] = xdata[i] + xshift;
        yrot[i] = ydata[i] + yshift;
    }

    /* rotate */
    if (theta != 0) {
        sine = sin(-theta);
        cosine = cos(-theta);
        for (i = 0; i < no_pixels; i++) {
            xt = xrot[i];
            yt = yrot[i];
            temp = xt*cosine - yt*sine;
            xrot[i] = temp;
            temp = xt*sine + yt*cosine;
            yrot[i] = temp;
        }
    }

    /* translate back */
    for (i = 0; i < no_pixels; i++) {
        xrot[i] -= xshift;
        yrot[i] -= yshift;
    }
}

void read_link_data(FILE *fp, int *endoffile)
{
    char dumstring[50];
    int j;

    fscanf(fp,"%s %d\n",dumstring,&j);
    j = -1;
    do{
       j++;
       fscanf(fp,"%d %d\n",&xdata[j],&ydata[j]);
    } while(xdata[j] != -1);
    *endoffile = (ydata[j] == -1);
    if (feof(fp) && !(*endoffile)) {
        fprintf(stderr,"Incorrectly terminated file - assuming end of list\n");
        *endoffile = TRUE;
    }
    no_pixels = j;
}

void usage(char *progname)
{
    printf("usage: %s -i infile\n",progname);
    printf("options:\n");
    printf("         -o  file  output normalised curve\n");
    exit(-1);
}

/* ############################################################ */

/* 
convexhull.c

Find the convex hull of a set of points.

The algorithm used is as describe in 

Shamos, Michael,  "Problems
in Computational Geometry"  May, 1975 (a set of photocopies -- 
QA 447.S52 1983 in Carlson).  

It originally appeared in a more complicated form in 

Jarvis, R.A., "On the Identification of the Convex Hull of a 
Finite Set of Points in the Plane", Info. Proc. Letters 2(1973),
pp. 18-21.

The algorithm is of complexity k*n, where n is the number of points in the
input and k the number of points in the convex hull.

usage:
convex_hull(p,n,ch,&nch,directions);
where p is an n*2 array of doubles containing the set of points,
n is the number of points,
ch is an array of size n integers to hold the list of points in the 
    convex hull, numbered 0 to nch-1;
In nch the number of points in the convex hull is returned.
directions is either "full" or "norm".  If directions="full" all the
possible points on the convex hull are returned.  If directions="norm"
a minimal set of points to describe the convex hull is returned.

epsilon is the angle tolerance in radians.  When two angles are closer than
PI radians they are considered equal.
*/

/* ### CONTENTS OF INCLUDE FILE INSERTED HERE ### */

/* incl.h */

#define boolean int
#define true 1
#define false 0

#define ERROR -1
#define OK 0

#define EPSILON 1.e-6
#define BIGNUM 1.e20

#define sqr(x) ((x)*(x))

/* ### -------------------------------------- ### */

static int debug=0;

void convex_hull(double *p, int n, int *ch, int *p_nch, char *directions, double epsilon)
{
    double phi, max_phi, dist, max_cen_dist, min_dist, max_dist, 
        x, y, cen_x, cen_y, xp, yp, 
    xx, yy, m[2][2];
    int i, i_keep, vertex, furthest, ch_vert;
    boolean full;

    if (!strcmp(directions,"full")) {
    full = true;
    }
    else if (!strcmp(directions,"norm")) {
    full = false;
    }
    else {
    fprintf(stderr,"convex_hull: invalid argument \"%s\"\n",directions);
    exit(ERROR);
    }
    centroid(p,n,&cen_x,&cen_y);
    /* find the point furthest from the centroid */
    max_cen_dist = 0.;
    for (i=0; i<n; i++) {
    x = p[2*i];
    y = p[2*i+1];
    dist = sqrt(sqr(x-cen_x) + sqr(y-cen_y));
    if (dist>max_cen_dist) {
        max_cen_dist = dist;
        furthest = i;
    }
    }

    /* 
    Determine rotation matrix so that coordinate system for determining
    the orientations of line segments is wrt the line from the point
    under consideration to the centroid.  Then all angles will be 
    < 90 degrees.  To maintain the strict inequality the furthest 
    point along the extreme ray will be used as the next point on 
    the convex hull.
    */

    make_rotation_matrix((cen_x-p[furthest*2])/max_cen_dist,
             (cen_y-p[furthest*2+1])/max_cen_dist,(double *)m);
    ch_vert = 0;
    vertex = furthest;

    /* HACK: to avoid loop with problem data - PLR */
    ch[1] = -999;

    do {
        ch[ch_vert] = vertex;
        /* Find the ray with the maximum and minimum angle in the new 
           coordinate system */
        if (debug) printf("vertex %d\n",vertex);
        max_phi = - BIGNUM;
        min_dist = BIGNUM;
        max_dist = 0.;
        for (i=0; i<n; i++) {
            /* calculate phi, the angle in the new coordinate system */
            x = p[2*i] - p[2*vertex];
            y = p[2*i+1] - p[2*vertex+1];
            xp = m[0][0]*x + m[0][1]*y;
            yp = m[1][0]*x + m[1][1]*y;
            if (debug) printf("\ti %d x %f y %f xp %f yp %f\n", i,x,y,xp,yp);
            if ((dist=sqrt(sqr(x)+sqr(y))) > EPSILON) {
                phi = atan2(yp,xp);
                if (debug) printf("\tphi %f\n", phi);
                if (phi > max_phi-epsilon) {
                    if (full) {
                        /* use the closest point */
                        if (phi > max_phi + epsilon || dist < min_dist) {
                            min_dist = dist;
                            max_phi = phi;
                            i_keep = i;
                        }
                    }
                    else {
                        /* use the furthest point */
                        if (phi > max_phi + epsilon || dist > max_dist) {
                            max_dist = dist;
                            max_phi = phi;
                            i_keep = i;
                        }
                    }
                    if (debug) printf("\t\tmax_phi %f i_keep %d\n", max_phi,i_keep);
                }
            }
        }
        vertex = i_keep;
        xx = cen_x - p[vertex*2];
        yy = cen_y - p[vertex*2+1];
        dist = sqrt(sqr(xx) + sqr(yy));
        make_rotation_matrix(xx/dist,yy/dist,(double *)m);
        ch_vert++;
    /*
    } while (vertex != ch[0]);
    */
    /* HACK: to avoid loop with problem data - PLR */
    } while ((vertex != ch[0]) && (vertex != ch[1]));

    *p_nch = ch_vert;
}

void centroid(double *pts, int n, double *p_cen_x, double *p_cen_y)
/* 
Determines the centroid of the set of n points in the n*2 array of
doubles pts and returns its x-coordinate and y-coordinate in p_cen_x
and p_cen_y respectively.
*/
{
    double sumx, sumy;
    int i;

    sumx = sumy = 0;
    for (i=0; i<n; i++) {
    sumx += pts[2*i];
    sumy += pts[2*i+1];
    }
    *p_cen_x = sumx / n;
    *p_cen_y = sumy / n;
}


void make_rotation_matrix(double cos_theta,double sin_theta,double *m)
/* 
Given a unit vector (vx,vy) system, finds the matrix m that
corresponds to rotating the coordinate system so that its x-axis 
lies in the direction defined by (vx,vy).
*/
{
    *m = cos_theta;
    *(m+1) = sin_theta;
    *(m+2) = - sin_theta;
    *(m+3) = cos_theta;
}
