#!/bin/csh -f

# replicate figure 3

foreach i (t_0023-ramer.pix t_0028-ramer.pix t_0027-ramer.pix t_0003-ramer.pix t_0016-ramer.pix t_0018-ramer.pix t_0020-ramer.pix t_0012-ramer.pix t_0010-ramer.pix t_0015-ramer.pix t_0024-ramer.pix t_0013-ramer.pix t_0019-ramer.pix t_0005-ramer.pix t_0009-ramer.pix t_0002-ramer.pix t_0004-ramer.pix t_0026-ramer.pix t_0032-ramer.pix t_0014-ramer.pix)
	echo $i ==========
	
	convexityJ3 -i $i
end
