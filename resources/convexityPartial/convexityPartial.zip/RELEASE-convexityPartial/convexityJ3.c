/*    modify convexityJ2.c to cope with multiple (disjoint) curves
 *
 *    new convexity measure
 *    check random lines between polygon vertices for intersection with polygon
 *    random lines must also lie inside polygon
 *
 *    version that samples points on edges between input polygon vertices
 *    this will cope better with colinear pairs of points
 *
 *    use colinear.c to remove colinear points (may need to run more than once)
 *
 *    NOTE - this gives different results from convexityJ2.c even for single polylines
 *           I can't remember why this is the case
 *           the Electronic Letters paper uses convexityJ3.c
 *
 *    described in:
 *        J. Zunic, P.L. Rosin,
 *        Convexity measure for shapes with partially extracted boundaries,
 *        Electronics Letters, vol. 43, no. 7, pp. 380-382, 2007
 *
 *    Paul Rosin
 *    January 2007
 *
 *    NOTE:  it might be worth adding updated version of doIntersectProper in pix_intersect_cut.c
 *           which added boundingBoxCheck
 *
 *    added fix to ran3
 *    Paul Rosin
 *    August 2018
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define MAX_PIXELS 100000
#define MAX_RAND 500000
#define MAX_LISTS 50

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define ABS(x)    (((x)<0.0)? (-(x)): (x))
#define SQR(x)    ((x)*(x))

/* removed char c field */
typedef struct point { double x, y; } POINT;

POINT data[MAX_LISTS][MAX_PIXELS],polygon[MAX_LISTS][MAX_PIXELS];
int no_polygon[MAX_LISTS];

int no_pixels[MAX_LISTS];
int x[MAX_LISTS][MAX_PIXELS],y[MAX_LISTS][MAX_PIXELS];
int no_lists;

float ran3();

// store random set of index values
int index_rand[MAX_RAND];
int no_random = 100000;

double lengths[MAX_LISTS][MAX_PIXELS];
double cum_lengths[MAX_LISTS][MAX_PIXELS];
double dx[MAX_LISTS][MAX_PIXELS],dy[MAX_LISTS][MAX_PIXELS];
double sum_lengths[MAX_LISTS];

int no_tested,no_ok;

double frac = 0.001;

void find_proportion(int *v,int *l,double *p);
void debug(double x1,double y1,double x2,double y2);
int doIntersectProper(POINT a, POINT b, POINT c, POINT d);
int isColinear(POINT p1, POINT p2, POINT p3);
int isLeft(POINT p1, POINT p2, POINT p3);
double AreaTriangle2(POINT a, POINT b, POINT c);
void read_link_data(FILE *fp, int *endoffile,int *list);
void usage(char *progname);

main(argc,argv)
int argc;
char *argv[];
{
    FILE *fp1;
    char file_type[50];
    int endoffile;
    int list;
    int i,j,k,kk;
    int found_intersection;
    char *infile=NULL;
    double tx,ty;
    int v1,v2;
    int l1,l2;
    double p1,p2;
    double x1,y1,x2,y2;
    double ddx,ddy;
    POINT start,end,middle;
    double total_sum_lengths;

    for (i = 1; i < argc; i++)
       if (argv[i][0] == '-')
          switch (argv[i][1]) {
              case 'f':
                   i++;
                   frac = atof(argv[i]);
                   break;
              case 'n':
                   i++;
                   no_random = atoi(argv[i]);
                   break;
              case 'i':
                   i++;
                   infile = argv[i];
                   break;
              default:
                   usage(argv[0]);
          }
        else
           usage(argv[0]);

    if (infile == NULL)
        usage(argv[0]);

    if ((fp1=fopen(infile,"r")) == NULL){
        printf("cant open %s\n",infile);
        exit(-1);
    }

    /* read magic word for format of file */
    fscanf(fp1,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0){
        printf("not link data file - aborting\n");
        exit(-1);
    }

    no_lists = 0;
    do {
        read_link_data(fp1,&endoffile,&list);

        /* eliminate duplicated end points */
        if ((x[no_lists][0] == x[no_lists][no_pixels[no_lists]-1]) &&
            (y[no_lists][0] == y[no_lists][no_pixels[no_lists]-1]))
            no_pixels[no_lists]--;

        no_lists++;
    } while (!endoffile);
    fclose(fp1);

    /* copy pixel data into polygon structure */
    /* #### CHANGED INDEX FROM i+1 -> i #### */
    /* #### PLR 20/2/06                 #### */
    for (j = 0; j < no_lists; j++) {
        for (i = 0; i < no_pixels[j]; i++) {
            polygon[j][i].x = x[j][i];
            polygon[j][i].y = y[j][i];
        }
        no_polygon[j] = no_pixels[j];
    }

    /* check that there are no colinear triples */
    for (j = 0; j < no_lists; j++) {
        if (no_pixels[j] <= 2) continue;
        for (i = 0; i < no_pixels[j]-1; i++) {
            start.x = x[j][(i-1+no_pixels[j])%no_pixels[j]];
            start.y = y[j][(i-1+no_pixels[j])%no_pixels[j]];
            middle.x = x[j][i];
            middle.y = y[j][i];
            end.x = x[j][(i+1)%no_pixels[j]];
            end.y = y[j][(i+1)%no_pixels[j]];

            if (isColinear(start,middle,end)) {
                fprintf(stderr,"ERROR: colinear triple of points in data (%.1f %.1f) (%.1f %.1f) (%.1f %.1f)\n",
                    start.x,start.y,middle.x,middle.y,end.x,end.y);
                exit(-1);
            }
        }
    }

    // calculate edge lengths
    total_sum_lengths = 0;
    for (j = 0; j < no_lists; j++) {
        sum_lengths[j] = 0;
        for (i = 0; i < no_pixels[j]-1; i++) {
            dx[j][i] = x[j][(i+1)] - x[j][i];
            dy[j][i] = y[j][(i+1)] - y[j][i];
            lengths[j][i] = sqrt(SQR(dx[j][i]) + SQR(dy[j][i]));
            sum_lengths[j] += lengths[j][i];
        }
        total_sum_lengths += sum_lengths[j];
    }

    //printf("total Sum lengths %f\n",total_sum_lengths);

    // normalise lengths to sum to one
    for (j = 0; j < no_lists; j++)
        for (i = 0; i < no_pixels[j]-1; i++)
            lengths[j][i] /= total_sum_lengths;

    // make lengths cumulative
    for (j = 0; j < no_lists; j++) {
        cum_lengths[j][0] = lengths[j][0];
        if (j > 0)
            cum_lengths[j][0] += cum_lengths[j-1][no_pixels[j-1]-2];

        for (i = 1; i < no_pixels[j]-1; i++)
            cum_lengths[j][i] = cum_lengths[j][i-1] + lengths[j][i];
    }

    /***
    for (i = 0; i < no_pixels; i++)
        printf("%7.3f\n",cum_lengths[i]);
    ***/

    // test random pairs of points
    no_tested = no_ok = 0;
    for (i = 0; i < no_random; i++) {
        find_proportion(&v1,&l1,&p1);
        x1 = x[l1][v1] + p1 * dx[l1][v1];
        y1 = y[l1][v1] + p1 * dy[l1][v1];

        find_proportion(&v2,&l2,&p2);
        x2 = x[l2][v2] + p2 * dx[l2][v2];
        y2 = y[l2][v2] + p2 * dy[l2][v2];

        // two points on same edge
        if ((l1 == l2) && (v1 == v2)) {
            //printf("2 POINTS ON SAME EDGE\n");
            no_tested++;
            no_ok++;
            //debug(x1,y1,x2,y2);
            continue;
        }
        /*
        printf("fff %d %f\n",v1,p1);
        printf("%d %d -> %d %d\n",x[v1],y[v1],x[vv1],y[vv1]);
        printf("%.2f %.2f\n",x1,y1);

        printf("fff %d %f\n",v2,p2);
        printf("%d %d -> %d %d\n",x[v2],y[v2],x[vv2],y[vv2]);
        printf("%.2f %.2f\n",x2,y2);

        printf("---------------------\n");
        */

        ddx = x2 - x1;
        ddy = y2 - y1;

        // shrink test line segment by contraction factor
        start.x = x1+ddx*frac; start.y = y1+ddy*frac;
        end.x = x1+ddx*(1-frac); end.y = y1+ddy*(1-frac);

        // test against all edges
        found_intersection = FALSE;
        for (j = 0; j < no_lists; j++) {
            for (k = 0; k < no_polygon[j]-1; k++) {
                kk = (k+1) % no_polygon[j];

                // line segment intersects polygon
                if (doIntersectProper(start,end,polygon[j][k],polygon[j][kk])) {
                    //printf("line segment intersects polygon\n");
                    //debug(start.x,start.y,end.x,end.y);

                    found_intersection = TRUE;
                    break;
                }
            }
        }
        no_tested++;
        if (!found_intersection)
            no_ok++;
    }

    //printf("tested %d lines\n",no_tested);

    printf("convexity = %d / %d = %f\n",
        no_ok, no_tested, (double)no_ok / no_tested);
}

/* get random point
 * it lies a proportion p after vertex indexed by v on list l
 */
void find_proportion(int *v,int *l,double *p)
{
    int i,j;
    double r,prev;
    double proportion;

    r = ran3();

    for (j = 0; j < no_lists; j++) {
        for (i = 0; i < no_pixels[j]-1; i++)
            if (cum_lengths[j][i] >= r) break;
        // break out of outer loop too
        if (cum_lengths[j][i] >= r) break;
    }

    if (i == 0)
        if (j == 0)
            prev = 0;
        else
            prev = cum_lengths[j-1][no_pixels[j-1]-2];
    else
        prev = cum_lengths[j][i-1];

    proportion = (r - prev) / lengths[j][i];

    //printf("r %f   list %d vertex %d   cl %f\n",r,j,i,prev);

    *v = i;
    *l = j;
    *p = proportion;
}

void debug(double x1,double y1,double x2,double y2)
{
    printf("list: 0 ");
    if (x1 < x2)
        printf("%.2f %.2f  %.2f %.2f ",x1,y1,x2,y2);
    else
        printf("%.2f %.2f  %.2f %.2f ",x2,y2,x1,y1);
    printf("-1 0\n");
}

// Test whether lines intersect properly (i.e. lines cross completely).
// (from 'Computational Geometry in C', J. O'Rourke, ode 1.6)
int doIntersectProper(POINT a, POINT b, POINT c, POINT d)
{
    if ((isColinear(a,b,c))||(isColinear(a,b,d))||(isColinear(c,d,a))||(isColinear(c,d,b)))
        return FALSE;
    else
        return (isLeft(a,b,c)^isLeft(a,b,d)) && (isLeft(c,d,a)^isLeft(c,d,b));
}

int isColinear(POINT p1, POINT p2, POINT p3)
{
    if (AreaTriangle2(p1,p2,p3)==0)
        return TRUE;
    else
        return FALSE;
}

int isLeft(POINT p1, POINT p2, POINT p3)
{
    if (AreaTriangle2(p1,p2,p3)>0)
        return TRUE;
    else
        return FALSE;
}

double AreaTriangle2(POINT a, POINT b, POINT c)
{
    // returns twice the signed area of the triangle,m positive is ccw from a to b to c
    return  a.x*b.y-a.y*b.x +
            a.y*c.x-a.x*c.y +
            b.x*c.y-c.x*b.y;
}

#if 0
/* is point (tx,ty) inside the polygon?
 * yes - if the number of intersections with the polygon along a ray from (tx,ty)
 * is an odd number
 */
int inside(tx,ty)
double tx,ty;
{
    int k,kk;
    int count = 0;
    POINT p1,p2;

    p1.x = tx; p1.y = ty;
    /* I am assuming that no polygon vertex lies exactly on p2 */
    p2.x = tx+3.1415926; p2.y = 9e9;

    // test against all edges
    for (k = 0; k < no_polygon; k++) {
        kk = (k+1) % no_polygon;

        if (doIntersectProper(p1,p2,polygon[k],polygon[kk])) {
            count++;
        }
    }

    return (count % 2) == 1;
}
#endif

void read_link_data(FILE *fp, int *endoffile,int *list)
{
    char dumstring[50];
    int j;

    fscanf(fp,"%s %d\n",dumstring,list);
    j = -1;
    do {
       j++;
       fscanf(fp,"%d %d\n",&x[no_lists][j],&y[no_lists][j]);
    } while(x[no_lists][j] != -1);
    *endoffile = (y[no_lists][j] == -1);
    if (feof(fp) && !(*endoffile)) {
        fprintf(stderr,"Incorrectly terminated file - assuming end of list\n");
        *endoffile = TRUE;
    }
    no_pixels[no_lists] = j;
    if (no_pixels[no_lists] >= MAX_PIXELS) {
        fprintf(stderr,"ERROR: Too many pixels\n");
        exit(-1);
    }
}

/*#####################################*/

#define MBIG 1000000000
#define MSEED 161803398
#define MZ 0
#define FAC (1.0/MBIG)

// Returns a uniform random deviate between 0.0 and 1.0. Set idum to any NEGATIVE value to initialize or reinitialize the sequence.
float ran3()
{
    static int inext,inextp;
    static long ma[56];
    static int iff=0;
    long mj,mk;
    int i,ii,k;
    static int idum = -1;

    if (idum < 0 || iff == 0) {
        iff=1;

        //NOTE: I just found this fix on 21/08/2018 - PLR
        //mj=MSEED-(idum < 0 ? -idum : idum);
        mj=abs(MSEED-abs(idum));

        mj %= MBIG;
        ma[55]=mj;
        mk=1;
        for (i=1;i<=54;i++) {
            ii=(21*i) % 55;
            ma[ii]=mk;
            mk=mj-mk;
            if (mk < MZ) mk += MBIG;
            mj=ma[ii];
        }
        for (k=1;k<=4;k++)
            for (i=1;i<=55;i++) {
                ma[i] -= ma[1+(i+30) % 55];
                if (ma[i] < MZ) ma[i] += MBIG;
            }
        inext=0;
        inextp=31;
        idum=1;
    }
    if (++inext == 56) inext=1;
    if (++inextp == 56) inextp=1;
    mj=ma[inext]-ma[inextp];
    if (mj < MZ) mj += MBIG;
    ma[inext]=mj;
    return mj*FAC;
}

#undef MBIG
#undef MSEED
#undef MZ
#undef FAC

void usage(char *progname)
{
    printf("usage: %s -i infile\n",progname);
    printf("options:\n");
    printf("         -n  number of sampled points (default: %d)\n",no_random);
    printf("         -f  fraction contraction of test lines [0->0.5] (default: %f)\n",frac);
    exit(-1);
}
