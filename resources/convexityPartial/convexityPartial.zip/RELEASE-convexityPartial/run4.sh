#!/bin/csh -f

# replicate figure 4

foreach i (disney3-ramer.pix disney2-ramer.pix disney4-ramer.pix matisse1-ramer.pix matisse4-ramer.pix matisse3-ramer.pix seuss4-ramer.pix seuss3-ramer.pix seuss1-ramer.pix)
	echo $i ==========
	
	convexityJ3 -i $i
end
