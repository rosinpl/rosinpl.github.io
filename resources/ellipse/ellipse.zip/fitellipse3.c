/* stripped down and tidied version of fitellipse1.c
 *
 * fit an ellipse to data containing outliers using many different methods
 * most are based on:
 *    1/ doing lots of 5 point fits
 *    2/ choosing the best one
 *    3/ flagging the inliers
 *    4/ polishing (i.e. refitting to inliers using standard least squares algebraic distance criterion)
 *
 * this program is quite old, so there may be a few strange legacy bits in it
 * e.g. I access xdata & ydata from 1..n for some reason
 *
 * input format:  pixel list (integer or float format)
 * output format: superdata or Postscript
 *
 * The methods are described in the following papers:
 *
 * P.L. Rosin, "Further five-point fit ellipse fitting", Graphical Models and Image Processing, vol. 61, no. 5, pp. 245-259, 1999.
 * P.L. Rosin, "A note on the least squares fitting of ellipses", Pattern Recognition Letters, vol. 14, pp. 799-808, 1993.
 * P.L. Rosin, "Ellipse fitting using orthogonal hyperbolae and Stirling's oval", Graphical Models and Image Processing, vol. 60, no. 3, pp. 209-213, 1998.
 * P.L. Rosin, "Ellipse fitting by accumulating five-point fits", Pattern Recognition Letters, vol. 14, pp. 661-669, 1993.
 *
 * methods based on the median of the parameters (options -i1 -> i6) are generally not as good as
 * methods based on the LMedS of some error (options -e1 -> -e6)
 * and methods -i5, -i6 (Hilbert scan, MVE) seem least reliable
 *
 * Paul Rosin
 * Cardiff University
 * Paul.Rosin@cs.cf.ac.uk
 * October 1996 / September 2013
 * added <string.h> March 2018
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_POINTS   100000
#define MAX_C        400000

#define MAX_CTR      1000
#define MAX_MAJ      1000
#define MAX_MINA     1000

#define MIN_CTR      0
#define MIN_MAJ      0
#define MIN_MINA     0

#define CTR_RANGE  (MAX_CTR - MIN_CTR)
#define MAJ_RANGE  (MAX_MAJ - MIN_MAJ)
#define MINA_RANGE (MAX_MINA - MIN_MINA)

#define TWO_POWER_32 4294967296.0
#define TWO_POWER_30 1073741824.0
#define TWO_POWER_24 16777216.0

#define ALGEBRAIC  0
#define WEIGHTED   1
#define FOCI       2
#define ORTHOGONAL 3
#define STIRLING   4
#define HARKER     5

#define MEDIAN 0
#define LMedS  1

#define NONE       0
#define REGULAR    1
#define NONREGULAR 2

#define ALL_DATA 0
#define FLAGGED_DATA 1

#define OK  0
#define BAD 1

#define SUPER  0
#define EPS    1

#define TWO_PI 6.2831852
#define PI 3.1415926
#define HALF_PI (PI / 2.0)

#define TINY 1.0e-20

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define PRINTOUT TRUE

#define RAD2DEG(r)   ((r) * 180.0 / PI)

#define MAX(a,b)     (((a) > (b)) ? (a) : (b))
#define MIN(a,b)     (((a) < (b)) ? (a) : (b))

#define SQR(a)       ((a)*(a))
#define CUBE(x)      ((x)*(x)*(x))
#define ABS(x)       (((x)<0.0)? -(x): (x))

int no_points;
double datax[MAX_POINTS],datay[MAX_POINTS];
double coeff1,coeff2,coeff3,coeff4,coeff5,coeff6;
double param1[MAX_C],param2[MAX_C],param3[MAX_C];
double param4[MAX_C],param5[MAX_C];
double errors[MAX_POINTS],tmp_errors[MAX_POINTS];

double all_data[MAX_C][4];

FILE *fp;

char *infile,*outfile;

int flags[MAX_POINTS];

double global_mean,global_median;

int num_tuples = 95;

int use_approx = FALSE;

int output_mode = SUPER;

int skip_polish = FALSE;

void regular_5_fits_params(int method);
void regular_5_fits_params_rand(int fit_method, int rand_method);
void regular_5_fits_lmeds(int select_error);
void regular_5_fits_lmeds_rand(int select_error, int rand_method);
double determine_errors(double c1, double c2, double c3, double c4, double c5, double c6, int keep);
double determine_errors2(double c1, double c2, double c3, double c4, double c5, double c6, int keep);
double determine_errors3(double c1, double c2, double c3, double c4, double c5, double c6, int keep);
double determine_errors4(double c1, double c2, double c3, double c4, double c5, double c6, int keep);
double determine_errors5(double c1, double c2, double c3, double c4, double c5, double c6, int keep);
double determine_errors6(double c1, double c2, double c3, double c4, double c5, double c6, int keep);
void flag_outliers(double median);
void regular_5_fitsw(void);
void regular_5_fits_l(void);
void regular_5_hilbert(void);
void regular_mve(void);
double LMedS_1D(int count, double param[]);
double LMedS_1D_ang(int count, double param[], double max_val);
double estimate_angle(int count, double data[], double max_val);
double circ_mean(int count, double data[], double max_val);
double approx_circ_median(int count, double data[], double max_val);
double angle(double x1, double y1, double x2, double y2);
int lms_fit(int type);
void read_link_data(FILE *fp, int *endoffile);
int ellipse_type(double c1, double c2, double c3);
void solve_conic(int p1, int p2, int p3, int p4, int p5);
void determine_parameters(double a, double b, double c, double d, double e, double f, double *x_cent, double *y_cent, double *major_axis, double *minor_axis, double *rot_angle);
void determine_parameters2(double a, double b, double c, double d, double e, double f, double *x_cent, double *y_cent, double *major_axis, double *minor_axis, double *rot_angle);
void sort(int n, double ra[]);
void ludcmp(double a[6][6], int n, int indx[6], double *d);
void lubksb(double a[6][6], int n, int indx[6], double b[6]);
void error(char s[]);
void determine_ellipse_lms(double m[7]);
void determine_ellipse_lms2(double m[7]);
void hilbert_i2c(int n, int m, long int r, int a[]);
void hilbert_c2i(int n, int m, int a[], long int *r);
int my_random(int range);
double ran3();
int random_seed();
void ellipse_only(double *x_cent, double *y_cent, double *major_axis, double *minor_axis, double *rot_angle);
void ROTATE(double a[7][7], int i, int j, int k, int l, double tau, double s);
void jacobi2(double a[7][7], int n, double d[7], double v[7][7], int nrot);
void choldc(double a[7][7], int n, double l[7][7]);
int inverse6(double TB[7][7], double InvB[7][7], int N);
void AperB6(double _A[7][7], double _B[7][7], double _res[7][7], int _righA, int _colA, int _righB, int _colB);
void A_TperB(double _A[7][7], double _B[7][7], double _res[7][7], int _righA, int _colA, int _righB, int _colB);
void AperB_T(double _A[7][7], double _B[7][7], double _res[7][7], int _righA, int _colA, int _righB, int _colB);
void polyCentroid(double x[], double y[], int n, double *area);
void output_ellipse(double xc, double yc, double major_axis, double minor_axis, double rot_angle, char *filename, int mode);
void mve(double data[100000][4], int no_points, double w_means[4]);
static void calctables(int n);

main(argc,argv)
int argc;
char *argv[];
{
    int i,j,jj;
    char file_type[50];
    int endoffile;
    int lsf_flag,reg_flag,reg_l_flag;
    int wrap;
    int reg_flag_lmeds;
    int reg_hilbert_flag;
    int reg_mve_flag;
    int method;
    int rand_method;

    infile = argv[argc-2];
    outfile = argv[argc-1];

    if (argc == 1) {
        printf("Usage: %s [options] input_pixel_list output_super_list/output_EPS_file\n",argv[0]);
        printf("options:\n");
        printf("   -a       least squares fit (all data)\n");
        printf("   -A       use approximation of angular median\n");
        printf("   -r       randomly select 95 regular tuples     (default: all regularly spaced 5-tuples)\n");
        printf("   -R       randomly select 95 non-regular tuples (default: all regularly spaced 5-tuples)\n");
        printf("   -n int   set number of desired tuples\n");
        printf("   -p       output format = Postscript\n");
        printf("   -X       skip polishing step\n");
        printf("\n");
        printf("   -i1      median of intrinsic parameters\n");
        printf("   -i2      median of intrinsic parameters - wrap around\n");
        printf("   -i3      median of intrinsic parameters (> 1/2 data separation)\n");
        printf("   -i4      LMedS of intrinsic parameters\n");
        printf("   -i5      median of intrinsic parameters with Hilbert scan\n");
        printf("   -i6      MVE of intrinsic parameters\n");
        printf("\n");
        printf("   -e1      LMedS algebraic error\n");
        printf("   -e2      LMedS algebraic error / grad\n");
        printf("   -e3      LMedS foci bisector error\n");
        printf("   -e4      LMedS orthogonal conic error\n");
        printf("   -e5      LMedS Stirling's oval error\n");
        printf("   -e6      LMedS Harker and O'Leary error\n");
        exit(-1);
    }

    lsf_flag = reg_flag = FALSE;
    reg_l_flag = wrap = FALSE;
    reg_flag_lmeds = reg_hilbert_flag = FALSE;
    reg_mve_flag = FALSE;

    rand_method = NONE;

    for (i = 1; i < argc; i++) {
       if (argv[i][0] == '-') {
            switch (argv[i][1]) {
                case 'a':
                     lsf_flag = TRUE;
                     break;
                case 'A':
                     use_approx = TRUE;
                     break;
                case 'n':
                     i++;
                     num_tuples = atoi(argv[i]);
                     break;
                case 'i':
                     switch(argv[i][2]) {
                         case '1':
                              reg_flag = TRUE;
                              method = MEDIAN;
                              break;
                         case '2':
                              wrap = TRUE;
                              break;
                         case '3':
                              reg_l_flag = TRUE;
                              break;
                         case '4':
                              reg_flag = TRUE;
                              method = LMedS;
                              break;
                         case '5':
                              reg_hilbert_flag = TRUE;
                              break;
                         case '6':
                              reg_mve_flag = TRUE;
                              break;
                         default:
                             fprintf(stderr,"ERROR in -e switch\n");
                             exit(-1);
                     }
                     break;
                case 'e':
                     switch(argv[i][2]) {
                         case '1':
                              reg_flag_lmeds = TRUE;
                              method = ALGEBRAIC;
                              break;
                         case '2':
                              reg_flag_lmeds = TRUE;
                              method = WEIGHTED;
                              break;
                         case '3':
                              reg_flag_lmeds = TRUE;
                              method = FOCI;
                              break;
                         case '4':
                              reg_flag_lmeds = TRUE;
                              method = ORTHOGONAL;
                              break;
                         case '5':
                              reg_flag_lmeds = TRUE;
                              method = STIRLING;
                              break;
                         case '6':
                              reg_flag_lmeds = TRUE;
                              method = HARKER;
                              break;
                         default:
                             fprintf(stderr,"ERROR in -e switch\n");
                             exit(-1);
                     }
                     break;
                case 'r':
                     rand_method = REGULAR;
                     break;
                case 'R':
                     rand_method = NONREGULAR;
                     break;
                case 'p':
                     output_mode = EPS;
                     break;
                case 'X':
                     skip_polish = TRUE;
                     printf("skipping polishing step\n");
                     break;
                default:
                     printf("illegal option %c\n",argv[i][1]);
                     exit(-1);
            }
        }
    }

    if ((fp = fopen(infile, "r")) == NULL) {
        fprintf(stderr,"ERROR: cannot open %s\n", infile);
        exit(-1);
    }

    /* read magic word for format of file */
    fscanf(fp, "%s\n", file_type);
    j = strcmp(file_type, "pixel");
    jj = strcmp(file_type, "pixel_float");
    if ((j != 0) && (jj != 0)) {
        fprintf(stderr,"not link data file - aborting\n");
        exit(-1);
    }

    read_link_data(fp, &endoffile);

    fclose(fp);

    if (reg_flag) {
       if (rand_method == NONE)
           regular_5_fits_params(method);
       else
           regular_5_fits_params_rand(method,rand_method);
    }

    if (reg_flag_lmeds) {
       if (rand_method == NONE)
           regular_5_fits_lmeds(method);
       else
           regular_5_fits_lmeds_rand(method,rand_method);
    }

   if (lsf_flag)
      lms_fit(ALL_DATA);

   if (wrap)
      regular_5_fitsw();

   if (reg_l_flag)
      regular_5_fits_l();

   if (reg_hilbert_flag)
      regular_5_hilbert();

   if (reg_mve_flag)
      regular_mve();
}

/* only do regularly spaced 5 point fits */
/* apply simple median or LMedS to each parameter */
void regular_5_fits_params(int method)
{
   int i,count,sep;
   double xc,yc,maj,mina,rot;
   double save_xc,save_yc,save_maj,save_min,save_rot;
   int countall = 0;

   sep = 1;
   count = 0;
   do {
      i = 1;
      do {
         countall++;
         solve_conic(i,i+1*sep,i+2*sep,i+3*sep,i+4*sep);
         if (ellipse_type(coeff1,coeff2,coeff3)) {
            determine_parameters(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,
                                 &xc,&yc,&maj,&mina,&rot);
            count++;
            param1[count] = xc;
            param2[count] = yc;
            param3[count] = maj;
            param4[count] = mina;
            param5[count] = rot;
            if (count >= MAX_C) {
               fprintf(stderr,"ERROR: too many ellipses\n");
               exit(-1);
            }
         }
         i++;
      } while((i+4*sep) <= no_points);
      sep++;
   } while((1+4*sep <= no_points));

    if (method == MEDIAN) {
       sort(count,param1); save_xc =  param1[count/2];
       sort(count,param2); save_yc =  param2[count/2];
       sort(count,param3); save_maj = param3[count/2];
       sort(count,param4); save_min = param4[count/2];
       /*
       sort(count,param5); save_rot = param5[count/2];
       */
       save_rot = (double)estimate_angle(count,param5,2.0 * PI);
   }
   else if (method == LMedS) {
       sort(count,param1); save_xc =  LMedS_1D(count,param1);
       sort(count,param2); save_yc =  LMedS_1D(count,param2);
       sort(count,param3); save_maj = LMedS_1D(count,param3);
       sort(count,param4); save_min = LMedS_1D(count,param4);
       /*
       sort(count,param5); save_rot = LMedS_1D(count,param5);
       */
       save_rot = (double)estimate_angle(count,param5,2.0 * PI);
    }

#if PRINTOUT
    if (method == MEDIAN)
        printf("using 1D medians\n");
    else if (method == LMedS)
        printf("using 1D LMedS\n");

   printf("number of ellipses fitted (regular combinations): %d\n",count);
   printf("total number of conics considered: %d\n",countall);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",
          save_xc,save_yc,save_maj,save_min,RAD2DEG(save_rot));
#endif

   if (count > 1)
      output_ellipse(save_xc,save_yc,save_maj,save_min,save_rot,outfile,output_mode);
   else
      printf("only one ellipse fit!!\n");
}

/* only do num_tuples randomly selected regularly spaced 5 point fits */
/* apply simple median or LMedS to each parameter */
void regular_5_fits_params_rand(int fit_method, int rand_method)
{
   int count,st,sep;
   double xc,yc,maj,mina,rot;
   double save_xc,save_yc,save_maj,save_min,save_rot;
   int countall = 0;
   int i1,i2,i3,i4,i5;

   count = 0;
   do {
      if (rand_method == REGULAR) {
          st = my_random(no_points-1) + 1;
          sep = my_random(no_points/4) + 1;

          countall++;

          if (st+4*sep > no_points)
             continue;

          solve_conic(st,st+1*sep,st+2*sep,st+3*sep,st+4*sep);
      }
      else {
          countall++;

          i1 = my_random(no_points-1) + 1;
          i2 = my_random(no_points-1) + 1;
          i3 = my_random(no_points-1) + 1;
          i4 = my_random(no_points-1) + 1;
          i5 = my_random(no_points-1) + 1;

          solve_conic(i1,i2,i3,i4,i5);
      }

      if (ellipse_type(coeff1,coeff2,coeff3)) {
         determine_parameters(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,
                              &xc,&yc,&maj,&mina,&rot);
         count++;
         param1[count] = xc;
         param2[count] = yc;
         param3[count] = maj;
         param4[count] = mina;
         param5[count] = rot;
      }
   } while ((count < num_tuples) && (countall < num_tuples*2));

    if (fit_method == MEDIAN) {
       sort(count,param1); save_xc =  param1[count/2];
       sort(count,param2); save_yc =  param2[count/2];
       sort(count,param3); save_maj = param3[count/2];
       sort(count,param4); save_min = param4[count/2];
       /*
       sort(count,param5); save_rot = param5[count/2];
       */
       save_rot = (double)estimate_angle(count,param5,2.0 * PI);
   }
   else if (fit_method == LMedS) {
       sort(count,param1); save_xc =  LMedS_1D(count,param1);
       sort(count,param2); save_yc =  LMedS_1D(count,param2);
       sort(count,param3); save_maj = LMedS_1D(count,param3);
       sort(count,param4); save_min = LMedS_1D(count,param4);
       /*
       sort(count,param5); save_rot = LMedS_1D(count,param5);
       */
       save_rot = (double)estimate_angle(count,param5,2.0 * PI);
    }

#if PRINTOUT
    if (fit_method == MEDIAN)
        printf("using 1D medians\n");
    else if (fit_method == LMedS)
        printf("using 1D LMedS\n");

   printf("number of ellipses fitted (regular combinations): %d\n",count);
   printf("total number of conics considered: %d\n",countall);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",
          save_xc,save_yc,save_maj,save_min,RAD2DEG(save_rot));
#endif

   if (count > 1)
      output_ellipse(save_xc,save_yc,save_maj,save_min,save_rot,outfile,output_mode);
   else
      printf("only one ellipse fit!!\n");
}

/* only do regularly spaced 5 point fits
 * chose fit with either LMedS 1/ algebraic error
 *                             2/ algebraic error/grad
 *                             3/ foci bisector
 *                             4/ orthogonal conics
 *                             5/ Harker & O'Leary
 *                             also Stirling
 */
void regular_5_fits_lmeds(int select_error)
{
   int i,count,sep;
   double xc,yc,maj,mina,rot;
   int countall = 0;
   double save_c1,save_c2,save_c3,save_c4,save_c5,save_c6;
   double cur_err,best_err;
   //double determine_errors(),determine_errors2(),determine_errors3();
   //double determine_errors4(),determine_errors5(),determine_errors6();
   int etype;

   save_c1 = save_c2 = save_c3 = save_c4 = save_c5 = save_c6 = -1;
   best_err = 9e25;
   sep = 1;
   count = 0;
   do {
      i = 1;
      do {
         countall++;
         solve_conic(i,i+1*sep,i+2*sep,i+3*sep,i+4*sep);
         if (ellipse_type(coeff1,coeff2,coeff3)) {
            count++;

             if (select_error == ALGEBRAIC)
                 cur_err =
                    determine_errors(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
             else if (select_error == WEIGHTED)
                 cur_err =
                    determine_errors2(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
             else if (select_error == FOCI)
                 cur_err =
                    determine_errors3(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
             else if (select_error == ORTHOGONAL)
                 cur_err =
                    determine_errors4(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
             else if (select_error == STIRLING)
                 cur_err =
                    determine_errors5(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
             else if (select_error == HARKER)
                 cur_err =
                    determine_errors6(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);

            if (cur_err < best_err) {
                save_c1 = coeff1; save_c2 = coeff2; save_c3 = coeff3;
                save_c4 = coeff4; save_c5 = coeff5; save_c6 = coeff6;
                best_err = cur_err;
            }
         }
         i++;
      } while((i+4*sep) <= no_points);
      sep++;
   } while((1+4*sep <= no_points));

   determine_parameters(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,
                        &xc,&yc,&maj,&mina,&rot);

#if PRINTOUT
   printf("number of ellipses fitted (reg. combs.; LMedS of ");
   if (select_error == ALGEBRAIC) printf("ALGEBRAIC");
   else if (select_error == WEIGHTED) printf("WEIGHTED");
   else if (select_error == FOCI) printf("FOCI");
   else if (select_error == ORTHOGONAL) printf("ORTHOGONAL");
   else if (select_error == STIRLING) printf("STIRLING");
   else if (select_error == HARKER) printf("HARKER");
   printf(" error): %d\n",count);
   printf("total number of conics considered: %d\n",countall);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",xc,yc,maj,mina,RAD2DEG(rot));
   printf("best error = %f\n",best_err);
#endif

   /* polish fit */
   if (select_error == ALGEBRAIC)
       cur_err =
           determine_errors(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == WEIGHTED)
       cur_err =
           determine_errors2(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == FOCI)
       cur_err =
           determine_errors3(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == ORTHOGONAL)
       cur_err =
           determine_errors4(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == STIRLING)
       cur_err =
           determine_errors5(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == HARKER)
       cur_err =
           determine_errors6(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);

   flag_outliers(cur_err);

   if (skip_polish) {
       output_ellipse(xc,yc,maj,mina,rot,outfile,output_mode);
       etype = (count > 0);
   }
   else {
       printf("polishing fit\n");
       etype = lms_fit(FLAGGED_DATA);
   }

   if (!etype) {
       fprintf(stderr,"NON-ELLIPSE (not saving/overwriting output file)\n");
       exit(-1);
   }
}

/* only do num_tuples randomly selected regularly spaced 5 point fits
 * chose fit with either LMedS 1/ algebraic error
 *                             2/ algebraic error/grad
 *                             3/ foci bisector
 *                             4/ orthogonal conics
 *                             5/ Harker & O'Leary
 *                             also Stirling
 */
void regular_5_fits_lmeds_rand(int select_error, int rand_method)
{
   int count,st,sep;
   double xc,yc,maj,mina,rot;
   int countall = 0;
   double save_c1,save_c2,save_c3,save_c4,save_c5,save_c6;
   double cur_err,best_err;
   //double determine_errors(),determine_errors2(),determine_errors3();
   //double determine_errors4(),determine_errors5(),determine_errors6();
   int i1,i2,i3,i4,i5;
   double avg_err,norm_err,summed_err,area;
   int etype;

   save_c1 = save_c3 = save_c4 = save_c5 = save_c6 = -1;
   save_c2 = -999;
   best_err = 9e25;
   count = 0;
   do {
      if (rand_method == REGULAR) {
          st = my_random(no_points-1) + 1;
          sep = my_random(no_points/4) + 1;

          countall++;

          if (st+4*sep > no_points)
             continue;

          solve_conic(st,st+1*sep,st+2*sep,st+3*sep,st+4*sep);
      }
      else {
          countall++;

          i1 = my_random(no_points-1) + 1;
          i2 = my_random(no_points-1) + 1;
          i3 = my_random(no_points-1) + 1;
          i4 = my_random(no_points-1) + 1;
          i5 = my_random(no_points-1) + 1;
          solve_conic(i1,i2,i3,i4,i5);
      }

      if (ellipse_type(coeff1,coeff2,coeff3)) {
         count++;

         if (select_error == ALGEBRAIC)
             cur_err =
                determine_errors(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
         else if (select_error == WEIGHTED)
             cur_err =
                determine_errors2(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
         else if (select_error == FOCI)
             cur_err =
                determine_errors3(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
         else if (select_error == ORTHOGONAL)
             cur_err =
                determine_errors4(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
         else if (select_error == STIRLING)
             cur_err =
                determine_errors5(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);
         else if (select_error == HARKER)
             cur_err =
                determine_errors6(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,FALSE);

         if (cur_err < best_err) {
             save_c1 = coeff1; save_c2 = coeff2; save_c3 = coeff3;
             save_c4 = coeff4; save_c5 = coeff5; save_c6 = coeff6;
             best_err = cur_err;
         }
      }
   } while ((count < num_tuples) && (countall < num_tuples*2));

   determine_parameters(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,
                        &xc,&yc,&maj,&mina,&rot);

   if (count == 0) {
       fprintf(stderr,"no ellipse fits found (not saving/overwriting output file)\n");
       exit(-1);
   }

#if PRINTOUT
   printf("number of ellipses fitted (reg. combs.; LMedS of ");
   if (select_error == ALGEBRAIC) printf("ALGEBRAIC");
   else if (select_error == WEIGHTED) printf("WEIGHTED");
   else if (select_error == FOCI) printf("FOCI");
   else if (select_error == ORTHOGONAL) printf("ORTHOGONAL");
   else if (select_error == STIRLING) printf("STIRLING");
   else if (select_error == HARKER) printf("HARKER");
   printf(" error): %d\n",count);
   printf("total number of conics considered: %d\n",countall);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",xc,yc,maj,mina,RAD2DEG(rot));
   printf("best error = %f\n",best_err);
#endif

   /* polish fit */
   if (select_error == ALGEBRAIC)
       cur_err =
           determine_errors(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == WEIGHTED)
       cur_err =
           determine_errors2(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == FOCI)
       cur_err =
           determine_errors3(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == ORTHOGONAL)
       cur_err =
           determine_errors4(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == STIRLING)
       cur_err =
           determine_errors5(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);
   else if (select_error == HARKER)
       cur_err =
           determine_errors6(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,TRUE);

   flag_outliers(cur_err);

   if (skip_polish) {
       output_ellipse(xc,yc,maj,mina,rot,outfile,output_mode);
       etype = (count > 0);
   }
   else {
       printf("polishing fit\n");
       etype = lms_fit(FLAGGED_DATA);
   }

   if (!etype) {
       fprintf(stderr,"NON-ELLIPSE (not saving/overwriting output file)\n");
       exit(-1);
   }
}

/* determine residuals using algebraic distance */
double determine_errors(double c1, double c2, double c3, double c4, double c5, double c6, int keep)
{
    int i;
    double x,y;

    for (i = 1; i <= no_points; i++) {
        x = datax[i]; y = datay[i];
        tmp_errors[i] = c1 * x*x + c2 * x*y + c3 * y*y +
                    c4 * x + c5 * y + c6;
        tmp_errors[i] = ABS(tmp_errors[i]);
    }

    if (keep)
        for (i = 1; i <= no_points; i++)
            errors[i] = tmp_errors[i];

    sort(no_points,tmp_errors);
    return(tmp_errors[no_points/2]);
}

/* determine residuals using Q(x,y) / grad Q(x,y) */
double determine_errors2(double c1, double c2, double c3, double c4, double c5, double c6, int keep)
{
    int i;
    double x,y;
    double gx,gy;

    for (i = 1; i <= no_points; i++) {
        x = datax[i]; y = datay[i];
        tmp_errors[i] = c1 * x*x + c2 * x*y + c3 * y*y +
                    c4 * x + c5 * y + c6;
        gx = 2 * c1 * x + c2 * y + c4;
        gy = c2 * x + 2 * c3 * y + c5;
        tmp_errors[i] = SQR(tmp_errors[i]) / (gx*gx+gy*gy);
        tmp_errors[i] = sqrt(tmp_errors[i]);
    }

    if (keep)
        for (i = 1; i <= no_points; i++)
            errors[i] = tmp_errors[i];

    sort(no_points,tmp_errors);
    return(tmp_errors[no_points/2]);
}

/* determine residuals using foci bisector */
double determine_errors3(double c1, double c2, double c3, double c4, double c5, double c6, int keep)
{
    int i;
    double x,y;
    double xc,yc,maj,mina,rot;
    //double angle();

    double A,B,C,D,E,F;
    double a,b,c;
    double U,V;
    double t,xi1,yi1,xi2,yi2,euc1,euc2;
    double theta_f1,theta_f2,theta;

    double cosine,sine,tx,ty;
    double f1,f2,f1_x,f1_y,f2_x,f2_y;

    A = c1; B = c2; C = c3; D = c4; E = c5; F = c6;
    determine_parameters(c1,c2,c3,c4,c5,c6,&xc,&yc,&maj,&mina,&rot);

    /* calculate co-ordinates of foci */

    /* location in canonical position */
    f1 = sqrt(SQR(maj) - SQR(mina));
    f2 = -f1;

    /* rotate and translate */
    sine = sin(rot);
    cosine = cos(rot);

    tx = f1; ty = 0;
    f1_x = tx*cosine - ty*sine;
    f1_y = tx*sine   + ty*cosine;
    f1_x += xc; f1_y += yc;

    tx = f2; ty = 0;
    f2_x = tx*cosine - ty*sine;
    f2_y = tx*sine   + ty*cosine;
    f2_x += xc; f2_y += yc;

    for (i = 1; i <= no_points; i++) {
        x = datax[i]; y = datay[i];

        theta = angle((double)y,(double)x,(double)xc,(double)yc);

        theta_f1 = angle((double)x,(double)y,f1_x,f1_y);
        theta_f2 = angle((double)x,(double)y,f2_x,f2_y);

        theta = (theta_f1 + theta_f2) / 2.0;

        /* eqn of bisector */
        U = cos(theta);     /* diff x */
        V = sin(theta);     /* diff y */

        /* coefficients of eqn of intersection */
        a = A*SQR(U) + B*U*V + C*SQR(V);
        b = 2*A*U*x + B*(V*x+U*y) + 2*C*V*y + D*U + E*V;
        c = A*SQR(x) + B*x*y + C*SQR(y) + D*x + E*y + F;

        /* solve intersection and resubstitute into line eqn */
        if ((SQR(b) - 4*a*c) > 0) {
            t = (-b + sqrt(SQR(b) - 4*a*c)) / (2*a);
            xi1 = x + U * t;
            yi1 = y + V * t;

            /* solve intersection and resubstitute into line eqn */
            t = (-b - sqrt(SQR(b) - 4*a*c)) / (2*a);
            xi2 = x + U * t;
            yi2 = y + V * t;
        }

        euc1 = SQR(x-xi1) + SQR(y-yi1);
        euc2 = SQR(x-xi2) + SQR(y-yi2);
        tmp_errors[i] = sqrt(MIN(euc1,euc2));
    }

    if (keep)
        for (i = 1; i <= no_points; i++)
            errors[i] = tmp_errors[i];

    sort(no_points,tmp_errors);
    return(tmp_errors[no_points/2]);
}

/* determine residuals using orthogonal conics */
double determine_errors4(double c1, double c2, double c3, double c4, double c5, double c6, int keep)
{
    int i;
    double x,y;
    double xc,yc,maj,mina,rot;

    double cosine,sine,tx,ty;

    double Aq,Bq,Cq;
    double A,A1,A2,F,X,Y;
    double ae,be,ah,bh; /* ellipse & hyperbola axes */
    double xi,yi,euc1,euc2,euc3,euc4;

    determine_parameters(c1,c2,c3,c4,c5,c6,&xc,&yc,&maj,&mina,&rot);

    ae = maj;
    be = mina;

    if (ae == be) {
        for (i = 1; i <= no_points; i++) {
            tx = datax[i]; ty = datay[i];

            euc1 = sqrt(SQR(xc-tx) + SQR(yc-ty));
            tmp_errors[i] = ABS(euc1 - maj);
        }
    }
    else {
        sine = sin(-rot);
        cosine = cos(-rot);
    
        for (i = 1; i <= no_points; i++) {
            tx = datax[i]; ty = datay[i];
    
            tx -= xc; ty -= yc;
            x = tx*cosine - ty*sine;
            y = tx*sine   + ty*cosine;
    
            /* solve to find confocal hyperbola through point (x,y) */
    
            X = SQR(x);
            Y = SQR(y);
            F = SQR(ae) - SQR(be);
    
            Aq = 1;
            Bq = -(X + Y + F);
            Cq = X * F;
            A1 = (-Bq - sqrt(SQR(Bq) - 4 * Aq * Cq)) / (2 * Aq);
            A2 = (-Bq + sqrt(SQR(Bq) - 4 * Aq * Cq)) / (2 * Aq);
            A = MIN(A1,A2);
    
            ah = sqrt(A);
            bh = sqrt(ABS(F - A));
    
            /* find intersection of ellipse & hyperbola */
    
            xi = ah * sqrt(
                        (SQR(ae) * (SQR(be) + SQR(bh))) /
                        (SQR(ah) * SQR(be) + SQR(ae) * SQR(bh))
                      );
            yi = (be * bh * sqrt(SQR(ae) - SQR(ah))) /
                  sqrt(SQR(ah) * SQR(be) + SQR(ae) * SQR(bh));
    
            euc1 = SQR(x-xi) + SQR(y-yi);
            euc2 = SQR(x+xi) + SQR(y-yi);
            euc3 = SQR(x-xi) + SQR(y+yi);
            euc4 = SQR(x+xi) + SQR(y+yi);
    
            tmp_errors[i]
                = sqrt(
                        MIN(
                            MIN(euc1,euc2),
                            MIN(euc3,euc4)
                        )
                   );
        }
    }

    if (keep)
        for (i = 1; i <= no_points; i++)
            errors[i] = tmp_errors[i];

    sort(no_points,tmp_errors);
    return(tmp_errors[no_points/2]);
}

/* determine residuals using Stirling's oval */
double determine_errors5(double c1, double c2, double c3, double c4, double c5, double c6, int keep)
{
    int i;
    double x,y;
    double xc,yc,maj_axis,min_axis,rot;
    double p,n,cl,cm,pm,pl,dx,dy;
    int flag;
    double cosine,sine,tx,ty;
    double dist;

    determine_parameters(c1,c2,c3,c4,c5,c6,&xc,&yc,&maj_axis,&min_axis,&rot);

    sine = sin(-rot);
    cosine = cos(-rot);

    for (i = 1; i <= no_points; i++) {
        tx = datax[i]; ty = datay[i];

        tx -= xc; ty -= yc;
        x = tx*cosine - ty*sine;
        y = tx*sine   + ty*cosine;

        /* move point to 1st quadrant */
        x = ABS(x); y = ABS(y);

        p = (maj_axis + min_axis) / 2.0;
        n = (maj_axis - min_axis) / 2.0;
        cl = (2*n*p+n*n+n*sqrt(2*p*p-n*n)) / (p + n);
        cm = (2*n*p-n*n+n*sqrt(2*p*p-n*n)) / (p - n);
        /* check which arc to measure distance to
         * look to see which side of line the point lies on
         */
        flag = y - (cm / cl) * (x - cl);
        if (flag > 0) {
            dx = x - 0;
            dy = y - (-cm);
            pm = sqrt(dx*dx + dy*dy);
            dist = (min_axis+cm) - pm;
        }
        else {
            dx = x - cl;
            dy = y - 0;
            pl = sqrt(dx*dx + dy*dy);
            dist = (maj_axis-cm) - pl;
        }
        tmp_errors[i] = ABS(dist);
    }

    if (keep)
        for (i = 1; i <= no_points; i++)
            errors[i] = tmp_errors[i];

    sort(no_points,tmp_errors);
    return(tmp_errors[no_points/2]);
}

/* determine residuals using Harker & O'Leary */
double determine_errors6(double c1, double c2, double c3, double c4, double c5, double c6, int keep)
{
    int i;
    double x,y;
    double xc,yc,maj,mina,rot;
    double tx,ty;
    double a1,a2,a3,a4,a5,a6;
    double wn,wd,dist;
    double sine,cosine;

    determine_parameters(c1,c2,c3,c4,c5,c6,&xc,&yc,&maj,&mina,&rot);

    sine = sin(-rot);
    cosine = cos(-rot);

    a1 = -1.0 / SQR(maj);
    a2 = 0;
    a3 = -1.0 / SQR(mina);

    for (i = 1; i <= no_points; i++) {
        tx = datax[i]; ty = datay[i];
        tx -= xc; ty -= yc;
        x = tx*cosine - ty*sine;
        y = tx*sine   + ty*cosine;

        a4 = 2*x/SQR(maj);
        a5 = 2*y/SQR(mina);
        a6 = 1 - SQR(x/maj) - SQR(y/mina);

        wn =
            8*SQR(a4)*a3*a6 +
            16*SQR(a3)*SQR(a6) -
            8*a3*a6*SQR(a5) +
            pow(a5,4.0) +
            16*SQR(a2)*SQR(a6) +
            pow(a4,4.0) +
            2*SQR(a4)*SQR(a5) -
            32*a1*a3*SQR(a6) +
            8*a1*SQR(a5)*a6 -
            16*a2*a6*a4*a5 -
            8*a1*a6*SQR(a4) +
            16*SQR(a1)*SQR(a6);

        wd =
            32*a1*SQR(a2)*CUBE(a6) +
            32*a3*SQR(a2)*CUBE(a6) -
            32*SQR(a1)*a3*CUBE(a6) -
            pow(a4,6.0) -
            32*a1*SQR(a3)*CUBE(a6) +
            10*a1*a6*pow(a4,4.0) -
            8*a1*pow(a5,4.0)*a6 -
            8*SQR(a1)*SQR(a6)*SQR(a5) +
            2*a1*SQR(a4)*SQR(a5)*a6 +
            18*a2*CUBE(a5)*a4*a6 +
            18*a2*a6*CUBE(a4)*a5 +
            40*a1*a3*SQR(a6)*SQR(a5) +
            2*a3*SQR(a4)*SQR(a5)*a6 -
            32*SQR(a1)*SQR(a6)*SQR(a4) -
            8*pow(a4,4.0)*a3*a6 -
            20*SQR(a2)*SQR(a5)*SQR(a6) +
            10*a3*a6*pow(a5,4.0) -
            20*SQR(a2)*SQR(a4)*SQR(a6) -
            32*SQR(a3)*SQR(a6)*SQR(a5) -
            8*SQR(a3)*SQR(a6)*SQR(a4) -
            24*a1*a2*SQR(a6)*a4*a5 -
            24*a3*a2*SQR(a6)*a4*a5 +
            40*a1*SQR(a4)*a3*SQR(a6) +
            32*CUBE(a1)*CUBE(a6) +
            32*CUBE(a3)*CUBE(a6) -
            3*SQR(a4)*pow(a5,4.0) -
            3*pow(a4,4.0)*SQR(a5) -
            pow(a5,6.0);

        dist = -(wn / wd) * SQR(a6);
        dist = sqrt(ABS(dist));
        tmp_errors[i] = dist;
    }

    if (keep)
        for (i = 1; i <= no_points; i++)
            errors[i] = tmp_errors[i];

    sort(no_points,tmp_errors);
    return(tmp_errors[no_points/2]);
}

void flag_outliers(double median)
{
    int i;
    double tmp[MAX_POINTS];
    double mad;
    int no_retained = 0;

    /* calculate median absolute deviation */
    for (i = 1; i <= no_points; i++)
        tmp[i] = ABS(errors[i] - median);

    sort(no_points,tmp);
    mad = tmp[no_points/2];

    /* flag points outwith 3*sigma of mad */
    for (i = 1; i <= no_points; i++) {
        /*
         * NOTE: this was how it was described in my CVIU paper
         * but I think it must have been a mistake!
         *
         * PLR 11/2004
        if (errors[i] < 3*mad*1.4) {
        */
        if (errors[i] < median+3*mad*1.4) {
            flags[i] = OK;
            no_retained++;
        }
        else {
            flags[i] = BAD;
        }
    }
#if PRINTOUT
    fprintf(stderr,"%d inlying points retained from %d\n",no_retained,no_points);
#endif
}

/* only do regularly spaced 5 point fits */
/* wrap around points so that each point is uniformly sampled */
void regular_5_fitsw(void)
{
   int i,count,sep;
   double xc,yc,maj,mina,rot;
   double save_xc,save_yc,save_maj,save_min,save_rot;
   int countall = 0;
   int a,b,c,d,e;

   sep = 1;
   count = 0;
   do {
      i = 1;
      do {
         countall++;
         a = i; a = (a%no_points)+1;
         b = i+1*sep; b = (b%no_points)+1;
         c = i+2*sep; c = (c%no_points)+1;
         d = i+3*sep; d = (d%no_points)+1;
         e = i+4*sep; e = (e%no_points)+1;
         solve_conic(a,b,c,d,e);
         if (ellipse_type(coeff1,coeff2,coeff3)) {
            determine_parameters(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,
                                 &xc,&yc,&maj,&mina,&rot);
            count++;
            param1[count] = xc;
            param2[count] = yc;
            param3[count] = maj;
            param4[count] = mina;
            param5[count] = rot;
            if (count >= MAX_C) {
               fprintf(stderr,"ERROR: too many ellipses\n");
               exit(-1);
            }
         }
         i++;
      } while(i <= no_points);
      sep++;
   } while((1+4*sep <= no_points));

   sort(count,param1); save_xc =  param1[count/2];
   sort(count,param2); save_yc =  param2[count/2];
   sort(count,param3); save_maj = param3[count/2];
   sort(count,param4); save_min = param4[count/2];
   sort(count,param5); save_rot = param5[count/2];

#if PRINOUT
   printf("number of ellipses fitted (regular combinations): %d\n",count);
   printf("total number of conics considered: %d\n",countall);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",
          save_xc,save_yc,save_maj,save_min,RAD2DEG(save_rot));
#endif

   if (count > 1)
      output_ellipse(save_xc,save_yc,save_maj,save_min,save_rot,outfile,output_mode);
   else
      printf("only one ellipse fit!!\n");
}

/* only do regularly spaced 5 point fits */
/* start spacing to cover 1/2 the data */
void regular_5_fits_l(void)
{
   int i,count,sep;
   double xc,yc,maj,mina,rot;
   double save_xc,save_yc,save_maj,save_min,save_rot;

   sep = no_points/10;
   count = 0;
   do {
      i = 1;
      do {
         solve_conic(i,i+1*sep,i+2*sep,i+3*sep,i+4*sep);
         if (ellipse_type(coeff1,coeff2,coeff3)) {
            determine_parameters(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,
                                 &xc,&yc,&maj,&mina,&rot);
            count++;
            param1[count] = xc;
            param2[count] = yc;
            param3[count] = maj;
            param4[count] = mina;
            param5[count] = rot;
            if (count >= MAX_C) {
               fprintf(stderr,"ERROR: too many ellipses\n");
               exit(-1);
            }
         }
         i += 1;
      } while((i+4*sep) <= no_points);
      sep++;
   } while((1+4*sep <= no_points));

   sort(count,param1); save_xc =  param1[count/2];
   sort(count,param2); save_yc =  param2[count/2];
   sort(count,param3); save_maj = param3[count/2];
   sort(count,param4); save_min = param4[count/2];
   sort(count,param5); save_rot = param5[count/2];

#if PRINOUT
   printf("regular combinations (> 1/2; sep from %d); no ellipses: %d\n",
                   no_points/10,count);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",
          save_xc,save_yc,save_maj,save_min,RAD2DEG(save_rot));
#endif

   if (count > 1)
      output_ellipse(save_xc,save_yc,save_maj,save_min,save_rot,outfile,output_mode);
   else
      printf("only one ellipse fit!!\n");
}

/* regularly spaced 5 point fits
 * scan 4D parameter space with Hilbert curve and return median parameters
 * approx circular median of orientation
 */
void regular_5_hilbert(void)
{
   int i,j,count,count2,sep;
   double xc,yc,maj,mina,rot;
   int countall = 0;
   int coords[4];
   unsigned long int r;
   //void hilbert_i2c(),hilbert_c2i();
   int okay;
   double MAX_BIN = 255.0;

   sep = 1;
   count = 0;
   do {
      i = 1;
      do {
         countall++;
         solve_conic(i,i+1*sep,i+2*sep,i+3*sep,i+4*sep);
         if (ellipse_type(coeff1,coeff2,coeff3)) {
            determine_parameters(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,
                                 &xc,&yc,&maj,&mina,&rot);
            count++;

            param1[count] = xc;
            param2[count] = yc;
            param3[count] = maj;
            param4[count] = mina;

            if (rot < 0) rot += TWO_PI;
            if (rot > TWO_PI) rot -= TWO_PI;
            param5[count] = rot;

            if (count >= MAX_C) {
               fprintf(stderr,"ERROR: too many ellipses\n");
               exit(-1);
            }
         }
         i++;
      } while((i+4*sep) <= no_points);
      sep++;
   } while((1+4*sep <= no_points));

   count2 = 0;
   /* normalise ellipse parameters to lie in [0,MAX_BIN]
    * convert 4D co-ordinate to Hilbert curve index and store in list
    */
   for (i = 1; i <= count; i++) {
      coords[0] = (param1[i] - MIN_CTR)  * MAX_BIN / (double)CTR_RANGE;
      coords[1] = (param2[i] - MIN_CTR)  * MAX_BIN / (double)CTR_RANGE;
      coords[2] = (param3[i] - MIN_MAJ)  * MAX_BIN / (double)MAJ_RANGE;
      coords[3] = (param4[i] - MIN_MINA) * MAX_BIN / (double)MINA_RANGE;

      okay = TRUE;
      for (j = 0; (j < 4) && okay; j++) {
         if (coords[j] < 0) okay = FALSE;
         if (coords[j] > MAX_BIN) okay = FALSE;
      }

      if (okay) {
         hilbert_c2i(4, 8, coords, &r);
         param1[++count2] = r;
      }
   }

   sort(count2,param1);

   r = param1[count2/2];
#if PRINTOUT
   printf("median Hilbert index: %lu\n",r);
#endif

   hilbert_i2c(4, 8, r, coords);

   xc   = (coords[0] * CTR_RANGE)  / (double)MAX_BIN + MIN_CTR;
   yc   = (coords[1] * CTR_RANGE)  / (double)MAX_BIN + MIN_CTR;
   maj  = (coords[2] * MAJ_RANGE)  / (double)MAX_BIN + MIN_MAJ;
   mina = (coords[3] * MINA_RANGE) / (double)MAX_BIN + MIN_MINA;

   rot = (double)estimate_angle(count, param5, 2.0 * PI);

#if PRINTOUT
   printf("number of ellipses considered (regular combinations): %d\n",count);
   printf("number of ellipses fitted (regular combinations): %d\n",count2);
   printf("total number of conics considered: %d\n",countall);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",
          xc,yc,maj,mina,RAD2DEG(rot));
#endif

   if (count > 1)
      output_ellipse(xc,yc,maj,mina,rot,outfile,output_mode);
   else
      printf("only one ellipse fit!!\n");
}

/* use centre of minimum volume ellipsoid estimator
 * approx circular median of orientation
 */
void regular_mve(void)
{
   int i,count,sep;
   double xc,yc,maj,mina,rot;
   int countall = 0;
   double w_means[4];

   sep = 1;
   count = 0;
   do {
      i = 1;
      do {
         countall++;
         solve_conic(i,i+1*sep,i+2*sep,i+3*sep,i+4*sep);
         if (ellipse_type(coeff1,coeff2,coeff3)) {
            determine_parameters(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,
                                 &xc,&yc,&maj,&mina,&rot);

            count++;

            all_data[count-1][0] = xc;
            all_data[count-1][1] = yc;
            all_data[count-1][2] = maj;
            all_data[count-1][3] = mina;

            param5[count] = rot;

            if (count >= MAX_C) {
               fprintf(stderr,"ERROR: too many ellipses\n");
               exit(-1);
            }
         }
         i++;
      } while((i+4*sep) <= no_points);
      sep++;
   } while((1+4*sep <= no_points));

   /* calculate minimum volume ellipsoid */
   mve(all_data,count,w_means);

   xc   = w_means[0];
   yc   = w_means[1];
   maj  = w_means[2];
   mina = w_means[3];

   /*
   sort(count,param5);
   rot = param5[count/2];
   */

   rot = (double)estimate_angle(count, param5, 2.0 * PI);

#if PRINTOUT
   printf("number of ellipses fitted (regular combinations): %d\n",count);
   printf("total number of conics considered: %d\n",countall);
   printf("parameters: %.3f %.3f %.3f %.3f %.3f\n",
          xc,yc,maj,mina,RAD2DEG(rot));
#endif

   if (count > 1)
      output_ellipse(xc,yc,maj,mina,rot,outfile,output_mode);
   else
      printf("only one ellipse fit!!\n");
}

/*
 * do the LMedS on 1D list of values
 * this requires finding the sequence of count/2 values with the minimum range
 * the result is the average of the extremal values in this range
 */
double LMedS_1D(int count, double param[])
{
    int i;
    int half = count/2;
    double range,min_range;
    int min_loc = 1;
    double result;

    i = 1;
    min_range = ABS(param[i]-param[i+half]);
    for (i = 2; i <= half; i++) {
        range = ABS(param[i]-param[i+half]);
        if (range < min_range) {
            min_loc = i;
            min_range = range;
        }
    }
    result = (param[min_loc] + param[min_loc+half]) / 2.0;

    return(result);
}

/*
 * do the LMedS on 1D list of ANGULAR values
 * this requires finding the sequence of count/2 values with the minimum range
 * the result is the average of the extremal values in this range
 *
 * simple additional bit to check for wrap-around
 */
double LMedS_1D_ang(int count, double param[], double max_val)
{
    int i;
    int half = count/2;
    double range,min_range;
    int min_loc = 1;
    double result;
    double data[2*MAX_C];

    /* copy values */
    for (i = 1; i <= count; i++)
        data[i] = param[i];
    /* copy a second set of values incrementing by
     * max_val to cope with wrap-around
     */
    for (i = 1; i <= count; i++)
        data[count+i] = param[i]+max_val;

    /* still keep window size to half of old data size */
    i = 1;
    min_range = ABS(data[i]-data[i+half]);
    for (i = 2; i <= count; i++) {
        range = ABS(data[i]-data[i+half]);
        if (range < min_range) {
            min_loc = i;
            min_range = range;
        }
    }
    result = (data[min_loc] + data[min_loc+half]) / 2.0;
    if (result > max_val)
        result -= max_val;

    return(result);
}

double estimate_angle(int count, double data[], double max_val)
{
    //double approx_circ_median();
    //double LMedS_1D_ang();

    if (use_approx)
        return approx_circ_median(count,data,max_val);
    else
        return LMedS_1D_ang(count,data,max_val);
}

/* calculate circular mean - see Mardia */
double circ_mean(int count, double data[], double max_val)
{
    int i;
    double c,s;
    double factor = (2 * PI) / max_val;
    double mean;

    c = s = 0;
    for (i = 1; i <= count; i++) {
        c += cos(data[i] * factor);
        s += sin(data[i] * factor);
    }
    c /= (double) count; s /= (double) count;

    if ((s > 0) && (c > 0))
        mean = atan(s/c);
    else if (c < 0)
        mean = atan(s/c) + PI;
    else if ((s < 0) && (c > 0))
        mean = atan(s/c) + 2 * PI;
    else
        fprintf(stderr,"ERROR: in circ_mean\n");

    mean /= factor;

    return(mean);
}

/* calculate approx circular median
 * use circular mean to rotate the data mean to the centre and then do a
 * regular (non circular) median
 */
double approx_circ_median(int count, double data[], double max_val)
{
    int i;
    double mean,median;
    double offset;

    mean = circ_mean(count,data,max_val);

    offset = max_val / 2.0 - mean;

    /* shift data to centralise mean */
    for (i = 1; i <= count; i++) {
        data[i] += offset;
        if (data[i] > max_val) data[i] -= max_val;
        if (data[i] < 0)       data[i] += max_val;
    }

    sort(count,data);

    median = data[count/2];

    median = median - offset;
    if (median > 0)       median -= max_val;
    if (median < 0)       median += max_val;

    global_median = median;
    global_mean = mean;

    /* now tidy up - not strictly necessary if data is not used again */

    /* shift data back again */
    for (i = 1; i <= count; i++) {
        data[i] -= offset;
        if (data[i] > max_val) data[i] -= max_val;
        if (data[i] < 0)       data[i] += max_val;
    }

    sort(count,data);

    return(median);
}

double angle(double x1, double y1, double x2, double y2)
{
    double xdiff,ydiff;
    double angle;

    xdiff = x2 - x1;
    ydiff = y2 - y1;
    if (xdiff == 0) {
        if (ydiff > 0)
            angle = HALF_PI;
        else
            angle = -HALF_PI;
    }
    else if (ydiff == 0) {
        if (xdiff > 0)
            angle = 0;
        else
            angle = PI;
    }
    else
        angle = atan2(ydiff,xdiff);

    if (angle<0) angle += TWO_PI;
    if (angle>TWO_PI) angle -= TWO_PI;

    return(angle);
}

/* lms fit */
/* also saves (overwrites) fitted parameters in output file */
int lms_fit(int type)
{
   int i;
   double m[7];   /* coefficients of best fit ellipse */
   double x_org,y_org;
   double xc,yc,maj,mina,rot;
   int e;

   /* shift data to the origin to minimise numerical errors */
   x_org = y_org = 0;
   for (i = 1; i <= no_points; i++) {
      x_org += datax[i];
      y_org += datay[i];
   }
   x_org /= no_points; y_org /= no_points;
   for (i = 1; i <= no_points; i++) {
      datax[i] -= x_org;
      datay[i] -= y_org;
   }
   /* rescale from 0->511 to 0-1 to prevent enormous numbers */
   for (i = 1; i <= no_points; i++) {
      datax[i] /= 512.0;
      datay[i] /= 512.0;
   }

   if (type == ALL_DATA) {
       determine_ellipse_lms(m);
   }
   else {
       determine_ellipse_lms2(m);
   }

   /* restore data after the above transformation */
   for (i = 1; i <= no_points; i++) {
      datax[i] *= 512.0;
      datay[i] *= 512.0;
   }
   for (i = 1; i <= no_points; i++) {
      datax[i] += x_org;
      datay[i] += y_org;
   }

#if PRINTOUT
   printf("performing least square fit\n");
#endif
   e = ellipse_type(m[1],m[2],m[3]);
   if (e) {
        determine_parameters(m[1],m[2],m[3],m[4],m[5],m[6],&xc,&yc,&maj,&mina,&rot);

        maj *= 512; mina *= 512;
        xc *= 512; xc += x_org;
        yc *= 512; yc += y_org;

        output_ellipse(xc,yc,maj,mina,rot,outfile,output_mode);
   }
   else {
#if PRINTOUT
       printf("%f %f %f %f %f %f\n",m[1],m[2],m[3],m[4],m[5],m[6]);
#endif
       fprintf(stderr,"NON-ELLIPSE (not saving/overwriting output file)\n");
       exit(-1);
   }

   return(e);
}

void read_link_data(FILE *fp, int *endoffile)
{
    char dumstring[50];
    int j;
    double t1,t2;
    double xd,yd;

    fscanf(fp, "%s %d\n", dumstring, &j);
    /* j = -1; */
    j = 0;
    do {
        j++;
        fscanf(fp, "%lf %lf\n", &t1,&t2);
        datax[j] = t1; datay[j] = t2;
    } while (datax[j] != -1);
    *endoffile = (datay[j] == -1);
    if (feof(fp) && !(*endoffile)) {
        fprintf(stderr, "Incorrectly terminated file - assuming end of list\n");
        *endoffile = TRUE;
    }
    /* no_points = j; */
    no_points = j-1;
    if (no_points >= MAX_POINTS) {
        fprintf(stderr,"ERROR: too many data points\n");
        exit(-1);
    }
}


/* is conic an ellipse? */
int ellipse_type(double c1, double c2, double c3)
{
   double f;

   f = c1 * c3 - c2 * c2 / 4;
   return(f > 0);
}

/**********************************
 find unique conic through 5 points
 **********************************/
void solve_conic(int p1, int p2, int p3, int p4, int p5)
{
     double dx,m,c;
     int i1,i2;
     double x1,y1,c1;
     double x2,y2,c2;
     double x3,y3,c3;
     double x4,y4,c4;
     double xp,yp;
     double lambda;
     double x2c,y2c,xyc,xc,yc;
     double t1,t2;

   /*
     cross((int)datax[p1],(int)datay[p1],4,"pink");
     cross((int)datax[p2],(int)datay[p2],4,"pink");
     cross((int)datax[p3],(int)datay[p3],4,"pink");
     cross((int)datax[p4],(int)datay[p4],4,"pink");
     cross((int)datax[p5],(int)datay[p5],4,"pink");
   */

     i1 = p1; i2 = p2;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x1 = -m; y1 = 1; c1 = -c;
     }
     else {
          x1 = 0; y1 = 1; c1 = -datax[i1];
     }

     i1 = p3; i2 = p4;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x2 = -m; y2 = 1; c2 = -c;
     }
     else {
          x2 = 0; y2 = 1; c2 = -datax[i1];
     }

     i1 = p1; i2 = p3;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x3 = -m; y3 = 1; c3 = -c;
     }
     else {
          x3 = 0; y3 = 1; c3 = -datax[i1];
     }

     i1 = p2; i2 = p4;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x4 = -m; y4 = 1; c4 = -c;
     }
     else {
          x4 = 0; y4 = 1; c4 = -datax[i1];
     }

     xp = datax[p5]; yp = datay[p5];

     t1 = ((x1*xp+y1*yp+c1)*(x2*xp+y2*yp+c2));
     t2 = ((x3*xp+y3*yp+c3)*(x4*xp+y4*yp+c4));
     if ((t1 == 0) || (t2 == 0)) {
     /*
        fprintf(stderr,"ERROR: lambda is degenerate\n");
     */
        /* so just set coefficients to make conic non-elliptical */
        coeff1 = coeff3 = coeff4 = coeff5 = coeff6 = 0;
        coeff2 = 100;
        return;
     }
     lambda = t1 / t2;

     x2c = x1*x2 - lambda*x3*x4;
     xyc = x1*y2 + y1*x2 - lambda*(x3*y4 + y3*x4);
     y2c = y1*y2 - lambda*y3*y4;
     xc = x1*c2 + c1*x2 - lambda*(x3*c4 + c3*x4);
     yc = y1*c2 + c1*y2 - lambda*(y3*c4 + c3*y4);
     c = c1*c2 - lambda*c3*c4;

     /*
     printf("COEFFS: %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f\n",
             x2c,xyc,y2c,xc,yc,c);
     */

     coeff1 = x2c;
     coeff2 = xyc;
     coeff3 = y2c;
     coeff4 = xc;
     coeff5 = yc;
     coeff6 = c;
}

void determine_parameters(double a, double b, double c, double d, double e, double f, double *x_cent, double *y_cent, double *major_axis, double *minor_axis, double *rot_angle)
{
    double ca,sa;
    double t,u,v,w;
    double mina,maja;

    if (a == c)
       *rot_angle = 0;
    else
       *rot_angle = atan(b/(a-c)) / 2.0;
    ca = cos(*rot_angle);
    sa = sin(*rot_angle);
    t = a*SQR(ca)+b*ca*sa+c*SQR(sa);
    u = a*SQR(sa)-b*ca*sa+c*SQR(ca);
    v = d*ca+e*sa;
    w = -d*sa+e*ca;
    *x_cent = (-d*c/2.0 + e*b/4.0) / (a*c - b*b/4.0);
    *y_cent = (-a*e/2.0 + d*b/4.0) / (a*c - b*b/4.0);

    maja = sqrt(((SQR(v)/(4*t))+(SQR(w)/(4*u))-f)/t);
    mina = sqrt(((SQR(v)/(4*t))+(SQR(w)/(4*u))-f)/u);

    if (maja < mina) {
        *minor_axis = maja;
        *major_axis = mina;
        *rot_angle += HALF_PI;
    }
    else {
        *minor_axis = mina;
        *major_axis = maja;
    }
}

/* modified from Haralick & Shapiro appendix */
void determine_parameters2(double a, double b, double c, double d, double e, double f, double *x_cent, double *y_cent, double *major_axis, double *minor_axis, double *rot_angle)
{
    double mina,maja;
    double t;

    if (a == c)
       *rot_angle = 0;
    else
       *rot_angle = atan(b/(a-c)) / 2.0;

    *x_cent = (-d*c/2.0 + e*b/4.0) / (a*c - b*b/4.0);
    *y_cent = (-a*e/2.0 + d*b/4.0) / (a*c - b*b/4.0);

    t = a+c+f*sqrt(SQR(b)+SQR((a-c)/f));
    maja = sqrt(-2*f / t);
    t = a+c-f*sqrt(SQR(b)+SQR((a-c)/f));
    mina = sqrt(-2*f / t);

    /***
    a /= -f;
    b /= -f;
    c /= -f;
    maja = sqrt(a+c - sqrt(SQR(a-c)+SQR(b)));
    mina = sqrt(a+c + sqrt(SQR(a-c)+SQR(b)));
    maja = sqrt(2.0) / maja;
    mina = sqrt(2.0) / mina;
    ***/

    if (maja < mina) {
        *minor_axis = maja;
        *major_axis = mina;
        *rot_angle += HALF_PI;
    }
    else {
        *minor_axis = mina;
        *major_axis = maja;
    }
}

/* from numerical recipes in C */
void sort(int n, double ra[])
{
   int l,j,ir,i;
   double rra;

   l=(n >> 1)+1;
   ir=n;
   for (;;) {
      if (l > 1)
         rra=ra[--l];
      else {
         rra=ra[ir];
         ra[ir]=ra[1];
         if (--ir == 1) {
            ra[1]=rra;
            return;
         }
      }
      i=l;
      j=l << 1;
      while (j <= ir) {
         if (j < ir && ra[j] < ra[j+1]) ++j;
         if (rra < ra[j]) {
            ra[i]=ra[j];
            j += (i=j);
         }
         else j=ir+1;
      }
      ra[i]=rra;
   }
}

/* ===================================================================*/

/* LEAST SQUARE FITTING STUFF */

/* ===================================================================*/

/* LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void ludcmp(double a[6][6], int n, int indx[6], double *d)
{
        int i,imax,j,k;
        double big,dum,sum,temp;
        double vv[6];

        *d = 1.0;
        for (i = 1; i <= n; i++) {
                big = 0.0;
                for (j = i; j <= n; j++)
                        if ((temp = fabs(a[i][j])) > big) big = temp;
                if (big == 0.0) error("Singular matrix in routine LUDCMP");
                vv[i] = 1.0/big;
        }
        for (j = 1; j <= n; j++) {
                for (i = 1; i < j; i++) {
                        sum = a[i][j];
                        for (k = 1; k < i; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                }
                big = 0.0;
                for (i = j; i <= n;i++) {
                        sum = a[i][j];
                        for (k = 1; k < j; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                        if ( (dum = vv[i]*fabs(sum)) >= big) {
                                big = dum;
                                imax = i;
                        }
                }
                if (j != imax) {
                        for (k = 1; k <= n; k++) {
                                dum = a[imax][k];
                                a[imax][k] = a[j][k];
                                a[j][k] = dum;
                        }
                        *d = -(*d);
                        vv[imax] = vv[j];
                }
                indx[j] = imax;
                if (a[j][j] == 0.0) a[j][j] = TINY;
                if (j != n) {
                        dum = 1.0/(a[j][j]);
                        for (i = j+1; i <= n ;i++) a[i][j] *= dum;
                }
        }
}

/* forward substitution & backsubstitution */
/* use with LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void lubksb(double a[6][6], int n, int indx[6], double b[6])
{
        int i,ii=0,ip,j;
        double sum;

        for (i = 1;i <= n;i++) {
                ip = indx[i];
                sum = b[ip];
                b[ip] = b[i];
                if (ii)
                        for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
                else if (sum) ii = i;
                b[i] = sum;
        }
        for (i=n;i>=1;i--) {
                sum = b[i];
                for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
                b[i] = sum/a[i][i];
        }
}

void error(char s[])
{
   fprintf(stderr,"ERROR: %s\n",s);
   exit(-1);
}

void determine_ellipse_lms(double m[7])
{
   int j;
   double sx,sx2,sx3,sx4,sy,sy2,sy3,sy4,sxy,sx2y,sx3y,sx2y2,sxy2,sxy3;
   double x2,y2,x3,y3;
   double m1[6][6];
   double m2[6];
   int indx[6];
   double d;

   sx = 0;
   sx2 = 0;
   sx3 = 0;
   sx4 = 0;
   sy = 0;
   sy2 = 0;
   sy3 = 0;
   sy4 = 0;
   sxy = 0;
   sx2y = 0;
   sx3y = 0;
   sx2y2 = 0;
   sxy2 = 0;
   sxy3 = 0;

   for (j = 1; j <= no_points; j++) {
      x2 = datax[j] * datax[j];
      x3 = x2 * datax[j];
      y2 = datay[j] * datay[j];
      y3 = y2 * datay[j];

      sx += datax[j];
      sx2 += x2;
      sx3 += x3;
      sx4 += (x3 * datax[j]);
      sy += datay[j];
      sy2 += y2;
      sy3 += y3;
      sy4 += (y3 * datay[j]);
      sxy += (datax[j] * datay[j]);
      sx2y = sx2y + x2 * datay[j];
      sx3y = sx3y + x3 * datay[j];
      sx2y2 = sx2y2 + x2 * y2;
      sxy2 = sxy2 + datax[j] * y2;
      sxy3 = sxy3 + datax[j] * y3;
   }

   m1[1][1] = sx4;
   m1[2][1] = sx3y;
   m1[3][1] = sx2y2;
   m1[4][1] = sx3;
   m1[5][1] = sx2y;
   m1[1][2] = sx3y;
   m1[2][2] = sx2y2;
   m1[3][2] = sxy3;
   m1[4][2] = sx2y;
   m1[5][2] = sxy2;
   m1[1][3] = sx2y2;
   m1[2][3] = sxy3;
   m1[3][3] = sy4;
   m1[4][3] = sxy2;
   m1[5][3] = sy3;
   m1[1][4] = sx3;
   m1[2][4] = sx2y;
   m1[3][4] = sxy2;
   m1[4][4] = sx2;
   m1[5][4] = sxy;
   m1[1][5] = sx2y;
   m1[2][5] = sxy2;
   m1[3][5] = sy3;
   m1[4][5] = sxy;
   m1[5][5] = sy2;

   m2[1] = -sx2;
   m2[2] = -sxy;
   m2[3] = -sy2;
   m2[4] = -sx;
   m2[5] = -sy;

   /* solve simultaneous equations */
   ludcmp(m1,5,indx,&d);
   lubksb(m1,5,indx,m2);

   m[1] = m2[1];
   m[2] = m2[2];
   m[3] = m2[3];
   m[4] = m2[4];
   m[5] = m2[5];
   m[6] = 1;
}

/* find lms fit of flagged points only */
void determine_ellipse_lms2(double m[7])
{
   int j;
   double sx,sx2,sx3,sx4,sy,sy2,sy3,sy4,sxy,sx2y,sx3y,sx2y2,sxy2,sxy3;
   double x2,y2,x3,y3;
   double m1[6][6];
   double m2[6];
   int indx[6];
   double d;

   sx = 0;
   sx2 = 0;
   sx3 = 0;
   sx4 = 0;
   sy = 0;
   sy2 = 0;
   sy3 = 0;
   sy4 = 0;
   sxy = 0;
   sx2y = 0;
   sx3y = 0;
   sx2y2 = 0;
   sxy2 = 0;
   sxy3 = 0;

   for (j = 1; j <= no_points; j++)
   if (flags[j] == OK)
   {
      x2 = datax[j] * datax[j];
      x3 = x2 * datax[j];
      y2 = datay[j] * datay[j];
      y3 = y2 * datay[j];

      sx += datax[j];
      sx2 += x2;
      sx3 += x3;
      sx4 += (x3 * datax[j]);
      sy += datay[j];
      sy2 += y2;
      sy3 += y3;
      sy4 += (y3 * datay[j]);
      sxy += (datax[j] * datay[j]);
      sx2y = sx2y + x2 * datay[j];
      sx3y = sx3y + x3 * datay[j];
      sx2y2 = sx2y2 + x2 * y2;
      sxy2 = sxy2 + datax[j] * y2;
      sxy3 = sxy3 + datax[j] * y3;
   }

   m1[1][1] = sx4;
   m1[2][1] = sx3y;
   m1[3][1] = sx2y2;
   m1[4][1] = sx3;
   m1[5][1] = sx2y;
   m1[1][2] = sx3y;
   m1[2][2] = sx2y2;
   m1[3][2] = sxy3;
   m1[4][2] = sx2y;
   m1[5][2] = sxy2;
   m1[1][3] = sx2y2;
   m1[2][3] = sxy3;
   m1[3][3] = sy4;
   m1[4][3] = sxy2;
   m1[5][3] = sy3;
   m1[1][4] = sx3;
   m1[2][4] = sx2y;
   m1[3][4] = sxy2;
   m1[4][4] = sx2;
   m1[5][4] = sxy;
   m1[1][5] = sx2y;
   m1[2][5] = sxy2;
   m1[3][5] = sy3;
   m1[4][5] = sxy;
   m1[5][5] = sy2;

   m2[1] = -sx2;
   m2[2] = -sxy;
   m2[3] = -sy2;
   m2[4] = -sx;
   m2[5] = -sy;

   /* solve simultaneous equations */
   ludcmp(m1,5,indx,&d);
   lubksb(m1,5,indx,m2);

   m[1] = m2[1];
   m[2] = m2[2];
   m[3] = m2[3];
   m[4] = m2[4];
   m[5] = m2[5];
   m[6] = 1;
}

/* ==================== Hilbert conversion routines ==================== */

/*
 * This software is copyrighted as noted below.  It may be freely copied,
 * modified, and redistributed, provided that the copyright notice is
 * preserved on all copies.
 *
 * There is no warranty or other guarantee of fitness for this software,
 * it is provided solely "as is".  Bug reports or fixes may be sent
 * to the author, who may or may not act on them as he desires.
 *
 * You may not include this software in a program or other software product
 * without supplying the source, or without informing the end-user that the
 * source is available for no extra charge.
 *
 * If you modify this software, you should include a notice giving the
 * name of the person performing the modification, the date of modification,
 * and the reason for such modification.
 */

/*
 * hilbert.c - Computes Hilbert curve coordinates from position and v.v.
 *
 * Author:    Spencer W. Thomas
 *         EECS Dept.
 *         University of Michigan
 * Date:    Thu Feb  7 1991
 * Copyright (c) 1991, University of Michigan
 * email: spencer@engin.umich.edu
 */
static char rcsid[] = "$Header: /l/spencer/src/urt/lib/RCS/hilbert.c,v 3.0.1.1 1992/04/30 14:07:11 spencer Exp $";

/*
 * Lots of tables to simplify calculations.  Notation: p#i means bit i
 * in byte p (high order bit first).
 * p_to_s:    Output s is a byte from input p such that
 *            s#i = p#i xor p#(i-1)
 * s_to_p:    The inverse of the above.
 * p_to_J:    Output J is "principle position" of input p.  The
 *            principle position is the last bit s.t.
 *            p#J != p#(n-1) (or n-1 if all bits are equal).
 * bit:       bit[i] == (1 << (n - i))
 * circshift: circshift[b][i] is a right circular shift of b by i
 *            bits in n bits.
 * parity:    Parity[i] is 1 or 0 depending on the parity of i (1 is odd).
 * bitof:     bitof[b][i] is b#i.
 * nbits:     The value of n for which the above tables have been
 *            calculated.
 */

typedef unsigned int byte;

static int nbits = 0;

static byte
    p_to_s[512],
    s_to_p[512],
    p_to_J[512],
    bit[9],
    circshift[512][9],
    parity[512],
    bitof[512][9];

/* Calculate the above tables when nbits changes. */
static void calctables(int n)
{
    register int i, b;
    int two_n = 1 << n;

    if ( nbits == n )
    return;

    nbits = n;
    /* bit array is easy. */
    for ( b = 0; b < n; b++ )
    bit[b] = 1 << (n - b - 1);

    /* Next, do bitof. */
    for ( i = 0; i < two_n; i++ )
    for ( b = 0; b < n; b++ )
        bitof[i][b] = (i & bit[b]) ? 1 : 0;

    /* circshift is independent of the others. */
    for ( i = 0; i < two_n; i++ )
    for ( b = 0; b < n; b++ )
        circshift[i][b] = (i >> (b)) |
        ((i << (n - b)) & (two_n - 1));

    /* So is parity. */
    parity[0] = 0;
    for ( i = 1, b = 1; i < two_n; i++ ) {
        /* Parity of i is opposite of the number you get when you
         * knock the high order bit off of i.
         */
        if ( i == b * 2 )
            b *= 2;
        parity[i] = !parity[i - b];
    }

    /* Now do p_to_s, s_to_p, and p_to_J. */
    for ( i = 0; i < two_n; i++ )
    {
    int s;

    s = i & bit[0];
    for ( b = 1; b < n; b++ )
        if ( bitof[i][b] ^ bitof[i][b-1] )
        s |= bit[b];
    p_to_s[i] = s;
    s_to_p[s] = i;

    p_to_J[i] = n - 1;
    for ( b = 0; b < n; b++ )
        if ( bitof[i][b] != bitof[i][n-1] )
        p_to_J[i] = b;
    }
}

/*****************************************************************
 * TAG( hilbert_i2c )
 *
 * Convert an index into a Hilbert curve to a set of coordinates.
 * Inputs:
 *     n:    Number of coordinate axes.
 *     m:    Number of bits per axis.
 *     r:    The index, contains n*m bits (so n*m must be <= 32).
 * Outputs:
 *     a:    The list of n coordinates, each with m bits.
 * Assumptions:
 *     n*m < (sizeof r) * (bits_per_byte), n <= 8, m <= 9.
 * Algorithm:
 *     From A. R. Butz, "Alternative Algorithm for Hilbert's
 *         Space-Filling Curve", IEEE Trans. Comp., April, 1971,
 *         pp 424-426.
 */
void hilbert_i2c(int n, int m, long int r, int a[])
{
    byte rho[9], rh, J, sigma, tau,
         sigmaT, tauT, tauT1 = 0, omega, omega1 = 0, alpha[9];
    register int i, b;
    int Jsum;

    /* Initialize bit twiddle tables. */
    calctables(n);

    /* Distribute bits from r into rho. */
    for ( i = m - 1; i >= 0; i-- )
    {
    rho[i] = r & ((1 << n) - 1);
    r >>= n;
    }

    /* Loop over bytes. */
    Jsum = 0;
    for ( i = 0; i < m; i++ )
    {
    rh = rho[i];
    /* J[i] is principle position of rho[i]. */
    J = p_to_J[rh];

    /* sigma[i] is derived from rho[i] by exclusive-oring adjacent bits. */
    sigma = p_to_s[rh];

    /* tau[i] complements low bit of sigma[i], and bit at J[i] if
     * necessary to make even parity.
     */
    tau = sigma ^ 1;
    if ( parity[tau] )
        tau ^= bit[J];

    /* sigmaT[i] is circular shift of sigma[i] by sum of J[0..i-1] */
    /* tauT[i] is same circular shift of tau[i]. */
    if ( Jsum > 0 )
    {
        sigmaT = circshift[sigma][Jsum];
        tauT = circshift[tau][Jsum];
    }
    else
    {
        sigmaT = sigma;
        tauT = tau;
    }

    Jsum += J;
    if ( Jsum >= n )
        Jsum -= n;

    /* omega[i] is xor of omega[i-1] and tauT[i-1]. */
    if ( i == 0 )
        omega = 0;
    else
        omega = omega1 ^ tauT1;
    omega1 = omega;
    tauT1 = tauT;

    /* alpha[i] is xor of omega[i] and sigmaT[i] */
    alpha[i] = omega ^ sigmaT;
    }

    /* Build coordinates by taking bits from alphas. */
    for ( b = 0; b < n; b++ ) {
        register int ab, bt;
        ab = 0;
        bt = bit[b];
        /* Unroll the loop that stuffs bits into ab.
         * The result is shifted left by 9-m bits.
         */
        switch( m ) {
            case 9:    if ( alpha[8] & bt) ab |= 0x01;
            case 8:    if ( alpha[7] & bt) ab |= 0x02;
            case 7:    if ( alpha[6] & bt) ab |= 0x04;
            case 6:    if ( alpha[5] & bt) ab |= 0x08;
            case 5:    if ( alpha[4] & bt) ab |= 0x10;
            case 4:    if ( alpha[3] & bt) ab |= 0x20;
            case 3:    if ( alpha[2] & bt) ab |= 0x40;
            case 2:    if ( alpha[1] & bt) ab |= 0x80;
            case 1:    if ( alpha[0] & bt) ab |= 0x100;
        }
        a[b] = ab >> (9 - m);
    }
}

/*****************************************************************
 * TAG( hilbert_c2i )
 *
 * Convert coordinates of a point on a Hilbert curve to its index.
 * Inputs:
 *     n:    Number of coordinates.
 *     m:    Number of bits/coordinate.
 *     a:    Array of n m-bit coordinates.
 * Outputs:
 *     r:    Output index value.  n*m bits.
 * Assumptions:
 *     n*m <= 32, n <= 8, m <= 9.
 * Algorithm:
 *     Invert the above.
 */
void hilbert_c2i(int n, int m, int a[], long int *r)
{
    byte rho[9], J, sigma, tau,
         sigmaT, tauT, tauT1 = 0, omega, omega1 = 0, alpha[9];
    register int i, b;
    int Jsum;
    long int rl;

    calctables(n);

    /* Unpack the coordinates into alpha[i]. */
    /* First, zero out the alphas. */
    switch ( m ) {
    case 9: alpha[8] = 0;
    case 8: alpha[7] = 0;
    case 7: alpha[6] = 0;
    case 6: alpha[5] = 0;
    case 5: alpha[4] = 0;
    case 4: alpha[3] = 0;
    case 3: alpha[2] = 0;
    case 2: alpha[1] = 0;
    case 1: alpha[0] = 0;
    }

    /* The loop that unpacks bits of a[b] into alpha[i] has been unrolled.
     * The high-order bit of a[b] has to go into alpha[0], so we pre-shift
     * a[b] so that its high-order bit is always in the 0x100 position.
     */
    for ( b = 0; b < n; b++ )
    {
    register int bt = bit[b], t = a[b] << (9 - m);

    switch (m)
    {
    case 9: if ( t & 0x01 ) alpha[8] |= bt;
    case 8: if ( t & 0x02 ) alpha[7] |= bt;
    case 7: if ( t & 0x04 ) alpha[6] |= bt;
    case 6: if ( t & 0x08 ) alpha[5] |= bt;
    case 5: if ( t & 0x10 ) alpha[4] |= bt;
    case 4: if ( t & 0x20 ) alpha[3] |= bt;
    case 3: if ( t & 0x40 ) alpha[2] |= bt;
    case 2: if ( t & 0x80 ) alpha[1] |= bt;
    case 1: if ( t & 0x100 ) alpha[0] |= bt;
    }
    }

    Jsum = 0;
    for ( i = 0; i < m; i++ )
    {
    /* Compute omega[i] = omega[i-1] xor tauT[i-1]. */
    if ( i == 0 )
        omega = 0;
    else
        omega = omega1 ^ tauT1;

    sigmaT = alpha[i] ^ omega;
    /* sigma[i] is the left circular shift of sigmaT[i]. */
    if ( Jsum != 0 )
        sigma = circshift[sigmaT][n - Jsum];
    else
        sigma = sigmaT;

    rho[i] = s_to_p[sigma];

    /* Now we can get the principle position. */
    J = p_to_J[rho[i]];

    /* And compute tau[i] and tauT[i]. */
    /* tau[i] complements low bit of sigma[i], and bit at J[i] if
     * necessary to make even parity.
     */
    tau = sigma ^ 1;
    if ( parity[tau] )
        tau ^= bit[J];

    /* tauT[i] is right circular shift of tau[i]. */
    if ( Jsum != 0 )
        tauT = circshift[tau][Jsum];
    else
        tauT = tau;
    Jsum += J;
    if ( Jsum >= n )
        Jsum -= n;

    /* Carry forth the "i-1" values. */
    tauT1 = tauT;
    omega1 = omega;
    }

    /* Pack rho values into r. */
    rl = 0;
    for ( i = 0; i < m; i++ )
    rl = (rl << n) | rho[i];
    *r = rl;
}

/* in [0,range] */
int my_random(int range)
{
    int i;
    //double ran3();

    i = ran3() * range;
    return(i);
}

/*#####################################*/

#include <time.h>

#define MBIG 1000000000
#define MSEED 161803398
#define MZ 0
#define FAC (1.0/MBIG)

/* generates a uniform random value between 0 & 1 */
double ran3()
{
    static int inext,inextp;
    static long ma[56];
    static int iff=0;
    long mj,mk;
    int i,ii,k;
    static idum = -1;

    /****
    easier to debug if not randomly initialised
    ADDED - PLR July 2005
    if (idum == -1)
        idum = random_seed();
    ****/

    if (idum < 0 || iff == 0) {
        iff=1;
        mj=MSEED-(idum < 0 ? -idum : idum);
        mj %= MBIG;
        ma[55]=mj;
        mk=1;
        for (i=1;i<=54;i++) {
            ii=(21*i) % 55;
            ma[ii]=mk;
            mk=mj-mk;
            if (mk < MZ) mk += MBIG;
            mj=ma[ii];
        }
        for (k=1;k<=4;k++)
            for (i=1;i<=55;i++) {
                ma[i] -= ma[1+(i+30) % 55];
                if (ma[i] < MZ) ma[i] += MBIG;
            }
        inext=0;
        inextp=31;
        idum=1;
    }
    if (++inext == 56) inext=1;
    if (++inextp == 56) inextp=1;
    mj=ma[inext]-ma[inextp];
    if (mj < MZ) mj += MBIG;
    ma[inext]=mj;
    return mj*FAC;
}

#undef MBIG
#undef MSEED
#undef MZ
#undef FAC

/* gets initial random number to seed the random number generator
 * uses the time function and combines the second, minute, day, etc values
 *
 * returns a random integer
 */
int random_seed()
{
    char line[1000],str[100];
    FILE *fp;
    int c,sum;

    time_t date1;
    struct tm *date2;

    date1 = time((time_t *)NULL);
    date2 = gmtime(&date1);
    sum = date2->tm_mon + date2->tm_mday + date2->tm_hour +
          date2->tm_min + date2->tm_sec;

    return(sum);
}

/* ================================================================== */

/***** Bastardized C version of Java ellipse fitting code by Pilu *****/

double zero=10e-20;
int  solind=0;

void ellipse_only(double *x_cent, double *y_cent, double *major_axis, double *minor_axis, double *rot_angle)
{
    int np;           /* number of points */
    double D[MAX_POINTS+1][7];
    double S[7][7];
    double Const[7][7] ;
    double temp[7][7];
    double L[7][7];
    double C[7][7];

    double invL[7][7];
    double d[7];
    double V[7][7];
    double sol[7][7];
    double tx,ty;
    int nrot=0;
    int i,j;
    double pvec[7];

    Const[1][3] = -2;
    Const[2][2] = 1;
    Const[3][1] = -2;

    np = no_points;

    /* Now first fill design matrix */
    for (i=1; i <= np; i++) {
        tx = datax[i];
        ty = datay[i];
        D[i][1] = tx*tx;
        D[i][2] = tx*ty;
        D[i][3] = ty*ty;
        D[i][4] = tx;
        D[i][5] = ty;
        D[i][6] = 1.0;
    }

    /* Now compute scatter matrix  S */
    {
    int p,q,l;
    for (p=1;p<=6;p++)
    for (q=1;q<=6;q++) {
        S[p][q]=0.0;
        for (l=1;l<=np;l++)
          S[p][q]=S[p][q]+D[l][p]*D[l][q];
    }
    }

    choldc(S,6,L);

    inverse6(L,invL,6);

    AperB_T(Const,invL,temp,6,6,6,6);
    AperB6(invL,temp,C,6,6,6,6);

    jacobi2(C,6,d,V,nrot);

    A_TperB(invL,V,sol,6,6,6,6);

    /* Now normalize them  */
    for (j=1;j<=6;j++)  /* Scan columns */
      {
        double mod = 0.0;
        for (i=1;i<=6;i++)
          mod += sol[i][j]*sol[i][j];
        for (i=1;i<=6;i++)
          sol[i][j] /=  sqrt(mod);
      }

    for (i=1; i<=6; i++)
        if (d[i]<0 && ABS(d[i])>zero)
            solind = i;

    /* Now fetch the right solution */
    for (j=1;j<=6;j++)
      pvec[j] = sol[j][solind];

    determine_parameters(pvec[1],pvec[2],pvec[3],pvec[4],pvec[5],pvec[6],
                         x_cent,y_cent,major_axis,minor_axis,rot_angle);
}

void ROTATE(double a[7][7], int i, int j, int k, int l,
                    double tau, double s)
{
    double g,h;
    g=a[i][j]; h=a[k][l]; a[i][j]=g-s*(h+g*tau);
    a[k][l]=h+s*(g-h*tau);
}

void jacobi2(double a[7][7], int n, double d[7] , double v[7][7], int nrot)
{
    int j,iq,ip,i;
    double tresh,theta,tau,t,sm,s,h,g,c;

    double b[7];
    double z[7];

    for (ip=1;ip<=n;ip++) {
      for (iq=1;iq<=n;iq++) v[ip][iq]=0.0;
      v[ip][ip]=1.0;
    }
    for (ip=1;ip<=n;ip++) {
      b[ip]=d[ip]=a[ip][ip];
      z[ip]=0.0;
    }
    nrot=0;
    for (i=1;i<=50;i++) {
      sm=0.0;
      for (ip=1;ip<=n-1;ip++) {
        for (iq=ip+1;iq<=n;iq++)
          sm += ABS(a[ip][iq]);
      }
      if (sm == 0.0) {
        /*    free_vector(z,1,n);
          free_vector(b,1,n);  */
        return;
      }
      if (i < 4)
        tresh=0.2*sm/(n*n);
      else
        tresh=0.0;
      for (ip=1;ip<=n-1;ip++) {
        for (iq=ip+1;iq<=n;iq++) {
          g=100.0*ABS(a[ip][iq]);
          if (i > 4 && (ABS(d[ip])+g == ABS(d[ip]))
          && (ABS(d[iq])+g == ABS(d[iq])))
        a[ip][iq]=0.0;
          else if (ABS(a[ip][iq]) > tresh) {
        h=d[iq]-d[ip];
        if (ABS(h)+g == ABS(h))
          t=(a[ip][iq])/h;
        else {
          theta=0.5*h/(a[ip][iq]);
          t=1.0/(ABS(theta)+sqrt(1.0+theta*theta));
          if (theta < 0.0) t = -t;
        }
        c=1.0/sqrt(1+t*t);
        s=t*c;
        tau=s/(1.0+c);
        h=t*a[ip][iq];
        z[ip] -= h;
        z[iq] += h;
        d[ip] -= h;
        d[iq] += h;
        a[ip][iq]=0.0;
        for (j=1;j<=ip-1;j++)
            ROTATE(a,j,ip,j,iq,tau,s);
        for (j=ip+1;j<=iq-1;j++)
            ROTATE(a,ip,j,j,iq,tau,s);
        for (j=iq+1;j<=n;j++)
            ROTATE(a,ip,j,iq,j,tau,s);
        for (j=1;j<=n;j++)
            ROTATE(v,j,ip,j,iq,tau,s);
        ++nrot;
          }
        }
      }
      for (ip=1;ip<=n;ip++) {
        b[ip] += z[ip];
        d[ip]=b[ip];
        z[ip]=0.0;
      }
    }
}


/*  Perform the Cholesky decomposition     */
/* Return the lower triangular L  such that L*L'=A   */
void choldc(double a[7][7], int n, double l[7][7])
{
    int i,j,k;
    double sum;
    double p[7];

    for (i=1; i<=n; i++)  {
      for (j=i; j<=n; j++)  {
        for (sum=a[i][j],k=i-1;k>=1;k--) sum -= a[i][k]*a[j][k];
        if (i == j) {
          if (sum<=0.0)
        {}
          else
        p[i]=sqrt(sum); }
        else
          {
        a[j][i]=sum/p[i];
          }
      }
    }
    for (i=1; i<=n; i++)
      for (j=i; j<=n; j++)
        if (i==j)
          l[i][i] = p[i];
        else
          {
        l[j][i]=a[j][i];
        l[i][j]=0.0;
          }
}

/********************************************************************/
/**    Calcola la inversa della matrice  B mettendo il risultato   **/
/**    in InvB . Il metodo usato per l'inversione e' quello di     **/
/**    Gauss-Jordan.   N e' l'ordine della matrice .               **/
/**    ritorna 0 se l'inversione  corretta altrimenti ritorna     **/
/**    SINGULAR .                                                  **/
/********************************************************************/
int inverse6(double TB[7][7], double InvB[7][7], int N)
{
  int k,i,j,p,q;
  double mult;
  double D,temp;
  double maxpivot;
  int npivot;
  double B[7][8];
  double A[7][14];
  double eps = 10e-20;

  for(k=1;k<=N;k++)
    for(j=1;j<=N;j++)
        B[k][j]=TB[k][j];

  for (k=1;k<=N;k++)
{
  for (j=1;j<=N+1;j++)
    A[k][j]=B[k][j];
  for (j=N+2;j<=2*N+1;j++)
    A[k][j]=(double)0;
  A[k][k-1+N+2]=(double)1;
}
  for (k=1;k<=N;k++)
{
  maxpivot=ABS((double)A[k][k]);
  npivot=k;
  for (i=k;i<=N;i++)
    if (maxpivot<ABS((double)A[i][k]))
      {
    maxpivot=ABS((double)A[i][k]);
    npivot=i;
      }
  if (maxpivot>=eps)
    {      if (npivot!=k)
         for (j=k;j<=2*N+1;j++)
           {
         temp=A[npivot][j];
         A[npivot][j]=A[k][j];
         A[k][j]=temp;
           } ;
       D=A[k][k];
       for (j=2*N+1;j>=k;j--)
         A[k][j]=A[k][j]/D;
       for (i=1;i<=N;i++)
         {
           if (i!=k)
         {
           mult=A[i][k];
           for (j=2*N+1;j>=k;j--)
             A[i][j]=A[i][j]-mult*A[k][j] ;
         }
         }
     }
  else
    {  /* printf("\n The matrix may be singular !!") ; */
       return(-1);
     };
}
  /**   Copia il risultato nella matrice InvB  ***/
  for (k=1,p=1;k<=N;k++,p++)
    for (j=N+2,q=1;j<=2*N+1;j++,q++)
          InvB[p][q]=A[k][j];
  return(0);
}            /*  End of INVERSE   */

void AperB6(double _A[7][7], double _B[7][7], double _res[7][7],
        int _righA, int _colA, int _righB, int _colB)
{
    int p,q,l;

    for (p=1;p<=_righA;p++)
    for (q=1;q<=_colB;q++)
      { _res[p][q]=0.0;
        for (l=1;l<=_colA;l++)
          _res[p][q]=_res[p][q]+_A[p][l]*_B[l][q];
      }
}

void A_TperB(double _A[7][7], double  _B[7][7], double _res[7][7],
             int _righA, int _colA, int _righB, int _colB)
{
    int p,q,l;
    for (p=1;p<=_colA;p++)
    for (q=1;q<=_colB;q++) {
        _res[p][q]=0.0;
        for (l=1;l<=_righA;l++)
          _res[p][q]=_res[p][q]+_A[l][p]*_B[l][q];
    }
}

void AperB_T(double _A[7][7], double _B[7][7], double _res[7][7],
             int _righA, int _colA, int _righB, int _colB)
{
    int p,q,l;
    for (p=1;p<=_colA;p++)
    for (q=1;q<=_colB;q++)
      { _res[p][q]=0.0;
        for (l=1;l<=_righA;l++)
          _res[p][q]=_res[p][q]+_A[p][l]*_B[q][l];
      }
}

/*
 * ANSI C code from the article
 * "Centroid of a Polygon"
 * by Gerard Bashein and Paul R. Detmer,
    (gb@locke.hs.washington.edu, pdetmer@u.washington.edu)
 * in "Graphics Gems IV", Academic Press, 1994
 */

/* CUT DOWN VERSION */
void polyCentroid(double x[], double y[], int n, double *area)
{
     register int i, j;
     double ai, atmp = 0;
     for (i = n-1, j = 0; j < n; i = j, j++) {
         ai = x[i+1] * y[j+1] - x[j+1] * y[i+1];
         atmp += ai;
     }
     *area = atmp / 2;

     /* !!!!! make area unsigned !!!!! */
     *area = ABS(*area);
}

/* outputs ellipse in superdata format
 * or else ellipse and data in Postscript format
 */
void output_ellipse(double xc, double yc, double major_axis, double minor_axis, double rot_angle, char *filename, int mode)
{
    FILE *fp_out;
    float minx,maxx,miny,maxy,dx,dy;
    int i;

#if PRINTOUT
    printf("fitted parameters: %f %f %f %f %f\n",xc,yc,major_axis,minor_axis,rot_angle);
#endif

    if ((fp_out = fopen(filename,"w")) == NULL) {
        fprintf(stderr,"cant open %s\n",filename);
        exit(-1);
    }

    if (mode == SUPER) {
        fprintf(fp_out,"super\nlist: 0\n");
        fprintf(fp_out,"ellipse: 0.0 %.0f %.0f 0 0 0 0 %.0f %.0f %f 1\n",
            xc,yc,major_axis,minor_axis,rot_angle);
        fprintf(fp_out,"endl:\nendf:\n");
        fclose(fp_out);
    }
    else {
        fprintf(fp_out,"%%!PS-Adobe-2.0 EPSF-2.0\n");
        fprintf(fp_out,"%%%%Title: ellipse fit\n");
        fprintf(fp_out,"%%%%For: Paul Rosin\n");
        fprintf(fp_out,"%%%%Orientation: Portrait\n");
        fprintf(fp_out,"%%%%BoundingBox: (atend)\n");
        fprintf(fp_out,"%%%%Pages: 1\n");
        fprintf(fp_out,"%%%%EndComments\n");

        fprintf(fp_out,"/DrawEllipse {\n");
        fprintf(fp_out,"   /orient exch def\n");
        fprintf(fp_out,"   /width exch def\n");
        fprintf(fp_out,"   /endangle exch def\n");
        fprintf(fp_out,"   /startangle exch def\n");
        fprintf(fp_out,"   /yrad exch def\n");
        fprintf(fp_out,"   /xrad exch def\n");
        fprintf(fp_out,"   /y exch def\n");
        fprintf(fp_out,"   /x exch def\n");
        fprintf(fp_out,"   gsave\n");
        fprintf(fp_out,"   /cmtx matrix currentmatrix def\n");
        fprintf(fp_out,"   newpath\n");
        fprintf(fp_out,"   width setlinewidth\n");
        fprintf(fp_out,"   x y translate\n"),
        fprintf(fp_out,"   0 orient sub rotate\n");
        fprintf(fp_out,"   xrad yrad scale 0 0 1 startangle endangle arc\n");
        fprintf(fp_out,"   closepath\n");
        fprintf(fp_out,"   cmtx setmatrix\n");
        fprintf(fp_out,"   stroke\n");
        fprintf(fp_out,"   grestore\n");
        fprintf(fp_out,"   } def\n");

        fprintf(fp_out,"1 setlinejoin\n1 setlinecap\nnewpath\n");
        fprintf(fp_out,"1 setlinewidth\n");
        fprintf(fp_out,"/Lcirc 3 def\n");

        minx = maxx = datax[1];
        miny = maxy = datay[1];
        for (i = 1; i <= no_points; i++) {
            fprintf(fp_out,"newpath %f %f Lcirc 0.00 360.00 arc stroke\n",datax[i],datay[i]);
            minx = MIN(minx,datax[i]);
            maxx = MAX(maxx,datax[i]);
            miny = MIN(miny,datay[i]);
            maxy = MAX(maxy,datay[i]);
        }
        dx = maxx - minx;
        dy = maxy - miny;

        fprintf(fp_out,"%.2f %.2f %.2f %.2f %.2f %.2f %d %.2f DrawEllipse\n",
                    xc,yc,major_axis,minor_axis,0.0,360.0,1,RAD2DEG(-rot_angle));

        fprintf(fp_out,"%%%%Trailer\n");
        fprintf(fp_out,"%%%%BoundingBox: %f %f %f %f\n",
            minx - dx/2, miny - dy/2, maxx + dx/2, maxy + dy/2);
        fprintf(fp_out,"%%%%EOF\n");
    }
}
