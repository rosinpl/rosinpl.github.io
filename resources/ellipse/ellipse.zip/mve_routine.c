/*    minimum volume ellipsoid estimator
 *    converted from original FORTRAN using f2c and much post-hacking!
 *
 *    stripped to a routine that returns the weighted mean
 *
 *    Paul Rosin
 *    November 1996
 */

/***************************************************************************/
/*                                                                         */
/*        MINVOL (version of October 26, 1990)                             */
/*        Computes the minimum volume ellipsoid estimator (MVE)            */
/*        of multivariate location and dispersion.                         */
/*        Objective function: minimize the [(n+p+1)/2] order statistic     */
/*        to obtain the best possible finite sample breakdown point.       */
/*        Includes correction factor c(n,p) = 1 + 15/(n-p) .               */
/*                                                                         */
/***************************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define ABS(x) (((x)<0.0)? -(x): (x))

#define MAX_C      100000

#define NDIM 4
#define MAX_DATA MAX_C
#define MAX_DATA_SPACE (MAX_DATA*NDIM)

void mve(double data[100000][4], int no_points, double w_means[4]);
void mult_array(double *a, int n1, int n2, double fac);
void admit(double *rec, int nvar, int nvar1, double *sscp);
void zero_array(double *a, int n1, int n2);
void covar(int n, int nvar, int nvar1, double *sscp, double *cova, double *means, double *sd);
void correl(int nvar, double *a, double *b, double *sd);
void rangen_(int *n, int *nsel, int *index, int *seed);
double uniran_(int *seed);
void shsort_(double *a, int *n);
void copy_array(double *a, double *b, int n1, int n2);
void sweep_(double *a, int *nvar, int *k);
double mahad_(double *rec, int *nvar, double *means, double *sigma);
void repcmp(int n, int *nsel, int *reptab, int *replow, int *nrep);
void genpn(int n, int nsel, int *index);
void jacobi(int n, double *a, double *d, double *b, double *z);
double findq_(double *aw, int *ncas, int *k);

void mve(double data[100000][4], int no_points, double w_means[4])
{
    static double   eps = 1e-12;
    /* Median of chi-squared distribution: */
    static double   chi250[10] = {.454937, 1.38629, 2.36597, 3.3567, 4.35146,
                                  5.34812, 6.34581, 7.34412, 8.34283, 9.34182};
    /* Quantile 0.975 of chi-squared distribution: */
    static double   chi2[20] /* was [10][2] */ = {3.84146, 5.99147, 7.81473,
                              9.48773, 11.0705, 12.5916, 14.0671, 15.5073,
                              16.919, 18.307, 5.02389,
                              7.37776, 9.3484, 11.1433, 12.8325, 14.4494,
                              16.0128, 17.5346, 19.0228, 20.4831};
    static int      perc = 2;
    static double   pct[2] = {95., 97.5};
    static int      reptab[11] = {500, 1000, 1500, 2000, 2500, 3000, 3000,
                                  3000, 3000, 3000, 3000};
    static int      replow[11] = {500, 50, 22, 17, 15, 14, 0, 0, 0, 0, 0};

    int      ncol;
    int      seed=0, nsel;
    double   dist;
    int      nrep;
    int      nvar=0;
    double   fact2, medi2, dist2, adiff;
    double   mahad_(), findq_();
    int      j, k, i, n;
    double   w[MAX_DATA_SPACE];
    int      nhalf;
    double   means[10];
    int      index[11];
    double   odist;
    int      ndist;
    int      kount=0;    /* count the singular subsamples */
    double   pivot;
    int      ncova1, ncova2, ncova3, ncova4;
    double   odist2;
    int      nsscp1, nb, nc, nd, nz;
    double   sd[10];
    int      nmahad;
    double   bmeans[10], object;
    int      inbest[11];
    int      weight;
    double   volume;
    int      all;
    double   det;
    double   cnp;
    int      nin=0;
    double   rat;

    nvar = ncol = NDIM;
    if (nvar > 10) {
        fprintf(stderr,"ERROR: too many variables\n");
        exit(-1);
    }
    nsel = nvar + 1;

    /* Reading data: */
    n = k = 0;
    for (i = 0; i < no_points; i++) {
        for (j = 0; j < ncol; j++) {
			w[k] = data[i][j];
			k++;
        }
        n++;
    }

L18:
    if (nsel * nsel + (nvar + 2) * n + nvar * 3 + nvar * 5 * nvar > MAX_DATA_SPACE) {
        fprintf(stderr,"ERROR: not enough workspace\n");
        exit(-1);
    }

    /* Okay, data are read. We now know n. */

    if (n <= replow[nsel - 1]) {
        all = TRUE;
        repcmp(n, &nsel, reptab, replow, &nrep);
    }
    else {
        /* all combinations  */
		/* or set i = 0 for random replications */
        i = 0;

        if (i == 1) {
            all = TRUE;
            repcmp(n, &nsel, reptab, replow, &nrep);
        }
        else {
            all = FALSE;
            nrep = reptab[nsel - 1];
        }
    }

    /* nhalf is the quantile to be optimized */
    nhalf = (n + nvar + 1) / 2;

    /* compute offsets in work array w with following organization: */
    /* contents         size           offset                       */
    /* -----------------------------------------------------------  */
    /* data             n*nvar         1                            */
    /* original MD2's   n              nmahad                       */
    /* sscp             nsel*nsel      nsscp1                       */
    /* 4 cova arrays    4*nvar*nvar    ncova1,ncova2,ncova3,ncova4  */
    /* robust MD2's     n              ndist                        */
    /* 1 cova array     nvar*nvar      nc                           */
    /* eigenvalues      nvar           nd                           */
    /* 2 aux arrays     2*nvar         nb,nz                        */
    /* -----------------------------------------------------------  */
    /* total needed: (nvar+2)*n + nsel*nsel + 5*nvar*nvar + 3*nvar  */

    nmahad = n * nvar + 1;
    nsscp1 = nmahad + n;
    ncova1 = nsscp1 + nsel * nsel;
    ncova2 = ncova1 + nvar * nvar;
    ncova3 = ncova2 + nvar * nvar;
    ncova4 = ncova3 + nvar * nvar;
    ndist = ncova4 + nvar * nvar;
    nc = ndist + n;
    nd = nc + nvar * nvar;
    nb = nd + nvar;
    nz = nb + nvar;
    zero_array(&w[nsscp1 - 1],  nvar + 1, nvar + 1);
    for (i = 1; i <= n; ++i) {
        k = nvar * (i - 1) + 1;
        admit(&w[k - 1], nvar, nvar + 1, &w[nsscp1 - 1]);
    }

    covar(n, nvar, nvar + 1, &w[nsscp1 - 1], &w[ncova1 - 1], means, sd);
    copy_array(&w[ncova1 - 1], &w[ncova2 - 1], nvar, nvar);
    correl(nvar, &w[ncova1 - 1], &w[ncova1 - 1], sd);

    /* compute classical squared Mahalanobis distance of the data */
    for (j = 1; j <= nvar; j++)
        sweep_(&w[ncova2 - 1], &nvar, &j);
    for (j = 1; j <= n; j++) {
        k = (j - 1) * nvar + 1;
        w[nmahad + j - 2] = mahad_(&w[k - 1], &nvar, means, &w[ncova2 - 1]);
    }

    /* main loop;  drawing random subsamples */
    /* every time the sscp of the subsample is placed in nsscp1 */
    /* its covariance matrix in ncova1 */
    /* its inverse in ncova2 */
    /* the minimum volume covariance matrix is placed in ncova3 */
    /* its inverse in ncova4 */
    /* the mahalanobis distances are placed in ndist */

    object = (float) 1e6;
    if (all)
        for (i = 1; i <= nsel - 1; ++i)
            index[i - 1] = i;
    index[nsel - 1] = nsel - 1;

    for (i = 1; i <= nrep; ++i) {
        zero_array(&w[nsscp1 - 1], nvar + 1, nvar + 1);
        if (all)
            genpn(n, nsel, index);
        else
            rangen_(&n, &nsel, index, &seed);
        for (j = 1; j <= nsel; j++) {
            k = (index[j - 1] - 1) * nvar + 1;
            admit(&w[k - 1], nvar, nvar + 1, &w[nsscp1 - 1]);
        }
        covar(nsel, nvar, nvar + 1, &w[nsscp1 - 1], &w[ncova1 - 1], means, sd);
        copy_array(&w[ncova1 - 1], &w[ncova2 - 1], nvar, nvar);
        det = (float) 1.;
        for (j = 1; j <= nvar; j++) {
            pivot = w[ncova2 - 1 + (j - 1) * nvar + j - 1];
            det *= pivot;
            if (pivot < eps) {
                ++kount;
                goto L1000;
            }
            sweep_(&w[ncova2 - 1], &nvar, &j);
        }
        for (j = 1; j <= n; j++) {
            k = (j - 1) * nvar + 1;
            w[ndist + j - 2] = mahad_(&w[k - 1], &nvar, means, &w[ncova2 - 1]);
        }
        dist2 = findq_(&w[ndist - 1], &n, &nhalf);
        dist = sqrt(dist2);
        det = sqrt(det);
        volume = det * exp(nvar * log(dist));
        if (i == 1 || volume < object) {
            medi2 = dist2;
            object = volume;
            for (j = 1; j <= nsel; ++j)
                inbest[j - 1] = index[j - 1];
            copy_array(&w[ncova1 - 1], &w[ncova3 - 1], nvar, nvar);
            copy_array(&w[ncova2 - 1], &w[ncova4 - 1], nvar, nvar);
            copy_array(means, bmeans, nvar, 1);
        }
L1000:
        ;
    }

    mult_array(&w[ncova3 - 1], nvar, nvar, medi2);

    mult_array(&w[ncova4 - 1], nvar, nvar, 1.0 / medi2);

    /*   Multiply with correction factor 1 + 15/(n-p) */

    adiff = (double) (n - nvar);
    cnp = (float) 15./ adiff + (float) 1.;

    fact2 = cnp * cnp;
    fact2 /= chi250[nvar - 1];
    mult_array(&w[ncova3 - 1], nvar, nvar, fact2);
    mult_array(&w[ncova4 - 1], nvar, nvar, 1.0 / fact2);

    /* the location of the mve is in bmeans */
    /* the corresponding covariance in ncova3 */
    /* and its inverse in ncova4 */
    /* for every observation compute the mahalanobis distance */
    /* and compare it to a percentage point of chi2(p) */
    /* if the point is within, then weight=1 */

    /* sscp and covar of all the points within are in nsscp1 and ncova1 */

    zero_array(&w[nsscp1 - 1], nvar + 1, nvar + 1);

    for (i = 1; i <= n; ++i) {
        k = (i - 1) * nvar + 1;
        dist2 = mahad_(&w[k - 1], &nvar, bmeans, &w[ncova4 - 1]);
        dist = sqrt(dist2);
        odist2 = w[nmahad + i - 2];
        odist = sqrt(odist2);
        if (dist2 <= chi2[nvar + perc * 10 - 11]) {
            weight = 1;
            ++nin;
            admit(&w[k - 1], nvar, nvar + 1, &w[nsscp1 - 1]);
        }
        else
            weight = 0;
    }

    /* at this point the augmented sscp of the points within */
    /* the ellipsoid is at offset nsscp1 */

    covar(nin, nvar, nvar + 1, &w[nsscp1 - 1], &w[ncova1 - 1], means, sd);

    /* Weighted mean */
    for (i = 0; i < nvar; ++i)
		w_means[i] = means[i];
}

/******************************************************************/
/*        MVELIB (version January 7, 1990).                       */
/*        Set of subroutines for MINVOL.                          */
/******************************************************************/

void mult_array(double *a, int n1, int n2, double fac)
{
    /* Local variables */
    int  i, j;

    /* Parameter adjustments */
    a -= n1 + 1;

    for (i = 1; i <= n1; ++i)
        for (j = 1; j <= n2; ++j)
            a[i + j * n1] *= fac;
}

void admit(double *rec, int nvar, int nvar1, double *sscp)
{
    /* System generated locals */
    int  sscp_dim1, sscp_offset;

    /* Local variables */
    int   i, j;

    /* Parameter adjustments */
    sscp_dim1 = nvar1;
    sscp_offset = sscp_dim1 + 1;
    sscp -= sscp_offset;
    --rec;

    ++sscp[sscp_dim1 + 1];
    for (j = 1; j <= nvar; ++j) {
        sscp[(j + 1) * sscp_dim1 + 1] += rec[j];
        sscp[j + 1 + sscp_dim1] = sscp[(j + 1) * sscp_dim1 + 1];
    }
    for (i = 1; i <= nvar; ++i)
        for (j = 1; j <= nvar; ++j)
            sscp[i + 1 + (j + 1) * sscp_dim1] += rec[i] * rec[j];
}

/* set all array elements to 0 */
void zero_array(double *a, int n1, int n2)
{
    /* Local variables */
    int   i, j;

    /* Parameter adjustments */
    a -= n1 + 1;

    for (i = 1; i <= n1; ++i)
        for (j = 1; j <= n2; ++j)
            a[i + j * n1] = (float) 0.;
}

void covar(int n, int nvar, int nvar1, double *sscp, double *cova, double *means, double *sd)
{
    /* System generated locals */
    int  sscp_offset, cova_offset;

    /* Local variables */
    double f;
    int   i, j;

    /* Parameter adjustments */
    --sd;
    --means;
    cova_offset = nvar + 1;
    cova -= cova_offset;
    sscp_offset = nvar1 + 1;
    sscp -= sscp_offset;

    for (i = 1; i <= nvar; ++i) {
        means[i] = sscp[(i + 1) * nvar1 + 1];
        sd[i] = sscp[i + 1 + (i + 1) * nvar1];
        f = (sd[i] - means[i] * means[i] / n) / (n - 1);
        if (f > 0.)
            sd[i] = sqrt(f);
        else
            sd[i] = (float) 0.;
        means[i] /= n;
    }
    for (i = 1; i <= nvar; ++i)
        for (j = 1; j <= nvar; ++j)
            cova[i + j * nvar] = sscp[i + 1 + (j + 1) * nvar1];
    for (i = 1; i <= nvar; ++i)
        for (j = 1; j <= nvar; ++j) {
            cova[i + j * nvar] -= n * means[i] * means[j];
            cova[i + j * nvar] /= n - 1;
        }
}

void correl(int nvar, double *a, double *b, double *sd)
{
    /* Local variables */
    int   i, j;

    /* Parameter adjustments */
    --sd;
    b -= nvar + 1;
    a -= nvar + 1;

    for (i = 1; i <= nvar; ++i)
        for (j = 1; j <= nvar; ++j)
            b[i + j * nvar] = a[i + j * nvar] / (sd[i] * sd[j]);
}

/* draws nsel numbers out of n 
 * index is the index set
 */
void rangen_(int *n, int *nsel, int *index, int *seed)
{
    /* Local variables */
    int   i, j;
    extern double uniran_();
    int   num;

    /* Parameter adjustments */
    --index;

    for (i = 1; i <= *nsel; ++i) {
L9910:
        num = (int ) (uniran_(seed) * *n) + 1;
        if (i > 1)
            for (j = 1; j <= i - 1; ++j)
                if (index[j] == num)
                    goto L9910;
        index[i] = num;
    }
}

/* random number from uniform distribution on 0-1 */
double uniran_(int *seed)
{
    int   quot;

    *seed = *seed * 5761 + 999;
    quot = *seed / 65536;
    *seed -= quot << 16;
    return((float) (*seed) / (float) 65536);
}

void shsort_(double *a, int *n)
{
    /* Local variables */
    int   i, j;
    double t;
    int   nextj, gap;

    /* Parameter adjustments */
    --a;

    gap = *n;
L99100:
    gap /= 2;
    if (gap == 0)
        return;
    for (i = 1; i <= *n - gap; ++i) {
        j = i;
L99120:
        if (j < 1)
            goto L99180;
        nextj = j + gap;
        if (a[j] > a[nextj]) {
            t = a[j];
            a[j] = a[nextj];
            a[nextj] = t;
        }
        else
            j = 0;
        j -= gap;
        goto L99120;
L99180:
        ;
    }
    goto L99100;
}

void copy_array(double *a, double *b, int n1, int n2)
{
    /* Local variables */
    int   i, j;

    /* Parameter adjustments */
    b -= n1 + 1;
    a -= n1 + 1;

    for (i = 1; i <= n1; ++i)
        for (j = 1; j <= n2; ++j)
            b[i + j * n1] = a[i + j * n1];
}

void sweep_(double *a, int *nvar, int *k)
{
    /* System generated locals */
    int          a_dim1, a_offset;

    /* Local variables */
    double b, d;
    int   i, j;

    /* Parameter adjustments */
    a_dim1 = *nvar;
    a_offset = a_dim1 + 1;
    a -= a_offset;

    d = a[*k + *k * a_dim1];
    for (j = 1; j <= *nvar; ++j)
        a[*k + j * a_dim1] /= d;
    for (i = 1; i <= *nvar; ++i) {
        if (i != *k) {
            b = a[i + *k * a_dim1];
            for (j = 1; j <= *nvar; ++j)
                a[i + j * a_dim1] -= b * a[*k + j * a_dim1];
            a[i + *k * a_dim1] = -b / d;
        }
    }
    a[*k + *k * a_dim1] = 1 / d;
}

double mahad_(double *rec, int *nvar, double *means, double *sigma)
{
    /* System generated locals */
    int          sigma_dim1, sigma_offset;

    /* Local variables */
    int   j, k;
    double t;

    /* Parameter adjustments */
    sigma_dim1 = *nvar;
    sigma_offset = sigma_dim1 + 1;
    sigma -= sigma_offset;
    --means;
    --rec;

    t = 0.;
    for (j = 1; j <= *nvar; ++j)
        for (k = 1; k <= *nvar; ++k)
            t += (rec[j] - means[j]) * (rec[k] - means[k]) *
                 sigma[j + k * sigma_dim1];
    return t;
}

void repcmp(int n, int *nsel, int *reptab, int *replow, int *nrep)
{
    /* Local variables */
    int   pfac, j, npfac;

    /* Parameter adjustments */
    --replow;
    --reptab;

    if (*nsel == 1)
        *nrep = n;
    else {
        pfac = 1;
        for (j = 2; j <= *nsel; ++j)
            pfac = j * pfac;
        npfac = n;
        for (j = n - 1; j >= n - *nsel + 1; --j)
            npfac = j * npfac;
        *nrep = npfac / pfac;
    }
}

void genpn(int n, int nsel, int *index)
{
    int i, k;

    /* Parameter adjustments */
    --index;

    k = nsel;
    index[k]++;
L9910:
    if (k == 1 || index[k] <= n - (nsel - k))
        return;
    k--;
    index[k]++;
    for (i = k + 1; i <= nsel; ++i)
        index[i] = index[i - 1] + 1;
    goto L9910;
}

void jacobi(int n, double *a, double *d, double *b, double *z)
{
    /* System generated locals */
    int          a_dim1, a_offset;
    double      d__1, d__2, d__3, d__4;

    /* Local variables */
    double c, g, h;
    int   i, j, p, q;
    double s, t, theta, tresh, sm, tau;

    /* jacobi method for real symmetric matrices */
    /* see wilkinson and reinsch p 204 */
    /* only eigenvalues will be computed */
    /* b and z are auxiliary arrays */

    /* Parameter adjustments */
    --z;
    --b;
    --d;
    a_dim1 = n;
    a_offset = a_dim1 + 1;
    a -= a_offset;

    for (p = 1; p <= n; ++p) {
        b[p] = a[p + p * a_dim1];
        d[p] = a[p + p * a_dim1];
        z[p] = (float) 0.;
    }
    for (i = 1; i <= 50; ++i) {
        sm = (float) 0.;
        for (p = 1; p <= n - 1; ++p)
            for (q = p + 1; q <= n; ++q)
                sm += (d__1 = a[p + q * a_dim1], ABS(d__1));
        if (sm == 0.)
            return;
        if (i < 4)
            tresh = sm * (float).2 / (n * n);
        else
            tresh = (float) 0.;
        for (p = 1; p <= n - 1; ++p) {
            for (q = p + 1; q <= n; ++q) {
                g = (d__1 = a[p + q * a_dim1], ABS(d__1)) * (float) 100.;
                if (i > 4 &&
                    (d__1 = d[p], ABS(d__1)) +
                    g == (d__2 = d[p], ABS(d__2))
                    && (d__3 = d[q], ABS(d__3))
                    + g == (d__4 = d[q], ABS(d__4)))
                {
                    a[p + q * a_dim1] = (float) 0.;
                }
                else {
                    if ((d__1 = a[p + q * a_dim1], ABS(d__1)) > tresh) {
                        h = d[q] - d[p];
                        if (ABS(h) + g == ABS(h))
                            t = a[p + q * a_dim1] / h;
                        else {
                            theta = h * (float).5 / a[p + q * a_dim1];
                            t = (float) 1./ 
                                (ABS(theta) + sqrt(theta * theta + (float) 1.));
                            if (theta < 0.)
                                t = -t;
                        }
                        c = 1 / sqrt(t * t + (float) 1.);
                        s = t * c;
                        tau = s / (c + (float) 1.);
                        h = t * a[p + q * a_dim1];
                        z[p] -= h;
                        z[q] += h;
                        d[p] -= h;
                        d[q] += h;
                        a[p + q * a_dim1] = (float) 0.;
                        for (j = 1; j <= p - 1; ++j) {
                            g = a[j + p * a_dim1];
                            h = a[j + q * a_dim1];
                            a[j + p * a_dim1] = g - s * (h + g * tau);
                            a[j + q * a_dim1] = h + s * (g - h * tau);
                        }
                        for (j = p + 1; j <= q - 1; ++j) {
                            g = a[p + j * a_dim1];
                            h = a[j + q * a_dim1];
                            a[p + j * a_dim1] = g - s * (h + g * tau);
                            a[j + q * a_dim1] = h + s * (g - h * tau);
                        }
                        for (j = q + 1; j <= n; ++j) {
                            g = a[p + j * a_dim1];
                            h = a[q + j * a_dim1];
                            a[p + j * a_dim1] = g - s * (h + g * tau);
                            a[q + j * a_dim1] = h + s * (g - h * tau);
                        }
                    }
                }
            }
        }
        for (p = 1; p <= n; ++p) {
            b[p] += z[p];
            d[p] = b[p];
            z[p] = (float) 0.;
        }
    }
}

double findq_(double *aw, int *ncas, int *k)
{
    /* Local variables */
    int   j, l;
    double ax, wa;
    int   lr, jnc;

    /* see "pull" by Dr. Annick Leroy */

    /* Parameter adjustments */
    --aw;

    l = 1;
    lr = *ncas;
L9920:
    if (l >= lr)
        goto L9990;
    ax = aw[*k];
    jnc = l;
    j = lr;
L9930:
    if (jnc > j)
        goto L9980;
L9940:
    if (aw[jnc] >= ax)
        goto L9950;
    ++jnc;
    goto L9940;
L9950:
    if (aw[j] <= ax)
        goto L9960;
    --j;
    goto L9950;
L9960:
    if (jnc > j)
        goto L9970;
    wa = aw[jnc];
    aw[jnc] = aw[j];
    aw[j] = wa;
    ++jnc;
    --j;
L9970:
    goto L9930;
L9980:
    if (j < *k)
        l = jnc;
    if (*k < jnc)
        lr = j;
    goto L9920;
L9990:
    return aw[*k];
}
