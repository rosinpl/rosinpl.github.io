extern float angle();
