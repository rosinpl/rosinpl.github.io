/* ellipse-specific fitting of conic
 * provided by chatGPT as a replacement to the my bastardized C version of Java ellipse fitting code by Pilu
 * as laterly that seemed to fail (maybe due to compiler changes)
 * reads in pixel lists and fits ellipses to them, and outputs superdata
 *
 * Paul Rosin
 * March 2026
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define ABS(x)       (((x)<0.0)? (-(x)): (x))
#define SQR(x)       ((x)*(x))

#define MAX_POINTS 10000

extern float x_trans3[],y_trans3[];
extern int nseg2;

int ellipse_fit(float *x_cent, float *y_cent, float *major_axis, float *minor_axis, float *rot_angle);

double x[MAX_POINTS],y[MAX_POINTS];

int fit_ellipse_conic_nolib(const double *x, const double *y, int n, double p_out[6]);
int conic_to_ellipse_params(const double p[6], double *xc, double *yc, double *a, double *b, double *theta_rad);
int read_link_data(FILE *fp, int *endoffile);

int ellipse_fit(float *x_cent, float *y_cent, float *major_axis, float *minor_axis, float *rot_angle)
{
    int j;
    double x_cent1,y_cent1,major_axis1,minor_axis1,rot_angle1;

    // bit clunky
    for(int j=0;j<nseg2;j++){
        x[j] = x_trans3[j];
        y[j] = y_trans3[j];
    }
    /* ### hack for compatibility ### */
    x[0] = x[nseg2];
    y[0] = y[nseg2];

    double p[6];
    if (!fit_ellipse_conic_nolib(x, y, nseg2, p)) {
      printf("Fit failed\n");
	  /***
      for(int j=0;j<nseg2;j++){
	  	 printf("%.1f %.1f\n",x[j],y[j]);
	  }
	  ***/
      return 1;
    }
  
    if (conic_to_ellipse_params(p, &x_cent1,&y_cent1, &major_axis1,&minor_axis1, &rot_angle1)) {
      *x_cent = x_cent1;
      *y_cent = y_cent1;
      *major_axis = major_axis1;
      *minor_axis = minor_axis1;
      *rot_angle = rot_angle1;
      //printf("Ellipse: center=(%g,%g) axes=(%g,%g) theta=%g rad\n", x_cent1,y_cent1,major_axis1,minor_axis1,rot_angle1);
      return 0;
    } else {
      fprintf(stderr,"Could not convert to geometric params (degenerate / not ellipse)\n");
	  /***
      for(int j=0;j<nseg2;j++){
	  	 printf("%.1f %.1f\n",x[j],y[j]);
	  }
	  ***/
      return 1;
    }
}

/*
  Pure-C ellipse-specific conic fit (no external libraries)

  Fits conic parameters p = [A,B,C,D,E,F] for:
      A x^2 + B x y + C y^2 + D x + E y + F = 0
  with ellipse constraint (selects solution with 4AC - B^2 > 0).

  Method:
   - Build scatter matrix S = D^T D with design D=[x^2, xy, y^2, x, y, 1]
   - Partition into S11,S12,S22
   - Compute reduced 3x3: Sred = S11 - S12 * inv(S22) * S12^T
   - Solve generalized eigen: Sred a = λ C a
     where C = [[0,0,2],[0,-1,0],[2,0,0]] (invertible)
   - Convert to standard eigenproblem: M a = λ a, M = inv(C)*Sred
   - Choose eigenvector yielding ellipse: 4A*C - B^2 > 0
   - Recover linear terms: [D,E,F]^T = -inv(S22) * S12^T * [A,B,C]^T
   - Undo centering to original coordinates

  Build:
    gcc ellipse_fit_nolib.c -O2 -lm

  Minimal demo:
    gcc ellipse_fit_nolib.c -O2 -lm -DDEMO && ./a.out
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* ---------- 3x3 helpers ---------- */

static void mat3_zero(double M[3][3]) { memset(M, 0, 9*sizeof(double)); }

static void mat3_mul_mat3(const double A[3][3], const double B[3][3], double C[3][3]) {
  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      double s=0;
      for(int k=0;k<3;k++) s += A[i][k]*B[k][j];
      C[i][j]=s;
    }
  }
}

static void mat3T_mul_mat3(const double A[3][3], const double B[3][3], double C[3][3]) {
  // C = A^T * B
  for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
      double s=0;
      for(int k=0;k<3;k++) s += A[k][i]*B[k][j];
      C[i][j]=s;
    }
  }
}

static void mat3_mul_vec3(const double A[3][3], const double x[3], double y[3]) {
  for(int i=0;i<3;i++){
    y[i]=A[i][0]*x[0]+A[i][1]*x[1]+A[i][2]*x[2];
  }
}

static void mat3_sub(const double A[3][3], const double B[3][3], double C[3][3]) {
  for(int i=0;i<3;i++) for(int j=0;j<3;j++) C[i][j]=A[i][j]-B[i][j];
}

static double det3(const double M[3][3]) {
  return
    M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1]) -
    M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0]) +
    M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0]);
}

static int inv3(const double M[3][3], double invM[3][3]) {
  double a=M[0][0], b=M[0][1], c=M[0][2];
  double d=M[1][0], e=M[1][1], f=M[1][2];
  double g=M[2][0], h=M[2][1], i=M[2][2];

  double A =  (e*i - f*h);
  double B = -(d*i - f*g);
  double C =  (d*h - e*g);
  double D = -(b*i - c*h);
  double E =  (a*i - c*g);
  double F = -(a*h - b*g);
  double G =  (b*f - c*e);
  double H = -(a*f - c*d);
  double I =  (a*e - b*d);

  double det = a*A + b*B + c*C;
  if (fabs(det) < 1e-18) return 0;

  double invdet = 1.0/det;
  invM[0][0]=A*invdet; invM[0][1]=D*invdet; invM[0][2]=G*invdet;
  invM[1][0]=B*invdet; invM[1][1]=E*invdet; invM[1][2]=H*invdet;
  invM[2][0]=C*invdet; invM[2][1]=F*invdet; invM[2][2]=I*invdet;
  return 1;
}

static void vec3_cross(const double a[3], const double b[3], double c[3]) {
  c[0] = a[1]*b[2] - a[2]*b[1];
  c[1] = a[2]*b[0] - a[0]*b[2];
  c[2] = a[0]*b[1] - a[1]*b[0];
}

static double vec3_norm(const double v[3]) {
  return sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
}

static int vec3_normalize(double v[3]) {
  double n = vec3_norm(v);
  if (n < 1e-18) return 0;
  v[0]/=n; v[1]/=n; v[2]/=n;
  return 1;
}

/* ---------- cubic solver for real roots: x^3 + a x^2 + b x + c = 0 ---------- */

static int solve_cubic_real(double a, double b, double c, double roots[3]) {
  // Depress cubic: x = y - a/3 => y^3 + p y + q = 0
  double a3 = a / 3.0;
  double p = b - a*a3;                         // b - a^2/3
  double q = 2*a3*a3*a3 - a3*b + c;            // 2a^3/27 - ab/3 + c

  double disc = (q*q)/4.0 + (p*p*p)/27.0;

  if (disc > 1e-15) {
    // One real root
    double sqrt_disc = sqrt(disc);
    double u = cbrt(-q/2.0 + sqrt_disc);
    double v = cbrt(-q/2.0 - sqrt_disc);
    roots[0] = (u + v) - a3;
    return 1;
  } else if (fabs(disc) <= 1e-15) {
    // Multiple real roots (at least two equal)
    double u = cbrt(-q/2.0);
    roots[0] =  2*u - a3;
    roots[1] = -u - a3;
    return 2;
  } else {
    // Three distinct real roots
    double r = sqrt(-p*p*p/27.0);
    double phi = acos(-q/(2.0*r));
    double t = 2.0 * sqrt(-p/3.0);

    roots[0] = t*cos(phi/3.0) - a3;
    roots[1] = t*cos((phi + 2.0*M_PI)/3.0) - a3;
    roots[2] = t*cos((phi + 4.0*M_PI)/3.0) - a3;
    return 3;
  }
}

/* ---------- eigenvectors for 3x3 (general) matrix M via (M-λI)v=0 ---------- */

static int eigenvector_3x3(const double M[3][3], double lambda, double v[3]) {
  double A[3][3] = {
    { M[0][0]-lambda, M[0][1],        M[0][2]       },
    { M[1][0],        M[1][1]-lambda, M[1][2]       },
    { M[2][0],        M[2][1],        M[2][2]-lambda}
  };

  double r1[3] = {A[0][0],A[0][1],A[0][2]};
  double r2[3] = {A[1][0],A[1][1],A[1][2]};
  double r3[3] = {A[2][0],A[2][1],A[2][2]};

  double c12[3], c13[3], c23[3];
  vec3_cross(r1,r2,c12);
  vec3_cross(r1,r3,c13);
  vec3_cross(r2,r3,c23);

  double n12=vec3_norm(c12), n13=vec3_norm(c13), n23=vec3_norm(c23);

  if (n12 >= n13 && n12 >= n23) { v[0]=c12[0]; v[1]=c12[1]; v[2]=c12[2]; }
  else if (n13 >= n12 && n13 >= n23) { v[0]=c13[0]; v[1]=c13[1]; v[2]=c13[2]; }
  else { v[0]=c23[0]; v[1]=c23[1]; v[2]=c23[2]; }

  return vec3_normalize(v);
}

/* ---------- main ellipse fit ---------- */

int fit_ellipse_conic_nolib(const double *x, const double *y, int n, double p_out[6]) {
  if (n < 6) return 0;

  // Center for numerical stability
  double mx=0.0, my=0.0;
  for(int k=0;k<n;k++){ mx += x[k]; my += y[k]; }
  mx /= (double)n; my /= (double)n;

  // Scatter blocks
  double S11[3][3], S12[3][3], S22[3][3];
  mat3_zero(S11); mat3_zero(S12); mat3_zero(S22);

  for(int k=0;k<n;k++){
    double X = x[k] - mx;
    double Y = y[k] - my;

    double d1[3] = { X*X, X*Y, Y*Y };
    double d2[3] = { X,   Y,   1.0 };

    for(int i=0;i<3;i++){
      for(int j=0;j<3;j++){
        S11[i][j] += d1[i]*d1[j];
        S12[i][j] += d1[i]*d2[j];
        S22[i][j] += d2[i]*d2[j];
      }
    }
  }

  double invS22[3][3];
  if (!inv3(S22, invS22)) return 0;

  // Sred = S11 - S12*inv(S22)*S12^T
  double tmp[3][3], S12T[3][3], prod[3][3], Sred[3][3];
  mat3_mul_mat3(S12, invS22, tmp);
  for(int i=0;i<3;i++) for(int j=0;j<3;j++) S12T[i][j] = S12[j][i];
  mat3_mul_mat3(tmp, S12T, prod);
  mat3_sub(S11, prod, Sred);

  // Constraint matrix C (invertible)
  // C = [[0,0,2],[0,-1,0],[2,0,0]]
  double Cmat[3][3] = {
    {0, 0, 2},
    {0,-1, 0},
    {2, 0, 0}
  };
  double invC[3][3];
  if (!inv3(Cmat, invC)) return 0;

  // Standard eigenproblem: M a = λ a where M = inv(C)*Sred
  double M[3][3];
  mat3_mul_mat3(invC, Sred, M);

  // Characteristic polynomial coefficients for 3x3:
  // λ^3 - tr(M) λ^2 + s2 λ - det(M) = 0
  double tr = M[0][0] + M[1][1] + M[2][2];

  // s2 = sum of principal 2x2 minors:
  double s2 =
    (M[0][0]*M[1][1] - M[0][1]*M[1][0]) +
    (M[0][0]*M[2][2] - M[0][2]*M[2][0]) +
    (M[1][1]*M[2][2] - M[1][2]*M[2][1]);

  double det = det3(M);

  // Convert to x^3 + a x^2 + b x + c = 0
  double a = -tr;
  double b =  s2;
  double c = -det;

  double evals[3];
  int nr = solve_cubic_real(a, b, c, evals);
  if (nr <= 0) return 0;

  // Choose eigenvector that yields ellipse (4AC - B^2 > 0)
  double best_a[3] = {0,0,0};
  int found = 0;

  for(int i=0;i<nr;i++){
    double v[3];
    if (!eigenvector_3x3(M, evals[i], v)) continue;

    // v corresponds to [A,B,C] in centered coords
    double A0=v[0], B0=v[1], C0=v[2];
    if (4.0*A0*C0 - B0*B0 > 0.0) {
      best_a[0]=A0; best_a[1]=B0; best_a[2]=C0;
      found = 1;
      break;
    }
  }
  if (!found) return 0;

  // Linear terms in centered coords:
  // [D,E,F]^T = -inv(S22) * S12^T * [A,B,C]^T
  double tvec[3], lin[3];
  mat3_mul_vec3(S12T, best_a, tvec);
  mat3_mul_vec3(invS22, tvec, lin);
  lin[0] = -lin[0];
  lin[1] = -lin[1];
  lin[2] = -lin[2];

  // Conic in centered coords (X,Y):
  // A0 X^2 + B0 X Y + C0 Y^2 + D0 X + E0 Y + F0 = 0
  double A0=best_a[0], B0=best_a[1], C0=best_a[2];
  double D0=lin[0],    E0=lin[1],    F0=lin[2];

  // Convert back to original coords (x,y) with X=x-mx, Y=y-my
  double A1 = A0;
  double B1 = B0;
  double C1 = C0;

  double D1 = D0 - 2.0*A0*mx - B0*my;
  double E1 = E0 - 2.0*C0*my - B0*mx;

  double F1 = F0
            + A0*mx*mx + B0*mx*my + C0*my*my
            - D0*mx - E0*my;

  // Normalize scale (optional but handy)
  double norm = sqrt(A1*A1 + B1*B1 + C1*C1 + D1*D1 + E1*E1);
  if (norm < 1e-18) return 0;
  A1/=norm; B1/=norm; C1/=norm; D1/=norm; E1/=norm; F1/=norm;

  p_out[0]=A1; p_out[1]=B1; p_out[2]=C1; p_out[3]=D1; p_out[4]=E1; p_out[5]=F1;
  return 1;
}

/* Optional: convert conic to center/axes/angle */
int conic_to_ellipse_params(const double p[6],
                            double *xc, double *yc,
                            double *a, double *b,
                            double *theta_rad)
{
  double A=p[0], B=p[1], C=p[2], D=p[3], E=p[4], F=p[5];

  if (4.0*A*C - B*B <= 0.0) return 0;

  double det = 4.0*A*C - B*B;
  if (fabs(det) < 1e-18) return 0;

  *xc = (B*E - 2.0*C*D)/det;
  *yc = (B*D - 2.0*A*E)/det;

  double x0=*xc, y0=*yc;
  double Fp = F + A*x0*x0 + B*x0*y0 + C*y0*y0 + D*x0 + E*y0;

  *theta_rad = 0.5 * atan2(B, (A - C));
  double ct = cos(*theta_rad), st = sin(*theta_rad);

  double Apr = A*ct*ct + B*ct*st + C*st*st;
  double Cpr = A*st*st - B*ct*st + C*ct*ct;

  if (Apr <= 0.0 || Cpr <= 0.0) return 0;
  if (Fp >= 0.0) return 0;

  *a = sqrt((-Fp)/Apr);
  *b = sqrt((-Fp)/Cpr);
  return 1;
}
