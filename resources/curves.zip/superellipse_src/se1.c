/*
    Basterdised version of superellipses.c
    fits one superellipse to complete pixel list without recursing or segmenting

    Input: pixel data format.
    Output: super data format (only arcs).
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define TESTING 0         /* output in non-super format */
#define DO_ARC  0         /* fit arc, otherwise fit complete superellipse */

#define NO_LINE_SEGS 10000 /* max number of lines per list */
#define NO_ARCS 200       /* max number of arcs per list  */
#define LINE 1
#define ARC 2
#define PI 3.141591
#define CLOCKWISE 1       /* direction of arc from start to finish */
#define ANTICLOCKWISE 2

#define DEBUG 1           /* compile debug output if 1 */
#define STOP_EARLY 1      /* just fit to all data in a list and stop if 1 */
                          /* normal recursive algorithm if = 0 */
#define NO_PIXELS 10000
#define NO_ARCS 200       /* max number of arcs per list  */

#define PI 3.141591
#define NINETY 1.570796327
#define KEEP 0         /* KEEP and REJECT used to tell if arcs to be kept */
#define REJECT 1
#define LARGE_SIG 99999
#define MIN_LENGTH 7
#define FALSE 0
#define TRUE (!FALSE)

#define ELLIPSE 0
#define PARABOLA 1
#define HYPERBOLA 2

#define SQR(x) ((x) * (x))

/* temp array for manipulatable data from x_c,y_c */
float x_trans3[NO_LINE_SEGS],y_trans3[NO_LINE_SEGS];

/* ellipse parameterisation arrays */
float arc_centre_x[NO_ARCS],arc_centre_y[NO_ARCS];
int arc_start_x[NO_ARCS],arc_start_y[NO_ARCS];
int arc_end_x[NO_ARCS],arc_end_y[NO_ARCS];
float arc_squareness[NO_ARCS];
float maj_axis[NO_ARCS],min_axis[NO_ARCS];
float rot_ang[NO_ARCS];
int arc_dirs[NO_ARCS];
float arc_sig[NO_ARCS];

int number_arcs;
int nseg2;   /* number of points in x_trans3, y_trans3 */

int arc_status[NO_ARCS];
int x_c[NO_PIXELS],y_c[NO_PIXELS];
int arc_start[NO_ARCS],arc_finish[NO_ARCS];

int number_pixels;

int global_pos;
int representation_ok;

FILE *fp,*fp_out;

void read_list(int *number_pixels, int *end_of_file, int *list_no);
void segment(int start_in, int finish_in, float *sig_out);
float angle(float x1, float y1, float x2, float y2);
float euclid(float x1, float y1, float x2, float y2);
void compute_minimum_diff(float *deviation, float x_cir, float y_cir, float x1, float y1, float x2, float y2);
void compute_dev(float *max_dev, int *max_pos, float major_axis, float minor_axis, float squareness, int arc_dir);
void compute_lgt(float *lgt, float major_axis, float minor_axis, float squareness, int arc_dir);
void compute_poly_lgt(float *lgt);
void determine_superellipse_fit(int st, int fi, float *final_major_axis, float *final_minor_axis, float *final_squareness, float *final_rot_angle, float *final_xc, float *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig);
float distance(float x1, float y1, float x2, float y2);
int curve_type(char array[50]);
int find_conic_type(float c1,float c2,float c3);
void error(char *s);
float first_root(float t,float e);

void fit_superellipse(float *a, float *b, float *e, float *xc, float *yc, float *rot);

int main(int argc, char *argv[]);

int main(int argc, char *argv[])
{
    int j;
    float sig;    /* not really used - just dummy param for segment */
    int list_no,end_of_file;
    float temp;
    char file_type[50];
    char *file_name_in;
    char *file_name_out;
    int set_input_file = FALSE;
    int set_output_file = FALSE;
    char *ch;
    float delete = -1;

    if (argc == 1) {
        printf("Usage: %s -i file -o file\n",argv[0]);
        exit(-1);
    }

    while (--argc > 0 && (*++argv)[0] == '-') {
        for (ch = argv[0] + 1; *ch != '\0'; ch++) {
            switch (*ch) {
                case 'i':
                    set_input_file = TRUE;
                    argc--; argv++;
                    file_name_in = argv[0];
                    break;
                case 'o':
                    set_output_file = TRUE;
                    argc--; argv++;
                    file_name_out = argv[0];
                    break;
                case 'd':
                    argc--; argv++;
                    delete = atof(argv[0]);
                    break;
                default:
                    printf("illegal option %c\n",*ch);
                    argc = 0;
                    exit(-1);
                    break;
            }
        }
    }

    if (set_input_file == FALSE) {
        printf("no input file specified - aborting\n");
        exit(-1);
    }
    if (set_output_file == FALSE) {
        printf("no output file specified - aborting\n");
        exit(-1);
    }
    if ((fp = fopen(file_name_in,"r")) == NULL) {
        printf("cant open %s\n",file_name_in);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0) {
        printf("not pixel data file - aborting\n");
        exit(-1);
    }

    if ((fp_out = fopen(file_name_out,"w")) == NULL) {
        printf("cant open %s\n",file_name_out);
        exit(-1);
    }
    /* write magic word for format of file */
#if !TESTING
    fprintf(fp_out,"super\n");
#endif

    do{
        read_list(&number_pixels,&end_of_file,&list_no);

        /* delete some data to simulate occlusion */
        if (delete != -1)
            number_pixels *= delete;

        number_arcs = 0;
        segment(1,number_pixels,&sig);

        /* super data output format */
        for (j = 1;j <= number_arcs;j++)
           if (arc_status[j] == KEEP) {
              if (arc_sig[j] < (LARGE_SIG - 1)) {
                 /* !! HACK !! */
                 if (maj_axis[j] < min_axis[j]) {
                    temp = maj_axis[j];
                    maj_axis[j] = min_axis[j];
                    min_axis[j] = temp;
                    rot_ang[j] += PI/2;
                 }
#if TESTING
                 fprintf(fp_out,"ctr %f %f\n",arc_centre_x[j],arc_centre_y[j]);
                 fprintf(fp_out,"a b %f %f\n",maj_axis[j],min_axis[j]);
                 fprintf(fp_out,"theta %f\n",rot_ang[j]);
                 fprintf(fp_out,"epsilon %f\n",arc_squareness[j]);
#else
                 fprintf(fp_out,"superellipse: %f %.0f %.0f %d %d %d %d %f %f %f %f %d\n",
                    arc_sig[j],
                    arc_centre_x[j],arc_centre_y[j],
                    arc_start_x[j],arc_start_y[j],
                    arc_end_x[j],arc_end_y[j],
                    maj_axis[j],min_axis[j],arc_squareness[j],rot_ang[j],
                    arc_dirs[j]);
#endif
              }
              else
                 fprintf(fp_out,"line: 0.0 %d %d %d %d\n",
                    arc_start_x[j],arc_start_y[j],
                    arc_end_x[j],arc_end_y[j]);
           }
#if !TESTING
        fprintf(fp_out,"endl:\n");
        if (end_of_file == 1)
            fprintf(fp_out,"endf:\n");
#endif
    }while(end_of_file == 0);
}

void read_list(int *number_pixels, int *end_of_file, int *list_no)
{
    char dumstring[50];
    int j;
    int tx,ty;

    fscanf(fp,"%s %d\n",dumstring,list_no);
    j = 0;
    do{
        j++;
        fscanf(fp,"%d %d\n",&tx,&ty);
        x_c[j] = tx;
        y_c[j] = ty;
    }while(x_c[j] != -1);
    if (y_c[j] == -1)
       *end_of_file = 1;
    else
       *end_of_file = 0;
    *number_pixels = --j;
}

void segment(int start_in, int finish_in, float *sig_out)
{
    int i;
    int pos;
    float max_dev;
    float sig1,sig2,sig3,max_sig;
    float centre_x, centre_y;
    int arc_length,arc_dir;
    float major_axis,minor_axis,squareness,rot_angle;

    /* compute significance at this level */

    if ((finish_in - start_in) < MIN_LENGTH)
        representation_ok = FALSE;
    else
        determine_superellipse_fit(start_in,finish_in,&major_axis,&minor_axis,
                &squareness,&rot_angle,&centre_x,&centre_y,
                &max_dev,&arc_length,&arc_dir,&sig1);

    if (representation_ok == FALSE)
       sig1 = LARGE_SIG;

    pos = global_pos + start_in - 1;

    number_arcs++;
    arc_sig[number_arcs] = sig1;
    arc_centre_x[number_arcs] = centre_x;
    arc_centre_y[number_arcs] = centre_y;
    arc_start_x[number_arcs] = x_c[start_in];   /* to change? */
    arc_start_y[number_arcs] = y_c[start_in];   /*      "     */
    arc_end_x[number_arcs] = x_c[finish_in];    /*      "     */
    arc_end_y[number_arcs] = y_c[finish_in];    /*      "     */
    arc_dirs[number_arcs] = arc_dir;
    maj_axis[number_arcs] = major_axis;
    min_axis[number_arcs] = minor_axis;
    arc_squareness[number_arcs] = squareness;
    rot_ang[number_arcs] = rot_angle;
    arc_start[number_arcs] = start_in;
    arc_finish[number_arcs] = finish_in;
    arc_status[number_arcs] = KEEP;
    if (((finish_in - start_in) < MIN_LENGTH) ||
         (max_dev < 3) ||
         (STOP_EARLY == 1))
    {
        /* at lowest level of recursion */
        /* save arc match at this lowest of levels */
        /* and significance */

        *sig_out = sig1;
    }
    else{
        /* recurse to next level down */
        segment(start_in,pos,&sig2);
        segment(pos,finish_in,&sig3);
        /* get best significance from lower level */
        if (sig2 < sig3)
            max_sig = sig2;
        else
            max_sig = sig3;
        if (max_sig < sig1) {
            /* return best significance, keep lower level description */
            *sig_out = max_sig;
        /* remove the single arc from start_in to finish_in */
        for (i = 0;i <= number_arcs;i++)
            if ((arc_start[i] == start_in) &&
                (arc_finish[i] == finish_in))
            arc_status[i] = REJECT;
        }
        else{
            /* line at this level is more significant */
            /* remove arcs at lower levels */
            /* i.e between start_in and finish_in */
            /* DOES IT EVER GET HERE ???? */
            printf("JUST REPLACED LOWER LEVEL ARCS\n");
            *sig_out = sig1;
            for (i = 0;i <= number_arcs;i++) {
                if ((arc_start[i] == start_in) &&
                    (arc_finish[i] == finish_in))
                {
                    /* do nothing - leave it */
                }
                else if ((arc_start[i] >= start_in) &&
                         (arc_finish[i] <= finish_in))
                {
                    arc_status[i] = REJECT;
                }
            }
        }
    }
}

/*
int round(value)
float value;
{
    int i;

    i = floor(value + 0.5);
    return(i);
}
*/

float angle(float x1, float y1, float x2, float y2)
{

    float angle_temp;
    float xx,yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if (xx == 0.0)
        angle_temp = PI/2.0;
    else
        angle_temp = atan(fabs(yy/xx));
    if ((xx < 0.0) && (yy >= 0.0))
       angle_temp = PI - angle_temp;
    else if ((xx < 0.0) && (yy < 0.0))
       angle_temp = PI + angle_temp;
    else if ((xx >= 0.0) && ( yy < 0.0))
       angle_temp = PI*2.0 - angle_temp;
    return(angle_temp);
}

float euclid(float x1, float y1, float x2, float y2)
{
    float temp1,temp2;
    float dist;

    temp1 = fabs(x1-x2);
    temp2 = fabs(y1-y2);
    dist = sqrt(SQR(temp1)+SQR(temp2));
    return(dist);
}

/* rotate polygon segment (x1,y1) -> (x2,y2) to lie along x axis,
 * compute the minimum distance between the line segment and
 * a point on the circle defined as (x_cir,y_cir).
 * take perpendicular distance if x_cir between end points else
 * take euclidian distance to nearest end point.
 */
void compute_minimum_diff(float *deviation, float x_cir, float y_cir, float x1, float y1, float x2, float y2)
{
    float angle1;
    float x_off,y_off,cosine,sine;
    float temp;
    float min1,min2;

/*
    printf("entered compute_minimum_diff\n");
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    angle1 = angle(x1,y1,x2,y2);
    cosine = cos(-angle1);
    sine = sin(-angle1);
    x_off = x1;
    y_off = y1;
    /* offset points so x1,y1 at origin */
    x1 = 0;
    y1 = 0;
    x2 = x2 - x_off;
    y2 = y2 - y_off;
    x_cir = x_cir - x_off;
    y_cir = y_cir - y_off;
    /* rotate points with x2,y2 on x axis */
    temp = x2*cosine - y2*sine;
    y2 = x2*sine + y2*cosine;
    x2 = temp;
    temp = x_cir*cosine - y_cir*sine;
    y_cir = x_cir*sine + y_cir*cosine;
    x_cir = temp;
/*
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    min1 = euclid(x_cir,y_cir,x1,y1);
    min2 = euclid(x_cir,y_cir,x2,y2);
    if (x_cir < x1) {
        *deviation = min1;
    }else if (x_cir > x2) {
        *deviation = min2;
    }else{
        *deviation = fabs(y_cir);
    }
/*    printf("deviation: %f\n",*deviation,); */
}

/*
 * New version that walks around hypothesised superellipse
 * finding minimum distance to polygon at each step.
 * Nearest point is either the perpendicular distance,
 * or the euclidian distance to the nearest end point.
 * For all cases the nearest end point is taken as the
 * possible break point. max_dev is the deviation,
 * max_pos is the vertex for max_dev,
 * major_axis,minor_axis define the ellipse
 */
void compute_dev(float *max_dev, int *max_pos, float major_axis, float minor_axis, float squareness, int arc_dir)
{
    int l2;
    float l1,step;
    float s_ang,f_ang,temp;
    float x_cir,y_cir;
    float deviation;
    float min_dev;
    int min_pos;
    float t;

    *max_dev = 0.0;

    /* determine angles */
    s_ang = angle(0.0,0.0,
            first_root(x_trans3[1]/major_axis,squareness),
            first_root(y_trans3[1]/minor_axis,squareness));
    f_ang = angle(0.0,0.0,
                  first_root(x_trans3[nseg2]/major_axis,squareness),
                  first_root(y_trans3[nseg2]/minor_axis,squareness));
#if DEBUG
    printf("start coords: %f %f\n",x_trans3[1],y_trans3[1]);
    printf("finish coords: %f %f\n",x_trans3[nseg2],y_trans3[nseg2]);
    printf("angles: %f %f\n",s_ang,f_ang);
#endif
    /* default is anticlockwise, swap if clockwise */
    if (arc_dir == CLOCKWISE) {
        temp = s_ang;
        s_ang = f_ang;
        f_ang = temp;
    }
/* ang4 must be bigger than ang3 */
    if (f_ang < s_ang) {
        f_ang += PI*2.0;
    }
#if DEBUG
    printf("start angle: %f finish angle %f\n",s_ang,f_ang);
/* walk around circle from angle1 to angle2 */
    printf("walking around circle\n");
#endif
    step = (f_ang-s_ang)/10.0;    /* use 11 steps presently */
    l1 = s_ang;
    do{
        min_dev = 1000000;
        x_cir = major_axis * first_root(cos(l1),squareness);
        y_cir = minor_axis * first_root(sin(l1),squareness);
        l2 = 1;
        do{
            /* printf("for line %d\n",l2);   */
            compute_minimum_diff(&deviation,x_cir,y_cir,x_trans3[l2],
                                 y_trans3[l2],x_trans3[l2+1],y_trans3[l2+1]);
            if (deviation < min_dev) {
                min_dev = deviation;
                min_pos = l2;
            }
            l2++;
        }while(l2 <= nseg2-1);

        if (min_dev > *max_dev) {
            *max_dev = min_dev;
            *max_pos = min_pos;
        }
        l1 += step;
    }while (l1 <= f_ang);
#if DEBUG
    printf("maximum deviation: %f\n",*max_dev);
#endif
}

/* computes length of arc
 * works on temporary data from determine_superellipse_fit
 * i.e. data: (x_trans3,y_trans3),major_axis,minor_axis.
 * new version computes start and finish angles, then
 * arc length from angle and radius
 */
void compute_lgt(float *lgt, float major_axis, float minor_axis, float squareness, int arc_dir)
{
    float s_ang,f_ang,temp;
    float xold,yold,xnew,ynew;
    float step;
    float t;

    s_ang = angle(0.0,0.0,
            first_root(x_trans3[1]/major_axis,squareness),
            first_root(y_trans3[1]/minor_axis,squareness));
    f_ang = angle(0.0,0.0,
            first_root(x_trans3[nseg2]/major_axis,squareness),
            first_root(y_trans3[nseg2]/minor_axis,squareness));
    /* default is anticlockwise, so swap angles if clockwise */
    if (arc_dir == CLOCKWISE) {
       temp = s_ang;
       s_ang = f_ang;
       f_ang = temp;
    }
    /* start angle must be less that f_ang */
    if (f_ang < s_ang)
       f_ang += PI*2.0;
    *lgt = 0.0;

    xold = major_axis * first_root(cos(s_ang),squareness);
    yold = minor_axis * first_root(sin(s_ang),squareness);

    step = (f_ang - s_ang) / 20.0;
    temp = s_ang;
    do{
        temp += step;
        xnew = major_axis * first_root(cos(temp),squareness);
        ynew = minor_axis * first_root(sin(temp),squareness);
        *lgt = *lgt + distance(xold,yold,xnew,ynew);
        xold = xnew;
        yold = ynew;
    }while(temp <= f_ang);
}

void compute_poly_lgt(float *lgt)
{
    int loop1;
    float dx,dy;

    *lgt = 0;
    for (loop1 = 1;loop1 < nseg2;loop1++) {
        dx = x_trans3[loop1] - x_trans3[loop1+1];
        dy = y_trans3[loop1] - y_trans3[loop1+1];
        *lgt += sqrt(SQR(dx) + SQR(dy));
    }
}

/*
 * determine the best fit superellipse
 */
 void determine_superellipse_fit(int st, int fi, float *final_major_axis, float *final_minor_axis, float *final_squareness, float *final_rot_angle, float *final_xc, float *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig)

{
    /* new variables for lms fitting */
    float c_ang;

    /* original variables */
    float xt,yt;   /* temp variables */
    float x_cent_t,y_cent_t; /* temp centre coords - after transformation */
    float sine,cosine;
    float max_dev,arc_length,poly_length;
    int loop1;
    int max_pos;
    float sum;
    float ratio = 1;
    float temp;
    float x_off,y_off;

    float a,b,e,xc,yc,rot;

    float angle_s,angle_f,diff_angle;

    *sig = 0;

    /*
       set representation_ok to TRUE - set to FALSE by any code that
       cannot fit the representation to the data
    */
    representation_ok = TRUE;

    /* get data into temp array */
    nseg2 = 0;
    for (loop1 = st; loop1 <= fi; loop1++) {
       nseg2++;
       x_trans3[nseg2] = x_c[loop1];
       y_trans3[nseg2] = y_c[loop1];
    }

    fit_superellipse(&a,&b,&e,&xc,&yc,&rot);

    if (representation_ok == FALSE)
       return;

#if DO_ARC
   /* determine arc_size
    * transform temp to lie along X axis, then compute average displacement
    * of y coords. If +ve then circle on +ve side of axis else on -ve. This
    * in combination with the position of the centre will indicate if the are
    * is large (>180 degrees) or small (<=180 degrees). Also can determine if
    * arc is clockwise or anticlockwise
    * rotate and translate temp data.
    * take chord between points, rotate so that chord is
    * along x axis - rotate and translate all other points the same.
    */
    c_ang = angle(x_trans3[1],y_trans3[1],x_trans3[nseg2],y_trans3[nseg2]);
    sine = sin(-c_ang);
    cosine = cos(-c_ang);

    /* translate so first point is at origin */
    x_off = x_trans3[1];
    y_off = y_trans3[1];
    for (loop1 = 1;loop1 <= nseg2;loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - x_off;
        y_trans3[loop1] = y_trans3[loop1] - y_off;
    }
    /* rotate to align chord with x axis */
    for (loop1 = 1;loop1 <= nseg2;loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt * cosine - yt * sine;
        x_trans3[loop1] = temp;
        temp = xt * sine + yt * cosine;
        y_trans3[loop1] = temp;
    }

    /* do same for centre */
    xt = xc - x_off;
    yt = yc - y_off;
    temp = xt*cosine - yt*sine;
    x_cent_t = temp;
    temp = xt*sine + yt*cosine;
    y_cent_t = temp;

    /* compute average Y coord of all points */
    sum = 0.0;
    for (loop1=1;loop1<=nseg2;loop1++)
        sum += y_trans3[loop1];

    /* determine size and sense of arc */
    if ((sum >= 0.0) && (y_cent_t >= 0.0)) {
        *arc_dir = CLOCKWISE;
    }
    else if ((sum < 0.0) && (y_cent_t < 0.0)) {
        *arc_dir = ANTICLOCKWISE;
    }
    else if ((sum >= 0.0) && (y_cent_t < 0.0)) {
        *arc_dir = CLOCKWISE;
    }
    /* CHANGED Y_CENT TO Y_CENT_T - PLR */
    else if ((sum < 0.0) && (y_cent_t >= 0.0)) {
        *arc_dir = ANTICLOCKWISE;
    }
    /* !!! FOR VERY FLAT SECTIONS !!! */
    if (fabs(sum/nseg2) < 3.0) {
       angle_s = angle(x_cent_t,y_cent_t,x_trans3[1],y_trans3[1]);
       angle_f = angle(x_cent_t,y_cent_t,x_trans3[nseg2],y_trans3[nseg2]);
       diff_angle = angle_f - angle_s;
       if (diff_angle < 0) diff_angle += (PI*2.0);
       if (diff_angle < PI)
          *arc_dir = ANTICLOCKWISE;
       else
          *arc_dir = CLOCKWISE;
    }

    /*
    for (loop2=1;loop2<=nseg2;loop2++)
        printf("x_trans3: %f y_trans3: %f\n",x_trans3[loop2],y_trans3[loop2]);
    */

    /* transform data so major_axis axis of superellipse is along X axis */
    /* get data into temp arrays */
    nseg2 = 0;
    for (loop1 = st; loop1 <= fi; loop1++) {
        nseg2++;
        x_trans3[nseg2] = x_c[loop1];
        y_trans3[nseg2] = y_c[loop1];
    }
    /* first translate */
    for (loop1=1; loop1<=nseg2; loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - xc;
        y_trans3[loop1] = y_trans3[loop1] - yc;
    }
    /* now rotate */
    sine = sin(-rot);
    cosine = cos(-rot);
    for (loop1=1; loop1<=nseg2; loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt*cosine - yt*sine;
        x_trans3[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans3[loop1] = temp;
    }
    x_cent_t = 0.0;
    y_cent_t = 0.0;

    /*
     * determine length of ellipse for this circle approx - use data
     * transformed to put major axis along x axis
     */
    compute_lgt(&arc_length,a,b,e,*arc_dir);

    /*
     * determine actual length of data - a polygon here
     */
    compute_poly_lgt(&poly_length);

    /*
     * determine position and value of the maximum deviation - use data
     * transformed to put major axis along x axis
     */
    compute_dev(&max_dev,&max_pos,a,b,e,*arc_dir);

    /*
     * hack to stop breakpoint near ends - to be modified
     * break at middle of data if too close to end points
     */
    if ((max_pos <= MIN_LENGTH) || (max_pos > nseg2-MIN_LENGTH))
        max_pos = nseg2 / 2;

#if DEBUG
    printf("arc length: %f\n",arc_length);
    printf("poly length: %f\n",poly_length);
    printf("maximum deviation: %f\n",max_dev);
    printf("point of maximum deviation: %d\n",max_pos);
#endif

    /*
     * compute significance based on max_dev, arc_length and
     * some heuristics!
     */
    /* polygonal length should be similar to arc length */
    ratio = poly_length / arc_length;
    if (ratio < 1)
        ratio = arc_length / poly_length;

    *final_lgt = arc_length;
    max_dev = max_dev * ratio;        /* temp to modify sig */
    *final_dev = max_dev;

    if ((max_dev != 0.0) && (arc_length != 0))
        *sig = max_dev / (float)arc_length;
    else
        *sig = LARGE_SIG;

    /* save position of maximum deviation */
    global_pos = max_pos;
#else
    *arc_dir = 1;
#endif

    /* save parameters for best ellipse as integers */
    *final_major_axis = a;
    *final_minor_axis = b;
    *final_squareness = e;
    *final_rot_angle = rot;
    *final_xc = xc;
    *final_yc = yc;
}

float distance(float x1, float y1, float x2, float y2)
{
    return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

int curve_type(char array[50])
{
    int i,j;

    if ((j = strcmp(array,"list:")) == 0)
        i = 1;
    else if ((j = strcmp(array,"line:")) == 0)
        i = 2;
    else if ((j = strcmp(array,"arc:")) == 0)
        i = 3;
    else if ((j = strcmp(array,"endl:")) == 0)
        i = 4;
    else if ((j = strcmp(array,"endf:")) == 0)
        i = 5;
    return(i);
}

/*
int strcmp(s,t)
char s[],t[];
{
    int i;

    i = 0;
    while(s[i] == t[i])


        if (s[i++] == '\0')
            return(0);
    return(s[i] - t[i]);
}
*/

/*
 *  code below used to be in determ3.c
 *  fits ellipses to data using a kalman filter
 *  abort when any error condition occurs - that is cannot fit an ellipse
 *  Paul Rosin
 *  January 1990
 */

int find_conic_type(float c1,float c2,float c3)
{
    float fx;
    int temp;

    fx = c1 * c3 - c2 * c2 / 4;
        if (fx > 0)
           temp = ELLIPSE;
    else if (fx < 0)
           temp = HYPERBOLA;
    else
           temp = PARABOLA;
/*      printf("fx: %f\n",fx); */
    return(temp);
}

void error(char *s)
{
    printf("ERROR: %s\n",s);
    exit(-1);
}

float first_root(float t,float e)
/* get first root of the value t for the power e */
{
    if (t > 0)
        return pow(t,e);
    else if (t < 0)
        return -pow(-t,e);
    else
        return 0.0;
}

