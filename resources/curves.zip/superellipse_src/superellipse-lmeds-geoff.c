/*
 * perform LMedS fit of a superellipse
 *
 * use Powell's method for non-linear optimisation
 *
 * Paul Rosin
 * April 1995
 */

#include <stdio.h>
#include <math.h>

#include "nr.h" 
#include "nrutil.h"  

#define FALSE 0
#define TRUE (!FALSE)

#define TINY 1.0e-20
#define NDIM 6
#define FTOL 1.0e-6

#define PI 3.1415926

#define SQR(x) ((x)*(x))
#define R2D(x) ((x)*180.0/PI)
#define D2R(x) ((x)*PI/180.0)

#define ABS(a) ((a)>=0 ? a : -(a))

extern float x_trans3[],y_trans3[];
extern int nseg2;
extern int representation_ok;

fit_superellipse(a,b,e,xc,yc,rot)
float *a,*b,*e,*xc,*yc,*rot;
{
	float aT,bT,eT,xcT,ycT,rotT;
	float radius2;
	float compute_orientation();

    /* fit ellipse to get initial estimate for superellipse */
    lms_fit(&xcT,&ycT,&aT,&bT,&rotT);
	if (!representation_ok) {
		/* fit circle to get initial estimate for superellipse */
    	compute_circle(&xcT,&ycT,&radius2,nseg2,x_trans3,y_trans3);
		if (representation_ok) {
			fprintf(stderr,"use circle fit for initialisation\n");
			aT = bT = sqrt(radius2);
			/* get orientation estimate using central moments */
			/* hack - seem to need to negate angle */
			rotT = -compute_orientation(nseg2,x_trans3,y_trans3);
		}
		else {
			fprintf(stderr,"ERROR: no initialisation\n");
			representation_ok = FALSE;
			return;
			/* MUST BE A STRAIGHT LINE !! */
			/* SHOULD DO SOMETHING ... */
		}
	}

    rotT = R2D(rotT);
	eT = 1;
    testfit(&aT,&bT,&eT,&xcT,&ycT,&rotT);
    rotT = D2R(rotT);

	*a = aT;
	*b = bT;
	*e = eT;
	*xc = xcT;
	*yc = ycT;
	*rot = rotT;
}

/* avoid error messages from math library */
float POW(a,b)
float a,b;
{
    float r;

    if (a == 0)
        r = 0;
    else
        r = pow(a,b);

    return(r);
}

/*********************************************
 definition of function to optimize
**********************************************/
float func(p)
float p[];
{
    int i;
    float fi;
    float xi,yi;
    float dx,dy;
    float tx,ty;
    float x,y;
    float POW();
    float sine2,cosine2;
	float list[NO_PIXELS];

	/* abort if a, b, or e have impossible values */
	if ((p[1] < 0) || (p[2] < 0) || (p[3] < 0)) {
		return(9e99);
	}

    cosine2 = cos(D2R(-p[6]));
    sine2 = sin(D2R(-p[6]));

    for (i = 1; i <= nseg2; i++) {

        tx = x_trans3[i] - p[4];
        ty = y_trans3[i] - p[5];

        x = ABS(tx * cosine2 - ty * sine2);
        y = ABS(tx * sine2 + ty * cosine2);

        xi = 1.0 / POW(p[1],2.0/p[3]) + POW(y/(x*p[2]),2.0/p[3]);
        xi = 1.0 / xi;
        xi = ABS(xi);
        xi = POW(xi,p[3]/2.0);

        yi = xi * y/x;

        dx = x - xi;
        dy = y - yi;

        fi = sqrt(dx*dx + dy*dy);
		list[i] = fi;
    }

	sort(nseg2,list);

    return(list[nseg2/2]);
}

/**********************************************
 Fitting data to an ellipse
***********************************************/
testfit(a,b,e,xo,yo,rot)
float *a,*b,*e,*xo,*yo,*rot;
{
    int i,iter,j;
    float fret,**xi;
    float p[7];

    /* starting point */
    p[1] = *a;
    p[2] = *b;
    p[3] = *e;
    p[4] = *xo;
    p[5] = *yo;
    p[6] = *rot;

    /* set of initial directions */
    xi = matrix(1,NDIM,1,NDIM);
    for (i = 1; i <= NDIM; i++)
        for (j = 1; j <= NDIM; j++)
            xi[i][j] = (i == j ? 1.0 : 0.0);

    powell(p,xi,NDIM,FTOL,&iter,&fret,func);

    fprintf(stderr,"Iterations: %d\n",iter);
    fprintf(stderr,"Minimum found at:\n");
    for (i = 1; i <= NDIM; i++)
        fprintf(stderr,"%.2f  ",p[i]);

    *a = p[1];
    *b = p[2];
    *e = p[3];
    *xo = p[4];
    *yo = p[5];
    *rot = p[6];

    fprintf(stderr,"\nMinimum function value = %.2f\n\n",fret);

    free_matrix(xi,1,NDIM,1,NDIM);
}

/* from numerical recipes in C */
sort(n,ra)
int n;
float ra[];
{
   int l,j,ir,i;
   float rra;

   l=(n >> 1)+1;
   ir=n;
   for (;;) {
      if (l > 1)
         rra=ra[--l];
      else {
         rra=ra[ir];
         ra[ir]=ra[1];
         if (--ir == 1) {
            ra[1]=rra;
            return;
         }
      }
      i=l;
      j=l << 1;
      while (j <= ir) {
         if (j < ir && ra[j] < ra[j+1]) ++j;
         if (rra < ra[j]) {
            ra[i]=ra[j];
            j += (i=j);
         }
         else j=ir+1;
      }
      ra[i]=rra;
   }
}
