/*
 * perform least-square fit of a superellipse
 *
 * use Powell's method for non-linear optimisation
 *
 * reads in data in either superdata or pixel (float point and integer) format!
 *
 * Paul Rosin
 * April 1993
 */

#include <stdio.h>
#include <math.h>
#include <suntool/sunview.h>
#include <suntool/canvas.h>
#include <sunwindow/cms_rainbow.h>

#include "nr.h" 
#include "nrutil.h"  

#define TINY 1.0e-20
#define NDIM 5
#define FTOL 1.0e-6

#define WHITE 0
#define RED 1
#define ORANGE 2
#define YELLOW 3
#define GREEN 4
#define BLUE 5
#define INDIGO 6
#define PURPLE 7

#define LISTS 1
#define LINES 2
#define ARCS 3
#define ENDL 4
#define ENDF 5

#define INTEGER 0
#define FLOAT 1

#define PI 3.1415926

#define SQR(x) ((x)*(x))

#define MAX_POINTS 10000

#define ABS(a) ((a)>=0 ? a : -(a))

int no_points;
float datax[MAX_POINTS],datay[MAX_POINTS];
float tempx[MAX_POINTS],tempy[MAX_POINTS];
char ch;
FILE *fp_in,*fp_out;

int current_x,current_y;  /* saves current plot point */
unsigned char red2[CMS_RAINBOWSIZE];
unsigned char green[CMS_RAINBOWSIZE];
unsigned char blue[CMS_RAINBOWSIZE];

Frame frame;
Canvas canvas;
Pixwin *pw;
int current_colour;

int ORG = 0;      /* origin */
int dump = FALSE;   /* dump image */
int set_output = FALSE; /* store parameters of fitted ellipses */ 

int file_data_type;
char *infile,*outfile;

main(argc,argv)
int argc;
char *argv[];
{
   int i;
   char *dump_filename;

   infile = outfile = NULL;

   for (i = 1; i < argc; i++)
      if (argv[i][0] == '-')
         switch (argv[i][1]) {
             case 'd':
                  dump = TRUE;
                  i++;
                  dump_filename = argv[i];
                  break;
             case 'O':
                  i++;
                  ORG = atoi(argv[i]);
                  break;
             case 'i':
                  i++;
                  infile = argv[i];
                  break;
             case 'o':
                  i++;
                  outfile = argv[i];
                  set_output = TRUE;
                  break;
             default:
                  printf("illegal option -%c\n",argv[i][1]);
                  printf("usage: %s -i infile -o outfile [options]\n",argv[0]);
                  exit();
         }
       else {
          printf("illegal option %c\n",argv[i][0]);
          printf("usage: %s -i infile -o outfile [options]\n",argv[0]);
          exit();
       }

   if (infile == NULL) {
       printf("ERROR: require input filename\n");
       printf("usage: %s -i infile [options]\n",argv[0]);
       exit(-1);
   }

   if (set_output)
      if((fp_out=fopen(outfile,"w")) == NULL) {
          printf("cant open %s\n",outfile);
          exit(-1);
      }

   open_device();

   do_fits();

   if (dump) dump_image(dump_filename,512,512);

   close_graph();
}

do_fits()
{
    char file_type[50];
    int end_of_file;
    int super_data,pixel_data;
    float a,b,e;
    float xc,yc,maj,mina,rot;

    super_data = pixel_data = FALSE;

    if((fp_in=fopen(infile,"r")) == NULL) {
        printf("cant open %s\n",infile);
        exit(-1);
    }

    /* read magic word for format of file */
    fscanf(fp_in,"%s\n",file_type);
    if (strcmp(file_type,"super") == 0)
       super_data = TRUE;
    else if (strcmp(file_type,"pixel") == 0) {
       pixel_data = TRUE;
       file_data_type = INTEGER;
    }
    else if (strcmp(file_type,"pixel_float") == 0) {
       pixel_data = TRUE;
       file_data_type = FLOAT;
    }
    else {
        printf("not super data or pixel format file - aborting\n");
        exit();
    }
 
    setcolor(PURPLE);
 
    if (set_output) fprintf(fp_out,"super\nlist: 0\n");
 
    do{
       if (super_data)
          read_super_data(&no_points,&end_of_file);
       else
          read_pixel_data(&no_points,&end_of_file);
       if (!end_of_file || pixel_data) {
          plot_data();

          setcolor(RED);
          /* fit ellipse to get initial estimate for superellipse */
          lms_fit(&xc,&yc,&maj,&mina,&rot);
          plot_ellipse(xc,yc,maj,mina,rot);

          a = maj;
          b = mina;
          e = 1;
          setcolor(GREEN);
          plot_super(a,b,e,xc,yc);

          testfit(&a,&b,&e,&xc,&yc);

          setcolor(BLUE);
          plot_super(a,b,e,xc,yc);
        }
    }while (!end_of_file);

    fclose(fp_in);
    if (set_output) {
       fprintf(fp_out,"endl:\nendf:\n");
       fclose(fp_out);
    }
}

/* lms conic fit */
/* normalisation: f=1 */
lms_fit(xc,yc,maj,mina,rot)
float *xc,*yc,*maj,*mina,*rot;
{
   int i;
   float m[7];   /* coefficients of best fit ellipse */
   float x_org,y_org;

   /* shift data to the origin to minimise numerical errors */
   x_org = y_org = 0;
   for (i=0; i<no_points; i++) {
      x_org += datax[i];
      y_org += datay[i];
   }
   x_org /= no_points; y_org /= no_points;
   for (i=0; i<no_points; i++) {
      tempx[i] = datax[i] - x_org;
      tempy[i] = datay[i] - y_org;
   }
   /* rescale from 0->511 to 0-1 to prevent enormous numbers */
   for (i=0; i<no_points; i++) {
      tempx[i] /= 512.0;
      tempy[i] /= 512.0;
   }

   determine_ellipse_lms(m);

   if (ellipse_type(m[1],m[2],m[3])) {
      determine_parameters(m[1],m[2],m[3],m[4],m[5],m[6],
                           xc,yc,maj,mina,rot);
      *maj *= 512; *mina *= 512; *xc *= 512; *yc *= 512;
      *xc += x_org;
      *yc += y_org;
   }
   else {
      printf("NON-ELLIPSE\n");
   }
}

/* least square fit; f = 1 */
determine_ellipse_lms(m)
float m[7];
{
    int i,j;
    float sx,sx2,sx3,sx4,sy,sy2,sy3,sy4,sxy,sx2y,sx3y,sx2y2,sxy2,sxy3;
    float x2,y2,x3,y3;
    float m1[6][6];
    float m2[6];
    int indx[6];
    float d;

   sx = 0;
   sx2 = 0;
   sx3 = 0;
   sx4 = 0;
   sy = 0;
   sy2 = 0;
   sy3 = 0;
   sy4 = 0;
   sxy = 0;
   sx2y = 0;
   sx3y = 0;
   sx2y2 = 0;
   sxy2 = 0;
   sxy3 = 0;

   for (j = 0; j < no_points; j++) {
      x2 = tempx[j] * tempx[j];
      x3 = x2 * tempx[j];
      y2 = tempy[j] * tempy[j];
      y3 = y2 * tempy[j];

      sx += tempx[j];
      sx2 += x2;
      sx3 += x3;
      sx4 += (x3 * tempx[j]);
      sy += tempy[j];
      sy2 += y2;
      sy3 += y3;
      sy4 += (y3 * tempy[j]);
      sxy += (tempx[j] * tempy[j]);
      sx2y = sx2y + x2 * tempy[j];
      sx3y = sx3y + x3 * tempy[j];
      sx2y2 = sx2y2 + x2 * y2;
      sxy2 = sxy2 + tempx[j] * y2;
      sxy3 = sxy3 + tempx[j] * y3;
   }

   m1[1][1] = sx4;
   m1[2][1] = sx3y;
   m1[3][1] = sx2y2;
   m1[4][1] = sx3;
   m1[5][1] = sx2y;
   m1[1][2] = sx3y;
   m1[2][2] = sx2y2;
   m1[3][2] = sxy3;
   m1[4][2] = sx2y;
   m1[5][2] = sxy2;
   m1[1][3] = sx2y2;
   m1[2][3] = sxy3;
   m1[3][3] = sy4;
   m1[4][3] = sxy2;
   m1[5][3] = sy3;
   m1[1][4] = sx3;
   m1[2][4] = sx2y;
   m1[3][4] = sxy2;
   m1[4][4] = sx2;
   m1[5][4] = sxy;
   m1[1][5] = sx2y;
   m1[2][5] = sxy2;
   m1[3][5] = sy3;
   m1[4][5] = sxy;
   m1[5][5] = sy2;

   m2[1] = -sx2;
   m2[2] = -sxy;
   m2[3] = -sy2;
   m2[4] = -sx;
   m2[5] = -sy;

   /* solve simultaneous equations */
   ludcmp(m1,5,indx,&d);
   lubksb(m1,5,indx,m2);

   m[1] = m2[1];
   m[2] = m2[2];
   m[3] = m2[3];
   m[4] = m2[4];
   m[5] = m2[5];
   m[6] = 1;
}

/* dumps an image to a file */
dump_image(file_name,width,height)
char file_name[];
int width,height;
{
    register int x,y;
    unsigned char *charimage,*charptr;
    FILE *fopen(),*fp;
    int val;

    if((fp=fopen(file_name,"w")) == NULL) {
        printf("can't open %s\n",file_name);
        exit();
    }
    charimage = (unsigned char *) malloc(width);
    for (y = 0; y < height; y++) {
        charptr = charimage;
        for (x = 0; x < width; x++) {
         val = pw_get(pw,x,y);

         /* map onto good grey values */
         if (val == GREEN) val = 180;
         else if (val == PURPLE) val = 0;
         else if (val == BLUE) val = 0;
         else if (val == RED) val = 0;
         else val = 255;

         *charptr++ = (char) val;
      }
        if (fwrite(charimage,sizeof(*charimage),width,fp) != width)
            printf("Error writing image data (possible file size error)\n");
    }
    free(charimage);
    fclose(fp);
}

read_super_data(no_segs,end_of_file)
int *no_segs,*end_of_file;
{
    int i,j,k,l;
    float f;
    char data_type[40],ch;

    k = 0;
    do{
        i = -1;
        do{
            fscanf(fp_in,"%c",&ch);
            data_type[++i] = ch;
        }while(ch != ':');
        data_type[++i] = '\0';
        j = curve_type(data_type);

        if(j == LISTS) {
            fscanf(fp_in,"%d\n",&l);
        }
        else if(j == LINES) {
            fscanf(fp_in,"%f %f %f %f %f\n",
                &f,&f,&f,&datax[k],&datay[k]);
            k++;
         if (k > MAX_POINTS) {
            printf("ERROR: too many points&n");
            exit();
         }
        }
        else if(j == ARCS) {
            printf("warning! ARC in data - ignoring\n");
            fscanf(fp_in,"%f %d %d %d %d %d %d %d %d\n",
                &f,&f,&f,&f,&f,&f,&f,&f,&f);
        }
        else if(j == ENDL) {  /* read to end of line */
            fscanf(fp_in,"\n");
        }
    }while((j != ENDL) && (j != ENDF));
    if(j == ENDF)
        *end_of_file = TRUE;
    else
        *end_of_file = FALSE;
    *no_segs = k;
}

read_pixel_data(no_pixels,end_of_file)
int *no_pixels,*end_of_file;
{
   char dumstring[50];
   int j = 0;
   int xi,yi;
   float xf,yf;
   int list_no;

   if (file_data_type == INTEGER) {
      /* process integer pixel data */
      fscanf(fp_in,"%s %d\n",dumstring,&list_no);
      do{
         fscanf(fp_in,"%d %d\n",&xi,&yi);
         datax[j] = xi;
         datay[j] = yi;
         j++;
      } while((datax[j-1] != -1) && !feof(fp_in));
   }
   else{
      /* process floating point data */
      fscanf(fp_in,"%s %d\n",dumstring,&list_no);
      do{
         fscanf(fp_in,"%f %f\n",&xf,&yf);
         datax[j] = xf;
         datay[j] = yf;
         j++;
      }while((datax[j-1] != -1) && !feof(fp_in));
   }

   *no_pixels = j-1;
   if ((datay[j-1] == -1) || feof(fp_in))
      *end_of_file = TRUE;
   else
      *end_of_file = FALSE;
}

int curve_type(array)
char array[50];
{
    int i,j;

    if((j = strcmp(array,"list:")) == 0)
        i = 1;
    else if((j = strcmp(array,"line:")) == 0)
        i = 2;
    else if((j = strcmp(array,"arc:")) == 0)
        i = 3;
    else if((j = strcmp(array,"endl:")) == 0)
        i = 4;
    else if((j = strcmp(array,"endf:")) == 0)
        i = 5;
    return(i);
}

int strcmp(s,t)
char s[],t[];
{
    int i;

    i = 0;
    while(s[i] == t[i])
        if(s[i++] == '\0')
            return(0);
    return(s[i] - t[i]);
}

point(xs,ys)
int xs,ys;
{
    moveto(xs,ys);
    lineto(xs,ys);
}

plot_data()
{
   int i;


   for (i = 0; i < no_points; i++)
      cross((int)datax[i],(int)datay[i],3);
}

/* is conic an ellipse? */
int ellipse_type(c1,c2,c3)
float c1,c2,c3;
{
   float f;

   f = c1 * c3 - c2 * c2 / 4;
   return(f > 0);
}

determine_parameters(a,b,c,d,e,f,x_cent,y_cent,major_axis,minor_axis,rot_angle)
float a,b,c,d,e,f;
float *x_cent,*y_cent,*major_axis,*minor_axis,*rot_angle;
{
    float ca,sa;
    float t,u,v,w;

    if (a == c)
       *rot_angle = 0;
    else
       *rot_angle = atan(b/(a-c)) / 2.0;
    ca = cos(*rot_angle);
    sa = sin(*rot_angle);
    t = a*SQR(ca)+b*ca*sa+c*SQR(sa);
    u = a*SQR(sa)-b*ca*sa+c*SQR(ca);
    v = d*ca+e*sa;
    w = -d*sa+e*ca;
    *major_axis = sqrt(((SQR(v)/(4*t))+(SQR(w)/(4*u))-f)/t);
    *minor_axis = sqrt(((SQR(v)/(4*t))+(SQR(w)/(4*u))-f)/u);
    *x_cent = (-d*c/2.0 + e*b/4.0) / (a*c - b*b/4.0);
    *y_cent = (-a*e/2.0 + d*b/4.0) / (a*c - b*b/4.0);
}

plot_ellipse(xc,yc,major_axis,minor_axis,rot_angle)
float xc,yc,major_axis,minor_axis,rot_angle;
{
    float sine2,cosine2;
    float temp,step,temp_angle;
    float xe,ye;

    /* generate transform from origin centred ellipse to image space */
    cosine2 = cos(rot_angle);
    sine2 = sin(rot_angle);

    /* moveto first point on ellipse in image */
    xe = major_axis * cos(0.0);
    ye = minor_axis * sin(0.0);
    temp = xe * cosine2 - ye * sine2;
    ye = xe * sine2 + ye * cosine2;
    xe = temp;
    xe = xe + xc;
    ye = ye + yc;
    moveto((int)xe,(int)ye);

    /* successively plot lines around ellipse */
   if (major_axis < 100)
       step = 2*PI / major_axis;
   else
       step = 2*PI / 100;
    for (temp_angle=0.0; temp_angle<2*PI+step; temp_angle += step) {
        xe = major_axis * cos(temp_angle);
   ye = minor_axis * sin(temp_angle);
   temp = xe * cosine2 - ye * sine2;
   ye = xe * sine2 + ye * cosine2;
   xe = temp;
   xe = xe + xc;
   ye = ye + yc;
        lineto((int)xe,(int)ye);
    }
}

plot_super(a,b,e,xo,yo)
float a,b,e,xo,yo;
{
    float sine2,cosine2;
    float temp,step,temp_angle;
    float xe,ye;
    float t;

    /* moveto first point on ellipse in image */
    t = cos(0.0);
    if (t > 0)
        t = exp(log(t) * e);
    else if (t < 0)
        t = -exp(log(-t) * e);
    else
        t = 0;
    xe = a * t + xo;

    t = sin(0.0);
    if (t > 0)
        t = exp(log(t) * e);
    else if (t < 0)
        t = -exp(log(-t) * e);
    else
        t = 0;
    ye = b * t + yo;

    moveto((int)xe,(int)ye);

    /* successively plot lines around ellipse */
    step = 2 * PI / 100;

    for (temp_angle = 0.0; temp_angle < 2 * PI + step; temp_angle += step) {
        t = cos(temp_angle);
        if (t > 0)
            t = exp(log(t) * e);
        else if (t < 0)
            t = -exp(log(-t) * e);
        else
            t = 0;
        xe = a * t + xo;

        t = sin(temp_angle);
        if (t > 0)
            t = exp(log(t) * e);
        else if (t < 0)
            t = -exp(log(-t) * e);
        else
            t = 0;
        ye = b * t + yo;

        lineto((int)xe,(int)ye);
    }
}

setcolor(colour)
unsigned char colour;
{
    current_colour = colour;
}

moveto(xpix,ypix)
int xpix,ypix;
{
    xpix += ORG; ypix += ORG;
    current_x = xpix;
    current_y = ypix;
}

lineto(xpix,ypix)
int xpix,ypix;
{
    int x,y;

    xpix += ORG; ypix += ORG;
    x = xpix;
    y = ypix;
    pw_vector(pw,current_x,current_y,x,y,PIX_SRC|PIX_COLOR(current_colour),1);
    current_x = x;
    current_y = y;
}

close_graph()
{
    window_main_loop(frame);
}

cross(x,y,l)
int x,y,l;
{
    x += ORG; y += ORG;
    pw_vector(pw,x-l,y-l,x+l,y+l,PIX_SRC|PIX_COLOR(current_colour),1);
    pw_vector(pw,x+l,y-l,x-l,y+l,PIX_SRC|PIX_COLOR(current_colour),1);
}

/* this version uses suntools on a Sun workstation */
open_device()
{
    frame = window_create(NULL,   FRAME,
            FRAME_LABEL,infile,
            FRAME_SHOW_LABEL,TRUE,
            WIN_HEIGHT,512,
            WIN_WIDTH,512,
            WIN_SHOW,TRUE,
            0);
    canvas = window_create(frame,CANVAS,
            CANVAS_AUTO_SHRINK,FALSE,
            CANVAS_AUTO_EXPAND,TRUE,
            0);

    cms_rainbowsetup(red2,green,blue);
    pw = (Pixwin *)canvas_pixwin(canvas);
    pw_setcmsname(pw,CMS_RAINBOW);
    pw_putcolormap(pw,0,CMS_RAINBOWSIZE,red2,green,blue);
    pw = canvas_pixwin(canvas);
}

/* ######################################################## */

/* avoid error messages from math library */
float POW(a,b)
float a,b;
{
    float r;

    if (a == 0)
        r = 0;
    else
        r = pow(a,b);

    return(r);
}

/*********************************************
 definition of function to optimize
**********************************************/
float func(p)
float p[];
{
    int i;
    float fi,fu;
    float xi,yi;
    float dx,dy;
    float x,y;
    float POW();

    fu = 0;
    for (i = 0; i < no_points; i++) {

        x = ABS(datax[i] - p[4]);
        y = ABS(datay[i] - p[5]);

        xi = 1.0 / POW(p[1],2.0/p[3]) + POW(y/(x*p[2]),2.0/p[3]);
        xi = 1.0 / xi;
        xi = ABS(xi);
        xi = POW(xi,p[3]/2.0);

        yi = xi * y/x;

        dx = x - xi;
        dy = y - yi;

        fi = sqrt(dx*dx + dy*dy);

        fu += ABS(fi);
    }

    return (fu);
}

/**********************************************
 Fitting data to an ellipse
***********************************************/
testfit(a,b,e,xo,yo)
float *a,*b,*e,*xo,*yo;
{
    int i,iter,j;
    float fret,**xi;
    float p[6];

    /* starting point */
    p[1] = *a;
    p[2] = *b;
    p[3] = *e;
    p[4] = *xo;
    p[5] = *yo;

    /* set of initial directions */
    xi = matrix(1,NDIM,1,NDIM);
    for (i = 1; i <= NDIM; i++)
        for (j = 1; j <= NDIM; j++)
            xi[i][j] = (i == j ? 1.0 : 0.0);

    powell(p,xi,NDIM,FTOL,&iter,&fret,func);

    fprintf(stderr,"Iterations: %d\n",iter);
    fprintf(stderr,"Minimum found at: ");
    for (i = 1; i <= NDIM; i++)
        fprintf(stderr,"%12.2f\n",p[i]);

    *a = p[1];
    *b = p[2];
    *e = p[3];
    *xo = p[4];
    *yo = p[5];

    fprintf(stderr,"\nMinimum function value = %.2f\n\n",fret);

    free_matrix(xi,1,NDIM,1,NDIM);
}

/* ===================================================================*/

/* LEAST SQUARE FITTING STUFF */

/* ===================================================================*/

/* LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void ludcmp(a,n,indx,d)
float a[6][6];
int n,indx[6];
float *d;
{
        int i,imax,j,k;
        float big,dum,sum,temp;
        float vv[6];

        *d = 1.0;
        for (i = 1; i <= n; i++) {
                big = 0.0;
                for (j = i; j <= n; j++)
                        if ((temp = fabs(a[i][j])) > big) big = temp;
                if (big == 0.0) error("Singular matrix in routine LUDCMP");
                vv[i] = 1.0/big;
        }
        for (j = 1; j <= n; j++) {
                for (i = 1; i < j; i++) {
                        sum = a[i][j];
                        for (k = 1; k < i; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                }
                big = 0.0;
                for (i = j; i <= n;i++) {
                        sum = a[i][j];
                        for (k = 1; k < j; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                        if ( (dum = vv[i]*fabs(sum)) >= big) {
                                big = dum;
                                imax = i;
                        }
                }
                if (j != imax) {
                        for (k = 1; k <= n; k++) {
                                dum = a[imax][k];
                                a[imax][k] = a[j][k];
                                a[j][k] = dum;
                        }
                        *d = -(*d);
                        vv[imax] = vv[j];
                }
                indx[j] = imax;
                if (a[j][j] == 0.0) a[j][j] = TINY;
                if (j != n) {
                        dum = 1.0/(a[j][j]);
                        for (i = j+1; i <= n ;i++) a[i][j] *= dum;
                }
        }
}

/* forward substitution & backsubstitution */
/* use with LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void lubksb(a,n,indx,b)
float a[6][6],b[6];
int n,indx[6];
{
        int i,ii=0,ip,j;
        float sum;

        for (i=1;i<=n;i++) {
                ip = indx[i];
                sum = b[ip];
                b[ip] = b[i];
                if (ii)
                        for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
                else if (sum) ii = i;
                b[i] = sum;
        }
        for (i=n;i>=1;i--) {
                sum = b[i];
                for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
                b[i] = sum/a[i][i];
        }
}

error(s)
char s[];
{
   printf("ERROR: %s\n",s);
   exit(-1);
}

