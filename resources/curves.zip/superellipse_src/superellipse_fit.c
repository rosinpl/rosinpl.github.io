/*
 * perform least-square fit of a superellipse
 *
 * use Powell's method for non-linear optimisation
 *
 * Paul Rosin
 * April 1993
 *
 * =========================================================
 * MODIFICATIONS:
 *
 * added extra overflow check for DEC Alpha
 * Paul Rosin
 * October 1994
 *
 * added alternatives: LS or LMedS error
 * Paul Rosin
 * January 1995
 *
 * added bias to avoid star shapes
 * uses ellipse_specific fit for initialisation
 * Paul Rosin
 * July 2005
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "nr.h"
#include "nrutil.h"

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define NO_PIXELS 10000

#define LMEDS TRUE

#define TINY 1.0e-20
#define NDIM 6
#define FTOL 1.0e-6

#define PI 3.1415926

#define SQR(x) ((x)*(x))
#define ABS(a) ((a)>=0 ? a : -(a))
#define R2D(x) ((x)*180.0/PI)
#define D2R(x) ((x)*PI/180.0)

extern float x_trans3[],y_trans3[];
extern int nseg2;
extern int representation_ok;

extern int bias;

void fit_superellipse(float *a, float *b, float *e, float *xc, float *yc, float *rot);
float POW(float a, float b);
float pow2(float a, float b);
float func(float p[]);
void testfit(float *a, float *b, float *e, float *xo, float *yo, float *rot);
void sort(int n, float ra[]);

int ellipse_fit(float *x_cent, float *y_cent, float *major_axis, float *minor_axis, float *rot_angle);

void fit_superellipse(float *a, float *b, float *e, float *xc, float *yc, float *rot)
{
    float aT,bT,eT,xcT,ycT,rotT;
    float radius2;
	int t;
    //float compute_orientation();

    /* fit ellipse to get initial estimate for superellipse */
    t = ellipse_fit(&xcT,&ycT,&aT,&bT,&rotT);
	if (t > 0) {
		representation_ok = FALSE;
	}
    //printf("initialisation:  ctr %f %f  ab %f %f  r %f\n",xcT,ycT,aT,bT,rotT);

    rotT = R2D(rotT);
    eT = 1;
    testfit(&aT,&bT,&eT,&xcT,&ycT,&rotT);
    rotT = D2R(rotT);

    *a = aT;
    *b = bT;
    *e = eT;
    *xc = xcT;
    *yc = ycT;
    *rot = rotT;
}

/* avoid error messages from math library */
/* HAD TO ADD EXTRA OVERFLOW CHECK FOR DEC - PLR Oct 1994 */
float POW(float a, float b)
{
    float r;
    float LN_MAX_FLOAT = 88;
    float LN_MIN_FLOAT = -88;

    if (a == 0)
        r = 0;
    else {
        /* trap overflow */
        if (b*log((float)a) > LN_MAX_FLOAT)
            r = 9e30;
        /* trap underflow */
        else if (b*log((float)a) < LN_MIN_FLOAT)
            r = 0;
        else
            r = pow((float)a,(float)b);
    }

    return(r);
}

float pow2(float a, float b)
{
    float r;

    if (a < 0) a = -a;

    if (a == 0)
        r = 0;
    else
        r = pow((float)a,(float)b);
    r = ABS(r);
    return(r);
}

/*********************************************
 definition of function to optimize
**********************************************/
float func(float p[])
{
    int i;
    float fi,fu;
    double xi,yi;
    float dx,dy;
    float tx,ty;
    float x,y;
    float sine2,cosine2;
    float list[NO_PIXELS];

    /* abort if a, b, or e have impossible values */
    if ((p[1] < 0) || (p[2] < 0) || (p[3] < 0)) {
        return(9e30);
    }

    cosine2 = cos(D2R(-p[6]));
    sine2 = sin(D2R(-p[6]));

    fu = 0;
    for (i = 1; i <= nseg2; i++) {
        tx = x_trans3[i] - p[4];
        ty = y_trans3[i] - p[5];

        x = ABS(tx * cosine2 - ty * sine2);
        y = ABS(tx * sine2 + ty * cosine2);

        /* trap divide-by-zero error - PLR Oct 1994 */
        if (p[3] != 0) {
            xi = POW(p[1],2.0/p[3]);
            if ((xi != 0) && (p[2] != 0) && (x != 0))
                xi = 1.0 / xi + POW(y/(x*p[2]),2.0/p[3]);
            else
                xi = 9e30;

            xi = 1.0 / xi;
            xi = ABS(xi);
            xi = POW(xi,p[3]/2.0);

            /* trap divide-by-zero error - PLR Oct 1994 */
            if (x != 0)
                yi = xi * y/x;
            else
                yi = 1e10;

            dx = x - xi;
            dy = y - yi;

            fi = sqrt(dx*dx + dy*dy);

            /* bias the superellipse to have 0 <= e <= 1 */
            if (bias)
                if (p[3] > 1)
                    //fi *= 10 * SQR(p[3]);
                    fi *= SQR(p[3]);
        }
        else {
            fi = 1e30;
        }
#if LMEDS
        list[i] = ABS(fi);
#else
        fu += ABS(fi);
#endif
    }

#if LMEDS
    sort(nseg2,list);
    return(list[nseg2/2]);
#else
    return(fu);
#endif
}

/**********************************************
 Fitting data to an ellipse
***********************************************/
void testfit(float *a, float *b, float *e, float *xo, float *yo, float *rot)
{
    int i,iter,j;
    float fret,**xi;
    float p[7];

    /* starting point */
    p[1] = *a;
    p[2] = *b;
    p[3] = *e;
    p[4] = *xo;
    p[5] = *yo;
    p[6] = *rot;

    /* set of initial directions */
    xi = matrix(1,NDIM,1,NDIM);
    for (i = 1; i <= NDIM; i++)
        for (j = 1; j <= NDIM; j++)
            xi[i][j] = (i == j ? 1.0 : 0.0);

    powell(p,xi,NDIM,FTOL,&iter,&fret,func);

    /***
    fprintf(stderr,"Iterations: %d\n",iter);
    fprintf(stderr,"Minimum found at:\n");
    for (i = 1; i <= NDIM; i++)
        fprintf(stderr,"%.2f  ",p[i]);
    ***/

    *a = p[1];
    *b = p[2];
    *e = p[3];
    *xo = p[4];
    *yo = p[5];
    *rot = p[6];

    /***
    fprintf(stderr,"\nMinimum function value = %.2f\n\n",fret);
    ***/

    free_matrix(xi,1,NDIM,1,NDIM);
}

/* from numerical recipes in C */
void sort(int n, float ra[])
{
   int l,j,ir,i;
   float rra;

   l=(n >> 1)+1;
   ir=n;
   for (;;) {
      if (l > 1)
         rra=ra[--l];
      else {
         rra=ra[ir];
         ra[ir]=ra[1];
         if (--ir == 1) {
            ra[1]=rra;
            return;
         }
      }
      i=l;
      j=l << 1;
      while (j <= ir) {
         if (j < ir && ra[j] < ra[j+1]) ++j;
         if (rra < ra[j]) {
            ra[i]=ra[j];
            j += (i=j);
         }
         else j=ir+1;
      }
      ra[i]=rra;
   }
}
