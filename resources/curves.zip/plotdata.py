#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
import re
import sys
from pathlib import Path
from typing import List, Tuple, Optional, Union, Dict

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.backend_bases import MouseButton
from matplotlib.backend_bases import MouseButton

# ---------------- Types ----------------
Point = Tuple[float, float]
Polyline = List[Point]
Segment = Tuple[Point, Point]

ArcSpec = Tuple[float, float, float, float, float, float, float, int]  # xc,yc,sx,sy,ex,ey,r,dir
EllipseSpec = Tuple[float, float, float, float, float, float, float, float, float, int]  # xc,yc,sx,sy,ex,ey,a,b,phi,dir
SuperEllipseSpec = Tuple[
    float, float, float, float, float, float, float, float, float, float, int
]  # xc,yc,sx,sy,ex,ey,a,b,n,phi,dir

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".ppm", ".pgm"}

# ---------------- Regex ----------------
LIST_RE = re.compile(r"^\s*list:\s*(\d+)\s*$")

LINE_RE = re.compile(
    r"""^\s*line:\s*
        ([+-]?\d+(?:\.\d*)?)\s+   # ignored
        ([+-]?\d+(?:\.\d*)?)\s+   # x1
        ([+-]?\d+(?:\.\d*)?)\s+   # y1
        ([+-]?\d+(?:\.\d*)?)\s+   # x2
        ([+-]?\d+(?:\.\d*)?)\s*   # y2
        $""",
    re.VERBOSE,
)

# arc_direction: 1 clockwise, 0 counter-clockwise
ARC_RE = re.compile(
    r"""^\s*arc:\s*
        ([+-]?\d+(?:\.\d*)?)\s+   # ignored
        ([+-]?\d+(?:\.\d*)?)\s+   # xc
        ([+-]?\d+(?:\.\d*)?)\s+   # yc
        ([+-]?\d+(?:\.\d*)?)\s+   # sx
        ([+-]?\d+(?:\.\d*)?)\s+   # sy
        ([+-]?\d+(?:\.\d*)?)\s+   # ex
        ([+-]?\d+(?:\.\d*)?)\s+   # ey
        ([+-]?\d+(?:\.\d*)?)\s+   # r
        ([01])\s*                 # dir
        $""",
    re.VERBOSE,
)

ELLIPSE_RE = re.compile(
    r"""^\s*ellipse:\s*
        ([+-]?\d+(?:\.\d*)?)\s+   # ignored
        ([+-]?\d+(?:\.\d*)?)\s+   # xc
        ([+-]?\d+(?:\.\d*)?)\s+   # yc
        ([+-]?\d+(?:\.\d*)?)\s+   # sx
        ([+-]?\d+(?:\.\d*)?)\s+   # sy
        ([+-]?\d+(?:\.\d*)?)\s+   # ex
        ([+-]?\d+(?:\.\d*)?)\s+   # ey
        ([+-]?\d+(?:\.\d*)?)\s+   # a
        ([+-]?\d+(?:\.\d*)?)\s+   # b
        ([+-]?\d+(?:\.\d*)?)\s+   # phi (radians)
        ([01])\s*                 # dir
        $""",
    re.VERBOSE,
)

# superellipse: <ignored> xc yc sx sy ex ey a b n phi dir
# n is exponent for cos & sin so n=1 -> ellipse
SUPERELLIPSE_RE = re.compile(
    r"""^\s*superellipse:\s*
        ([+-]?\d+(?:\.\d*)?)\s+   # ignored
        ([+-]?\d+(?:\.\d*)?)\s+   # xc
        ([+-]?\d+(?:\.\d*)?)\s+   # yc
        ([+-]?\d+(?:\.\d*)?)\s+   # sx
        ([+-]?\d+(?:\.\d*)?)\s+   # sy
        ([+-]?\d+(?:\.\d*)?)\s+   # ex
        ([+-]?\d+(?:\.\d*)?)\s+   # ey
        ([+-]?\d+(?:\.\d*)?)\s+   # a
        ([+-]?\d+(?:\.\d*)?)\s+   # b
        ([+-]?\d+(?:\.\d*)?)\s+   # n
        ([+-]?\d+(?:\.\d*)?)\s+   # phi
        ([01])\s*                 # dir
        $""",
    re.VERBOSE,
)


# ---------------- Utilities ----------------
def is_image_file(p: Path) -> bool:
    return p.suffix.lower() in IMAGE_EXTS


def read_first_nonempty_line(path: Union[str, Path]) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            s = raw.strip()
            if s:
                return s
    return ""


def sgn(v: float) -> float:
    return -1.0 if v < 0 else 1.0


def next_pow2_ge(x: float) -> int:
    if x <= 1:
        return 1
    n = 1
    while n < x:
        n <<= 1
    return n


def update_bounds(bounds: Optional[Tuple[float, float, float, float]], xs: List[float], ys: List[float]):
    if not xs or not ys:
        return bounds
    mnx, mxx = min(xs), max(xs)
    mny, mxy = min(ys), max(ys)
    if bounds is None:
        return (mnx, mxx, mny, mxy)
    a, b, c, d = bounds
    return (min(a, mnx), max(b, mxx), min(c, mny), max(d, mxy))


# ---------------- Parsers ----------------
def parse_pixel_curves(path: Union[str, Path]) -> List[Polyline]:
    curves: List[Polyline] = []
    current: Optional[Polyline] = None
    header_seen = False

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue

            if not header_seen:
                header_seen = True
                continue

            if LIST_RE.match(line):
                if current:
                    curves.append(current)
                current = []
                continue

            parts = line.split()
            if len(parts) < 2:
                continue

            try:
                x = float(parts[0])
                y = float(parts[1])
            except ValueError:
                continue

            if x == -1:
                if current:
                    curves.append(current)
                current = None
                continue

            if current is None:
                current = []
            current.append((x, y))

    if current:
        curves.append(current)
    return curves


def parse_super(
    path: Union[str, Path],
) -> Tuple[List[List[Segment]], List[List[ArcSpec]], List[List[EllipseSpec]], List[List[SuperEllipseSpec]]]:
    seg_lists: List[List[Segment]] = []
    arc_lists: List[List[ArcSpec]] = []
    ell_lists: List[List[EllipseSpec]] = []
    sup_lists: List[List[SuperEllipseSpec]] = []

    cur_segs: Optional[List[Segment]] = None
    cur_arcs: Optional[List[ArcSpec]] = None
    cur_ells: Optional[List[EllipseSpec]] = None
    cur_sups: Optional[List[SuperEllipseSpec]] = None

    header_seen = False

    def ensure_current():
        nonlocal cur_segs, cur_arcs, cur_ells, cur_sups
        if cur_segs is None:
            cur_segs, cur_arcs, cur_ells, cur_sups = [], [], [], []

    def flush_current():
        nonlocal cur_segs, cur_arcs, cur_ells, cur_sups
        if any(v is not None for v in (cur_segs, cur_arcs, cur_ells, cur_sups)):
            seg_lists.append(cur_segs or [])
            arc_lists.append(cur_arcs or [])
            ell_lists.append(cur_ells or [])
            sup_lists.append(cur_sups or [])
        cur_segs = cur_arcs = cur_ells = cur_sups = None

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue

            if not header_seen:
                header_seen = True
                continue

            if LIST_RE.match(line):
                flush_current()
                ensure_current()
                continue

            low = line.lower()
            if low.startswith("endl:"):
                flush_current()
                continue

            if low.startswith("endf:"):
                break

            m = LINE_RE.match(line)
            if m:
                ensure_current()
                _, x1, y1, x2, y2 = m.groups()
                cur_segs.append(((float(x1), float(y1)), (float(x2), float(y2))))
                continue

            m = ARC_RE.match(line)
            if m:
                ensure_current()
                _, xc, yc, sx, sy, ex, ey, r, d = m.groups()
                cur_arcs.append((float(xc), float(yc), float(sx), float(sy), float(ex), float(ey), float(r), int(d)))
                continue

            m = ELLIPSE_RE.match(line)
            if m:
                ensure_current()
                _, xc, yc, sx, sy, ex, ey, a, b, phi, d = m.groups()
                cur_ells.append(
                    (float(xc), float(yc), float(sx), float(sy), float(ex), float(ey), float(a), float(b), float(phi), int(d))
                )
                continue

            m = SUPERELLIPSE_RE.match(line)
            if m:
                ensure_current()
                _, xc, yc, sx, sy, ex, ey, a, b, n, phi, d = m.groups()
                cur_sups.append(
                    (float(xc), float(yc), float(sx), float(sy), float(ex), float(ey), float(a), float(b), float(n), float(phi), int(d))
                )
                continue

    flush_current()
    return seg_lists, arc_lists, ell_lists, sup_lists


# ---------------- Sampling ----------------
def arc_points(spec: ArcSpec, samples: int) -> Polyline:
    xc, yc, sx, sy, ex, ey, r, direction = spec
    a0 = math.atan2(sy - yc, sx - xc)
    a1 = math.atan2(ey - yc, ex - xc)

    if direction == 0:  # CCW
        while a1 <= a0:
            a1 += 2 * math.pi
    else:  # CW
        while a1 >= a0:
            a1 -= 2 * math.pi

    angles = [a0 + (a1 - a0) * i / (samples - 1) for i in range(samples)]
    return [(xc + r * math.cos(a), yc + r * math.sin(a)) for a in angles]


def ellipse_param_t(xc: float, yc: float, a: float, b: float, phi: float, x: float, y: float) -> float:
    c = math.cos(phi)
    s = math.sin(phi)
    dx, dy = x - xc, y - yc
    xr = dx * c + dy * s  # rotate by -phi
    yr = -dx * s + dy * c
    return math.atan2(yr / b, xr / a)


def ellipse_points(spec: EllipseSpec, samples: int) -> Polyline:
    xc, yc, sx, sy, ex, ey, a, b, phi, direction = spec
    t0 = ellipse_param_t(xc, yc, a, b, phi, sx, sy)
    t1 = ellipse_param_t(xc, yc, a, b, phi, ex, ey)

    if direction == 0:  # CCW
        while t1 <= t0:
            t1 += 2 * math.pi
    else:  # CW
        while t1 >= t0:
            t1 -= 2 * math.pi

    c = math.cos(phi)
    s = math.sin(phi)
    ts = [t0 + (t1 - t0) * i / (samples - 1) for i in range(samples)]
    pts: Polyline = []
    for t in ts:
        ct, st = math.cos(t), math.sin(t)
        x = xc + a * ct * c - b * st * s
        y = yc + a * ct * s + b * st * c
        pts.append((x, y))
    return pts


def superellipse_xy(xc: float, yc: float, a: float, b: float, n: float, phi: float, t: float) -> Point:
    # x' = a * sgn(cos t) * |cos t|^n ; y' = b * sgn(sin t) * |sin t|^n ; n=1 -> ellipse
    if n <= 0:
        n = 1e-6
    ct, st = math.cos(t), math.sin(t)
    x0 = a * sgn(ct) * (abs(ct) ** n)
    y0 = b * sgn(st) * (abs(st) ** n)
    c = math.cos(phi)
    s = math.sin(phi)
    return (xc + x0 * c - y0 * s, yc + x0 * s + y0 * c)


def superellipse_param_t(xc: float, yc: float, a: float, b: float, n: float, phi: float, x: float, y: float) -> float:
    # cos t ~= sgn(x'/a) * |x'/a|^(1/n), sin t ~= sgn(y'/b) * |y'/b|^(1/n)
    if a == 0 or b == 0:
        return 0.0
    if n <= 0:
        n = 1e-6

    c = math.cos(phi)
    s = math.sin(phi)
    dx, dy = x - xc, y - yc

    xr = dx * c + dy * s
    yr = -dx * s + dy * c

    u = sgn(xr) * (abs(xr / a) ** (1.0 / n))
    v = sgn(yr) * (abs(yr / b) ** (1.0 / n))
    return math.atan2(v, u)


def superellipse_points(spec: SuperEllipseSpec, samples: int) -> Polyline:
    xc, yc, sx, sy, ex, ey, a, b, n, phi, direction = spec
    t0 = superellipse_param_t(xc, yc, a, b, n, phi, sx, sy)
    t1 = superellipse_param_t(xc, yc, a, b, n, phi, ex, ey)

    if direction == 0:  # CCW
        while t1 <= t0:
            t1 += 2 * math.pi
    else:  # CW
        while t1 >= t0:
            t1 -= 2 * math.pi

    ts = [t0 + (t1 - t0) * i / (samples - 1) for i in range(samples)]
    return [superellipse_xy(xc, yc, a, b, n, phi, t) for t in ts]


# ---------------- Drawing helpers ----------------
def draw_crosses(ax, xs: List[float], ys: List[float], size_pts: float, visible: bool):
    if not xs:
        return None
    (artist,) = ax.plot(
        xs, ys,
        linestyle="None",
        marker="x",
        color="black",
        markersize=size_pts,
        markeredgewidth=1,
        zorder=10000,
        clip_on=False,
    )
    artist.set_visible(visible)
    return artist


def set_artists_visible(artists: List[object], visible: bool) -> None:
    for a in artists:
        try:
            a.set_visible(visible)
        except Exception:
            pass


def add_geometry_artists(
    ax,
    geom_path: Path,
    *,
    cross_size_pts: float,
    crosses_visible: bool,
    arc_samples: int,
    ellipse_samples: int,
    superellipse_samples: int,
    line_width: float,
    pixel_markers: bool,
    pixel_marker_size: float,
) -> Tuple[List[object], List[object], Optional[Tuple[float, float, float, float]]]:
    """
    Returns (line_artists, cross_artists, bounds) for one geometry file.
    bounds = (minx, maxx, miny, maxy) over ALL drawn geometry of this file.
    Cross positions are always computed for line segments; visibility toggled by 'x'.
    """
    header = read_first_nonempty_line(geom_path).strip().lower()
    line_artists: List[object] = []
    cross_artists: List[object] = []
    bounds: Optional[Tuple[float, float, float, float]] = None

    if header in {"pixel", "pixel_float"}:
        curves = parse_pixel_curves(geom_path)
        for poly in curves:
            xs = [p[0] for p in poly]
            ys = [p[1] for p in poly]
            bounds = update_bounds(bounds, xs, ys)

            if pixel_markers:
                (a,) = ax.plot(xs, ys, marker=".", markersize=pixel_marker_size, linewidth=line_width, zorder=10)
            else:
                (a,) = ax.plot(xs, ys, linewidth=line_width, zorder=10)
            line_artists.append(a)

    elif header == "super":
        seg_lists, arc_lists, ell_lists, sup_lists = parse_super(geom_path)

        ex: List[float] = []
        ey: List[float] = []

        for seglist in seg_lists:
            for (p1, p2) in seglist:
                xs = [p1[0], p2[0]]
                ys = [p1[1], p2[1]]
                bounds = update_bounds(bounds, xs, ys)

                (a,) = ax.plot(xs, ys, linewidth=line_width, zorder=10)
                line_artists.append(a)

                # Always collect possible cross endpoints (even if --endpoint-crosses not set)
                ex.extend(xs)
                ey.extend(ys)

        for arclist in arc_lists:
            for spec in arclist:
                pts = arc_points(spec, arc_samples)
                xs = [p[0] for p in pts]
                ys = [p[1] for p in pts]
                bounds = update_bounds(bounds, xs, ys)

                (a,) = ax.plot(xs, ys, linewidth=line_width, zorder=10)
                line_artists.append(a)

        for elllist in ell_lists:
            for spec in elllist:
                pts = ellipse_points(spec, ellipse_samples)
                xs = [p[0] for p in pts]
                ys = [p[1] for p in pts]
                bounds = update_bounds(bounds, xs, ys)

                (a,) = ax.plot(xs, ys, linewidth=line_width, zorder=10)
                line_artists.append(a)

        for suplist in sup_lists:
            for spec in suplist:
                pts = superellipse_points(spec, superellipse_samples)
                xs = [p[0] for p in pts]
                ys = [p[1] for p in pts]
                bounds = update_bounds(bounds, xs, ys)

                (a,) = ax.plot(xs, ys, linewidth=line_width, zorder=10)
                line_artists.append(a)

        if ex:
            ca = draw_crosses(ax, ex, ey, cross_size_pts, visible=crosses_visible)
            if ca is not None:
                cross_artists.append(ca)

    else:
        print(f"Skipping {geom_path}: unknown header '{header}'", file=sys.stderr)

    return line_artists, cross_artists, bounds


# ---------------- Main plotting ----------------
def plot_inputs(
    inputs: List[Path],
    *,
    endpoint_crosses: bool,
    cross_size_pts: float,
    arc_samples: int,
    ellipse_samples: int,
    superellipse_samples: int,
    line_width: float,
    pixel_markers: bool,
    pixel_marker_size: float,
    tight: bool,
    click_quit: bool,
) -> None:
    image_paths = [p for p in inputs if is_image_file(p)]
    geom_paths = [p for p in inputs if not is_image_file(p)]

    if len(image_paths) > 1:
        raise SystemExit("Provide at most one image.")
    if not geom_paths and not image_paths:
        raise SystemExit("No inputs.")

    # Default (non-tight): square window feel
    # Tight: let matplotlib default sizing
    fig, ax = (plt.subplots() if tight else plt.subplots(figsize=(7, 7)))

    def push_view():
        tb = getattr(fig.canvas, "toolbar", None)
        if tb is not None and hasattr(tb, "push_current"):
            tb.push_current()

    # crosses initial state from CLI (but 'x' can toggle regardless)
    crosses_visible = endpoint_crosses

    # ---- draw image (optional) ----
    image_artist = None
    global_bounds: Optional[Tuple[float, float, float, float]] = None

    if image_paths:
        img_path = image_paths[0]
        img = mpimg.imread(img_path)
        h, w = img.shape[0], img.shape[1]

        # Force grayscale display for 2D images (PGM)
        if getattr(img, "ndim", 0) == 2:
            image_artist = ax.imshow(img, cmap="gray", origin="upper", extent=(0, w, h, 0), zorder=0)
        else:
            image_artist = ax.imshow(img, origin="upper", extent=(0, w, h, 0), zorder=0)

        # image bounds in same coordinate frame
        global_bounds = update_bounds(global_bounds, [0, float(w)], [0, float(h)])
    else:
        # still want origin top-left
        ax.invert_yaxis()

    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, linestyle="--", linewidth=0.5)

    # ---- build artists per geometry file (for Spacebar stepping) ----
    groups: List[Dict[str, object]] = []
    for gp in geom_paths:
        lines, crosses, bnd = add_geometry_artists(
            ax,
            gp,
            cross_size_pts=cross_size_pts,
            crosses_visible=crosses_visible,
            arc_samples=arc_samples,
            ellipse_samples=ellipse_samples,
            superellipse_samples=superellipse_samples,
            line_width=line_width,
            pixel_markers=pixel_markers,
            pixel_marker_size=pixel_marker_size,
        )
        if bnd is not None:
            global_bounds = (
                bnd if global_bounds is None
                else (min(global_bounds[0], bnd[0]), max(global_bounds[1], bnd[1]),
                      min(global_bounds[2], bnd[2]), max(global_bounds[3], bnd[3]))
            )
        groups.append({"path": gp, "lines": lines, "crosses": crosses})

    # show only first geometry group initially (if any)
    current = 0
    for i, g in enumerate(groups):
        set_artists_visible(g["lines"], i == current)
        set_artists_visible(g["crosses"], (i == current) and crosses_visible)

    # ---- set view limits: tight OR power-of-2 square ----
    if global_bounds is None:
        global_bounds = (0.0, 1.0, 0.0, 1.0)

    minx, maxx, miny, maxy = global_bounds
    if tight:
        # Tight fit to content
        # Keep origin top-left: y axis goes down, so ylim is (maxy, miny)
        ax.set_xlim(minx, maxx)
        ax.set_ylim(maxy, miny)
    else:
        # Square with side = smallest power of 2 containing content
        spanx = maxx - minx
        spany = maxy - miny
        side = float(next_pow2_ge(max(spanx, spany)))

        # Anchor square at (minx,miny) so it contains the content
        x0 = minx
        y0 = miny
        ax.set_xlim(x0, x0 + side)
        ax.set_ylim(y0 + side, y0)
    push_view()

    # Title with current file info
    def update_title():
        parts = []
        if image_paths:
            parts.append(image_paths[0].name)
        if groups:
            parts.append(f"{groups[current]['path'].name}  ({current+1}/{len(groups)})")
        ax.set_title(" | ".join(parts) if parts else "overlay")

    update_title()
    fig.canvas.draw_idle()

    # ---- event handlers ----
    def on_key(event):
        nonlocal current, crosses_visible

        if event.key in ("q", "escape"):
            plt.close(fig)
            return

        # Toggle crosses (always possible)
        if event.key == "x":
            crosses_visible = not crosses_visible
            if groups:
                for i, g in enumerate(groups):
                    set_artists_visible(g["crosses"], (i == current) and crosses_visible)
            fig.canvas.draw_idle()
            return

        # Toggle image visibility (lowercase i)
        if event.key == "i" and image_artist is not None:
            image_artist.set_visible(not image_artist.get_visible())
            fig.canvas.draw_idle()
            return

        # Spacebar: advance geometry files one-by-one
        if event.key == " " and groups:
            set_artists_visible(groups[current]["lines"], False)
            set_artists_visible(groups[current]["crosses"], False)

            current = (current + 1) % len(groups)

            set_artists_visible(groups[current]["lines"], True)
            set_artists_visible(groups[current]["crosses"], crosses_visible)

            update_title()

            push_view()
            fig.canvas.draw_idle()
            return

    def on_click(event):
        # Canvas clicks only (toolbar icon clicks don't generate this event)
        if not click_quit:
            return
        if event.button == MouseButton.RIGHT:
            plt.close(fig)

        # If zoom/pan is active, don't treat clicks as quit attempts.
        if tb is not None and getattr(tb, "mode", ""):
            return

        if event.button == MouseButton.RIGHT:
            plt.close(fig)

    fig.canvas.mpl_connect("key_press_event", on_key)
    fig.canvas.mpl_connect("button_press_event", on_click)

    plt.show()

def main(argv: List[str]) -> int:
    ap = argparse.ArgumentParser(
        description=(
            "Display pixel/pixel_float curves and super primitives (line/arc/ellipse/superellipse) over optional image. "
            "Origin top-left.\n"
            "Keys: q/Esc quit, right-click quits, x toggles crosses, i toggles image, Space advances geometry files.\n"
            "Default view: square with side length = smallest power of 2 containing all content; use --tight for tight fit."
        )
    )
    ap.add_argument("inputs", nargs="+", help="Geometry files plus optionally one image (png/jpg/ppm/pgm/...)")

    ap.add_argument("--tight", action="store_true", help="Tight fit the view to the content (disables power-of-2 square view).")

    ap.add_argument("--cross-size", type=float, default=2.0, help="Cross size in points (default 2).")
    ap.add_argument("--endpoint-crosses", action="store_true",
                    help="Start with crosses visible (you can always toggle with 'x').")

    ap.add_argument("--line-width", type=float, default=1.0, help="Line width for all curves (default 1.0).")
    ap.add_argument("--arc-samples", type=int, default=80, help="Samples for circular arcs (default 80).")
    ap.add_argument("--ellipse-samples", type=int, default=120, help="Samples for ellipse arcs (default 120).")
    ap.add_argument("--superellipse-samples", type=int, default=160, help="Samples for superellipse arcs (default 160).")

    # Click-to-quit is ON by default (right-click). Disable with --no-click-quit.
    ap.set_defaults(click_quit=True)
    ap.add_argument("--no-click-quit", dest="click_quit", action="store_false",
                    help="Disable quitting by right-click (use q/Esc to quit).")

    ap.add_argument("--click-quit", action="store_true", help="Enable quitting by right-click (keeps left-click for zoom/pan).")

    # pixel curve marker control (off by default for consistent linewidth)
    ap.add_argument("--pixel-markers", action="store_true", help="Also draw '.' markers for pixel/pixel_float curves.")
    ap.add_argument("--pixel-marker-size", type=float, default=3.0, help="Marker size for pixel curves (default 3).")


    args = ap.parse_args(argv[1:])

    plot_inputs(
        [Path(p) for p in args.inputs],
        endpoint_crosses=args.endpoint_crosses,
        cross_size_pts=args.cross_size,
        arc_samples=args.arc_samples,
        ellipse_samples=args.ellipse_samples,
        superellipse_samples=args.superellipse_samples,
        line_width=args.line_width,
        pixel_markers=args.pixel_markers,
        pixel_marker_size=args.pixel_marker_size,
        tight=args.tight,
        click_quit=args.click_quit,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
