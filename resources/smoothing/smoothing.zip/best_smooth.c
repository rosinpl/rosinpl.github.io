/*
 *   best_smooth.c
 *
 *   segment and smooth curves
 *
 *   smooths either using Gaussian smoothing or by fitting 2nd order polynomials
 *
 *   smoothing criteria: remove all points of inflection
 *
 *   Note: This program is very slow & inefficient for the Gaussian smoothing
 *   (recalculating many things many times). It would be nice to rewrite it
 *   sometime.
 *
 *   Last updated November 1994 to port to DEC Alpha and correct various newly
 *   apparant bugs
 *
 *   Described in:
 *       International J. of Pattern Recognition and Artificial Intelligence,
 *       "Non-parametric multiscale curve smoothing",
 *       Paul L. Rosin,
 *       vol. 8, no. 6, pp. 1381-1406, 1994
 *
 *   Paul Rosin
 *   Joint Research Centre
 *   paul.rosin@jrc.it
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

/* output significance values */
#define SIGNIFICANCE FALSE

#define PI 3.141591
#define ROOT_TWO sqrt(2.0)

#define MAX_PIXELS 5000
#define MAX_WIN 2000

#define MID_POINT      0    /* use midpoint for breakpoint */
#define MAX_DEV        1    /* use maximum deviation for breakpoint */
#define BEST_RATIO1    2    /* use best error ratio for breakpoint */
#define BEST_RATIO2    3    /* use best error ratio for breakpoint */
#define BEST_RATIO3    4    /* use best error ratio for breakpoint */

#define GAUSSIAN 0
#define POLY 1

#define TINY  1.0e-20
#define LARGE 1.0e20

#define FORWARD 0
#define REVERSE 1
#define START   0
#define FINISH  1

#define MAX_SIGMA 1e5

#define SQR(a)    ((a)*(a))
#define CUBE(a)   ((a)*(a)*(a))
#define MIN(a,b)  ((a)<(b)?(a):(b))

int x_orig[MAX_PIXELS],y_orig[MAX_PIXELS];     /* original data - not altered */
int orig_number_pixels;                        /* length of original data */
float x[MAX_PIXELS],y[MAX_PIXELS];             /* extended copy of original data */
int number_pixels;                             /* length of extended data */
int x_trans[MAX_PIXELS],y_trans[MAX_PIXELS];   /* temporary: for extending data */
float xsmooth[MAX_PIXELS],ysmooth[MAX_PIXELS]; /* smoothed section of pixels */
float curvature[MAX_PIXELS];                   /* curvature of smoothed data */
float x_final[MAX_PIXELS],y_final[MAX_PIXELS]; /* final processed data */
float save_sig[MAX_PIXELS];                    /* final significance value
*/
float curvature_final[MAX_PIXELS]; 
float smoothing_done[MAX_PIXELS];              /* how much smoothing was applied */
float amount_of_smoothing;               /* amount of smoothing for each segment */
int label[MAX_PIXELS];
int label_value = 0;     /* unique identifier for each curve section */

double G[MAX_WIN];       /* convolution mask for Gaussian smoothing */
double G1[MAX_WIN];      /* convolution mask for 1st derivative of Gaussian */
double G2[MAX_WIN];      /* convolution mask for 2nd derivative of Gaussian */
int masksize,halfmask;
float cor_table[197];

FILE *fp_in,*fp_out;
int end_of_file,closed_loop;

#define CURVATURE 0
#define FLOAT 1
#define PS 2

int pixel_type = PS;

int breakpoint = MID_POINT;   /* which breakpoint method to use */
int smooth_type = GAUSSIAN;   /* which type of smoothing to use */ 

int find_breakpoint1();
int find_breakpoint2();
int find_breakpoint3();
void segment(int start_in, int finish_in, float *sig_out);
void deviation(int *pos, float *dev);
void transform1(float theta, int nseg, float x1, float y1);
void transform2(float theta, int nseg, float x1, float y1);
double gaussian(double sigma, int t);
double gaussian1(double sigma, int t);
double gaussian2(double sigma, int t);
void do_smoothing(int start, int finish);
void do_gaussian_smoothing(int start, int finish);
void do_poly_smoothing(int start, int finish);
int smooth_data(double sigma);;
float angle(float x1, float y1, float x2, float y2);
void extend_data(int length, int end);
void wraparound_data(int length);
void ludcmp(float a[4][4], int n, int indx[4], float *d);
void lubksb(float a[4][4], int n, int indx[4], float b[4]);
void error(char s[]);
void lms_fit(int no_points);
void read_link_data(int *number_pixels, int *end_of_file, int *closed_loop, int *list_no);
void write_link_data(int number_pixels);
void determine_poly_lms(float m[4], float datax[], float datay[], int no_points);
void make_cor_table(float sigma);
void G_G2inv_pair(float radius, float *curG, float *curG2i);
float shrink_correct(float sigma, float g, float g2);
void options(char *progname);

main(argc,argv)
int argc;
char *argv[];
{
    float dummy;
    char *infile,*outfile;
    int i;
    int list_no;

    infile = outfile = NULL;

    for (i = 1; i < argc; i++)
       if (argv[i][0] == '-')
          switch (argv[i][1]) {
              case 's':
                   i++;
                   smooth_type = atoi(argv[i]);
                   break;
              case 'b':
                   i++;
                   breakpoint = atoi(argv[i]);
                   break;
              case 'i':
                   i++;
                   infile = argv[i];
                   break;
              case 'o':
                   i++;
                   outfile = argv[i];
                   break;
              case 'c':
                   pixel_type = CURVATURE;
                   break;
              case 'f':
                   pixel_type = FLOAT;
                   break;
              case 'p':
                   pixel_type = PS;
                   break;
              default:
                   fprintf(stderr,"illegal option -%c\n",argv[i][1]);
                   options(argv[0]);
          }
        else {
           fprintf(stderr,"illegal option %c\n",argv[i][0]);
           options(argv[0]);
        }

    if ((infile == NULL) || (outfile == NULL)) {
        fprintf(stderr,"ERROR: require input and output filenames\n");
        options(argv[0]);
    }

    if (breakpoint != MID_POINT
     && breakpoint != MAX_DEV
     && breakpoint != BEST_RATIO1
     && breakpoint != BEST_RATIO2
     && breakpoint != BEST_RATIO3)
    {
        fprintf(stderr,"ERROR: breakpointpoint must be either:\n");
        fprintf(stderr,"      %d = MID_POINT\n",MID_POINT);
        fprintf(stderr,"      %d = MAX_DEV\n",MAX_DEV);
        fprintf(stderr,"      %d = BEST_RATIO1\n",BEST_RATIO1);
        fprintf(stderr,"      %d = BEST_RATIO2\n",BEST_RATIO2);
        fprintf(stderr,"      %d = BEST_RATIO3\n",BEST_RATIO3);
        exit(-1);
    }
    else {
        if (breakpoint == MID_POINT)
            fprintf(stderr,"using MID_POINT for breakpoint\n");
        else if (breakpoint == MAX_DEV)
            fprintf(stderr,"using MAX_DEV for breakpoint\n");
        else if (breakpoint == BEST_RATIO1)
            fprintf(stderr,"using BEST_RATIO1 for breakpoint\n");
        else if (breakpoint == BEST_RATIO2)
            fprintf(stderr,"using BEST_RATIO2 for breakpoint\n");
        else if (breakpoint == BEST_RATIO3)
            fprintf(stderr,"using BEST_RATIO3 for breakpoint\n");
        else
            fprintf(stderr,"ERROR!!!!!!!!!!!!!!!!!!!!\n");
    }

    if (smooth_type != GAUSSIAN && smooth_type != POLY) {
        fprintf(stderr,"ERROR: smoothing type must be either:\n");
        fprintf(stderr,"      %d = GAUSSIAN\n",GAUSSIAN);
        fprintf(stderr,"      %d = POLY\n",POLY);
        exit(-1);
    }
    else {
        if (smooth_type == GAUSSIAN)
            fprintf(stderr,"using GAUSSIAN for smooth_type\n");
        else if (smooth_type == POLY)
            fprintf(stderr,"using POLY for smooth_type\n");
        else
            fprintf(stderr,"ERROR!!!!!!!!!!!!!!!!!!!!\n");
    }

    if ((fp_in=fopen(infile,"r")) == NULL) {
        fprintf(stderr,"can't open %s\n",infile);
        exit(-1);
    }
    fscanf(fp_in,"pixel");

    if ((fp_out=fopen(outfile,"w")) == NULL) {
        fprintf(stderr,"can't open %s\n",outfile);
        exit(-1);
    }
    if (pixel_type == PS) {
        fprintf(fp_out,"%%!\ngsave\ninitgraphics\n1 1 scale\n");
        fprintf(fp_out,"20 100 translate\n");
        fprintf(fp_out,"1 setlinejoin\n1 setlinecap\nnewpath\n");
    }
    else if (pixel_type == FLOAT)
        fprintf(fp_out,"pixel_float\n");
    else
        fprintf(fp_out,"pixel_curvature\n");

    /* smooth each linked sequence of edges */
    do{
        read_link_data(&orig_number_pixels,&end_of_file,&closed_loop,&list_no);
        segment(0,orig_number_pixels-1,&dummy);
        write_link_data(orig_number_pixels);
    } while(!end_of_file);

    if (pixel_type == PS) {
        fprintf(fp_out,"stroke\nshowpage\n");
    }

    fclose(fp_in);
    fclose(fp_out);
}

void segment(int start_in, int finish_in, float *sig_out)
{
    int i,j;
    int pos;
    float dev;
    float sig1,sig2,sig3,max_sig;

    /* avoid problems with smoothing very short bits */
    if ((finish_in - start_in) < 5) {
        /*
         * save original curve at this lowest of levels
         * return poor significance
         */
        save_sig[start_in] = LARGE;
        for (i = start_in,j = 0; i <= finish_in; i++,j++) {
            x_final[i] = x_orig[i];
            y_final[i] = y_orig[i];
        }
        if (smooth_type == GAUSSIAN)
            for (i = start_in,j = 0; i <= finish_in; i++,j++) {
                curvature_final[i] = 0;
                smoothing_done[i] = 0;
            }
        else if (smooth_type == POLY) {
            for (i = start_in,j = 0; i <= finish_in; i++,j++) {
                curvature_final[i] = 0;
                label[i] = label_value;
            }
            label_value++;
        }
        *sig_out = LARGE;
        return;
    }

    /* compute significance at this level */

    do_smoothing(start_in,finish_in);

    /* after smoothing whole segment sections of curve are never closed */
    closed_loop = FALSE;

    deviation(&pos,&dev);

    /* several alternative methods for splitting the curve */
    if (breakpoint == MAX_DEV)
        pos += start_in;
    else if (breakpoint == MID_POINT)
        pos = (finish_in + start_in) / 2;
    else if (breakpoint == BEST_RATIO1)
        pos = find_breakpoint1() + start_in;
    else if (breakpoint == BEST_RATIO2)
        pos = find_breakpoint2() + start_in;
    else if (breakpoint == BEST_RATIO3)
        pos = find_breakpoint3() + start_in;

    sig1 = dev / (finish_in - start_in);

    /* SHOULD THIS APPLY TO GAUSSIAN TOO? */
    if (smooth_type == POLY) {
        if ((finish_in - start_in) < 4)
            sig1 = LARGE;
    }

    if ((dev <= 0) || (pos == start_in) || (pos == finish_in)) {
        /*
         * save smoothed curve at this lowest of levels
         * return significance
         */
        save_sig[start_in] = sig1;
        for (i = start_in,j = 0; i <= finish_in; i++,j++) {
            x_final[i] = xsmooth[j];
            y_final[i] = ysmooth[j];
        }
        if (smooth_type == GAUSSIAN)
            for (i = start_in,j = 0; i <= finish_in; i++,j++) {
                curvature_final[i] = curvature[i];
                smoothing_done[i] = amount_of_smoothing;
            }
        else if (smooth_type == POLY) {
            for (i = start_in,j = 0; i <= finish_in; i++,j++) {
                curvature_final[i] = curvature[i];
                label[i] = label_value;
            }
            label_value++;
        }
        *sig_out = sig1;
    }
    else{
        /*
         * recurse to next level down
         */
        segment(start_in,pos,&sig2);
        segment(pos,finish_in,&sig3);
        /*
         * get best significance from lower level
         */
        max_sig = MIN(sig2,sig3);
        /*
         * return best significance, keep lower level description
         */
        if (max_sig < sig1) {
            *sig_out = max_sig;
        }
        /*
         * this level more significant so replace lower levels
         */
        else{
            *sig_out = sig1;
            /*
             * this level more significant so replace lower levels
             */
            /* need to regenerate smoothed data first - inefficient */
            do_smoothing(start_in,finish_in);
            save_sig[start_in] = *sig_out;
            for (i = start_in,j = 0; i <= finish_in; i++,j++) {
                x_final[i] = xsmooth[j];
                y_final[i] = ysmooth[j];
            }
            if (smooth_type == GAUSSIAN)
                for (i = start_in,j = 0; i <= finish_in; i++,j++) {
                    curvature_final[i] = curvature[i];
                    smoothing_done[i] = amount_of_smoothing;
                }
            else if (smooth_type == POLY) {
                for (i = start_in,j = 0; i <= finish_in; i++,j++) {
                    curvature_final[i] = curvature[i];
                    label[i] = label_value;
                }
                label_value++;
            }
        }
    }
}

/* calculate deviation between smoothed & unsmoothed section of curve */
void deviation(int *pos, float *dev)
{
    int i;
    int pos1;
    float max1;
    float dx,dy,diff;

    /* HACK - for some reason there is one too few smoothed data points */
    xsmooth[number_pixels-1] = xsmooth[number_pixels-2];
    ysmooth[number_pixels-1] = ysmooth[number_pixels-2];

    pos1 = 0;
    max1 = 0.0;
    for (i = 0; i < number_pixels; i++) {
        dx = x[i]-xsmooth[i];
        dy = y[i]-ysmooth[i];
        diff = sqrt(SQR(dx)+SQR(dy));
        if (diff > max1) {
            max1 = diff;
            pos1 = i;
        }
    }
    *pos = pos1;
    *dev = max1;
}

/*
 * find breakpoint by choosing point with maximum heterogeneity &
 * centrality
 */
int find_breakpoint1()
{
    int i;
    float dx,dy,diff;
    float errors[MAX_PIXELS];
    float total_error = 0;
    float errorR,errorL,errorR_avg,errorL_avg;
    float lengthR,lengthL;
    float heterogeneity,centrality,measure,max_measure;
    int best_breakpoint; 

    /* calculate difference between smoothed & unsmoothed curves */
    for (i = 0; i < number_pixels; i++) {
        dx = x[i]-xsmooth[i];
        dy = y[i]-ysmooth[i];
        diff = sqrt(SQR(dx)+SQR(dy));
        errors[i] = diff;
        total_error += diff;
    }

    errorR = total_error;
    errorL = 0;
    lengthR = number_pixels;
    lengthL = 1;
    max_measure = best_breakpoint = -1;
    for (i = 1; i < number_pixels-1; i++) {
        errorR -= errors[i];
        errorL += errors[i];
        lengthR--;
        lengthL++;
        errorR_avg = errorR / lengthR;
        errorL_avg = errorL / lengthL;

        if (errorL_avg <= errorR_avg)
            heterogeneity = 1 - (errorL_avg / errorR_avg);
        else
            heterogeneity = 1 - (errorR_avg / errorL_avg);

        if (lengthL <= lengthR)
            centrality = lengthL / lengthR;
        else
            centrality = lengthR / lengthL;
        
        /*
         * downplay significance of centrality
         * otherwise it totally outweighs heterogeneity
         */
        centrality = sqrt(centrality);

        measure = heterogeneity * centrality;

        if (measure > max_measure) {
            max_measure = measure;
            best_breakpoint = i;
        }
    }

    if (best_breakpoint <= 0) {
        best_breakpoint = number_pixels / 2;
    }

    return(best_breakpoint);
}

/*
 * find breakpoint by choosing point with maximum heterogeneity &
 * centrality
 */
int find_breakpoint2()
{
    int i;
    float dx,dy,diff;
    float errors[MAX_PIXELS];
    float total_error = 0;
    float errorR,errorL,errorR_avg,errorL_avg;
    float lengthR,lengthL;
    float heterogeneity,max_heterogeneity;
    int best_breakpoint; 

    /* calculate difference between smoothed & unsmoothed curves */
    for (i = 0; i < number_pixels; i++) {
        dx = x[i]-xsmooth[i];
        dy = y[i]-ysmooth[i];
        diff = sqrt(SQR(dx)+SQR(dy));
        errors[i] = diff;
        total_error += diff;
    }

    errorR = total_error;
    errorL = 0;
    lengthR = number_pixels;
    lengthL = 1;
    max_heterogeneity = best_breakpoint = -1;
    for (i = 1; i < number_pixels-1; i++) {
        errorR -= errors[i];
        errorL += errors[i];
        lengthR--;
        lengthL++;
        errorR_avg = errorR / lengthR;
        errorL_avg = errorL / lengthL;

        if (errorL_avg <= errorR_avg)
            heterogeneity = 1 - (errorL_avg / errorR_avg);
        else
            heterogeneity = 1 - (errorR_avg / errorL_avg);

        if (heterogeneity > max_heterogeneity) {
            max_heterogeneity = heterogeneity;
            best_breakpoint = i;
        }
    }

    if ((best_breakpoint <= 0) || (max_heterogeneity <= 0)) {
        best_breakpoint = number_pixels / 2;
    }
    else
        best_breakpoint = best_breakpoint * max_heterogeneity + 
                          (number_pixels / 2) * (1 - max_heterogeneity);

    return(best_breakpoint);
}

/*
 * find breakpoint by choosing point with maximum heterogeneity &
 * centrality
 */
int find_breakpoint3()
{
    int i;
    float dx,dy,diff;
    float errors[MAX_PIXELS];
    float total_error = 0;
    float errorR,errorL,errorR_avg,errorL_avg;
    float lengthR,lengthL;
    float heterogeneity,sum_pos,sum_heterogeneity;
    int best_breakpoint; 

    /* calculate difference between smoothed & unsmoothed curves */
    for (i = 0; i < number_pixels; i++) {
        dx = x[i]-xsmooth[i];
        dy = y[i]-ysmooth[i];
        diff = sqrt(SQR(dx)+SQR(dy));
        errors[i] = diff;
        total_error += diff;
    }

    errorR = total_error;
    errorL = 0;
    lengthR = number_pixels;
    lengthL = 1;
    sum_pos = sum_heterogeneity = 0;
    for (i = 1; i < number_pixels-1; i++) {
        errorR -= errors[i];
        errorL += errors[i];
        lengthR--;
        lengthL++;

        errorR_avg = errorR / lengthR;
        errorL_avg = errorL / lengthL;

        if (errorL_avg <= errorR_avg)
            heterogeneity = 1 - (errorL_avg / errorR_avg);
        else
            heterogeneity = 1 - (errorR_avg / errorL_avg);

        sum_pos += i * heterogeneity;
        sum_heterogeneity += heterogeneity;
    }

    best_breakpoint = sum_pos / sum_heterogeneity;

    if ((best_breakpoint <= 0) || (best_breakpoint >= number_pixels)) {
        printf("ERROR: in find_breakpoint3\n");
        printf("best_breakpoint = %d; no pixels: %d\n",
            best_breakpoint,number_pixels);

        printf("sum pos %f  sum het %f\n",sum_pos,sum_heterogeneity);
    }

    return(best_breakpoint);
}

void read_link_data(int *number_pixels, int *end_of_file, int *closed_loop, int *list_no)
{
    char dumstring[50];
    int j;
    int xd,yd;

    fscanf(fp_in,"%s %d\n",dumstring,list_no);
    j = 0;
    do{
        fscanf(fp_in,"%d %d\n",&x_orig[j],&y_orig[j]);
        j++;
    } while(x_orig[j-1] != -1);
    *end_of_file = (y_orig[j-1] == -1);
    j--;
    *number_pixels = j;
    if (*number_pixels > MAX_PIXELS) {
        printf("ERROR: curve too long!!\n");
        exit(-1);
    }
    xd = abs(x_orig[0] - x_orig[j-1]);
    yd = abs(y_orig[0] - y_orig[j-1]);
    *closed_loop = ((xd <= 1) && (yd <= 1));
}

/* output a smoothed curve */
void write_link_data(int number_pixels)
{
    int i;
    float prev_smoothing;

    if (pixel_type != PS) {
        fprintf(fp_out,"list: 0\n");
        if (pixel_type == CURVATURE)
            fprintf(fp_out,"sigma: -1\n");
    }
    /* HACK - don't print last co-ordinate!!!!!! */
    if (pixel_type == PS) {
        /* if Gaussian smoothing used */
        if (smooth_type == GAUSSIAN) {
            prev_smoothing = smoothing_done[0];
            fprintf(fp_out,"stroke\n");
            fprintf(fp_out,"%f setlinewidth\n",prev_smoothing*0.3);
            fprintf(fp_out,"%f %f moveto\n",x_final[0],512-y_final[0]);
            for (i = 1; i < number_pixels-1; i++) {
                if (smoothing_done[i] != prev_smoothing) {
                    prev_smoothing = smoothing_done[i];
                    fprintf(fp_out,"stroke\n%f setlinewidth\n",prev_smoothing*0.3);
                    fprintf(fp_out,"%f %f moveto\n",x_final[i],512-y_final[i]);
                }
                else
                    fprintf(fp_out,"%f %f lineto\n",x_final[i],512-y_final[i]);
            }
        }
        else if (smooth_type == POLY) {
            fprintf(fp_out,"1 setlinewidth\n");
            fprintf(fp_out,"%f %f moveto\n",x_final[0],512-y_final[0]);
            for (i = 1; i < number_pixels-1; i++) {
                if ((i > 0) && (label[i] != label[i-1])) {
                    fprintf(fp_out,"stroke\n");
                    fprintf(fp_out,"%f %f moveto\n",x_final[i],512-y_final[i]);
                }
                else
                    fprintf(fp_out,"%f %f lineto\n",x_final[i],512-y_final[i]);
            }
        }
    }
    else if (pixel_type == FLOAT) {
        if (smooth_type == GAUSSIAN) {
            for (i = 0; i < number_pixels-1; i++)
                fprintf(fp_out,"%f %f\n",x_final[i],y_final[i]);
        }
        else if (smooth_type == POLY) {
            for (i = 0; i < number_pixels-1; i++) {
                if ((i > 0) && (label[i] != label[i-1])) {
                    fprintf(fp_out,"-1 0\n");
                    fprintf(fp_out,"list: 0\n");
#if SIGNIFICANCE
                    fprintf(fp_out,"significance: %f\n",save_sig[i]);
#endif
                }
                fprintf(fp_out,"%f %f\n",x_final[i],y_final[i]);
            }
        }
    }
    else {
        if (smooth_type == GAUSSIAN) {
            /* haven't determined singular points of curvature */
            for (i = 0; i < number_pixels-1; i++)
                fprintf(fp_out,"%f %f %f -1\n",
                    x_final[i],y_final[i],curvature_final[i]);
        }
        else if (smooth_type == POLY) {
            /* haven't determined singular points of curvature */
            for (i = 0; i < number_pixels-1; i++) {
                if ((i > 0) && (label[i] != label[i-1])) {
                    fprintf(fp_out,"-1 0\n");
                    fprintf(fp_out,"list: 0\n");
                    fprintf(fp_out,"sigma: -1\n");
                }
                fprintf(fp_out,"%f %f %f -1\n",
                    x_final[i],y_final[i],curvature_final[i]);
            }
        }
    }

    if (pixel_type != PS) {
        if (end_of_file)
            fprintf(fp_out,"-1 -1\n");
        else
            fprintf(fp_out,"-1 0\n");
    }
}

/* ############################ smoothing stuff ############################ */

double gaussian(double sigma, int t)
{
    double g;

    g = exp(-(t*t)/(2*sigma*sigma)) / (sigma * sqrt(2*PI));

    return(g);
}

/* first derivative */
double gaussian1(double sigma, int t)
{
    double g;

    g = exp(-(t*t)/(2*sigma*sigma)) * (-t)
        / (sigma * sigma * sigma * sqrt(2*PI));

    return(g);
}

/* second derivative */
double gaussian2(double sigma, int t)
{
    double g;

    g = exp(-(t*t)/(2*sigma*sigma)) * (t*t/(sigma*sigma)-1)
        / (sigma * sigma * sigma * sqrt(2*PI));

    return(g);
}

/* smooth a section of data */
void do_smoothing(int start, int finish)
{
    if (smooth_type == GAUSSIAN)
        do_gaussian_smoothing(start,finish);
    else if (smooth_type == POLY)
        do_poly_smoothing(start,finish);
    else
        printf("ERROR: unknown smoothing type\n");
}

/* gaussian smooth data with increasing sigma until <= 1 zero-crossings of curvature */
void do_gaussian_smoothing(int start, int finish)
{
    double sigma = 1.0;
    int i;

    /* copy segment of curve into working arrays */
    number_pixels = 0;
    for (i = start;i <= finish;i++) {
        x[number_pixels] = x_orig[i];
        y[number_pixels] = y_orig[i];
        number_pixels++;
    }

    /* smooth data
     * abort if sigma grows too big - added this hack after porting to DEC
     * Alpha as sometimes it fails to eliminate all points of inflection and
     * sigma grows out of control
     */
    while ((smooth_data(sigma) > 0) && (sigma < MAX_SIGMA)) {
        sigma *= ROOT_TWO;
        /* copy segment of curve into working arrays  - again */
        number_pixels = 0;
        for (i = start;i <= finish;i++) {
            x[number_pixels] = x_orig[i];
            y[number_pixels] = y_orig[i];
            number_pixels++;
        }
    }
    if (sigma >= MAX_SIGMA)
        printf("ERROR: given up smoothing a curve as since even sigma = %.0f\n       didn't eliminate all points of inflection\n",sigma);

    /* keep a record of how much smoothing was performed */
    amount_of_smoothing = sigma;

    /*
     * copy segment of curve into working arrays
     * final time for later comparison with smoothed version
     */
    number_pixels = 0;
    for (i = start;i <= finish;i++) {
        x[number_pixels] = x_orig[i];
        y[number_pixels] = y_orig[i];
        number_pixels++;
    }
}

/* smooth data by independently fitting a 2nd order polynomial to X & Y */
void do_poly_smoothing(int start, int finish)
{
    int i;

    /* copy segment of curve into working arrays */
    number_pixels = 0;
    for (i = start;i <= finish;i++) {
        x[number_pixels] = x_orig[i];
        y[number_pixels] = y_orig[i];
        number_pixels++;
    }

    /* fit polynomial data */
    lms_fit(number_pixels);
}

/* smooth data with given sigma - return number of zero-crossings of curvature */
int smooth_data(double sigma)
{
    int j,t;
    double sum = 0.0;
    double sum_p = 0.0;
    double sum_n = 0.0;
    int point;
    float xG,yG,xG1,yG1,xG2,yG2;
    int xpoint,ypoint;
    float dist;
    //float shrink_correct();
    float k_now;
    int count;
    int negative,positive,zero;

    masksize = 5 * sigma;
    if ((masksize % 2) == 0) masksize++;
    if (masksize >= MAX_WIN) masksize = MAX_WIN-1;
    if (masksize >= 2*number_pixels) {
        masksize = 2*number_pixels-1;
        /*
        printf("truncated masksize due to lack of pixel data!!\n");
        */
    }
    halfmask = masksize / 2;

    if (closed_loop) {
        wraparound_data(halfmask);
    }
    else {
        extend_data(halfmask,FINISH);
        extend_data(halfmask,START);
    }

    /* generate masks for Gaussians & derivatives */
    for (t = -halfmask; t <= halfmask; t++)
        G[halfmask+t] = gaussian(sigma,t);
    for (t = 0; t < masksize; t++) sum += G[t];
    for (t = 0; t < masksize; t++) G[t] /= sum;

    for (t = -halfmask; t <= halfmask; t++)
        G1[halfmask+t] = gaussian1(sigma,t);

    for (t = -halfmask; t <= halfmask; t++)
        G2[halfmask+t] = gaussian2(sigma,t);

    for (t = 0; t < masksize; t++)
        if (G2[t] > 0)
            sum_p += G2[t];
        else
            sum_n -= G2[t];

    /* Added this hack since there are problems with normalising when the
     * masksize is very small - the positive lobes get totally removed!
     * although this only become apparant on porting * to the DEC Alpha
     *
     * Some more intelligent behaviour should really be done - but I haven't
     * gotten around to it!
     */
    if ((sum_p > 0) && (sum_n > 0)) {
        for (t = 0; t < masksize; t++)
            if (G2[t] < 0)
                G2[t] = G2[t]*sum_p/sum_n;
    }

    /* generate shrinkage correction table */
    make_cor_table(sigma);

    /* smooth data */
    for (t = 0; t < number_pixels-masksize; t++) {
        xG = yG = xG1 = yG1 = xG2 = yG2 = 0;
        for (j = 0; j < masksize; j++) {
            xpoint = x[t+j];
            ypoint = y[t+j];
            xG += (G[j]*xpoint);
            yG += (G[j]*ypoint);
            xG1 += (G1[j]*xpoint);
            yG1 += (G1[j]*ypoint);
            xG2 += (G2[j]*xpoint);
            yG2 += (G2[j]*ypoint);
        }
        dist = sqrt(SQR(xG1)+SQR(yG1));
        point = t + halfmask;
        xsmooth[point] = shrink_correct(sigma,xG,xG2);
        ysmooth[point] = shrink_correct(sigma,yG,yG2);
        curvature[point] = ((xG1*yG2)-(yG1*xG2))/CUBE(dist);
    }

    /* zeros of curvature */
    count = 0;
    negative = positive = FALSE;
    for (t = 1; t < number_pixels-masksize-1; t++) {
       k_now = curvature[t+halfmask];
       zero = FALSE;
       if (k_now > 0) {
          positive = TRUE;
          if (negative) zero = TRUE;
          negative = FALSE;
       }
       if (k_now < 0) {
          negative = TRUE;
          if (positive) zero = TRUE;
          positive = FALSE;
       }
       if (zero)
           count++;
    }

    /* shift smoothed data down so that it corresponds with the original data */
    for (t = 0; t < number_pixels-masksize; t++) {
        xsmooth[t] = xsmooth[t+halfmask];
        ysmooth[t] = ysmooth[t+halfmask];
    }
    number_pixels -= masksize;

    /* return number of zero-crossings of curvature */
    return(count);
}

/* extend data for closed curve */
void wraparound_data(int length)
{
    int s,t;

    /***
    if (length > number_pixels) {
        printf("length bigger than number_pixels!!!!\n");
    }
    ***/

    /* shift up the pixel data */
    for (t = number_pixels-1; t >= 0; t--) {
       x[t+length] = x[t];
       y[t+length] = y[t];
    }

    /* copy data to start of pixel list */
    number_pixels += length;
    for (s = length-1,t = number_pixels-1; t > number_pixels-1-length; s--,t--) {
       x[s] = x[t];
       y[s] = y[t];
    }

    /* copy data to end of pixel list */
    for (t = length; t < length*2; t++) {
       x[number_pixels] = x[t];
       y[number_pixels] = y[t];
       number_pixels++;
    }

/***
    for (t = 0; t < number_pixels;t++)
        printf("%d %d\n",x[t],y[t]);
***/
}

float angle(float x1, float y1, float x2, float y2)
{

    float angle_temp;
    float xx,yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if (xx == 0.0)
        angle_temp = PI/2.0;
    else
        angle_temp = atan(fabs(yy/xx));
    if ((xx < 0.0) && (yy >= 0.0))
       angle_temp = PI - angle_temp;
    else if ((xx < 0.0) && (yy < 0.0))
       angle_temp = PI + angle_temp;
    else if ((xx >= 0.0) && ( yy < 0.0))
       angle_temp = PI*2.0 - angle_temp;
    return(angle_temp);
}

/* the curve extension code is messy - but it works! */
void extend_data(int length, int end)
{
    int t,v;
    double theta;
    int st,fi;
    int nseg,dir;

    if (end == START) {
       st = 0; fi= length;
       dir = FORWARD;
    }
    else {
       st = number_pixels-length-1; fi = number_pixels-1;
       dir = REVERSE;
    }
    /*
    if (end == START)
       cross(x[fi],y[fi],5);
    else
       cross(x[st],y[st],5);
    */
    theta = angle(x[st],y[st],x[fi],y[fi]);
    /* get data into temp arrays */
    nseg = 0;
    if (dir == FORWARD)
       for (t = st;t < fi;t++) {
          x_trans[nseg] = x[t];
          y_trans[nseg] = y[t];
          nseg++;
       }
    else
       for (t = fi-1;t >= st;t--) {
          x_trans[nseg] = x[t];
          y_trans[nseg] = y[t];
          nseg++;
       }
    if (end == START)
       transform1(theta,nseg,x[st],y[st]);
    else
       transform1(theta,nseg,x[fi],y[fi]);

    for (t = 0; t < masksize; t++) {
       x_trans[t] = -x_trans[t];
       y_trans[t] = -y_trans[t];
    }

    if (end == START)
       transform2(theta,nseg,x[st],y[st]);
    else
       transform2(theta,nseg,x[fi],y[fi]);

    if (end == START) {
       for (t = number_pixels-1; t >= 0; t--) {
          x[t+length] = x[t];
          y[t+length] = y[t];
       }
       v = 0;
       for (t = length-1; t >= 0; t--) {
          x[v] = x_trans[t];
          y[v] = y_trans[t];
          v++; number_pixels++;
       }
    }
    else {
       for (t = 0; t < length; t++) {
          x[number_pixels] = x_trans[t];
          y[number_pixels] = y_trans[t];
          number_pixels++;
       }
    }
}

/* transform data curve onto X-axis */
void transform1(float theta, int nseg, float x1, float y1)
{
    int loop1;
    float temp,xt,yt;
    float sine,cosine;

    /* translate */
    for (loop1 = 0;loop1 < nseg;loop1++) {
        x_trans[loop1] -= x1;
        y_trans[loop1] -= y1;
    }
    /* rotate */
    sine = sin(-theta);
    cosine = cos(-theta);
    for (loop1 = 0;loop1 < nseg;loop1++) {
        xt = x_trans[loop1];
        yt = y_trans[loop1];
        temp = xt*cosine - yt*sine;
        x_trans[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans[loop1] = temp;
    }
}

/* transform extended data back from X-axis into the image */
void transform2(float theta, int nseg, float x1, float y1)
{
    int loop1;
    float temp,xt,yt;
    float sine,cosine;

    /* rotate */
    sine = sin(theta);
    cosine = cos(theta);
    for (loop1 = 0;loop1 < nseg;loop1++) {
        xt = x_trans[loop1];
        yt = y_trans[loop1];
        temp = xt*cosine - yt*sine;
        x_trans[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans[loop1] = temp;
    }
    /* translate */
    for (loop1 = 0;loop1 < nseg;loop1++) {
        x_trans[loop1] += x1;
        y_trans[loop1] += y1;
    }
}

/* lms polynomial fit */
void lms_fit(int no_points)
{
    int i;
    float f1,f2;
    float f;
    float m1[4],m2[4];   /* coefficients of fitted polynomials */
    float t[MAX_PIXELS];
 
    for (i = 0; i < no_points; i++)
         t[i] = i;
 
    determine_poly_lms(m1,t,x,no_points);
    determine_poly_lms(m2,t,y,no_points);

    f = 0;
    f1 = m1[1]*SQR(f)+m1[2]*f+m1[3];
    f2 = m2[1]*SQR(f)+m2[2]*f+m2[3];
    for (f = i = 0; f < no_points; f += 1, i++) {
        f1 = m1[1]*SQR(f)+m1[2]*f+m1[3];
        f2 = m2[1]*SQR(f)+m2[2]*f+m2[3];
        xsmooth[i] = f1;
        ysmooth[i] = f2;
        curvature[i] = 2 * (m1[2] * m2[1] - m1[1] * m2[2]) /
            sqrt(CUBE(4 * SQR(f) * (SQR(m1[1]) + SQR(m2[1])) +
                       4 * f * (m1[1] * m1[2] + m2[1] * m2[2]) +
                       SQR(m1[2]) + SQR(m2[2])));
    }
}

/* ===================================================================*/

/* LEAST SQUARE FITTING STUFF */

/* ===================================================================*/

/* LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=3; i.e. a[1..3][1..3], indx[1..3] */
void ludcmp(float a[4][4], int n, int indx[4], float *d)
{
        int i,imax,j,k;
        float big,dum,sum,temp;
        float vv[6];

        *d = 1.0;
        for (i = 1; i <= n; i++) {
                big = 0.0;
                for (j = i; j <= n; j++)
                        if ((temp = fabs(a[i][j])) > big) big = temp;
                if (big == 0.0) error("Singular matrix in routine LUDCMP");
                vv[i] = 1.0/big;
        }
        for (j = 1; j <= n; j++) {
                for (i = 1; i < j; i++) {
                        sum = a[i][j];
                        for (k = 1; k < i; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                }
                big = 0.0;
                for (i = j; i <= n;i++) {
                        sum = a[i][j];
                        for (k = 1; k < j; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                        if ( (dum = vv[i]*fabs(sum)) >= big) {
                                big = dum;
                                imax = i;
                        }
                }
                if (j != imax) {
                        for (k = 1; k <= n; k++) {
                                dum = a[imax][k];
                                a[imax][k] = a[j][k];
                                a[j][k] = dum;
                        }
                        *d = -(*d);
                        vv[imax] = vv[j];
                }
                indx[j] = imax;
                if (a[j][j] == 0.0) a[j][j] = TINY;
                if (j != n) {
                        dum = 1.0/(a[j][j]);
                        for (i = j+1; i <= n ;i++) a[i][j] *= dum;
                }
        }
}

/* forward substitution & backsubstitution */
/* use with LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=3; i.e. a[1..3][1..3], indx[1..3] */
void lubksb(float a[4][4], int n, int indx[4], float b[4])
{
        int i,ii=0,ip,j;
        float sum;

        for (i=1;i<=n;i++) {
                ip = indx[i];
                sum = b[ip];
                b[ip] = b[i];
                if (ii)
                        for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
                else if (sum) ii = i;
                b[i] = sum;
        }
        for (i=n;i>=1;i--) {
                sum = b[i];
                for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
                b[i] = sum/a[i][i];
        }
}
void error(char s[])
{
    printf("ERROR: %s\n",s);
    exit(-1);
}

void determine_poly_lms(float m[4], float datax[], float datay[], int no_points)
{
    int j;
    float sx,sx2,sx3,sx4;
    float sy,sxy,sx2y;
    float x2,x3,x4;
    float m1[4][4];
    float m2[4];
    int indx[4];
    float d;

    sy = sxy = sx2y = sx = sx2 = sx3 = sx4 = 0;
 
    for (j = 0; j < no_points; j++) {
       x2 = datax[j] * datax[j];
       x3 = x2 * datax[j];
       x4 = x2 * x2;
 
       sx += datax[j];
       sx2 += x2;
       sx3 += x3;
       sx4 += x4;

       sy += datay[j];
       sxy += datax[j] * datay[j];
       sx2y += x2 * datay[j];
    }
 
    m1[1][1] = sx4;
    m1[2][1] = sx3;
    m1[3][1] = sx2;
    m1[1][2] = sx3;
    m1[2][2] = sx2;
    m1[3][2] = sx;
    m1[1][3] = sx2;
    m1[2][3] = sx;
    m1[3][3] = no_points;
 
    m2[1] = sx2y;
    m2[2] = sxy;
    m2[3] = sy;
 
    /* solve simultaneous equations */
    ludcmp(m1,3,indx,&d);
    lubksb(m1,3,indx,m2);
 
    m[1] = m2[1];
    m[2] = m2[2];
    m[3] = m2[3];
}

/* ##### ALL CODE BELOW IS TRANSLATED FROM DAVID LOWE'S LISP VERSION ##### */

/*********************************************************************
Produce a table giving shrinkage correction values as a function of
the second derivative convolution. 
The table goes from 1/G2 = sigma to 1/G2 = 50*sigma in intervals of 
0.25*sigma (197 values).  Good results could be achieved with a smaller
table, but play it safe.
*********************************************************************/
void make_cor_table(float sigma)
{
    float curRadius = 50.0;
    float curG,curG2i;
    float prevG,prevG2i;
    float desG2i;
    int i;
    int first=TRUE;

    G_G2inv_pair(sigma*curRadius,&curG,&curG2i);
    for (i=0;i<197;i++) {
        desG2i=sigma*(50-i*0.25);
        /* lower radius until we bracket desired value of G2 */
        while ((first || (curG2i > desG2i)) && (curRadius > 0.25)) {
            first = FALSE;
            prevG = curG;
            prevG2i = curG2i;
            curRadius -= 0.25;
            G_G2inv_pair(sigma*curRadius,&curG,&curG2i);
            /*  if G2i stops shrinking then fill rest of table
                with current value of G */
            if (curG2i>prevG2i) {
                curG2i = 0;
                curG = prevG;
            }
        }
        /* place interpolated shrinkage error in correction table */
        cor_table[196-i] = curG +
            ((desG2i-curG2i)*(prevG-curG))/(prevG2i-curG2i);
    }
}

/*********************************************************************
We compute the amount of shrinkage that occurs for a given value of
the G2 convolution by actually convolving the current masks with a
path-length parameterized circle of the given radius.  While this is
more time-consuming than simply calculating the formulas given in
my paper, it is more accurate because it compensates for the sampling
and truncation errors in the current convolution masks (these errors
can amount to 10% or more for the current mask size of 5*sigma).
Since this is done during precomputation, there is little need to worry
about efficiency.
*********************************************************************/
void G_G2inv_pair(float radius, float *curG, float *curG2i)
{
    float s;    /* current path length parameter value */
    float x;    /* corresponding x coordinate value */
    float g,g2;
    int i;

    g = g2 = 0;
    for (i = 0; i < masksize; i++) {
        s = i - masksize/2;
        x = radius * (1 - cos(s/radius));
        g += (x*G[i]);
        g2 += (x*G2[i]);
    }
    *curG = g;
    *curG2i = 1.0/g2;
}

/*********************************************************************
Correct the Gaussian convolution value g according to the measure of
curvature g2.  Correction is computed using table lookup and linear
interpolation.
Efficiency is very important here, because this is executed for each
point that is smoothed.
*********************************************************************/
float shrink_correct(float sigma, float g, float g2)
{
    float ratio,index,sign,frac;
    int int1;

    if (fabs(g2*sigma) < 0.02) return(g);
    ratio = fabs(1.0/(g2*sigma));
    index = 4*(ratio-1);
    if (index > 195) index = 195;
    if (index < 0) index = 0;
    if (g2>0) sign = 1; else sign = -1;
    int1 = (int)index;
    frac = index - int1;
    return(g-sign*((1-frac)*(cor_table[int1])+(frac*cor_table[1+int1])));
}

void options(char *progname)
{
    fprintf(stderr,"usage: %s -i infile -o outfile [options]\n",progname);
    fprintf(stderr,"  -b  set breakpoint type\n");
    fprintf(stderr,"      %d = MID_POINT (default)\n",MID_POINT);
    fprintf(stderr,"      %d = MAX_DEV\n",MAX_DEV);
    fprintf(stderr,"      %d = BEST_RATIO1\n",BEST_RATIO1);
    fprintf(stderr,"      %d = BEST_RATIO2\n",BEST_RATIO2);
    fprintf(stderr,"      %d = BEST_RATIO3\n",BEST_RATIO3);
    fprintf(stderr,"  -c  output curvature pixel list\n");
    fprintf(stderr,"  -f  output float pixel list\n");
    fprintf(stderr,"  -p  output Postscript file (default)\n");
    fprintf(stderr,"  -s  set smoothing type\n");
    fprintf(stderr,"      %d = GAUSSIAN (default)\n",GAUSSIAN);
    fprintf(stderr,"      %d = POLY\n",POLY);
    exit(-1);
}
