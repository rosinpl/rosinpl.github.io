/*
 *    compute R1 measure of RECTILINEARITY of curve
 *
 *    input:  pixel list
 *    output: pixel list - this is optional; input curve is rotated to maximise rectilinearity
 *
 *    method:
 *        minimise ratio of perimeter of axis aligned bounding rectangle to
 *        L1 perimeter of shape
 *    sensitive to noise, so it's best to simplify the curve first
 *
 *    updated to only use orientations from original polygon edges PLR 2009
 *
 *    Paul Rosin
 *    October 2001
 *
 *    please cite:
 *    J. Zunic and P.L. Rosin, "Rectilinearity measurements for polygons",
 *    IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 25, no. 9, pp. 1193-1200, 2003
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_PIXELS 10000

#define PI 3.1415926

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define OPEN FALSE    // set TRUE of curves are open

#define ABS(x)       (((x)<0.0)? (-(x)): (x))
#define SQR(a)       ((a)*(a))
#define MAX(a,b)     (((a) > (b)) ? (a) : (b))
#define MIN(a,b)     (((a) < (b)) ? (a) : (b))

int no_pixels;
int xdata[MAX_PIXELS],ydata[MAX_PIXELS];
double xrot[MAX_PIXELS],yrot[MAX_PIXELS];
double thetas[MAX_PIXELS];

double rectilinearity();

FILE *fp_in,*fp_out;

main(argc,argv)
int argc;
char *argv[];
{
    char *infile,*outfile,file_type[50];
    int i,j;
    int endoffile;
    double theta,r;
    double max_r,max_t;
    double dx,dy,x1,y1,x2,y2;
    double xc,yc;
    int no_angles;

    infile = outfile = NULL;

    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            switch(argv[i][1]) {
                case 'i':
                    i++;
                    infile = argv[i];
                    break;
                case 'o':
                    i++;
                    outfile = argv[i];
                    break;
                default:
                    fprintf(stderr,"ERROR: unknown option %s\n",argv[i]);
                    usage(argv[0]);
                    exit(-1);
            }
        }
        else {
            fprintf(stderr,"ERROR: unknown option %s\n",argv[i]);
            usage(argv[0]);
            exit(-1);
        }
    }

    if (infile == NULL) {
        fprintf(stderr,"need input & output files\n");
        usage(argv[0]);
        exit(-1);
    }

    if ((fp_in=fopen(infile,"r")) == NULL) {
        printf("cant open %s\n",infile);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp_in,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0) {
        printf("not link data file - aborting\n");
        exit(-1);
    }

    if (outfile != NULL) {
        if ((fp_out=fopen(outfile,"w")) == NULL) {
            printf("cant open %s\n",outfile);
            exit(-1);
        }
        fprintf(fp_out,"pixel\n");
    }

    do {
        read_link_data(fp_in,&endoffile);
        if ((xdata[0] == xdata[no_pixels-1]) && (ydata[0] == ydata[no_pixels-1]))
            no_pixels--;


        /* go through original polygon edges storing angles */
        no_angles = 0;
        for (i = 0; i < no_pixels; i++) {
            x1 = xdata[i];
            y1 = ydata[i];
            x2 = xdata[(i+1)%no_pixels];
            y2 = ydata[(i+1)%no_pixels];
            dx = x2 - x1; dy = y2 - y1;
            thetas[no_angles++] = atan2(dy,dx);
        }

        max_r = -9e9;
        max_t = -9e9;
        for (i = 0; i < no_angles; i++) {
            theta = thetas[i];

			if (theta < 0) theta += PI;
			if (theta < 0) theta += PI;
			if (theta > PI) theta -= PI;
			if (theta > PI) theta -= PI;

            transform(0.0,0.0,theta);

            r = rectilinearity();
            if (r > max_r) {
                max_r = r;
                max_t = theta;
            }
        }
        //printf("maximum rectilinearity value at = %.1f degrees\n",max_t,max_t*180.0/PI);

        r = max_r;

        if (outfile != NULL) {
            xc = yc = 0;
            for (i = 0; i < no_pixels; i++) {
                xc += xdata[i];
                yc += ydata[i];
            }
            xc /= no_pixels;
            yc /= no_pixels;

            transform(-xc,-yc,max_t);
            output_pixels();
        }

        printf("rectilinearity = %f\n",r);

    } while (!endoffile);

    fclose(fp_in);
    if (outfile != NULL)
        fclose(fp_out);
}

output_pixels()
{
    int i;

    fprintf(fp_out,"list: 0\n");
    for (i = 0; i < no_pixels; i++)
        fprintf(fp_out,"%.0f %.0f\n",xrot[i],yrot[i]);
    fprintf(fp_out,"-1 0\n");
}

double rectilinearity()
{
    int i;
    double dx,dy,px,py;
    double sum_projections;
    double true_perimeter;
    double r;

    true_perimeter = px = py = 0;

    xrot[no_pixels] = xrot[0];
    yrot[no_pixels] = yrot[0];
#if OPEN
    for (i = 0; i < no_pixels-1; i++) {
#else
    for (i = 0; i < no_pixels; i++) {
#endif
        dx = xrot[i+1] - xrot[i];
        dy = yrot[i+1] - yrot[i];
        px += ABS(dx);
        py += ABS(dy);

        true_perimeter += sqrt( (double)(dx*dx + dy*dy) );
    }

    sum_projections = px + py;

    /*
    printf("SP %f   TP %f\n",sum_projections,true_perimeter);
    */

    r = (double)true_perimeter / (double)sum_projections;
    r = 4.0 / (4.0 - PI) * (r - PI / 4.0);

    return r;
}

// modified version that shifts back
transform(xshift,yshift,theta)
double xshift,yshift,theta;
{
    int i;
    float temp,xt,yt;
    float sine,cosine;

    /* translate */
    for (i = 0; i < no_pixels; i++) {
        xrot[i] = xdata[i] + xshift;
        yrot[i] = ydata[i] + yshift;
    }

    /* rotate */
    if (theta != 0) {
        sine = sin(-theta);
        cosine = cos(-theta);
        for (i = 0; i < no_pixels; i++) {
            xt = xrot[i];
            yt = yrot[i];
            temp = xt*cosine - yt*sine;
            xrot[i] = temp;
            temp = xt*sine + yt*cosine;
            yrot[i] = temp;
        }
    }

    /* translate back */
    for (i = 0; i < no_pixels; i++) {
        xrot[i] -= xshift;
        yrot[i] -= yshift;
    }
}

read_link_data(fp,endoffile)
FILE *fp;
int *endoffile;
{
    char dumstring[50];
    int j;

    fscanf(fp,"%s %d\n",dumstring,&j);
    j = -1;
    do{
       j++;
       fscanf(fp,"%d %d\n",&xdata[j],&ydata[j]);
    } while(xdata[j] != -1);
    *endoffile = (ydata[j] == -1);
    if (feof(fp) && !(*endoffile)) {
        fprintf(stderr,"Incorrectly terminated file - assuming end of list\n");
        *endoffile = TRUE;
    }
    no_pixels = j;
}

usage(progname)
char *progname;
{
    printf("usage: %s -i infile\n",progname);
    printf("options:\n");
    printf("         -o  file  output normalised curve\n");
    exit(-1);
}
