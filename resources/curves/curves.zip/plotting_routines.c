/*
    plotting_routines

        a Geoff West/Paul Rosin production
        all rights reserved

        various routines for plotting higher level graphics features
        e.g. Arcs,ellipses,crosses,etc.

        debugged for correct drawing of valid curves and full parts
        for ellipses and superellipses GAWW May 1993

        October 1992
*/

#include <stdio.h>
#include <math.h>
#include "plotstuff.h"
#include "plotlib.h"
#include "palette.h"
#include "angle.h"

#define CLOCKWISE 1
#define ANTICLOCKWISE 2

#define PI 3.141591
#define RAD_DEG (180.0/PI)

#define MIN(a,b)  ((a)<(b)?(a):(b))
#define ABS(x)    (((x)<0.0)? (-(x)): (x))

float first_root();

extern float gray_val;           /* used for Postscript */
extern int ps_dump;              /* is Postscript output required? */
extern int ps_raw;               /* scale/translate Postscript? */
extern FILE *fp_ps;              /* file to dump Postscript to */
extern int already_done_ps;       /* switch to temporarily turn of PS */

extern int width,height;

cross(xs,ys,c_w,colour)
float xs,ys;
int c_w;
char colour[50];
{
    float x,y;
    char old_colour[50];

    if (ps_dump) fprintf(fp_ps,"%%cross\n");
    strcpy(old_colour,current_colour);
    set_colour(colour);

    x = xs - c_w;
    y = ys - c_w;
    move(x,y);
    x = xs + c_w;
    y = ys + c_w;
    draw(0,x,y);
    x = xs + c_w;
    y = ys - c_w;
    move(x,y);
    x = xs - c_w;
    y = ys + c_w;
    draw(0,x,y);
    x = xs;
    y = ys;
    move(x,y);

    set_colour(old_colour);
}

plus(xs,ys,c_w,colour)
float xs,ys;
int c_w;
char colour[50];
{
    float x,y;
    char old_colour[50];

    strcpy(old_colour,current_colour);
    set_colour(colour);

    x = xs;
    y = ys - c_w;
    move(x,y);
    x = xs;
    y = ys + c_w;
    draw(0,x,y);
    x = xs + c_w;
    y = ys;
    move(x,y);
    x = xs - c_w;
    y = ys;
    draw(0,x,y);
    x = xs;
    y = ys;
    move(x,y);

    set_colour(old_colour);
}

box(xs,ys,b_w,colour)
float xs,ys;
int b_w;
char colour[50];
{
    float x,y;
    char old_colour[50];

    if (ps_dump) fprintf(fp_ps,"%%box\n");
    strcpy(old_colour,current_colour);
    set_colour(colour);

    x = xs - b_w;
    y = ys - b_w;
    move(x,y);
    x = xs + b_w;
    y = ys - b_w;
    draw(0,x,y);
    x = xs + b_w;
    y = ys + b_w;
    draw(0,x,y);
    x = xs - b_w;
    y = ys + b_w;
    draw(0,x,y);
    x = xs - b_w;
    y = ys - b_w;
    draw(0,x,y);

    x = xs;
    y = ys;
    move(x,y);

    set_colour(old_colour);
}

dtriangle(xs,ys,b_w,colour)
float xs,ys;
int b_w;
char colour[50];
{
    float x,y;
    char old_colour[50];

    strcpy(old_colour,current_colour);
    set_colour(colour);

    x = xs - b_w;
    y = ys - b_w;
    move(x,y);
    x = xs + b_w;
    y = ys - b_w;
    draw(0,x,y);
    x = xs;
    y = ys + b_w;
    draw(0,x,y);
    x = xs - b_w;
    y = ys - b_w;
    draw(0,x,y);

    x = xs;
    y = ys;
    move(x,y);

    set_colour(old_colour);
}

utriangle(xs,ys,b_w,colour)
float xs,ys;
int b_w;
char colour[50];
{
    float x,y;
    char old_colour[50];

    strcpy(old_colour,current_colour);
    set_colour(colour);

    x = xs;
    y = ys - b_w;
    move(x,y);
    x = xs + b_w;
    y = ys + b_w;
    draw(0,x,y);
    x = xs - b_w;
    y = ys + b_w;
    draw(0,x,y);
    x = xs;
    y = ys - b_w;
    draw(0,x,y);

    x = xs;
    y = ys;
    move(x,y);

    set_colour(old_colour);
}

diamond(xs,ys,b_w,colour)
float xs,ys;
int b_w;
char colour[50];
{
    float x,y;
    char old_colour[50];

    strcpy(old_colour,current_colour);
    set_colour(colour);

    x = xs;
    y = ys - b_w;
    move(x,y);
    x = xs + b_w;
    y = ys;
    draw(0,x,y);
    x = xs;
    y = ys + b_w;
    draw(0,x,y);
    x = xs - b_w;
    y = ys;
    draw(0,x,y);
    x = xs;
    y = ys - b_w;
    draw(0,x,y);

    x = xs;
    y = ys;
    move(x,y);

    set_colour(old_colour);
}

point(xs,ys)
float xs,ys;
{
    char old_colour[50];
    float x,y;

    strcpy(old_colour,current_colour);
    set_colour("black");

    x = xs;
    y = ys;
    move(x,y);
    draw(0,x,y);

    set_colour(old_colour);
}

plot_circle(xc,yc,r,ang1,ang2,iang1,iang2,style)
float xc,yc,r,ang1,ang2,iang1,iang2;
int style;
{
    int i;
    float tx,ty;
    float angle,a1,a2;
    float incr;
    float x,y;
    char r_str[100];

    if (ps_dump) {

        /* to account for inversion of Y co-ordinates... */
        a1 = iang1*180/PI;
        a2 = iang2*180/PI;

        /* ...OR... */

        /* ...I'm not sure if that above always works!!! */
		/*
        a1 = ang1*180/PI;
        a2 = ang2*180/PI;
		*/

        fprintf(fp_ps,"stroke\n");

        if (r == LITTLE_CIRCLE) {
            strcpy(r_str,"Lcirc");
            r = -r;
        }
        else if (r == MEDIUM_CIRCLE) {
            strcpy(r_str,"Mcirc");
            r = -r;
        }
        else
            sprintf(r_str,"%.2f",r);

        if (ps_raw)
            fprintf(fp_ps,"newpath %.2f %.2f %s %.2f %.2f arc stroke\n",
                xc,yc,r_str,a1,a2);
        else
            fprintf(fp_ps,"newpath %.2f %.2f %s %.2f %.2f arc stroke\n",
                xc,height-yc,r_str,a1,a2);
        already_done_ps = TRUE;
    }

    incr = 2 * PI / 500.0;

    tx = r * cos(ang1);
    ty = r * sin(ang1);
    x = xc + tx;
    y = yc + ty;
    move(x,y);
    if (style == 2) gray_val = 0.7;

    /*
    for (angle = ang1; angle < ang2+incr; angle += incr) {
    */
    for (angle = ang1; angle < ang2; angle += incr) {
        tx = r * cos(angle);
        ty = r * sin(angle);
        x = xc + tx;
        y = yc + ty;
        if (style == 0)
            draw(0,x,y);
        else if (style == 1)
            draw(1,x,y);
        else if (style == 2)
            draw(0,x,y);
    }
    angle = ang2;
    tx = r * cos(angle);
    ty = r * sin(angle);
    x = xc + tx;
    y = yc + ty;
    if (style == 0)
        draw(0,x,y);
    else if (style == 1)
        draw(1,x,y);
    else if (style == 2)
        draw(0,x,y);
    if (style == 2) gray_val = 0;

    /* reset position to original coordinates */
    x = xc;
    y = yc;
    move(x,y);

    already_done_ps = FALSE;
}

/*
   plots ellipse using all parameters by generating ellipse around
   origin and transforming it to image space
   parameters: xs,ys to xf,yf - start to finish coords
                xc,yc - centre of ellipse
                major_axis,minor_axis - of the ellipse
                rot_angle - rotation of major axis clockwise about
                origin starting at +ve x axis
   if full is set then plots remainder of ellipse dotted
*/
plot_ellipse(xs,ys,xf,yf,xc,yc,major_axis,minor_axis,rot_angle,arc_dir,bold,full)
float xs,ys,xf,yf,xc,yc;
float major_axis,minor_axis,rot_angle;
int arc_dir,bold,full;
{
    double x1,y1,x2,y2;
    double sine,cosine,sine2,cosine2;
    double temp;
    float step,temp_angle;
    float xold,yold,xe,ye;
    float st_ang,fi_ang;
    char old_colour[50];
    int width;

    if (bold)
        width = 3;
    else
        width = 1;

    if (ps_dump) {

        fprintf(fp_ps,"stroke\n");

        if (ps_raw)
            fprintf(fp_ps,"%.2f %.2f %.2f %.2f %.2f %.2f %d %.2f DrawEllipse\n",
                xc,yc,major_axis,minor_axis,0.0,360.0,width,rot_angle*RAD_DEG);
        else
            fprintf(fp_ps,"%.2f %.2f %.2f %.2f %.2f %.2f %d %.2f DrawEllipse\n",
                xc,height-yc,major_axis,minor_axis,0.0,360.0,width,rot_angle*RAD_DEG);

        already_done_ps = TRUE;
    }

    /* determine start and finish angles wrt to centre at the origin */
    /* first transform start and finish to origin offset */
    x1 = xs - xc;
    y1 = ys - yc;
    x2 = xf - xc;
    y2 = yf - yc;
    /* rotate */
    sine = sin(-rot_angle);
    cosine = cos(-rot_angle);
    temp = x1 * cosine - y1 * sine;
    y1 = x1 * sine + y1 * cosine;
    x1 = temp;
    temp = x2 * cosine - y2 * sine;
    y2 = x2 * sine + y2 * cosine;
    x2 = temp;
    st_ang = angle(0.0,0.0,x1/major_axis,y1/minor_axis);
    fi_ang = angle(0.0,0.0,x2/major_axis,y2/minor_axis);
    if(arc_dir == CLOCKWISE) {
        temp = st_ang;
        st_ang = fi_ang;
        fi_ang = temp;
    }
    /* fi_ang must be bigger than st_ang */
    if(fi_ang <= st_ang) {
        fi_ang += PI * 2.0;
    }

    /* generate transform from origin centred ellipse to image space */
    cosine2 = cos(rot_angle);
    sine2 = sin(rot_angle);

    /* moveto first point on ellipse in image */
    xe = major_axis * cos(st_ang);
    ye = minor_axis * sin(st_ang);
    temp = xe * cosine2 - ye * sine2;
    ye = xe * sine2 + ye * cosine2;
    xe = temp;
    xe = xe + xc;
    ye = ye + yc;
    move(xe,ye);

    /* successively plot lines around ellipse */
    if (major_axis < 100.0) {
        step = (fi_ang - st_ang) / major_axis;
        step = MIN(step,0.1);
    }
    else
        step = (fi_ang - st_ang) / 100.0;
    temp_angle = st_ang;
    for (temp_angle=st_ang;temp_angle<=fi_ang;temp_angle += step) {
        xe = major_axis * cos(temp_angle);
        ye = minor_axis * sin(temp_angle);
        temp = xe * cosine2 - ye * sine2;
        ye = xe * sine2 + ye * cosine2;
        xe = temp;
        xe = xe + xc;
        ye = ye + yc;
        if (bold == 0)
            draw(0,xe,ye);
        else
            draw(1,xe,ye);
    }
    xe = major_axis * cos(fi_ang);
    ye = minor_axis * sin(fi_ang);
    temp = xe * cosine2 - ye * sine2;
    ye = xe * sine2 + ye * cosine2;
    xe = temp;
    xe = xe + xc;
    ye = ye + yc;
    if (bold == 0)
        draw(0,xe,ye);
    else
        draw(1,xe,ye);
    if (full) {
        strcpy(old_colour,current_colour);
        set_colour("purple");
        st_ang += 2.0 * PI;
        xold = 0.0;
        yold = 0.0;
        for (temp_angle=fi_ang;temp_angle<=st_ang;temp_angle += step) {
            xe = major_axis * cos(temp_angle);
            ye = minor_axis * sin(temp_angle);
            temp = xe * cosine2 - ye * sine2;
            ye = xe * sine2 + ye * cosine2;
            xe = temp;
            xe = xe + xc;
            ye = ye + yc;
            draw(0,xe,ye);
        }
        xe = major_axis * cos(st_ang);
        ye = minor_axis * sin(st_ang);
        temp = xe * cosine2 - ye * sine2;
        ye = xe * sine2 + ye * cosine2;
        xe = temp;
        xe = xe + xc;
        ye = ye + yc;
        if (bold == 0)
               draw(0,xe,ye);
            else
            draw(1,xe,ye);
        set_colour(old_colour);
    }
}
oldplot_ellipse(xs,ys,xf,yf,xc,yc,major_axis,minor_axis,rot_angle,arc_dir,bold,full)
float xs,ys,xf,yf,xc,yc;
float major_axis,minor_axis,rot_angle;
int arc_dir,bold,full;
{
    double x1,y1,x2,y2;
    double sine,cosine,sine2,cosine2;
    double temp;
    float step,temp_angle;
    float xold,yold,xe,ye;
    float st_ang,fi_ang;
    char old_colour[50];

    /* determine start and finish angles wrt to centre at the origin */
    /* first transform start and finish to origin offset */
    x1 = xs - xc;
    y1 = ys - yc;
    x2 = xf - xc;
    y2 = yf - yc;
    /* rotate */
    sine = sin(-rot_angle);
    cosine = cos(-rot_angle);
    temp = x1 * cosine - y1 * sine;
    y1 = x1 * sine + y1 * cosine;
    x1 = temp;
    temp = x2 * cosine - y2 * sine;
    y2 = x2 * sine + y2 * cosine;
    x2 = temp;
    st_ang = angle(0.0,0.0,x1/major_axis,y1/minor_axis);
    fi_ang = angle(0.0,0.0,x2/major_axis,y2/minor_axis);
    if(arc_dir == CLOCKWISE) {
        temp = st_ang;
        st_ang = fi_ang;
        fi_ang = temp;
    }
    /* fi_ang must be bigger than st_ang */
    if(fi_ang <= st_ang) {
        fi_ang += PI * 2.0;
    }

    /* generate transform from origin centred ellipse to image space */
    cosine2 = cos(rot_angle);
    sine2 = sin(rot_angle);

    /* moveto first point on ellipse in image */
    xe = major_axis * cos(st_ang);
    ye = minor_axis * sin(st_ang);
    temp = xe * cosine2 - ye * sine2;
    ye = xe * sine2 + ye * cosine2;
    xe = temp;
    xe = xe + xc;
    ye = ye + yc;
    move(xe,ye);

    /* successively plot lines around ellipse */
    if (major_axis < 100.0) {
        step = (fi_ang - st_ang) / major_axis;
        step = MIN(step,0.1);
    }
    else
        step = (fi_ang - st_ang) / 100.0;
    temp_angle = st_ang;
    for (temp_angle=st_ang;temp_angle<=fi_ang;temp_angle += step) {
        xe = major_axis * cos(temp_angle);
        ye = minor_axis * sin(temp_angle);
        temp = xe * cosine2 - ye * sine2;
        ye = xe * sine2 + ye * cosine2;
        xe = temp;
        xe = xe + xc;
        ye = ye + yc;
        if (bold == 0)
            draw(0,xe,ye);
        else
            draw(1,xe,ye);
    }
    xe = major_axis * cos(fi_ang);
    ye = minor_axis * sin(fi_ang);
    temp = xe * cosine2 - ye * sine2;
    ye = xe * sine2 + ye * cosine2;
    xe = temp;
    xe = xe + xc;
    ye = ye + yc;
    if (bold == 0)
        draw(0,xe,ye);
    else
        draw(1,xe,ye);
    if (full) {
        strcpy(old_colour,current_colour);
        set_colour("purple");
        st_ang += 2.0 * PI;
        xold = 0.0;
        yold = 0.0;
        for (temp_angle=fi_ang;temp_angle<=st_ang;temp_angle += step) {
            xe = major_axis * cos(temp_angle);
            ye = minor_axis * sin(temp_angle);
            temp = xe * cosine2 - ye * sine2;
            ye = xe * sine2 + ye * cosine2;
            xe = temp;
            xe = xe + xc;
            ye = ye + yc;
            draw(0,xe,ye);
        }
        xe = major_axis * cos(st_ang);
        ye = minor_axis * sin(st_ang);
        temp = xe * cosine2 - ye * sine2;
        ye = xe * sine2 + ye * cosine2;
        xe = temp;
        xe = xe + xc;
        ye = ye + yc;
        if (bold == 0)
               draw(0,xe,ye);
            else
            draw(1,xe,ye);
        set_colour(old_colour);
    }
}


/*
   plots superellipse using all parameters by generating superellipse
   around origin and transforming it to image space
   parameters: xs,ys to xf,yf - start to finish coords
               xc,yc - centre
               a,b - axes lengths
               e - squareness
               rot_angle - rotation of major axis clockwise about
                           origin starting at +ve X axis
   if full is set then plots remainder of superellipse dotted
*/
plot_superellipse(xs,ys,xf,yf,xc,yc,a,b,e,rot,arc_dir,bold,full)
float xs,ys,xf,yf,xc,yc;
float a,b,e,rot;
int arc_dir,bold,full;
{
    double sine,cosine;
    double sine2,cosine2;
    double temp,step,temp_angle;
    double xe,ye;
    double tx,ty;
    double x1,y1,x2,y2;
    double st_ang,fi_ang;
    double t;
    char old_colour[50];

    /* I've lost track of when already_done_ps is used - it seems to turn off
     * Postscript stuff
     */
    already_done_ps = FALSE;

    /* determine start and finish angles wrt to centre at the origin */
    /* first transform start and finish to origin offset */
    x1 = xs - xc;
    y1 = ys - yc;
    x2 = xf - xc;
    y2 = yf - yc;
    /* rotate */
    sine = sin(-rot);
    cosine = cos(-rot);
    temp = x1 * cosine - y1 * sine;
    y1 = x1 * sine + y1 * cosine;
    x1 = temp;
    temp = x2 * cosine - y2 * sine;
    y2 = x2 * sine + y2 * cosine;
    x2 = temp;
    st_ang = angle(0.0,0.0,first_root(x1/a,1/e),first_root(y1/b,1/e));
    fi_ang = angle(0.0,0.0,first_root(x2/a,1/e),first_root(y2/b,1/e));
    if(arc_dir == CLOCKWISE) {
        temp = st_ang;
        st_ang = fi_ang;
        fi_ang = temp;
    }
    /* fi_ang must be bigger than st_ang */
    if (fi_ang <= st_ang) {
        fi_ang += PI * 2.0;
    }

    cosine2 = cos(rot);
    sine2 = sin(rot);

    /* move to first point on superellipse in image */
    xe = a * first_root(cos(st_ang),e);
    ye = b * first_root(sin(st_ang),e);
    /* rotate */
    tx = xe * cosine2 - ye * sine2;
    ty = xe * sine2 + ye * cosine2;
    /* shift */
    xe = tx + xc;
    ye = ty + yc;

    move(xe,ye);

    /* successively plot lines around superellipse */
    step = 2 * PI / 100;

    /***
    step /= 10;
    ***/

    if ((a > 1000) || (b > 1000))
        step /= 10;
    if ((a > 10000) || (b > 10000))
        step /= 10;
    /***
    ***/

    for (temp_angle = st_ang; temp_angle <= fi_ang; temp_angle += step) {
        xe = a * first_root(cos(temp_angle),e);
        ye = b * first_root(sin(temp_angle),e);
        /* rotate */
        tx = xe * cosine2 - ye * sine2;
        ty = xe * sine2 + ye * cosine2;
        /* shift */
        xe = tx + xc;
        ye = ty + yc;

        /* chop of narrow tails of astroids */
        if (e > 10) {
            /*
            if (ABS(tx) > pow(a,2*1/e) * 50) continue;
            if (ABS(ty) > pow(b,2*1/e) * 50) continue;
            */
            if (ABS(tx) > 90) continue;
            if (ABS(ty) > 90) continue;
        }

        if (ABS(xe) > width) continue;
        if (ABS(ye) > height) continue;

        if (bold == 0)
            draw(0,xe,ye);
        else
            draw(1,xe,ye);
    }

    /* draw to last point on superellipse in image */
    xe = a * first_root(cos(fi_ang),e);
    ye = b * first_root(sin(fi_ang),e);
    /* rotate */
    tx = xe * cosine2 - ye * sine2;
    ty = xe * sine2 + ye * cosine2;
    /* shift */
    xe = tx + xc;
    ye = ty + yc;
    if (bold == 0)
        draw(0,xe,ye);
    else
        draw(1,xe,ye);


    if (full) {
        gray_val = 0.7;
        strcpy(old_colour,current_colour);
        set_colour("purple");
        st_ang += 2.0 * PI;
        /* hack added - PLR December 1998 */
        if (st_ang == fi_ang)
            st_ang += 2.0 * PI;
        for (temp_angle = fi_ang; temp_angle <= st_ang; temp_angle += step) {
            xe = a * first_root(cos(temp_angle),e);
            ye = b * first_root(sin(temp_angle),e);
            /* rotate */
            tx = xe * cosine2 - ye * sine2;
            ty = xe * sine2 + ye * cosine2;
            /* shift */
            xe = tx + xc;
            ye = ty + yc;

            if (bold == 0)
                draw(0,xe,ye);
            else
                draw(1,xe,ye);
        }
        /* draw to start point */
        xe = a * first_root(cos(st_ang),e);
        ye = b * first_root(sin(st_ang),e);
        /* rotate */
        tx = xe * cosine2 - ye * sine2;
        ty = xe * sine2 + ye * cosine2;
        /* shift */
        xe = tx + xc;
        ye = ty + yc;
           if (bold == 0)
            draw(0,xe,ye);
        else
            draw(1,xe,ye);
        set_colour(old_colour);
    }
    gray_val = 0;
}


plot_line(xs,ys,xf,yf)
float xs,ys,xf,yf;
{
    set_colour("green");
    move(xs,ys);
    draw(0,xf,yf);
}

float first_root(t,e)
float t,e;
/* get first root of the value t for the power e */
{
    if (t > 0)
        return pow(t,e);
    else if (t < 0)
        return -pow(-t,e);
    else
        return 0.0;
}
