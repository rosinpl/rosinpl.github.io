/*
    ellipses.c

    A  P.L. Rosin / G.A.W.West production. Copyright 1990.

    Modified version of arcs.c to fit ellipses to pixel data
    uses determine_ellipse_fit routine found in ellnlms.c
    This replaces the determine_circle routine.

    June 1990 - analytic version of determine_parameters
              - better version of arc_dir determination
              - deals with straight lines
              - corrected the kalman loop to prevent hyperbolae
              - determ3.c is now included in this file
              - hack to make correct ambiguity of determine_parameters
              - corrected arc direction determination

    Input: pixel data format.
    Output: super data format (only arcs).
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define NO_LINE_SEGS 2048 /* max number of lines per list */
#define NO_ARCS 200       /* max number of arcs per list  */
#define LINE 1
#define ARC 2
#define IGNORE 3
#define PI 3.141591
#define SMALL 1           /* type of arc */
#define BIG 2
#define CLOCKWISE 1       /* direction of arc from start to finish */
#define ANTICLOCKWISE 2

#define GRAPHICS 0        /* compile graphics routines if 1 */
#define DEBUG 0           /* compile debug output if 1 */
#define STOP_EARLY 0      /* just fit to all data in a list and stop if 1 */
                          /* normal recursive algorithm if = 0 */
#define NO_PIXELS 2048
#define NO_ARCS 200       /* max number of arcs per list  */

#define PI 3.141591
#define NINETY 1.570796327
#define KEEP 0    /* KEEP and REJECT used to tell if arcs to be kept */
#define REJECT 1
#define LARGE_SIG 99999
#define MIN_LENGTH 5
#define FALSE 0
#define TRUE !FALSE

#define TINY 1.0e-20
#define BIG_NUM 1.0e4

#define N 4
#define E 2.718282
#define DELTA_X 1.5
#define DELTA_Y 1.5

#define SIZE 512

#define ELLIPSE 0
#define PARABOLA 1
#define HYPERBOLA 2

#define CV_DIFF 10

#define sqr(x) ((x) * (x))

/* temp array for manipulatable data from x_c,y_c */
float x_trans3[NO_LINE_SEGS],y_trans3[NO_LINE_SEGS];

/* ellipse parameterisation arrays */
int arc_centre_x[NO_ARCS],arc_centre_y[NO_ARCS];
int arc_start_x[NO_ARCS],arc_start_y[NO_ARCS];
int arc_end_x[NO_ARCS],arc_end_y[NO_ARCS];
float maj_axis[NO_ARCS],min_axis[NO_ARCS];
float rot_ang[NO_ARCS];
int arc_dirs[NO_ARCS];
float arc_sig[NO_ARCS];
int next[NO_LINE_SEGS];
int start[NO_LINE_SEGS];

int number_arcs;
int nseg2;   /* number of points in x_trans3, y_trans3 */

short arc_status[NO_ARCS];
short x_c[NO_PIXELS],y_c[NO_PIXELS];
short arc_start[NO_ARCS],arc_finish[NO_ARCS];

int number_pixels;

int start_data,finish_data;

int global_pos;
int representation_ok;

FILE *fp, *fp_out;

char filename[30];
float covariance = BIG_NUM;
int conic_type;
float max_cv,min_cv,mid_cv;
float result[6];

void segment(int start_in,int finish_in,float *sig_out);
void read_list(int *number_pixels, int *end_of_file, int *list_no);
float angle(float x1, float y1, float x2, float y2);
float euclid(float x1, float y1, float x2, float y2);
void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2);
void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir);
void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir);
void compute_poly_lgt(float *lgt);
void determine_ellipse_fit(int st, int fi, float *final_major_axis, float * final_minor_axis, float * final_rot_angle, int *final_xc, int *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig);
float distance(double x1, double y1, double x2, double y2);
//int round(float value);
int curve_type(char array[50]);
int find_conic_type(double c1, double c2, double c3);
void error(char s[]);
void ludcmp(float a[6][6], int n, int indx[6], float *d);
int kron(int i, int j);
void transp(float a[6][6], float b[6][6], int n, int p);
void w_sum(float a[6][6], float b[6][6], float c[6][6], int n, int p, double w1, double w2);
void mult(float a[6][6], float b[6][6], float c[6][6], int m, int n, int p);
void multvect(float a[6][6], float b[6], float c[6], int m, int n);
void kalman(float y[6], float m[6][6], float w[6][6], float a[6], float s[6][6], int n, int p);
void run_kalman(double c1, double c2, double c3, double c4, double c5);
void determine_ellipse_kalman(float m[]);
void determine_parameters(float m[], float *major_axis, float *minor_axis, float *rot_angle);
void compute_circle(float *x_cent, float *y_cent, float *radius2, int nseg2);

main(argc,argv)
int argc;
char *argv[];
{
    int j;
    float sig;    /* not really used - just dummy param for segment */
    int list_no,end_of_file;
    float temp;
    char file_type[50];
    char *file_name_in;
    char *file_name_out;
    int set_input_file = FALSE;
    int set_output_file = FALSE;
    char *ch;

    if(argc == 1) {
        printf("Usage: %s -i file -o file\n",argv[0]);
        exit(1);
    }

    while (--argc > 0 && (*++argv)[0] == '-') {
        for(ch = argv[0] + 1; *ch != '\0'; ch++) {
            switch (*ch) {
                case 'i':
                    set_input_file = TRUE;
                    argc--; argv++;
                    file_name_in = argv[0];
                    break;
                case 'o':
                    set_output_file = TRUE;
                    argc--; argv++;
                    file_name_out = argv[0];
                    break;
                default:
                    printf("illegal option %c\n",*ch);
                    argc = 0;
                    exit(1);
                    break;
            }
        }
    }

    if(set_input_file == FALSE) {
        printf("no input file specified - aborting\n");
        exit(1);
    }
    if(set_output_file == FALSE) {
        printf("no output file specified - aborting\n");
        exit(1);
    }
    if((fp = fopen(file_name_in,"r")) == NULL) {
        printf("cant open %s\n",file_name_in);
        exit(1);
    }
    /* read magic word for format of file */
    fscanf(fp,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if(j != 0) {
        printf("not pixel data file - aborting\n");
        exit(1);
    }

    if((fp_out = fopen(file_name_out,"w")) == NULL) {
        printf("cant open %s\n",file_name_out);
        exit(1);
    }
    /* write magic word for format of file */
    fprintf(fp_out,"super\n");

#if GRAPHICS
    init_graph();
#endif

    do{
        read_list(&number_pixels,&end_of_file,&list_no);

        number_arcs = 0;
        segment(1,number_pixels,&sig);

        /* super data output format */
        fprintf(fp_out,"list: %d\n",list_no);
        for(j = 1;j <= number_arcs;j++)
                   if (arc_status[j] == KEEP) {
                      if (arc_sig[j] < (LARGE_SIG - 1)) {
                         /* !! HACK !! */
                         if (maj_axis[j] < min_axis[j]) {
                            temp = maj_axis[j];
                            maj_axis[j] = min_axis[j];
                            min_axis[j] = temp;
                            rot_ang[j] += PI/2;
                         }
                         fprintf(fp_out,"ellipse: %f %d %d %d %d %d %d %f %f %f %d\n",
                   arc_sig[j],
                   arc_centre_x[j],arc_centre_y[j],
                   arc_start_x[j],arc_start_y[j],
                   arc_end_x[j],arc_end_y[j],
                   maj_axis[j],min_axis[j],rot_ang[j],
                                   arc_dirs[j]);
                      }
                      else
                         fprintf(fp_out,"line: 0.0 %d %d %d %d\n",
                   arc_start_x[j],arc_start_y[j],
                   arc_end_x[j],arc_end_y[j]);
                   }
        fprintf(fp_out,"endl:\n");
        if(end_of_file == 1)
            fprintf(fp_out,"endf:\n");
    }while(end_of_file == 0);
}

void read_list(int *number_pixels, int *end_of_file, int *list_no)
{
    char dumstring[50];
    int j;
    int tx,ty;

    fscanf(fp,"%s %d\n",dumstring,list_no);
    printf("list: %d ",*list_no);
    j = 0;
    do{
        j++;
        fscanf(fp,"%d %d\n",&tx,&ty);
        x_c[j] = tx;
        y_c[j] = ty;
    }while(x_c[j] != -1);
    if(y_c[j] == -1)
       *end_of_file = 1;
    else
       *end_of_file = 0;
    j--;

    /* avoid duplicated endpoints for closed curves */
    if ((x_c[1] == x_c[j]) && (y_c[1] == y_c[j])) {
        printf("removing duplicating end pixel\n");
        --j;
    }

    *number_pixels = j;
    printf("pixels: %d\n",*number_pixels);
}

void segment(int start_in,int finish_in,float *sig_out)
{
    int i;
    int pos;
    float max_dev;
    float sig1,sig2,sig3,max_sig;
    int centre_x, centre_y;
    int arc_length,arc_dir;
    float major_axis,minor_axis,rot_angle;

    /* compute significance at this level */

    determine_ellipse_fit(start_in,finish_in,&major_axis,&minor_axis,
                &rot_angle,&centre_x,&centre_y,
                &max_dev,&arc_length,&arc_dir,&sig1);
    if (representation_ok == FALSE)
       sig1 = LARGE_SIG;
#if DEBUG
    printf("best fit ellipse: maj %f min %f rot %f ctr %d %d dev %f lgt %d size %d\n",
           major_axis,minor_axis,rot_angle,centre_x,centre_y,max_dev,arc_length,arc_dir);
#endif
    pos = global_pos + start_in - 1;

    number_arcs++;
    arc_sig[number_arcs] = sig1;
    arc_centre_x[number_arcs] = centre_x;
    arc_centre_y[number_arcs] = centre_y;
    arc_start_x[number_arcs] = x_c[start_in];   /* to change? */
    arc_start_y[number_arcs] = y_c[start_in];   /*      "     */
    arc_end_x[number_arcs] = x_c[finish_in];    /*      "     */
    arc_end_y[number_arcs] = y_c[finish_in];    /*      "     */
    arc_dirs[number_arcs] = arc_dir;
    maj_axis[number_arcs] = major_axis;
    min_axis[number_arcs] = minor_axis;
    rot_ang[number_arcs] = rot_angle;
    arc_start[number_arcs] = start_in;
    arc_finish[number_arcs] = finish_in;
    arc_status[number_arcs] = KEEP;
    if(((finish_in - start_in) < MIN_LENGTH)
      || (max_dev < 3)
      || (STOP_EARLY == 1)) {
        /* at lowest level of recursion */
        /* save arc match at this lowest of levels */
        /* and significance */
        *sig_out = sig1;
    }
    else{
        /* recurse to next level down */
        segment(start_in,pos,&sig2);
        segment(pos,finish_in,&sig3);
        /* get best significance from lower level */
        if(sig2 < sig3)
            max_sig = sig2;
        else
            max_sig = sig3;
        if(max_sig < sig1) {
            /* return best significance, keep lower level description */
            *sig_out = max_sig;
        /* remove the single arc from start_in to finish_in */
        for(i = 0;i <= number_arcs;i++)
            if ((arc_start[i] == start_in) &&
                (arc_finish[i] == finish_in))
            arc_status[i] = REJECT;
        }
        else{
            /* line at this level is more significant */
            /* remove arcs at lower levels */
            /* i.e between start_in and finish_in */
            /* DOES IT EVER GET HERE ???? */
            printf("JUST REPLACED LOWER LEVEL ARCS\n");
            *sig_out = sig1;
            for(i = 0;i <= number_arcs;i++) {
                if ((arc_start[i] == start_in) &&
                    (arc_finish[i] == finish_in)) /* leave it */ {}
                else if ((arc_start[i] >= start_in)
                        && (arc_finish[i] <= finish_in))
                    arc_status[i] = REJECT;
            }
        }
    }
}

/*
int round(float value)
{
    int i;

    i = floor(value + 0.5);
    return(i);
}
*/

float angle(float x1, float y1, float x2, float y2)
{
    float angle_temp;
    float xx,yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if(xx == 0.0)
        angle_temp = PI/2.0;
    else
        angle_temp = atan(fabs(yy/xx));
    if((xx < 0.0) && (yy >= 0.0))
       angle_temp = PI - angle_temp;
    else if((xx < 0.0) && (yy < 0.0))
       angle_temp = PI + angle_temp;
    else if((xx >= 0.0) && ( yy < 0.0))
       angle_temp = PI*2.0 - angle_temp;
    return(angle_temp);
}

float euclid(float x1, float y1, float x2, float y2)
{
    float temp1,temp2;
    float dist;

    temp1 = fabs(x1-x2);
    temp2 = fabs(y1-y2);
    dist = sqrt(sqr(temp1)+sqr(temp2));
    return(dist);
}

void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2)
{
    /* rotate polygon segment (x1,y1) -> (x2,y2) to lie along x axis,
       compute the minimum distance between the line segment and
       a point on the circle defined as (x_cir,y_cir).
       take perpendicular distance if x_cir between end points else
       take euclidian distance to nearest end point.
    */
    float angle1;
    float x_off,y_off,cosine,sine;
    float temp;
    float min1,min2;

/*
    printf("entered compute_minimum_diff\n");
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    angle1 = angle(x1,y1,x2,y2);
    cosine = cos(-angle1);
    sine = sin(-angle1);
    x_off = x1;
    y_off = y1;
    /* offset points so x1,y1 at origin */
    x1 = 0;
    y1 = 0;
    x2 = x2 - x_off;
    y2 = y2 - y_off;
    x_cir = x_cir - x_off;
    y_cir = y_cir - y_off;
    /* rotate points with x2,y2 on x axis */
    temp = x2*cosine - y2*sine;
    y2 = x2*sine + y2*cosine;
    x2 = temp;
    temp = x_cir*cosine - y_cir*sine;
    y_cir = x_cir*sine + y_cir*cosine;
    x_cir = temp;
/*
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    min1 = euclid(x_cir,y_cir,x1,y1);
    min2 = euclid(x_cir,y_cir,x2,y2);
    if(x_cir < x1) {
        *deviation = min1;
    }else if(x_cir > x2) {
        *deviation = min2;
    }else{
        *deviation = fabs(y_cir);
    }
/*    printf("deviation: %f\n",*deviation,); */
}


void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir)
/*
New version that walks around hypothesised ellipse
finding minimum distance to polygon at each step.
Nearest point is either the perpendicular distance,
or the euclidian distance to the nearest end point.
For all cases the nearest end point is taken as the
possible break point. max_dev is the deviation,
max_pos is the vertex for max_dev,
major_axis,minor_axis define the ellipse
*/
{
    int l2;
    float l1,step;
    float s_ang,f_ang,temp;
    float x_cir,y_cir;
    float deviation;
    float min_dev;
    int min_pos;

    *max_dev = 0.0;

    /* determine angles */
    s_ang = angle(0.0,0.0,x_trans3[1]/major_axis,y_trans3[1]/minor_axis);
    f_ang = angle(0.0,0.0,
                  x_trans3[nseg2]/major_axis,y_trans3[nseg2]/minor_axis);
#if DEBUG
    printf("start coords: %f %f\n",x_trans3[1],y_trans3[1]);
    printf("finish coords: %f %f\n",x_trans3[nseg2],y_trans3[nseg2]);
    printf("angles: %f %f\n",s_ang,f_ang);
#endif
    /* default is anticlockwise, swap if clockwise */
    if(arc_dir == CLOCKWISE) {
        temp = s_ang;
        s_ang = f_ang;
        f_ang = temp;
    }
/* ang4 must be bigger than ang3 */
    if(f_ang < s_ang) {
        f_ang += PI*2.0;
    }
#if DEBUG
    printf("start angle: %f finish angle %f\n",s_ang,f_ang);
/* walk around circle from angle1 to angle2 */
    printf("walking around circle\n");
#endif
    step = (f_ang-s_ang)/10.0;    /* use 11 steps presently */
    l1 = s_ang;
    do{
        min_dev = 1000000;
        x_cir = cos(l1) * major_axis;
        y_cir = sin(l1) * minor_axis;
        /* printf("\nl1: %f (x_cir,y_cir): %f %f\n",l1,x_cir,y_cir);  */
        l2 = 1;
        do{
            /* printf("for line %d\n",l2);   */
            compute_minimum_diff(&deviation,x_cir,y_cir,x_trans3[l2],
                                 y_trans3[l2],x_trans3[l2+1],y_trans3[l2+1]);
            if(deviation < min_dev) {
                min_dev = deviation;
                min_pos = l2;
            }
            l2++;
        }while(l2 <= nseg2-1);
        /* printf("at this angle minimum deviation: %f at vertex: %d\n",
        min_dev,pos1);  */
        if(min_dev > *max_dev) {
            *max_dev = min_dev;
            *max_pos = min_pos;
        }
        l1 += step;
    }while (l1 <= f_ang);
#if DEBUG
    printf("maximum deviation: %f\n",*max_dev);
#endif
}

void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir)
{
    /* computes length of arc
    works on temporary data from determine_ellipse_fit
    i.e. data: (x_trans3,y_trans3),major_axis,minor_axis.
    new version computes start and finish angles, then
    arc length from angle and radius */

    float s_ang,f_ang,temp;
    float xold,yold,xnew,ynew;
    float step;

    s_ang = angle(0.0,0.0,x_trans3[1]/major_axis,y_trans3[1]/minor_axis);
    f_ang = angle(0.0,0.0,
                  x_trans3[nseg2]/major_axis,y_trans3[nseg2]/minor_axis);
    /* default is anticlockwise, so swap angles if clockwise */
    if(arc_dir == CLOCKWISE) {
       temp = s_ang;
       s_ang = f_ang;
       f_ang = temp;
    }
    /* start angle must be less that f_ang */
    if (f_ang < s_ang)
       f_ang += PI*2.0;
    *lgt = 0.0;
    xold = major_axis * cos(s_ang);
    yold = minor_axis * sin(s_ang);
    step = (f_ang - s_ang) / 20.0;
    temp = s_ang;
    do{
        temp += step;
        xnew = major_axis * cos(temp);
        ynew = minor_axis * sin(temp);
        *lgt = *lgt + distance(xold,yold,xnew,ynew);
        xold = xnew;
        yold = ynew;
    }while(temp <= f_ang);
}

void compute_poly_lgt(float *lgt)
{
    int loop1;
    float dx,dy;

    *lgt = 0;
    for(loop1 = 1;loop1 < nseg2;loop1++) {
        dx = x_trans3[loop1] - x_trans3[loop1+1];
        dy = y_trans3[loop1] - y_trans3[loop1+1];
        *lgt += sqrt(sqr(dx) + sqr(dy));
    }
}

/*
 Determine the best fit ellipse using Paul's robust kalman filter
 hack.
*/
void determine_ellipse_fit(int st, int fi, float *final_major_axis, float * final_minor_axis, float * final_rot_angle, int *final_xc, int *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig)
{
    /* ellipse fitting variables */
    float m[7];   /* coefficients of best fit ellipse */

    /* new variables for lms fitting */
    float x_cent,y_cent;
    float c_ang;

    /* original variables */
    float xt,yt;   /* temp variables */
    float x_cent_t,y_cent_t; /* temp centre coords - after transformation */
    float sine,cosine;
    float max_dev,arc_length,poly_length;
    int loop1,loop2;
    int max_pos;
    float sum,ratio;
    float temp;
    int arc_size;
    float x_off,y_off;
    float major_axis,minor_axis,rot_angle;
    float xs,ys,xf,yf;

    float angle_s,angle_f,diff_angle;

    /*
       set representation_ok to TRUE - set to FALSE by any code that
       cannot fit the representation to the data
    */
    representation_ok = TRUE;

#if DEBUG
    printf("\n\entering determine_ellipse_fit for data from: %d to %d\n",st,fi);
#endif
    /* set up global variables for plot_data */
    start_data = st;
    finish_data = fi;

    /* get data into temp array */
    nseg2 = 0;
    for(loop1 = st;loop1 <= fi;loop1++) {
       nseg2++;
       x_trans3[nseg2] = x_c[loop1];
       y_trans3[nseg2] = y_c[loop1];
    }
    /* scale values from 0 to 1 for kalman filter by dividing by 512 */
    for(loop1=1;loop1<=nseg2;loop1++) {
        x_trans3[loop1] /= 512.0;
        y_trans3[loop1] /= 512.0;
    }

    determine_ellipse_kalman(m);
    if(representation_ok == FALSE)
       return;
#if DEBUG
    printf("coefficients for fitted ellipse:\n");
    printf("%2.3f %2.3f %2.3f %2.3f %2.3f %2.3f\n",
           m[1],m[2],m[3],m[4],m[5],m[6]);
#endif

/* determine arc_size
* transform temp to lie along x axis, then compute average displacement
* of y coords. If +ve then circle on +ve side of axis else on -ve. This
* in combination with the position of the centre will indicate if the are
* is large (>180 degrees) or small (<=180 degrees). Also can determine if
* arc is clockwise or anticlockwise
* rotate and translate temp data.
* take chord between points, rotate so that chord is
* along x axis - rotate and translate all other points the same.
*/
    c_ang = angle(x_trans3[1],y_trans3[1],x_trans3[nseg2],y_trans3[nseg2]);
    sine = sin(-c_ang);
    cosine = cos(-c_ang);

/* translate so first point is at origin */
    x_off = x_trans3[1];
    y_off = y_trans3[1];
    for(loop1 = 1;loop1 <= nseg2;loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - x_off;
        y_trans3[loop1] = y_trans3[loop1] - y_off;
    }
/* rotate to align chord with x axis */
    for(loop1 = 1;loop1 <= nseg2;loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt*cosine - yt*sine;
        x_trans3[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans3[loop1] = temp;
    }
/* do same for centre */
    x_cent = (-m[4]*m[3]/2.0 + m[5]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);
    y_cent = (-m[1]*m[5]/2.0 + m[4]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);

    xt = x_cent - x_off;
    yt = y_cent - y_off;
    temp = xt*cosine - yt*sine;
    x_cent_t = temp;
    temp = xt*sine + yt*cosine;
    y_cent_t = temp;

/* compute average y coord of all points */
    sum = 0.0;
    for(loop1=1;loop1<=nseg2;loop1++)
        sum += y_trans3[loop1];

/* determine size and sense of arc */
        if((sum >= 0.0) && (y_cent_t >= 0.0)) {
        arc_size = BIG;
        *arc_dir = CLOCKWISE;
    }
    else if((sum < 0.0) && (y_cent_t < 0.0)) {
        arc_size = BIG;
        *arc_dir = ANTICLOCKWISE;
    }
    else if((sum >= 0.0) && (y_cent_t < 0.0)) {
        arc_size = SMALL;
        *arc_dir = CLOCKWISE;
    }
    /* CHANGED Y_CENT TO Y_CENT_T - PLR */
    else if ((sum < 0.0) && (y_cent_t >= 0.0)) {
        arc_size = SMALL;
        *arc_dir = ANTICLOCKWISE;
    }
/*
    printf("SUM: %f\n",sum*512/nseg2);
*/
    /* !!! FOR VERY FLAT SECTIONS !!! */
    if (fabs(sum*512/nseg2) < 3.0) {
       angle_s = angle(x_cent_t,y_cent_t,x_trans3[1],y_trans3[1]);
       angle_f = angle(x_cent_t,y_cent_t,x_trans3[nseg2],y_trans3[nseg2]);
       diff_angle = angle_f - angle_s;
       if (diff_angle < 0) diff_angle += (PI*2.0);
       if (diff_angle < PI)
          *arc_dir = ANTICLOCKWISE;
       else
          *arc_dir = CLOCKWISE;
    }

#if DEBUG
    if(arc_size == SMALL)
        printf("small arc ");
    else
        printf("big arc ");
    if(*arc_dir == CLOCKWISE)
        printf("direction clockwise\n");
    else
        printf("direction anticlockwise\n");
#endif

    /*
    for(loop2=1;loop2<=nseg2;loop2++)
        printf("x_trans3: %f y_trans3: %f\n",x_trans3[loop2],y_trans3[loop2]);
    */

/* convert coefficients to more meaningful parameters */
    determine_parameters(m,&major_axis,&minor_axis,&rot_angle);
    if (representation_ok == FALSE)
       return;
/* scale parameters to image space */
    major_axis *= 512.0;
    minor_axis *= 512.0;
    x_cent *= 512.0;
    y_cent *= 512.0;

#if DEBUG
    printf("parameters of ellipse:\n");
    printf("major_axis axis: %f minor_axis_axis %f\n",major_axis,minor_axis);
    printf("rotation angle of major_axis axis: %f\n",rot_angle);
    printf("centre: %f %f\n",x_cent,y_cent);
#endif

    xs = x_c[st];
    ys = y_c[st];
    xf = x_c[fi];
    yf = y_c[fi];

#if GRAPHICS
    plot_ellipse(xs,ys,xf,yf,x_cent,y_cent,
                 major_axis,minor_axis,rot_angle,
                 *arc_dir);
#endif

/* transform data so the major_axis axis of the ellipse is along the x axis */
/* get data into temp arrays */
    nseg2 = 0;
    for(loop1 = st;loop1 <= fi;loop1++) {
        nseg2++;
        x_trans3[nseg2] = x_c[loop1];
        y_trans3[nseg2] = y_c[loop1];
    }
/* first translate */
    for(loop1=1;loop1<=nseg2;loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - x_cent;
        y_trans3[loop1] = y_trans3[loop1] - y_cent;
    }
/* now rotate */
    sine = sin(-rot_angle);
    cosine = cos(-rot_angle);
    for(loop1=1;loop1<=nseg2;loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt*cosine - yt*sine;
        x_trans3[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans3[loop1] = temp;
    }
    x_cent_t = 0.0;
    y_cent_t = 0.0;

/*
determine length of ellipse for this circle approx - use data
transformed to put major axis along x axis
*/
    compute_lgt(&arc_length,major_axis,minor_axis,*arc_dir);

/*
determine actual length of data - a polygon here
*/
    compute_poly_lgt(&poly_length);

/*
determine position and value of the maximum deviation - use data
transformed to put major axis along x axis
*/
    compute_dev(&max_dev,&max_pos,major_axis,minor_axis,*arc_dir);

/*
hack to stop breakpoint near ends - to be modified
break at middle of data if too close to end points
*/
    if((max_pos <= MIN_LENGTH) || (max_pos > nseg2-MIN_LENGTH))
        max_pos = nseg2 / 2;

#if DEBUG
    printf("arc length: %f\n",arc_length);
    printf("poly length: %f\n",poly_length);
    printf("maximum deviation: %f\n",max_dev);
    printf("point of maximum deviation: %d\n",max_pos);
#endif

/* *****
compute significance based on max_dev, arc_length and
some heuristics!
**** */
/* polygonal length should be similar to arc length */
    ratio = poly_length / arc_length;
    if(ratio < 1)
        ratio = arc_length / poly_length;


/* save parameters for best ellipse as integers */
    *final_major_axis = major_axis;
    *final_minor_axis = minor_axis;
    *final_rot_angle = rot_angle;
    *final_xc = round(x_cent);
    *final_yc = round(y_cent);
    *final_lgt = arc_length;
    max_dev = max_dev * ratio;        /* temp to modify sig */
    *final_dev = max_dev;

    if((max_dev != 0.0) && (arc_length != 0))
        *sig = max_dev / (float)arc_length;
    else
        *sig = LARGE_SIG;

/* save position of maximum deviation */
    global_pos = max_pos;
}


float distance(double x1, double y1, double x2, double y2)
{
    return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

/* new improved version that works analytically thanks to Alah */
void determine_parameters(float m[], float *major_axis, float *minor_axis, float *rot_angle)
{
    float x_cent,y_cent;
    float a,b,c,d,e,f;
    float ca,sa;
    float t,u,v,w;

    a = m[1];
    b = m[2];
    c = m[3];
    d = m[4];
    e = m[5];
    f = m[6];

    if (a == c)
       *rot_angle = 0;
    else
       *rot_angle = atan(b/(a-c)) / 2.0;
    ca = cos(*rot_angle);
    sa = sin(*rot_angle);
    t = a*sqr(ca)+b*ca*sa+c*sqr(sa);
    u = a*sqr(sa)-b*ca*sa+c*sqr(ca);
    v = d*ca+e*sa;
    w = -d*sa+e*ca;
    *major_axis = sqrt(((sqr(v)/(4*t))+(sqr(w)/(4*u))-f)/t);
    *minor_axis = sqrt(((sqr(v)/(4*t))+(sqr(w)/(4*u))-f)/u);
}

#if GRAPHICS
plot_data()
/*
   plots original data
   - uses global variables start_data and finish_data to
   specify which part of the data to plot
*/
{
    int loop1;

    setcolor(12);
    cross((int)x_c[1],(int)y_c[1],5,15);
    for(loop1=start_data;loop1<finish_data;loop1++) {
        moveto((int)x_c[loop1],(int)y_c[loop1]);
        lineto((int)x_c[loop1+1],(int)y_c[loop1+1]);
    }
    cross((int)x_c[finish_data],(int)y_c[finish_data],5,14);
}

void plot_ellipse(xs,ys,xf,yf,xc,yc,major_axis,minor_axis,rot_angle,arc_dir)
float xs,ys,xf,yf,xc,yc;
float major_axis,minor_axis,rot_angle;
int arc_dir;

/*
   plots ellipse using all parameters by generating ellipse around
   origin and transforming it to image space
   parameters: xs,ys to xf,yf - start to finish coords
               xc,yc - centre of ellipse
               major_axis,minor_axis - of the ellipse
               rot_angle - rotation of major axis clockwise about
               origin starting at +ve x axis
*/
{
    float x1,y1,x2,y2;
    float sine,cosine,sine2,cosine2;
    float temp,step,temp_angle;
    float xold,yold,xe,ye;
    float st_ang,fi_ang;
    int gd,gm;
    char ch;

    /* determine start and finish angles wrt to centre at the origin */
    /* first transform start and finish to origin offset */
    x1 = xs - xc;
    y1 = ys - yc;
    x2 = xf - xc;
    y2 = yf - yc;
    /* rotate */
    sine = sin(-rot_angle);
    cosine = cos(-rot_angle);
    temp = x1 * cosine - y1 * sine;
    y1 = x1 * sine + y1 * cosine;
    x1 = temp;
    temp = x2 * cosine - y2 * sine;
    y2 = x2 * sine + y2 * cosine;
    x2 = temp;
    st_ang = angle(0.0,0.0,x1/major_axis,y1/minor_axis);
    fi_ang = angle(0.0,0.0,x2/major_axis,y2/minor_axis);
    if(arc_dir == CLOCKWISE) {
        temp = st_ang;
        st_ang = fi_ang;
        fi_ang = temp;
    }
    /* fi_ang must be bigger than st_ang */
    if(fi_ang < st_ang) {
        fi_ang += PI * 2.0;
    }

    do{
    }while(kbhit() == 0);
    ch = getch();

    gd = 9;
    gm = 2;
    initgraph(&gd,&gm,"c:\\tc");

    cross((int)xc,(int)yc,8,13);

    /* generate transform from origin centred ellipse to image space */
    cosine2 = cos(rot_angle);
    sine2 = sin(rot_angle);

    /* moveto first point on ellipse in image */
    xe = major_axis * cos(st_ang);
    ye = minor_axis * sin(st_ang);
    temp = xe * cosine2 - ye * sine2;
    ye = xe * sine2 + ye * cosine2;
    xe = temp;
    xe = xe + xc;
    ye = ye + yc;
    cross((int)xe,(int)ye,8,15);
    setcolor(13);
    moveto((int)xe,(int)ye);

    /* successively plot lines around ellipse */
    step = (fi_ang - st_ang) / 50.0;
    temp_angle = st_ang;
    for(temp_angle=st_ang;temp_angle<=fi_ang;temp_angle += step) {
        xe = major_axis * cos(temp_angle);
        ye = minor_axis * sin(temp_angle);
        temp = xe * cosine2 - ye * sine2;
        ye = xe * sine2 + ye * cosine2;
        xe = temp;
        xe = xe + xc;
        ye = ye + yc;
        lineto((int)xe,(int)ye);
    }

    /* generate last point on ellipse */
    xe = major_axis * cos(fi_ang);
    ye = minor_axis * sin(fi_ang);
    temp = xe * cosine2 - ye * sine2;
    ye = xe * sine2 + ye * cosine2;
    xe = temp;
    xe = xe + xc;
    ye = ye + yc;
    lineto((int)xe,(int)ye);
    cross((int)xe,(int)ye,8,13);

    do{
    }while(kbhit() == 0);
    ch = getch();

    plot_data();

    do{
    }while(kbhit() == 0);
    ch = getch();

    closegraph();
}
#endif

int curve_type(char array[50])
{
    int i,j;

    if((j = strcmp(array,"list:")) == 0)
        i = 1;
    else if((j = strcmp(array,"line:")) == 0)
        i = 2;
    else if((j = strcmp(array,"arc:")) == 0)
        i = 3;
    else if((j = strcmp(array,"endl:")) == 0)
        i = 4;
    else if((j = strcmp(array,"endf:")) == 0)
        i = 5;
    return(i);
}

/*
int strcmp(s,t)
char s[],t[];
{
    int i;

    i = 0;
    while(s[i] == t[i])


        if(s[i++] == '\0')
            return(0);
    return(s[i] - t[i]);
}
*/

/*
 *  code below used to be in determ3.c
 *  fits ellipses to data using a kalman filter
 *  abort when any error condition occurs - that is cannot fit an ellipse
 *  Paul Rosin
 *  January 1990
 */

int find_conic_type(double c1, double c2, double c3)
{
    float fx;
    int temp;

    fx = c1 * c3 - c2 * c2 / 4;
        if (fx > 0)
           temp = ELLIPSE;
    else if (fx < 0)
           temp = HYPERBOLA;
    else
           temp = PARABOLA;
/*      printf("fx: %f\n",fx); */
    return(temp);
}

void error(char s[])
{
    printf("ERROR: %s\n",s);
    exit(1);
}

/*
Implentation of lms circle fitting algorithm from:
'A simple approach for the estimation of circular arc centre and
its *radius' by S M Thomas and Y T Chan, CVGIP Vol 45, pp 362-370, 1989
*/

void compute_circle(float *x_cent, float *y_cent, float *radius2, int nseg2)
{
   float sx,sy,sx2,sy2,sxy,sx3,sy3,sx2y,sxy2;
   float a1,a2,b1,b2,c1,c2;
   int loop1;
   float temp;

   loop1 = 0;
   /* initialise variables */;
   sx = 0.0;
   sy = 0.0;
   sx2 = 0.0;
   sy2 = 0.0;
   sxy = 0.0;
   sx3 = 0.0;
   sy3 = 0.0;
   sx2y = 0.0;
   sxy2 = 0.0;
   /* compute summations */
   for(loop1=1;loop1<=nseg2;loop1++) {
      sx = sx + x_trans3[loop1];
      sy = sy + y_trans3[loop1];
      sx2 = sx2 + sqr(x_trans3[loop1]);
      sy2 = sy2 + sqr(y_trans3[loop1]);
      sxy = sxy + x_trans3[loop1] * y_trans3[loop1];
      sx3 = sx3 + x_trans3[loop1] * x_trans3[loop1] * x_trans3[loop1];
      sy3 = sy3 + y_trans3[loop1] * y_trans3[loop1] * y_trans3[loop1];
      sx2y = sx2y + sqr(x_trans3[loop1]) * y_trans3[loop1];
      sxy2 = sxy2 + sqr(y_trans3[loop1]) * x_trans3[loop1];
   }
   /* compute a's,b's,c's */
   a1 = 2.0 * (sqr(sx) - sx2 * nseg2);
   a2 = 2.0 * (sx * sy - sxy * nseg2);
   b1 = a2;
   b2 = 2.0 * (sqr(sy) - sy2 * nseg2);
   c1 = sx2 * sx - sx3 * nseg2 + sx * sy2 - sxy2 * nseg2;
   c2 = sx2 * sy - sy3 * nseg2 + sy * sy2 - sx2y * nseg2;
   /* compute centre */
   temp = a1*b2 - a2*b1;
   if (temp == 0) {
        printf("ERROR in circle fitting: divide by zero %f\n",temp);
        representation_ok = FALSE;
        return;
   }
   *x_cent = (c1 * b2 - c2 * b1) / (a1 * b2 - a2 * b1);
   *y_cent = (a1 * c2 - a2 * c1) / ( a1 * b2 - a2 * b1);
   /* compute radius squared */
   *radius2 = (sx2 - 2.0 * sx * *x_cent + sqr(*x_cent) * nseg2
            + sy2 - 2.0 * sy * *y_cent + sqr(*y_cent) * nseg2) / nseg2;
}

/*******************************************************************
        Matrix manipulation programs
*******************************************************************/

int kron(int i, int j)
{
        return ((i==j)? 1:0);
}

/* transposes a([1..n][1..p] into b  */
void transp(float a[6][6], float b[6][6], int n, int p)
{
        int i,j;

        /* printf("trans "); */
        for (i=1;i<=n;i++)
                for (j=1;j<=p;j++)
                        b[j][i] = a[i][j];

}

void w_sum(float a[6][6], float b[6][6], float c[6][6], int n, int p, double w1, double w2)
{
        int i,j;

        /* printf("w_sum "); */
        for (i=1;i<=n;i++)
                for (j=1;j<=p;j++)
                        c[i][j]  = w1 * a[i][j] + w2 * b[i][j];

}


/* Multiplies a[1..m][1..n] and b[1..n][1..p] and puts the result in c[1..m][1..p] */
void mult(float a[6][6], float b[6][6], float c[6][6], int m, int n, int p)
{
        int i,j,k;

        /* printf("mult "); */
        for (i=1;i<=m;i++)
            for (j=1;j<=p;j++)
                c[i][j] = 0;
        for (i = 1; i <= m; i++)
                for (j = 1; j <= p; j++)
                        for (k = 1; k <= n; k++)
                                c[i][j] += a[i][k] * b[k][j];
}

/* Multiplies a[1..m][1..n] and b[1..n] and puts the result in c[1..m]       */
void multvect(float a[6][6], float b[6], float c[6], int m, int n)
{
        int i,j;

       /* printf("multvect "); */
        for (i=1;i<=m;i++)
           c[i] = 0;
       for (i = 1; i <= m; i++)
                for (j = 1; j <= n; j++)
                                c[i] += a[i][j] * b[j];
}

/* decomposition */
void ludcmp(float a[6][6], int n, int indx[6], float *d)
{
     int i,imax,j,k;
     float big,dum,sum,temp;
     float vv[6];

     /* printf("ludcmp "); */
     *d = 1.0;
     for (i = 1; i <= n; i++) {
                big = 0.0;
                for (j = i; j <= n; j++)
                        if ((temp = fabs(a[i][j])) > big) big = temp;
                if (big == 0.0) error("Singular matrix in routine LUDCMP");
                vv[i] = 1.0/big;
     }
     for (j = 1; j <= n; j++) {
                for (i = 1; i < j; i++) {
                        sum = a[i][j];
                        for (k = 1; k < i; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                }
                big = 0.0;
                for (i = j; i <= n;i++) {
                        sum = a[i][j];
                        for (k = 1; k < j; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                        if ( (dum = vv[i]*fabs(sum)) >= big) {
                                big = dum;
                                imax = i;
                        }
                }
                if (j != imax) {
                        for (k = 1; k <= n; k++) {
                                dum = a[imax][k];
                                a[imax][k] = a[j][k];
                                a[j][k] = dum;
                        }
                        *d = -(*d);
                        vv[imax] = vv[j];
                }
                indx[j] = imax;
                if (a[j][j] == 0.0) a[j][j] = TINY;
                if (j != n) {
                        dum = 1.0/(a[j][j]);
                        for (i = j+1; i <= n ;i++) a[i][j] *= dum;
                }
     }
}

void lubksb(float a[6][6], int n, int indx[6], float b[6])
{
        int i,ii=0,ip,j;
        float sum;

       /* printf("ludksb "); */
        for (i=1;i<=n;i++) {
                ip = indx[i];
                sum = b[ip];
                b[ip] = b[i];
                if (ii)
                        for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
                else if (sum) ii = i;
                b[i] = sum;
        }
        for (i=n;i>=1;i--) {
                sum = b[i];
                for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
                b[i] = sum/a[i][i];
        }
}

void invers(float a[6][6], float b[6][6], int n)
{
    float d,col[6];
    int i,j,indx[6];

       /* printf("inverse "); */
       ludcmp(a,n,indx,&d);
        for (j=1;j<=n;j++) {
                for (i=1;i<=n;i++) col[i] = 0.0;
                col[j] = 1.0;
                lubksb(a,n,indx,col);
                for(i=1;i<=n;i++) b[i][j] = col[i];
        }
}

/*******************************************************************
    Kalman filter
*******************************************************************/

void kalman(float y[6], float m[6][6], float w[6][6], float a[6], float s[6][6], int n, int p)
{
        float k[6][6];
        float inv[6][6],temp[6][6],vect[6],delta[6];
        int i,j;//,kron();

       /* printf("kalman "); */
        transp(m,k,p,n);            /*  m transposed into k */
        mult(s,k,temp,n,n,p);       /*  s*transp(m)   */
        mult(m,temp,inv,p,n,p);     /*  m*s*transp(m) */
        w_sum(w,inv,temp,p,p,1.0,1.0);   /* temp=w+m*s*transp(m)  */
        invers(temp,inv,p);              /* inversion of temp into inv */
        mult(k,inv,temp,n,p,p);
        mult(s,temp,k,n,n,p);        /* k=s*tranp(m)*inv :  Kalman factor */
        for (i=1;i<=p;i++)
            vect[i] = 0;
        for (i=1;i<=p;i++) {
                for (j=1;j<=n;j++)
                        vect[i] += m[i][j]*a[j];
                vect[i] = y[i]-vect[i];
        }
        multvect(k,vect,delta,n,p);
        for (i=1;i<=n;i++) {
                a[i] += delta[i];    /* a: solution of the Kalman filter */
        }

        mult(k,m,temp,n,p,n);
        for (i=1;i<=n;i++) {
                for (j=1;j<=n;j++) {
                        temp[i][j] = kron(i,j)-temp[i][j];
                }
        }
        mult(temp,s,inv,n,n,n);
        for (i=1;i<=n;i++) {
                for (j=1;j<=n;j++) {
                        s[i][j] = inv[i][j];  /* s: covariance matrix of a */
                }
        }
}

/* rewritten for fitting of conic sections */
void run_kalman(double c1, double c2, double c3, double c4, double c5)
{
    float a[6],s[6][6],y[6],m[6][6],w[6][6];
    int i,j;

    /* define matrices */

    /* initialise matrices */
    /* coefficients found by circle fitting */
    a[1] = c1;
    a[2] = c2;
    a[3] = c3;
    a[4] = c4;
    a[5] = c5;

    /* high uncertainty */
    for (i = 1; i <= 5; i++)
        for (j = 1; j <= 5; j++)
            s[i][j] = 0;

    s[1][1] = covariance;
    s[2][2] = covariance;
    s[3][3] = covariance;
    s[4][4] = covariance;
    s[5][5] = covariance;
    for (i = 1; i <= nseg2; i++) {
        m[1][1] = x_trans3[i] * x_trans3[i] - y_trans3[i] * y_trans3[i];
        m[1][2] = 2 * x_trans3[i] * y_trans3[i];
        m[1][3] = 2 * x_trans3[i];
        m[1][4] = 2 * y_trans3[i];
        m[1][5] = 1;

        w[1][1] = sqr(2*c1*x_trans3[i] + 2*c2*y_trans3[i] + 2*c4) * sqr(DELTA_X) +
                 sqr(2*c2*x_trans3[i] + 2*(1-c1)*y_trans3[i] + 2*c5) * sqr(DELTA_Y);

        y[1] = - y_trans3[i] * y_trans3[i];

        kalman(y,m,w,a,s,5,1);
    }

    /* plot final estimate */
    /*
    plot_conic(a[1],a[2]*2,1-a[1],a[3]*2,a[4]*2,a[5],GREEN);
    */

    /* save result in array result */
    for(i=1;i<=5;i++)
        result[i] = a[i];

    conic_type = find_conic_type(a[1],a[2]*2,1-a[1]);
}

void determine_ellipse_kalman(float m[])
{
    float x_cent,y_cent,radius2,factor;
    float c1,c2,c4,c5,c6;
    int loop1;

    /* find best fit lms circle fit */
    compute_circle(&x_cent,&y_cent,&radius2,nseg2);
    if(representation_ok == FALSE)
        return;
#if DEBUG
    printf("%f %f %f\n",x_cent,y_cent,radius2);
#endif
    /* convert circle parameters to coefficients of conic */
    factor = -radius2 + sqr(x_cent) + sqr(y_cent);

    c1 = 1 / factor;
    c2 = 0;
    c4 = -2 * x_cent / factor;
    c5 = -2 * y_cent / factor;
    c6 = 1;

    /* convert coefficients so that c3 = 1-c1 */
    /* only works for circles, i.e. c1=c3 */
    factor = 2*c1;

    c1 = c1 / factor;
    c2 = c2 / factor;
    c4 = c4 / factor;
    c5 = c5 / factor;
    c6 = c6 / factor;

    m[1] = c1;
    m[2] = c2;
    m[3] = 1-c1;
    m[4] = c4;
    m[5] = c5;
    m[6] = c6;

    /* plot initial estimate */
    /*
    printf("initial circle fit:\n");
    plot_conic(c1,c2,1-c1,c4,c5,c6,GREEN);
    printf("\n");
    */

    run_kalman(c1,c2/2,c4/2,c5/2,c6);
/*
    printf("results: ");
    for(loop1=1;loop1<=5;loop1++)
        printf("%f ",result[loop1]);
    printf("\n");
*/
    max_cv = covariance;
    min_cv = 0;
    if (conic_type != ELLIPSE) {
/*
    printf("initial range: %2.1f -> %2.1f\n",min_cv,max_cv);
*/
      while ((max_cv - min_cv) > CV_DIFF) {
      mid_cv = (max_cv + min_cv) / 2.0;
      covariance = mid_cv;
/*
      printf("rerun KALMAN with CV: %f\n",mid_cv);
*/
      run_kalman(c1,c2,c4,c5,c6);
/*
      printf("results: ");
      for(loop1=1;loop1<=5;loop1++)
          printf("%f ",result[loop1]);
          printf("\n");
*/
          if (conic_type == ELLIPSE) {
              min_cv = mid_cv;
          }
          else {
              max_cv = mid_cv;
          }
/*
          printf("new range: %2.1f -> %2.1f\n",min_cv,max_cv);
*/
       }
       /*
        * run again to make sure it's fitting to lower covariance value
        * and fitting an ellipse
        */
        covariance = min_cv;
/*
        printf("final run of KALMAN with CV: %f\n",min_cv);
*/
        run_kalman(c1,c2,c4,c5,c6);
    }

    /* return final estimate of coefficients */
    m[1] = result[1];
    m[2] = result[2]*2;
    m[3] = 1 - result[1];
    m[4] = result[3]*2;
    m[5] = result[4]*2;
    m[6] = result[5];
#if DEBUG
    printf("conic type: %d\n",conic_type);
#endif
}
