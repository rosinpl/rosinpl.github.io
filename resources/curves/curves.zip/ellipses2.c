/*
    ellipses2.c

    A  P.L. Rosin / G.A.W.West production. Copyright 1990.

    Modified version of ellipses.c to fit ellipses to pixel data
    Uses Henrick Bendtson's formulation to bias conic to ellipse

    Input: pixel data format.
    Output: super data format (only arcs).
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define NO_LINE_SEGS 5000 /* max number of lines per list */
#define NO_ARCS 2000       /* max number of arcs per list  */
#define NO_PIXELS 5000

#define IGNORE 3
#define PI 3.141591
#define SMALL 1           /* type of arc */
#define BIG 2
#define CLOCKWISE 1       /* direction of arc from start to finish */
#define ANTICLOCKWISE 2

#define STOP_EARLY 0      /* just fit to all data in a list and stop if 1 */
                          /* normal recursive algorithm if = 0 */

#define PI 3.141591
#define NINETY 1.570796327
#define KEEP 0    /* KEEP and REJECT used to tell if arcs to be kept */
#define REJECT 1
#define LARGE_SIG 99999
#define MIN_LENGTH 6
#define FALSE 0
#define TRUE !FALSE

#define TINY 1.0e-20

#define SIZE 512

#define ELLIPSE 0
#define PARABOLA 1
#define HYPERBOLA 2

#define LAMBDA_DIFF 0.1
double lambda;

#define sqr(x) ((x) * (x))

/* temp array for manipulatable data from x_c,y_c */
float x_trans3[NO_LINE_SEGS],y_trans3[NO_LINE_SEGS];

/* ellipse parameterisation arrays */
int arc_centre_x[NO_ARCS],arc_centre_y[NO_ARCS];
int arc_start_x[NO_ARCS],arc_start_y[NO_ARCS];
int arc_end_x[NO_ARCS],arc_end_y[NO_ARCS];
float maj_axis[NO_ARCS],min_axis[NO_ARCS];
float rot_ang[NO_ARCS];
int arc_dirs[NO_ARCS];
float arc_sig[NO_ARCS];

int number_arcs;
int nseg2;   /* number of points in x_trans3, y_trans3 */

short arc_status[NO_ARCS];
short x_c[NO_PIXELS],y_c[NO_PIXELS];
short arc_start[NO_ARCS],arc_finish[NO_ARCS];

int number_pixels;

int global_pos;
int representation_ok;

FILE *fp, *fp_out;

int conic_type;

void segment(int start_in,int finish_in,float *sig_out);
void read_list(int *number_pixels, int *end_of_file, int *list_no);
float angle(float x1, float y1, float x2, float y2);
float euclid(float x1, float y1, float x2, float y2);
void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2);
void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir);
void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir);
void compute_poly_lgt(float *lgt);
void determine_ellipse_fit(int st, int fi, float *final_major_axis, float * final_minor_axis, float * final_rot_angle, int *final_xc, int *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig);
float distance(double x1, double y1, double x2, double y2);
//int round(float value);
int find_conic_type(double c1, double c2, double c3);
void error(char s[]);
void ludcmp(float a[6][6], int n, int indx[6], float *d);
void lubksb(float a[6][6], int n, int indx[6], float b[6]);
void w_sum(float a[6][6], float b[6][6], float c[6][6], int n, int p, double w1, double w2);
void mult(float a[6][6], float b[6][6], float c[6][6], int m, int n, int p);
void determine_parameters(float m[], float *major_axis, float *minor_axis, float *rot_angle);
void run_lms_fitting(float m[7]);
void determine_ellipse_lms3(float m[]);

main(argc,argv)
int argc;
char *argv[];
{
    int j;
    float sig;    /* not really used - just dummy param for segment */
    int list_no,end_of_file;
    float temp;
    char file_type[50];
    char *file_name_in;
    char *file_name_out;
    int set_input_file = FALSE;
    int set_output_file = FALSE;
    char *ch;

    if (argc == 1) {
        printf("Usage: %s -i file -o file\n",argv[0]);
        exit(-1);
    }

    while (--argc > 0 && (*++argv)[0] == '-') {
        for (ch = argv[0] + 1; *ch != '\0'; ch++) {
            switch (*ch) {
                case 'i':
                    set_input_file = TRUE;
                    argc--; argv++;
                    file_name_in = argv[0];
                    break;
                case 'o':
                    set_output_file = TRUE;
                    argc--; argv++;
                    file_name_out = argv[0];
                    break;
                default:
                    printf("illegal option %c\n",*ch);
                    argc = 0;
                    exit(-1);
                    break;
            }
        }
    }

    if (set_input_file == FALSE) {
        printf("no input file specified - aborting\n");
        exit(-1);
    }
    if (set_output_file == FALSE) {
        printf("no output file specified - aborting\n");
        exit(-1);
    }
    if ((fp = fopen(file_name_in,"r")) == NULL) {
        printf("cant open %s\n",file_name_in);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0) {
        printf("not pixel data file - aborting\n");
        exit(-1);
    }

    if ((fp_out = fopen(file_name_out,"w")) == NULL) {
        printf("cant open %s\n",file_name_out);
        exit(-1);
    }
    /* write magic word for format of file */
    fprintf(fp_out,"super\n");

    do{
        read_list(&number_pixels,&end_of_file,&list_no);

        number_arcs = 0;
        segment(1,number_pixels,&sig);

        /* super data output format */
        fprintf(fp_out,"list: %d\n",list_no);
        for (j = 1;j <= number_arcs;j++)
            if (arc_status[j] == KEEP) {
               if (arc_sig[j] < (LARGE_SIG - 1)) {
                  /* !! HACK !! */
                  if (maj_axis[j] < min_axis[j]) {
                     temp = maj_axis[j];
                     maj_axis[j] = min_axis[j];
                     min_axis[j] = temp;
                     rot_ang[j] += PI/2;
                  }
                  fprintf(fp_out,"ellipse: %f %d %d %d %d %d %d %f %f %f %d\n",
                        arc_sig[j],
                        arc_centre_x[j],arc_centre_y[j],
                        arc_start_x[j],arc_start_y[j],
                        arc_end_x[j],arc_end_y[j],
                        maj_axis[j],min_axis[j],rot_ang[j],
                        arc_dirs[j]);
               }
               else
                  fprintf(fp_out,"line: 0.0 %d %d %d %d\n",
               arc_start_x[j],arc_start_y[j],
               arc_end_x[j],arc_end_y[j]);
            }
        fprintf(fp_out,"endl:\n");
        if (end_of_file == 1)
            fprintf(fp_out,"endf:\n");
    }while (end_of_file == 0);
}

void read_list(int *number_pixels, int *end_of_file, int *list_no)
{
    char dumstring[50];
    int j;
    int tx,ty;

    fscanf(fp,"%s %d\n",dumstring,list_no);
    printf("list: %d ",*list_no);
    j = 0;
    do{
        j++;
        fscanf(fp,"%d %d\n",&tx,&ty);
        x_c[j] = tx;
        y_c[j] = ty;
    }while (x_c[j] != -1);
    if (y_c[j] == -1)
       *end_of_file = 1;
    else
       *end_of_file = 0;
    j--;

    /* avoid duplicated endpoints for closed curves */
    if ((x_c[1] == x_c[j]) && (y_c[1] == y_c[j])) {
        printf("removing duplicating end pixel\n");
        --j;
    }

    *number_pixels = j;
    printf("pixels: %d\n",*number_pixels);
}

void segment(int start_in,int finish_in,float *sig_out)
{
    int i;
    int pos;
    float max_dev;
    float sig1,sig2,sig3,max_sig;
    int centre_x, centre_y;
    int arc_length,arc_dir;
    float major_axis,minor_axis,rot_angle;

    /* compute significance at this level */

    if ((finish_in - start_in) > MIN_LENGTH) {
        determine_ellipse_fit(start_in,finish_in,&major_axis,&minor_axis,
                    &rot_angle,&centre_x,&centre_y,
                    &max_dev,&arc_length,&arc_dir,&sig1);
    }
    else {
        representation_ok = FALSE;
        sig1 = LARGE_SIG;
    }

#if DEBUG
    printf("best fit ellipse: maj %f min %f rot %f ctr %d %d dev %f lgt %d size %d\n",
           major_axis,minor_axis,rot_angle,centre_x,centre_y,max_dev,arc_length,arc_dir);
#endif
    pos = global_pos + start_in - 1;

    number_arcs++;
    arc_sig[number_arcs] = sig1;
    arc_centre_x[number_arcs] = centre_x;
    arc_centre_y[number_arcs] = centre_y;
    arc_start_x[number_arcs] = x_c[start_in];   /* to change? */
    arc_start_y[number_arcs] = y_c[start_in];   /*      "     */
    arc_end_x[number_arcs] = x_c[finish_in];    /*      "     */
    arc_end_y[number_arcs] = y_c[finish_in];    /*      "     */
    arc_dirs[number_arcs] = arc_dir;
    maj_axis[number_arcs] = major_axis;
    min_axis[number_arcs] = minor_axis;
    rot_ang[number_arcs] = rot_angle;
    arc_start[number_arcs] = start_in;
    arc_finish[number_arcs] = finish_in;
    arc_status[number_arcs] = KEEP;
    if (((finish_in - start_in) <= MIN_LENGTH)
      || (max_dev < 3)
      || (STOP_EARLY == 1)) {
        /* at lowest level of recursion */
        /* save arc match at this lowest of levels */
        /* and significance */
        *sig_out = sig1;
    }
    else{
        /* recurse to next level down */
        segment(start_in,pos,&sig2);
        segment(pos,finish_in,&sig3);
        /* get best significance from lower level */
        if (sig2 < sig3)
            max_sig = sig2;
        else
            max_sig = sig3;
        if (max_sig < sig1) {
            /* return best significance, keep lower level description */
            *sig_out = max_sig;
        /* remove the single arc from start_in to finish_in */
        for (i = 0;i <= number_arcs;i++)
            if ((arc_start[i] == start_in) &&
                (arc_finish[i] == finish_in))
            arc_status[i] = REJECT;
        }
        else{
            /* line at this level is more significant */
            /* remove arcs at lower levels */
            /* i.e between start_in and finish_in */
            /* DOES IT EVER GET HERE ???? */
            printf("JUST REPLACED LOWER LEVEL ARCS\n");
            *sig_out = sig1;
            for (i = 0;i <= number_arcs;i++) {
                if ((arc_start[i] == start_in) &&
                    (arc_finish[i] == finish_in)) /* leave it */ {}
                else if ((arc_start[i] >= start_in)
                        && (arc_finish[i] <= finish_in))
                    arc_status[i] = REJECT;
            }
        }
    }
}

/*
int round(value)
float value;
{
    int i;

    i = floor(value + 0.5);
    return(i);
}
*/

float angle(float x1, float y1, float x2, float y2)
{

    float angle_temp;
    float xx,yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if (xx == 0.0)
        angle_temp = PI/2.0;
    else
        angle_temp = atan(fabs(yy/xx));
    if ((xx < 0.0) && (yy >= 0.0))
       angle_temp = PI - angle_temp;
    else if ((xx < 0.0) && (yy < 0.0))
       angle_temp = PI + angle_temp;
    else if ((xx >= 0.0) && ( yy < 0.0))
       angle_temp = PI*2.0 - angle_temp;
    return(angle_temp);
}

float euclid(float x1, float y1, float x2, float y2)
{
    float temp1,temp2;
    float dist;

    temp1 = fabs(x1-x2);
    temp2 = fabs(y1-y2);
    dist = sqrt(sqr(temp1)+sqr(temp2));
    return(dist);
}

void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2)
{
    /* rotate polygon segment (x1,y1) -> (x2,y2) to lie along x axis,
       compute the minimum distance between the line segment and
       a point on the circle defined as (x_cir,y_cir).
       take perpendicular distance if x_cir between end points else
       take euclidian distance to nearest end point.
    */
    float angle1;
    float x_off,y_off,cosine,sine;
    float temp;
    float min1,min2;

/*
    printf("entered compute_minimum_diff\n");
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    angle1 = angle(x1,y1,x2,y2);
    cosine = cos(-angle1);
    sine = sin(-angle1);
    x_off = x1;
    y_off = y1;
    /* offset points so x1,y1 at origin */
    x1 = 0;
    y1 = 0;
    x2 = x2 - x_off;
    y2 = y2 - y_off;
    x_cir = x_cir - x_off;
    y_cir = y_cir - y_off;
    /* rotate points with x2,y2 on x axis */
    temp = x2*cosine - y2*sine;
    y2 = x2*sine + y2*cosine;
    x2 = temp;
    temp = x_cir*cosine - y_cir*sine;
    y_cir = x_cir*sine + y_cir*cosine;
    x_cir = temp;
/*
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    min1 = euclid(x_cir,y_cir,x1,y1);
    min2 = euclid(x_cir,y_cir,x2,y2);
    if (x_cir < x1) {
        *deviation = min1;
    }else if (x_cir > x2) {
        *deviation = min2;
    }else{
        *deviation = fabs(y_cir);
    }
/*    printf("deviation: %f\n",*deviation,); */
}


void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir)
/*
New version that walks around hypothesised ellipse
finding minimum distance to polygon at each step.
Nearest point is either the perpendicular distance,
or the euclidian distance to the nearest end point.
For all cases the nearest end point is taken as the
possible break point. max_dev is the deviation,
max_pos is the vertex for max_dev,
major_axis,minor_axis define the ellipse
*/
{
    int l2;
    float l1,step;
    float s_ang,f_ang,temp;
    float x_cir,y_cir;
    float deviation;
    float min_dev;
    int min_pos;

    *max_dev = 0.0;

    /* determine angles */
    s_ang = angle(0.0,0.0,x_trans3[1]/major_axis,y_trans3[1]/minor_axis);
    f_ang = angle(0.0,0.0,
                  x_trans3[nseg2]/major_axis,y_trans3[nseg2]/minor_axis);
#if DEBUG
    printf("start coords: %f %f\n",x_trans3[1],y_trans3[1]);
    printf("finish coords: %f %f\n",x_trans3[nseg2],y_trans3[nseg2]);
    printf("angles: %f %f\n",s_ang,f_ang);
#endif
    /* default is anticlockwise, swap if clockwise */
    if (arc_dir == CLOCKWISE) {
        temp = s_ang;
        s_ang = f_ang;
        f_ang = temp;
    }
/* ang4 must be bigger than ang3 */
    if (f_ang < s_ang) {
        f_ang += PI*2.0;
    }
#if DEBUG
    printf("start angle: %f finish angle %f\n",s_ang,f_ang);
/* walk around circle from angle1 to angle2 */
    printf("walking around circle\n");
#endif
    step = (f_ang-s_ang)/10.0;    /* use 11 steps presently */
    l1 = s_ang;
    do{
        min_dev = 1000000;
        x_cir = cos(l1) * major_axis;
        y_cir = sin(l1) * minor_axis;
        /* printf("\nl1: %f (x_cir,y_cir): %f %f\n",l1,x_cir,y_cir);  */
        l2 = 1;
        do{
            /* printf("for line %d\n",l2);   */
            compute_minimum_diff(&deviation,x_cir,y_cir,x_trans3[l2],
                                 y_trans3[l2],x_trans3[l2+1],y_trans3[l2+1]);
            if (deviation < min_dev) {
                min_dev = deviation;
                min_pos = l2;
            }
            l2++;
        }while (l2 <= nseg2-1);
        /* printf("at this angle minimum deviation: %f at vertex: %d\n",
        min_dev,pos1);  */
        if (min_dev > *max_dev) {
            *max_dev = min_dev;
            *max_pos = min_pos;
        }
        l1 += step;
    }while (l1 <= f_ang);
#if DEBUG
    printf("maximum deviation: %f\n",*max_dev);
#endif
}

void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir)
{
    /* computes length of arc
    works on temporary data from determine_ellipse_fit
    i.e. data: (x_trans3,y_trans3),major_axis,minor_axis.
    new version computes start and finish angles, then
    arc length from angle and radius */

    float s_ang,f_ang,temp;
    float xold,yold,xnew,ynew;
    float step;

    s_ang = angle(0.0,0.0,x_trans3[1]/major_axis,y_trans3[1]/minor_axis);
    f_ang = angle(0.0,0.0,
                  x_trans3[nseg2]/major_axis,y_trans3[nseg2]/minor_axis);
    /* default is anticlockwise, so swap angles if clockwise */
    if (arc_dir == CLOCKWISE) {
       temp = s_ang;
       s_ang = f_ang;
       f_ang = temp;
    }
    /* start angle must be less that f_ang */
    if (f_ang < s_ang)
       f_ang += PI*2.0;
    *lgt = 0.0;
    xold = major_axis * cos(s_ang);
    yold = minor_axis * sin(s_ang);
    step = (f_ang - s_ang) / 20.0;
    temp = s_ang;
    do{
        temp += step;
        xnew = major_axis * cos(temp);
        ynew = minor_axis * sin(temp);
        *lgt = *lgt + distance(xold,yold,xnew,ynew);
        xold = xnew;
        yold = ynew;
    }while (temp <= f_ang);
}

void compute_poly_lgt(float *lgt)
{
    int loop1;
    float dx,dy;

    *lgt = 0;
    for (loop1 = 1;loop1 < nseg2;loop1++) {
        dx = x_trans3[loop1] - x_trans3[loop1+1];
        dy = y_trans3[loop1] - y_trans3[loop1+1];
        *lgt += sqrt(sqr(dx) + sqr(dy));
    }
}

/*
 Determine the best fit ellipse using Paul's robust kalman filter
 hack.
*/

void determine_ellipse_fit(int st, int fi, float *final_major_axis, float * final_minor_axis, float * final_rot_angle, int *final_xc, int *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig)
{
    /* ellipse fitting variables */
    float m[7];   /* coefficients of best fit ellipse */

    /* new variables for lms fitting */
    float x_cent,y_cent;
    float c_ang;

    /* original variables */
    float xt,yt;   /* temp variables */
    float x_cent_t,y_cent_t; /* temp centre coords - after transformation */
    float sine,cosine;
    float max_dev,arc_length,poly_length;
    int loop1,loop2;
    int max_pos;
    float sum,ratio;
    float temp;
    int arc_size;
    float x_off,y_off;
    float major_axis,minor_axis,rot_angle;
    float xs,ys,xf,yf;
    float x_org,y_org;

    float angle_s,angle_f,diff_angle;

    /*
       set representation_ok to TRUE - set to FALSE by any code that
       cannot fit the representation to the data
    */
    representation_ok = TRUE;

#if DEBUG
    printf("\n\entering determine_ellipse_fit for data from: %d to %d\n",st,fi);
#endif

    /* get data into temp array */
    nseg2 = 0;
    for (loop1 = st;loop1 <= fi;loop1++) {
       nseg2++;
       x_trans3[nseg2] = x_c[loop1];
       y_trans3[nseg2] = y_c[loop1];
    }
    
    /* shift data to the origin to minimise numerical errors */
    x_org = y_org = 0;
    for (loop1=1; loop1<=nseg2; loop1++) {
       x_org += x_trans3[loop1];
       y_org += y_trans3[loop1];
    }
    x_org /= nseg2; y_org /= nseg2;
    for (loop1=1; loop1<=nseg2; loop1++) {
       x_trans3[loop1] -= x_org;
       y_trans3[loop1] -= y_org;
    }

    /* scale values from 0 to 1 for kalman filter by dividing by 512 */
    for (loop1=1; loop1<=nseg2; loop1++) {
        x_trans3[loop1] /= 512.0;
        y_trans3[loop1] /= 512.0;
    }

    determine_ellipse_lms3(m);
    if (representation_ok == FALSE)
       return;
#if DEBUG
    printf("coefficients for fitted ellipse:\n");
    printf("%2.3f %2.3f %2.3f %2.3f %2.3f %2.3f\n",
           m[1],m[2],m[3],m[4],m[5],m[6]);
#endif

   /* determine arc_size
    * transform temp to lie along x axis, then compute average displacement
    * of y coords. If +ve then circle on +ve side of axis else on -ve. This
    * in combination with the position of the centre will indicate if the are
    * is large (>180 degrees) or small (<=180 degrees). Also can determine if
    * arc is clockwise or anticlockwise
    * rotate and translate temp data.
    * take chord between points, rotate so that chord is
    * along x axis - rotate and translate all other points the same.
    */
    c_ang = angle(x_trans3[1],y_trans3[1],x_trans3[nseg2],y_trans3[nseg2]);
    sine = sin(-c_ang);
    cosine = cos(-c_ang);

    /* translate so first point is at origin */
    x_off = x_trans3[1];
    y_off = y_trans3[1];
    for (loop1 = 1;loop1 <= nseg2;loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - x_off;
        y_trans3[loop1] = y_trans3[loop1] - y_off;
    }
    /* rotate to align chord with x axis */
    for (loop1 = 1;loop1 <= nseg2;loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt*cosine - yt*sine;
        x_trans3[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans3[loop1] = temp;
    }
    /* do same for centre */
    x_cent = (-m[4]*m[3]/2.0 + m[5]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);
    y_cent = (-m[1]*m[5]/2.0 + m[4]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);

    xt = x_cent - x_off;
    yt = y_cent - y_off;
    temp = xt*cosine - yt*sine;
    x_cent_t = temp;
    temp = xt*sine + yt*cosine;
    y_cent_t = temp;

    /* compute average y coord of all points */
    sum = 0.0;
    for (loop1=1;loop1<=nseg2;loop1++)
        sum += y_trans3[loop1];

    /* determine size and sense of arc */
        if ((sum >= 0.0) && (y_cent_t >= 0.0)) {
        arc_size = BIG;
        *arc_dir = CLOCKWISE;
    }
    else if ((sum < 0.0) && (y_cent_t < 0.0)) {
        arc_size = BIG;
        *arc_dir = ANTICLOCKWISE;
    }
    else if ((sum >= 0.0) && (y_cent_t < 0.0)) {
        arc_size = SMALL;
        *arc_dir = CLOCKWISE;
    }
    /* CHANGED Y_CENT TO Y_CENT_T - PLR */
    else if ((sum < 0.0) && (y_cent_t >= 0.0)) {
        arc_size = SMALL;
        *arc_dir = ANTICLOCKWISE;
    }
/*
    printf("SUM: %f\n",sum*512/nseg2);
*/
    /* !!! FOR VERY FLAT SECTIONS !!! */
    if (fabs(sum*512/nseg2) < 3.0) {
       angle_s = angle(x_cent_t,y_cent_t,x_trans3[1],y_trans3[1]);
       angle_f = angle(x_cent_t,y_cent_t,x_trans3[nseg2],y_trans3[nseg2]);
       diff_angle = angle_f - angle_s;
       if (diff_angle < 0) diff_angle += (PI*2.0);
       if (diff_angle < PI)
          *arc_dir = ANTICLOCKWISE;
       else
          *arc_dir = CLOCKWISE;
    }

#if DEBUG
    if (arc_size == SMALL)
        printf("small arc ");
    else
        printf("big arc ");
    if (*arc_dir == CLOCKWISE)
        printf("direction clockwise\n");
    else
        printf("direction anticlockwise\n");
#endif

    /*
    for (loop2=1;loop2<=nseg2;loop2++)
        printf("x_trans3: %f y_trans3: %f\n",x_trans3[loop2],y_trans3[loop2]);
    */

    /* convert coefficients to more meaningful parameters */
    determine_parameters(m,&major_axis,&minor_axis,&rot_angle);
    if (representation_ok == FALSE)
       return;
    /* scale parameters to image space */
    major_axis *= 512.0;
    minor_axis *= 512.0;
    x_cent *= 512.0;
    y_cent *= 512.0;
    /* shift ellipse back from origin */
    x_cent += x_org;
    y_cent += y_org;

#if DEBUG
    printf("parameters of ellipse:\n");
    printf("major_axis axis: %f minor_axis_axis %f\n",major_axis,minor_axis);
    printf("rotation angle of major_axis axis: %f\n",rot_angle);
    printf("centre: %f %f\n",x_cent,y_cent);
#endif

    xs = x_c[st];
    ys = y_c[st];
    xf = x_c[fi];
    yf = y_c[fi];

/* transform data so the major_axis axis of the ellipse is along the x axis */
/* get data into temp arrays */
    nseg2 = 0;
    for (loop1 = st;loop1 <= fi;loop1++) {
        nseg2++;
        x_trans3[nseg2] = x_c[loop1];
        y_trans3[nseg2] = y_c[loop1];
    }
/* first translate */
    for (loop1=1;loop1<=nseg2;loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - x_cent;
        y_trans3[loop1] = y_trans3[loop1] - y_cent;
    }
/* now rotate */
    sine = sin(-rot_angle);
    cosine = cos(-rot_angle);
    for (loop1=1;loop1<=nseg2;loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt*cosine - yt*sine;
        x_trans3[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans3[loop1] = temp;
    }
    x_cent_t = 0.0;
    y_cent_t = 0.0;

/*
determine length of ellipse for this circle approx - use data
transformed to put major axis along x axis
*/
    compute_lgt(&arc_length,major_axis,minor_axis,*arc_dir);

/*
determine actual length of data - a polygon here
*/
    compute_poly_lgt(&poly_length);

/*
determine position and value of the maximum deviation - use data
transformed to put major axis along x axis
*/
    compute_dev(&max_dev,&max_pos,major_axis,minor_axis,*arc_dir);

/*
hack to stop breakpoint near ends - to be modified
break at middle of data if too close to end points
*/
    if ((max_pos <= MIN_LENGTH) || (max_pos > nseg2-MIN_LENGTH))
        max_pos = nseg2 / 2;

#if DEBUG
    printf("arc length: %f\n",arc_length);
    printf("poly length: %f\n",poly_length);
    printf("maximum deviation: %f\n",max_dev);
    printf("point of maximum deviation: %d\n",max_pos);
#endif

/* *****
compute significance based on max_dev, arc_length and
some heuristics!
**** */
/* polygonal length should be similar to arc length */
    ratio = poly_length / arc_length;
    if (ratio < 1)
        ratio = arc_length / poly_length;


/* save parameters for best ellipse as integers */
    *final_major_axis = major_axis;
    *final_minor_axis = minor_axis;
    *final_rot_angle = rot_angle;
    *final_xc = round(x_cent);
    *final_yc = round(y_cent);
    *final_lgt = arc_length;
    max_dev = max_dev * ratio;        /* temp to modify sig */
    *final_dev = max_dev;

    if ((max_dev != 0.0) && (arc_length != 0))
        *sig = max_dev / (float)arc_length;
    else
        *sig = LARGE_SIG;

/* save position of maximum deviation */
    global_pos = max_pos;
}


float distance(double x1, double y1, double x2, double y2)
{
    return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

/* new improved version that works analytically thanks to Alah */
void determine_parameters(float m[], float *major_axis, float *minor_axis, float *rot_angle)
{
    float a,b,c,d,e,f;
    float ca,sa;
    float t,u,v,w;

    a = m[1];
    b = m[2];
    c = m[3];
    d = m[4];
    e = m[5];
    f = m[6];

    if (a == c)
       *rot_angle = 0;
    else
       *rot_angle = atan(b/(a-c)) / 2.0;
    ca = cos(*rot_angle);
    sa = sin(*rot_angle);
    t = a*sqr(ca)+b*ca*sa+c*sqr(sa);
    u = a*sqr(sa)-b*ca*sa+c*sqr(ca);
    v = d*ca+e*sa;
    w = -d*sa+e*ca;
    *major_axis = sqrt(((sqr(v)/(4*t))+(sqr(w)/(4*u))-f)/t);
    *minor_axis = sqrt(((sqr(v)/(4*t))+(sqr(w)/(4*u))-f)/u);
}

/*
int strcmp(s,t)
char s[],t[];
{
    int i;

    i = 0;
    while (s[i] == t[i])


        if (s[i++] == '\0')
            return(0);
    return(s[i] - t[i]);
}
*/

/*
 *  code below used to be in determ3.c
 *  fits ellipses to data using a kalman filter
 *  abort when any error condition occurs - that is cannot fit an ellipse
 *  Paul Rosin
 *  January 1990
 */

int find_conic_type(double c1, double c2, double c3)
{
    float fx;
    int temp;

    fx = c1 * c3 - c2 * c2 / 4;
    if (fx > 0)
        temp = ELLIPSE;
    else if (fx < 0)
        temp = HYPERBOLA;
    else
        temp = PARABOLA;
    return(temp);
}

void determine_ellipse_lms3(float m[])
{
    float little_lambda,big_lambda,mid_lambda;

    lambda = little_lambda = 0;
    big_lambda = 2;

    run_lms_fitting(m);

    if (conic_type != ELLIPSE) {
        /*
        printf("initial range: %2.1f -> %2.1f\n",
            little_lambda,big_lambda);
        */
        while ((big_lambda - little_lambda) > LAMBDA_DIFF) {
            mid_lambda = (big_lambda + little_lambda) / 2.0;
            lambda = mid_lambda;
            /*
            printf("rerun HB with lambda: %f\n",lambda);
            */
            run_lms_fitting(m);
            if (conic_type == ELLIPSE) {
                big_lambda = mid_lambda;
            }
            else {
                little_lambda = mid_lambda;
            }
            /*
            printf("new range: %2.2f -> %2.2f\n",
                little_lambda,big_lambda);
            */
         }
         /*
          * run again to make sure it's fitting to lower value
          * and fitting an ellipse
          */
        lambda = big_lambda;
        /*
        printf("final run of HB with lambda: %f\n",lambda);
        */
        run_lms_fitting(m);
    }

#if DEBUG
    printf("conic type: %d\n",conic_type);
#endif
}

/* Henrick Bendtson's formulation */
void run_lms_fitting(float m[7])
{
    int j;
    float sx,sx2,sy,sy2,sxy,sx2y,sxy2;
    float sdx2y2xy,sdx2y2x,sdx2y2y,sdx2y2;
    float sy3,sxy3;
    float dx2y2,xy,x,y;
    float x2,y2,y3;
    float m1[6][6];
    float m2[6];
    int indx[6];
    float d;
    float snew1,snew2,snew3;

    sx = sx2 = sy = sy2 = sxy = sx2y = sxy2 = 0;
    sdx2y2xy = sdx2y2x = sdx2y2y = sdx2y2 = 0;
    sy3 = sxy3 = 0;
    snew1 = snew2 = snew3 = 0;

    for (j = 1; j <= nseg2; j++) {
        x = x_trans3[j];
        y = y_trans3[j];
        x2 = x * x;
        y2 = y * y;
        y3 = y * y * y;
        xy = x * y;
        dx2y2 = x2 - y2;
  
        sx += x;
        sx2 += x2;
        sy += y;
        sy2 += y2;
        sy3 += y3;
        sxy += xy;
        sx2y += (x2 * y);
        sxy2 += (x * y2);
        sxy3 += (x * y3);
  
        sdx2y2xy += (dx2y2 * xy);
        sdx2y2x += (dx2y2 * x);
        sdx2y2y += (dx2y2 * y);
        sdx2y2 += dx2y2;

        snew1 += sqr(dx2y2) + 4*nseg2*lambda;
        snew2 += (x2 * y2) + 4*nseg2*lambda;
        snew3 += (dx2y2 * y2) - 2*nseg2*lambda;
    }
 
    m1[1][1] = snew1;
    m1[2][1] = sdx2y2xy;
    m1[3][1] = sdx2y2x;
    m1[4][1] = sdx2y2y;
    m1[5][1] = sdx2y2;
    m1[1][2] = sdx2y2xy;
    m1[2][2] = snew2;
    m1[3][2] = sx2y;
    m1[4][2] = sxy2;
    m1[5][2] = sxy;
    m1[1][3] = sdx2y2x;
    m1[2][3] = sx2y;
    m1[3][3] = sx2;
    m1[4][3] = sxy;
    m1[5][3] = sx;
    m1[1][4] = sdx2y2y;
    m1[2][4] = sxy2;
    m1[3][4] = sxy;
    m1[4][4] = sy2;
    m1[5][4] = sy;
    m1[1][5] = sdx2y2;
    m1[2][5] = sxy;
    m1[3][5] = sx;
    m1[4][5] = sy;
    m1[5][5] = nseg2;
 
    m2[1] = -snew3;
    m2[2] = -sxy3;
    m2[3] = -sxy2;
    m2[4] = -sy3;
    m2[5] = -sy2;
 
    /* solve simultaneous equations */
    ludcmp(m1,5,indx,&d);
    if (!representation_ok) {
        return;
    }
    lubksb(m1,5,indx,m2);
 
    m[1] = m2[1];
    m[2] = m2[2];
    m[3] = 1 - m2[1];
    m[4] = m2[3];
    m[5] = m2[4];
    m[6] = m2[5];
    conic_type = find_conic_type(m[1],m[2],m[3]);
}

/* LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void ludcmp(float a[6][6], int n, int indx[6], float *d)
{
        int i,imax,j,k;
        float big,dum,sum,temp;
        float vv[6];

        *d = 1.0;
        for (i = 1; i <= n; i++) {
                big = 0.0;
                for (j = i; j <= n; j++)
                        if ((temp = fabs(a[i][j])) > big) big = temp;
                if (big == 0.0) {
                    representation_ok = FALSE;
                    return;
                }
                vv[i] = 1.0/big;
        }
        for (j = 1; j <= n; j++) {
                for (i = 1; i < j; i++) {
                        sum = a[i][j];
                        for (k = 1; k < i; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                }
                big = 0.0;
                for (i = j; i <= n;i++) {
                        sum = a[i][j];
                        for (k = 1; k < j; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                        if ( (dum = vv[i]*fabs(sum)) >= big) {
                                big = dum;
                                imax = i;
                        }
                }
                if (j != imax) {
                        for (k = 1; k <= n; k++) {
                                dum = a[imax][k];
                                a[imax][k] = a[j][k];
                                a[j][k] = dum;
                        }
                        *d = -(*d);
                        vv[imax] = vv[j];
                }
                indx[j] = imax;
                if (a[j][j] == 0.0) a[j][j] = TINY;
                if (j != n) {
                        dum = 1.0/(a[j][j]);
                        for (i = j+1; i <= n ;i++) a[i][j] *= dum;
                }
        }
}

/* forward substitution & backsubstitution */
/* use with LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void lubksb(float a[6][6], int n, int indx[6], float b[6])
{
        int i,ii=0,ip,j;
        float sum;

        for (i=1;i<=n;i++) {
                ip = indx[i];
                sum = b[ip];
                b[ip] = b[i];
                if (ii)
                        for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
                else if (sum) ii = i;
                b[i] = sum;
        }
        for (i=n;i>=1;i--) {
                sum = b[i];
                for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
                b[i] = sum/a[i][i];
        }
}

void error(char s[])
{
   printf("ERROR: %s\n",s);
   exit(-1);
}

