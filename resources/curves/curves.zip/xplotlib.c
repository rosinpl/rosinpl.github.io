/* 
    xplotlib.c - an X version of plotlib.c (sunview)

    uses the basicwin prog with an image structure to 
    plot images annd line/pixel/arc/ellipse data

    used Xlib for the basic functions


    routines for the selection of the correct method of plotting for
    the chosen display device 
    this version for sunview.
    
    only basic procedures are here such as move, draw, putpixel,
    opendevice,closedevice,setcolor
    
    for most if not all uses of these routines only a small number of
    colours are used at any one time

    Modified 20-July-1992 by GAWW
    Uses malloc for image array so any size image allowed.
    Default still 512x512

    Modified 26-October-1993 by PLR
    can zoom image

    Modified 22-September-1997 by PLR
    terrible hack to get it working again
    halve image intensities and double colour map

    Some updates (additions and deletions) to get it working on linux
    PLR December 2003
*/

#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include "malloc_image.h"
#include "plotstuff.h"

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>

#define MIN_GRAY 7

#include "plotdata.bitmap"

/* X windows structures etc */
Display *display;
int screen;
Window win;
char *icon_name = "xplotdata";
Pixmap icon_pixmap;
XSizeHints size_hints;
XEvent report;
GC gc;
XImage *xi;
XFontStruct *font_info;
char *display_name = NULL;
Colormap cmap;
XColor color, exact;
Visual *visual;
XGCValues values;

unsigned int border_width = 4;

unsigned int display_width,display_height,display_depth;

char current_colour[50];

int current_x,current_y;  /* saves current plot point */
char window_label[255];   /* label for top of window */
unsigned char *image;              /* array for plotting image etc. */
int **image2;             /* array for storing 2 byte image */
float x_scale=1,y_scale=1;
float aspect_ratio = 1.0;
int xoff=0,yoff=0;        /* offset plotting in window */

/* variables for implementing Postscript output */
int line_width = 0;       /* save as a global - save repetition */
int ps_dump;              /* is Postscript output required? */
int ps_raw;               /* scale/translate Postscript? */
FILE *fp_ps;              /* file to dump Postscript to */
float gray_val = 0;
float prev_gray_val = 0;
int already_done_ps = FALSE;   /* switch to temporarily turn off PS */
int border;
extern int do_output_list_numbers;
extern float zoom;
extern int height;
extern int ps_fill;              /* colour in pixel list regions */

int mapping;

move(xpix,ypix)
float xpix,ypix;
{
    float fx,fy;

    fx = xpix * x_scale;
    fy = ypix * y_scale * aspect_ratio;
    current_x = fx + xoff + 0.5;
    current_y = fy + yoff + 0.5;

    if ((ps_dump) && (!already_done_ps)) {
        /* finish off last line */
        if (ps_fill)
            fprintf(fp_ps,"closepath\nfill\n");
        else
            fprintf(fp_ps,"stroke\n");

        if (ps_raw)
            fprintf(fp_ps,"%.2f %.2f moveto\n",xpix,ypix);
        else
            fprintf(fp_ps,"%.2f %.2f moveto\n",xpix,height-ypix);
    }
}

draw(option,xpix,ypix)
int option;
float xpix,ypix;
{
    float fx,fy;
    int x,y,xx,yy;

    fx = xpix * x_scale;
    fy = ypix * y_scale * aspect_ratio;
    x = fx + xoff + 0.5;
    y = fy + yoff + 0.5;
    XDrawLine(display,win,gc,current_x,current_y,x,y);

    if (option == 1) {
       for (yy = -1; yy <= 1; yy++)
           for (xx = -1; xx <= 1; xx++)
              XDrawLine(display,win,gc,current_x+xx,current_y+yy,x+xx,y+yy);
    }
    current_x = x;
    current_y = y;

    if ((ps_dump) && (!already_done_ps)) {
        if (option != line_width) {
            if (option == 0)
                fprintf(fp_ps,"1 setlinewidth\n");
            else
                fprintf(fp_ps,"3 setlinewidth\n");
        }
        if (gray_val != prev_gray_val) {
            fprintf(fp_ps,"stroke\n");
            fprintf(fp_ps,"%.2f setgray\n",gray_val);
            if (ps_raw)
                fprintf(fp_ps,"%.2f %.2f moveto\n",xpix,ypix);
            else
                fprintf(fp_ps,"%.2f %.2f moveto\n",xpix,height-ypix);
            prev_gray_val = gray_val;
        }
        if (ps_raw)
            fprintf(fp_ps,"%.2f %.2f lineto\n",xpix,ypix);
        else
            fprintf(fp_ps,"%.2f %.2f lineto\n",xpix,height-ypix);
        /* save option as global */
        line_width = option;
    }
}

put_pixel(option,xpix,ypix)
int option;
float xpix,ypix;
{
    int x,y;

    // ?? XSetForeground(display,gc,current_colour);
    x = floor(xpix * x_scale + xoff);
    y = floor(ypix * y_scale * aspect_ratio + yoff);
    XDrawPoint(display,win,gc,x,y);
}

open_device(startx,starty,width,height,lut)
int startx, starty,width,height;
int lut;
{
    float image_scale;
    int i;
    int argc = 0;        /* dummy - not needed */
    char **argv = NULL;  /* dummy - not needed */

    /* malloc space for the image */
    image = (unsigned char *)malloc(width*height*sizeof(char));
    if (image == NULL) {
        printf("cannot malloc space for the image - aborting\n");
        exit(1);
    }

    /* connect to X server */

    if ((display = XOpenDisplay(display_name)) == NULL) {
        fprintf(stderr,"xplotdata: cannot connect to X server %s\n",
                        XDisplayName(display_name));
        exit(-1);
    }

    screen = DefaultScreen(display);

    display_depth = DisplayPlanes(display,screen);
    display_width = width;
    display_height = height;
    
    visual = DefaultVisual(display,screen);
    cmap = DefaultColormap(display,screen);

    /* new version - can alter lut's etc */
    //modified to work when porting to Linux
    win = XCreateSimpleWindow(display,RootWindow(display,screen),
                        (unsigned int)startx,(unsigned int)starty,
                        display_width,display_height,border_width,
                        128,50);

    icon_pixmap = XCreateBitmapFromData(display,win,plotdata_bits,
                    plotdata_width,plotdata_height);
    
    size_hints.flags = PPosition | PSize | PMinSize;
    size_hints.x = startx;
    size_hints.y = starty;
    size_hints.width = width;
    size_hints.height = height;

    XSetStandardProperties(display,win,window_label,
                        icon_name,icon_pixmap,
                        argv,argc,&size_hints);

    XSelectInput(display,win,ExposureMask | KeyPressMask |
                    ButtonPressMask | StructureNotifyMask);

    XSetWindowBackground(display,win,0);
    
    load_font(&font_info);

    get_GC(win,&gc,font_info);
    
    //printf("DISPLAY IS %s\n",visual_class_name(visual->class));

    XClearWindow(display,win);

    XMapWindow(display,win);
    
    /* XFlush(display); */

    wait_for_server();

    create_image(width,height);
}

set_colour(new_colour)
char new_colour[50];
{
    strcpy(current_colour,new_colour);
    XAllocNamedColor(display, cmap, current_colour, &color, &exact);
    XSetForeground(display,gc,color.pixel);
}
                                                                                      
open_graph(startx,starty,width,height)
int startx,starty,width,height;
/*
    sets lookup tables etc.
    grey levels above 240 are for colour plotting
*/
{
    int white,red,green,blue;
    int size,x1,x2,y1,y2;

    open_device(startx,starty,width,height);
}

store_current_image()
{
    unsigned long plane_mask = 255;

    xi = XGetImage(display,win,0,0,
                   size_hints.width,size_hints.height,
                   plane_mask,ZPixmap);
}
    
close_graph()
{
    int x,y;

    /* make sure all plotting done */
    
    XFlush(display);
    /* wait_for_server(); */
    
    store_current_image();

    while(1) {
        XNextEvent(display,&report);
        switch(report.type) {
            case Expose:
                while(XCheckTypedEvent(display,Expose,&report));
                XPutImage(display,win,gc,xi,0,0,0,0,
                            size_hints.width,size_hints.height);
                /* printf("e: %d\n",report.type); */
                break;
            case ConfigureNotify:
                size_hints.width = report.xconfigure.width;
                size_hints.height = report.xconfigure.height;
                /* printf("c: %d\n",report.type); */
                break;
            case ButtonPress:
                x = report.xbutton.x;
                y = report.xbutton.y;
                if (zoom == 1)
                    printf("pressed button at: %3d %3d\n",x,y);
                else
                    printf("pressed button at: %3d %3d (%3d %3d)\n",
                           x,y,(int)(x/zoom),(int)(y/zoom));
                if (do_output_list_numbers)
                    output_list_numbers(x,y);
                break;
            case KeyPress:
                XUnloadFont(display,font_info->fid);
                XFreeGC(display,gc);
                XDestroyImage(xi);
                XCloseDisplay(display);
                /* printf("k: %d\n",report.type); */
                /* exit(1); */
            default:
                /* printf("d: %d\n",report.type); */
                break;
        }
    }

    /*pf_close(font1); */
}



kill_graph()
{
    /* make sure all plotting done */
    
    XFlush(display);
    /* wait_for_server(); */
    
    store_current_image();

    XUnloadFont(display,font_info->fid);
    XFreeGC(display,gc);
    XDestroyImage(xi);
    XCloseDisplay(display);
}

outtextxy(x,y,text)
int x,y;
char text[];
{
    int len1;
    float fx,fy;

    fx = x * x_scale;
    fy = y * y_scale * aspect_ratio;
    
    // ??? XSetForeground(display,gc,current_colour);
    len1 = strlen(text);
    XDrawString(display,win,gc,(int)fx,(int)fy,text,len1);

    if (ps_dump) {
        fprintf(fp_ps,"%.1f %.1f moveto\n",fx,height-fy);
        fprintf(fp_ps,"(%s) show\n",text);
    }
}

print_val(x,y,val)
int x,y;
int val;
{
    int len1;
    char text[10];

    sprintf(text,"%d",val);

    // ??? XSetForeground(display,gc,current_colour);
    len1 = strlen(text);
    XDrawString(display,win,gc,x,y,text,len1);
}

/* plots an image in a window */
plot_image(width,height,image)
char *image;
int width,height;
{
     xi->data = image;
     XPutImage(display,win,gc,xi,0,0,0,0,width,height);
}

/* plots a portion of the image in a window */
plot_image_bit(x1,y1,x2,y2,image)
char *image;
int x1,x2,y1,y2;
{
     xi->data = image;
     XPutImage(display,win,gc,xi,x1,y1,x1,y1,x2-x1+1,y2-y1+1);
}

/* plots an image in a window */
plot_image2(width,height,im)
unsigned char **im;
int width,height;
{
     int x,y;

     for (y = 0; y < height; y++)
         for (x = 0; x < width; x++)
             *(image+x+y*width) = im[x][y];

     xi->data = image;
     XPutImage(display,win,gc,xi,0,0,0,0,width,height);
}


/*
 * reads 1 byte/pixel images into "image" or 2 byte/pixel images into
 * "image2" and rescaled version into "image"

######## NOT FINISHED 2byte STUFF !!!!!!!!!!!!!!!!!!!!!!
 */
read_plot_image(file_name,option,width,height,use_all_colours,zoom,no_bytes,lut)
char file_name[];
int option,width,height,use_all_colours;
float zoom;
int no_bytes;
int lut;
{
    FILE *fp;
    int i,j;
    unsigned char *im;
    unsigned char **tmp;
    int **tmp2;
    int x,y;
    unsigned int max_x,max_y;
    int max_grey = 245;

    /*
        option = TRUE plots image else just reads
        use_all_colours = 1 then use all the 256 colours
        use_all_colours = 0 then use colours from 6 to 245 only 
            image is truncated to use these colours only
    */
    /* 
        maps image to be from 6 to 245 to allow other colours for overlays
        and for the screen to remain in view when mouse in window 
        note colours 0, 254 and 255 have significance in Sunview
    */

    if ((fp=fopen(file_name,"r")) == NULL) {
        printf("cant open %s\n",file_name);
        exit(1);
    }

    im = image;
    tmp = malloc_char_image(width,height);

    /* read in image */
    if (no_bytes == 1) {
        read_image(tmp,file_name,width,height);

        /* hack: because I can't get 128-255 image values to work
         * so I'll have to make do with only 0-127, and halve image
         * intensities!
         */
         /*******************
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                tmp[x][y] /= 2;
         **********/
                
        /* transform image if desired */
        switch(mapping) {
            case NONE:
                break;
            case LOG:
                do_log1(tmp,width,height);
                break;
            case RESCALE:
                do_rescale1(tmp,width,height);
                break;
            default:
                fprintf(stderr,"ERROR: unknown image mapping type: %d\n",
                    mapping);
                exit(-1);
        }
    }
    else if (no_bytes == 2) {
        tmp2 = malloc_int_image(width,height);
        read_image2(tmp2,file_name,width,height);

        /* transform image if desired */
        switch(mapping) {
            case NONE:
                fit_1_2(tmp2,tmp,width,height);
                break;
            case LOG:
                /*
                do_log1(tmp2,tmp,width,height);
                */
                break;
            case RESCALE:
                do_rescale2(tmp2,tmp,width,height);
                break;
            default:
                fprintf(stderr,"ERROR: unknown image mapping type: %d\n",
                    mapping);
                exit(-1);
        }
    }
    else {
        printf("ERROR: incorrect number of bytes/pixel\n");
        return;
    }

    /* blow up image */
    max_x = width*zoom;
    max_y = height*zoom;
    for (y = 0; y < max_y; y++)
        for (x = 0; x < max_x; x++)
            *(im+x+y*max_x) = tmp[(int)(y/zoom)][(int)(x/zoom)];

    if (lut == GREY_COLOUR2)
        max_grey = 234;
    if (!use_all_colours) {
        im = image;
        for (i=0;i<max_x*max_y;i++) {
            if ((unsigned char)*im > max_grey) 
                *im = max_grey;
            else if ((unsigned char)*im < MIN_GRAY) 
                *im = MIN_GRAY;
            im++;
        }
    }

    if (option) {
        /* ????? ADDED PLR 2003 - just a guess! */
        xi->data = image;

        /* THE PROBLEM - I think I need to sort out the pixel depth
         * i.e. the display has R, G, B planes now
         */
        //XPutImage(display,win,gc,xi,0,0,0,0,max_x,max_y);
    }
}

/* log map image */
do_log1(image,width,height)
unsigned char **image;
int width,height;
{
    int x,y;
    double **tmp;
    double factor,val,min_val,max_val;

    printf("log mapping image\n");

    tmp = malloc_double_image(width,height);

    val = log(1.0+(double)image[0][0]);
    max_val = min_val = val;
    for (y=0;y<height;y++) {
        for (x=0;x<width;x++) {
            val = log(1.0+(double)image[y][x]);
            tmp[y][x] = val;
            if (val > max_val) max_val = val;
            if (val < min_val) min_val = val;
        }
    }

    /* rescale */
    factor = 255.0/(max_val-min_val);
    for(y=0;y<height;y++)
        for(x=0;x<width;x++)
            image[y][x] = (unsigned char)((tmp[y][x]-min_val)*factor);

    free_double_image(tmp,height);
}

/* rescale image to 0-> 255 */
do_rescale1(image,width,height)
unsigned char **image;
int width,height;
{
    int x,y;
    int val,min_val,max_val;
    double factor;

    val = image[0][0];
    max_val = min_val = val;
    for (y=0;y<height;y++) {
        for (x=0;x<width;x++) {
            val = image[y][x];
            if (val > max_val) max_val = val;
            if (val < min_val) min_val = val;
        }
    }

    /* rescale */
    factor = 255.0/(max_val-min_val);
    printf("rescaling image by %.2f (max val = %d)\n",factor,max_val);
    for(y=0;y<height;y++)
        for(x=0;x<width;x++)
            image[y][x] = (unsigned char)
                (((unsigned int)image[y][x]-min_val)*factor);
}

/* rescale image to 0-> 255 */
/* 2 byte/pixel image into 1 byte/pixel */
do_rescale2(image2,image1,width,height)
int **image2;
unsigned char **image1;
int width,height;
{
    int x,y;
    unsigned int val,min_val,max_val;
    double factor;

    printf("rescaling image ");

    val = (unsigned int)image2[0][0];
    max_val = min_val = val;
    for (y=0;y<height;y++) {
        for (x=0;x<width;x++) {
            val = (unsigned int)image2[y][x];
            if (val > max_val) max_val = val;
            if (val < min_val) min_val = val;
        }
    }

    /* rescale */
    factor = 255.0/(unsigned int)(max_val-min_val);
    printf("by %.2lf\n",factor);
    for(y=0;y<height;y++)
        for(x=0;x<width;x++)
            image1[y][x] = (unsigned char)((image1[y][x]-min_val)*factor);
}

/* convert a 2 byte/pixel image into 1 byte/pixel */
fit_1_2(image2,image1,width,height)
int **image2;
unsigned char **image1;
int width,height;
{
    int x,y;
    unsigned int val,min_val,max_val;
    double factor;

    printf("squeezing 2 byte/pixel image into 1 2 byte/pixel\n");

    for (y=0;y<height;y++) {
        for (x=0;x<width;x++) {
            image1[y][x] = image2[y][x] / 256;
        }
    }
}

create_image(width,height)
unsigned int width,height;
{
    xi = XCreateImage(display,      /* the display */
                      visual,       /* default visual */
                      8,            /* bit depth */
                      ZPixmap,      /* image format */
                      0,            /* bit offset */
                      image,        /* image data */
                      width,        /* image width */
                      height,       /* image height */
                      8,            /* scan line quantum */
                      width);       /* bytes per scan line */
}


/* 
    dumps an image to a file - should work by grabbing the image structure
    from the screen - using XGetPixel for now - slower
*/
dump_image(file_name,width,height)
char file_name[];
int width,height;
{
    int x,y;
    FILE *fp;
    unsigned char pix;

    XFlush(display); 
    /* wait_for_server(); */
    store_current_image();
    
    printf("dumping current image\n");
    if ((fp=fopen(file_name,"w")) == NULL) {
        printf("cant open %s\n",file_name);
        exit(1);
    }

    fprintf(fp,"P5\n");
    fprintf(fp,"#created by Paul Rosin\n");
    fprintf(fp,"%d %d\n",width,height);
    fprintf(fp,"255\n");
    
    if (border) {
        unsigned long val = 0;
        for (y=0;y<height;y++) {
            XPutPixel(xi,0,y,val);
            XPutPixel(xi,width-1,y,val);
        }
        for (x=0;x<width;x++) {
            XPutPixel(xi,x,0,val);
            XPutPixel(xi,x,height-1,val);
        }
    }
    for (y=0;y<height;y++) {
        for (x=0;x<width;x++) {
            pix = (unsigned char) XGetPixel(xi,x,y);
            putc(pix,fp);
        }
    }
    fclose(fp);
}

/* clear pixels to white */
void clear_window()
{
    XClearWindow(display,win);
}


load_font(font_info)
XFontStruct **font_info;
{
    /* char *fontname ="9x15"; */
    /* char *fontname ="5x8"; */
    char *fontname ="6x10";    /* works with X11 R5 and Sun Openwin 2 */

    if ((*font_info = XLoadQueryFont(display,fontname)) == NULL) {
        (void) fprintf(stderr,"Basic: Cannot open %s font\n",fontname);
        exit(-1);
    }
}


get_GC(win,gc,font_info)
Window win;
GC *gc;
XFontStruct *font_info;
{
    unsigned long valuemask = 0;
    unsigned int line_width = 1;
    int line_style = LineSolid;
    int cap_style = CapRound;
    int join_style = JoinRound;
    int dash_offset = 0;
    static char dash_list[] = { 12, 24};
    int list_length = 2;

    *gc = XCreateGC(display,win,valuemask,&values);

    XSetFont(display,*gc,font_info->fid);

    XSetForeground(display,*gc,255);

    XSetLineAttributes(display,*gc,line_width,line_style,cap_style,join_style);

    XSetDashes(display,*gc,dash_offset,dash_list,list_length);
}

/* loop until all the requests of the server have been completed */

wait_for_server()
{
    while (1) {
        XEvent      ev;
        XNextEvent(display, &ev);
        if (ev.type == Expose)
            break;
    }
}

/* send all plot instructions to the server - hope they get plotted */
flush_buffer()
{
    XFlush(display);
}

static char *visual_class_name(int clss) {
    switch (clss) {
    case PseudoColor: return "PseudoColor";
    case GrayScale:   return "GrayScale";
    case StaticGray:  return "StaticGray";
    case StaticColor: return "StaticColor";
    case DirectColor: return "DirectColor";
    case TrueColor:   return "TrueColor";
    default:          return "unknown_class!";
    }
}
