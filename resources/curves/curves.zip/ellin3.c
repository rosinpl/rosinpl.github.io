/*
 * ellnlms3.c fits ellipses to line sections this effectively supersedes
 * ellnlms1 & ellnlms2
 * 
 * version using simple least-squares ellipse fitting corrected version that
 * shifts data to origin during lms fit to minimise numerical errors analytic
 * version of determine_parameters hack to make correct ambiguity of
 * determine_parameters
 * 
 * takes as input line data plus 3 soft breakpoints reduces 5 line limit to 2
 * uses extra points only as required i.e. 2 points for 2 lines; 1 point for
 * 3 or 4 lines
 * 
 * corrected arc direction determination
 * 
 * BUG: if 3 consecutive points are colinear matrix stuff aborts such points can
 * be generated if the breakpoint set to the line's midpoint
 * 
 * Added improve_ellipses function - tries to grow ellipses after initial
 * segmentation.
 * 
 * Updated to process floating point data or integer depending on the file type.
 * If integer data in, produces integer data out. If float data in, produces
 * float data out. Gives identical results when processing integer line data.
 * Floating point results look worse - needs investigating. GAWW
 * 
 * now includes a choice of ellipse fitting routines:
 *       least squares fit
 *       median of five point fits
 *       least median of square error fit
 *
 * added a few checks to avoid infinite loops
 *
 * A P.L. Rosin/G.A.W. West production. Copyright 1991, 1992, 1994.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define DEBUG 0            /* compile debug output if 1 */
#define DEBUG_COMBINE 0    /* if 1 prints diags for combine function */

#define LARGE_SIG 99999     /* significance always > that a computed one */
#define LARGE_DEV 99999     /* deviation always > that a computed one */
#define MEDIUM_LARGE 1000   /* poor significance for lines */
#define MIN_LENGTH 2        /* minimum length of data to fit to an
                             * ellipse need at least 5 points to fit an
                             * ellipse */

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define TINY 1.0e-20

#define SQR(x) ((x) * (x))

#define LISTS 1
#define LINES 2
#define ARCS 3
#define ENDL 4
#define ENDF 5
#define SBREAK 7

#define NO_LINE_SEGS 2000  /* max number of lines per list */
#define NO_ARCS 1000        /* max number of arcs per list  */
#define LINE 1
#define ARC 2
#define IGNORE 3
#define PI 3.141591
#define SMALL 1            /* type of arc */
#define BIG 2
#define CLOCKWISE 1        /* direction of arc from start to finish */
#define ANTICLOCKWISE 2

#define ELLIPSE 0
#define PARABOLA 1
#define HYPERBOLA 2

/* improve_ellipses definitions */

#define FIRST 1
#define SECOND 2
#define THIRD 3

/* original sequence of ordered lists of line segments */
float x_start[NO_LINE_SEGS], y_start[NO_LINE_SEGS];
float x_end[NO_LINE_SEGS], y_end[NO_LINE_SEGS];
/* 3 extra points */
float x_extra1[NO_LINE_SEGS], y_extra1[NO_LINE_SEGS];
float x_extra2[NO_LINE_SEGS], y_extra2[NO_LINE_SEGS];
float x_extra3[NO_LINE_SEGS], y_extra3[NO_LINE_SEGS];

/* 1 list from x/y_start/end */
float x_start2[NO_LINE_SEGS], y_start2[NO_LINE_SEGS];
float x_end2[NO_LINE_SEGS], y_end2[NO_LINE_SEGS];
int location[NO_LINE_SEGS];

/* x/y_start2 transformed by determine_circle */
float x_trans3[NO_LINE_SEGS], y_trans3[NO_LINE_SEGS];

/* is line ok, deleted or an arc? */
int flags[NO_LINE_SEGS];

/* significance of line segments in x/y_start/end */
float sigs[NO_LINE_SEGS];

/* significance of line segments of list in x/y_start2/end2 */
float sigs2[NO_LINE_SEGS];

float arc_centre_x[NO_ARCS], arc_centre_y[NO_ARCS];
float arc_start_x[NO_ARCS], arc_start_y[NO_ARCS];
float arc_end_x[NO_ARCS], arc_end_y[NO_ARCS];
float maj_axis[NO_ARCS], min_axis[NO_ARCS];
float rot_ang[NO_ARCS];
int arc_dirs[NO_ARCS];
float arc_sig[NO_ARCS];
int next[NO_LINE_SEGS];
int start[NO_LINE_SEGS];

int number_arcs;
int number_lists;
int nseg;
int nseg2;            /* number of points in x_trans3, y_trans3 */
int orig_nseg2;       /* number of all (hard & soft) points in
                       * x_trans3, y_trans3 */

int use_improve;      /* if TRUE use improve_ellipses */
int use_weight;
float weight;         /* in improve_ellipses, weight biases
                       * decision    if weight = 1.0, no effect if
                       * weight < 1.0, favours new bigger ellipses
                       * use_weight enables user to input a value */

int use_recursion;    /* used to decide whether to fit one circle
                       * to all the data or recurse down and up the
                       * tree of interpretations */
int floating_point;   /* if TRUE I/O's floating point data else
                       * integer */

int lms_fit;          /* least squares ellipse fitting */
int reg5_fit;         /* regular median ellipse fitting */
int all5_fit;         /* all median ellipse fitting */
int lms2_fit;         /* regular median ellipse fitting - median of errors */

FILE *fp1, *fp;

int global_pos;

int representation_ok; /* fitting algorithm can signal if cannot fit
                        * at all to the data */

int set_sig_scale = FALSE;    /* rescale significance of ellipses */
float sig_scale_factor = 1; /* ???? */


/* median ellipse fitting stuff */
#define MAX_FITS 100000
#define ABS(X)   (((X)<0.0) ? -(X): (X))

#define OK       0
#define BAD      1

#define ALL_DATA 0
#define FLAGGED  1

/* select which data points should be used for least square fitting */
int flags2[NO_LINE_SEGS];

int downgrade = FALSE;
int read_3_sbreaks;

void main2();
void improve_ellipses(int start_in,int  finish_in);
void combine(int previous,int current,int *flag);
void segment(int start_in,int  finish_in,float *sig_out);
float angle(float x1, float y1, float x2, float y2);
float euclid(float x1, float y1, float x2, float y2);
void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2);
void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir);
void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir);
void compute_poly_lgt(float *lgt);
int find_conic_type(double c1, double c2, double c3);
void determine_ellipse_fit(int st, int fi, float *final_major_axis, float *final_minor_axis, float *final_rot_angle, float *final_xc, float *final_yc, float *final_dev, float *final_lgt, int *arc_dir, float *sig);
void ludcmp(float a[6][6], int n, int indx[6], float *d);
void determine_ellipse_lms(float m[7], int type);
float distance(double x1, double y1, double x2, double y2);
void read_line(int *no_segs, int *end_of_file, int *list_no);
void conic_to_intuitive(double a, double b, double c, double d, double e, double f, float *x_cent, float *y_cent, float *major_axis, float *minor_axis, float *rot_angle);
void intuitive_to_conic(double x_cent, double y_cent, double major_axis, double minor_axis, double rot_angle, float *a, float *b, float *c, float *d, float *e, float *f);
int curve_type(char array[50]);
void error(char s[]);
void regular_5_fits_lms(float m[7], float datax[], float datay[], int no_points);
void all_5_fits_lms(float m[7], float datax[], float datay[], int no_points);
float do_lms(int count, float param[]);
int ellipse_type(double c1, double c2, double c3);
void solve_conic(int p1, int p2, int p3, int p4, int p5, float *coeff1, float *coeff2, float *coeff3, float *coeff4, float *coeff5, float *coeff6, float datax[], float datay[]);
void sort(int n, float ra[]);
void regular_5_fits_lms2(float m[7], float datax[], float datay[], int no_points);
float determine_errors(double c1, double c2, double c3, double c4, double c5, double c6, float datax[], float datay[], int no_points);
void flag_outliers(double c1, double c2, double c3, double c4, double c5, double c6, float datax[], float datay[], int no_points);

main(argc, argv)
int argc;
char *argv[];
{
    char *s;
    char file_type[50];
    char *filename_in, *filename_out;
    int set_file_in = FALSE;
    int set_file_out = FALSE;

    use_improve = FALSE;
    use_weight = FALSE;
    use_recursion = TRUE;    /* can fit one ellipse to the data */
    weight = 1.0;
    lms_fit = TRUE;
    reg5_fit = all5_fit = FALSE;

    if (argc == 1) {
        printf("            ELLIN3\n");
        printf("Usage: ellin3 -i file -o file [options]\n");
        printf("options:\n");
        printf("   -s weight significances\n");
        printf("   -w (val) weight significances (in improve_ellipses)\n");
        printf("   -r dont use recursion\n");
        printf("   -I use improve_ellipses\n");
        printf("   -D downgrade all line fits\n");
        printf("   -R use regular median ellipse fit\n");
        printf("   -A use all median ellipse fit\n");
        printf("   -M use regular median ellipse fit - median of errors\n");
        exit(-1);
    }

    while (--argc > 0 && (*++argv)[0] == '-') {
        for (s = argv[0] + 1; *s != '\0'; s++) {
            switch (*s) {
            case 's':
                set_sig_scale = TRUE;
                argc--; argv++;
                sig_scale_factor = atof(argv[0]);
                break;
            case 'i':
                if (set_file_in == TRUE) {
                    printf("only one input file allowed - aborting\n");
                    exit(-1);
                }
                set_file_in = TRUE;
                argc--; argv++;
                filename_in = argv[0];
                break;
            case 'o':
                if (set_file_out == TRUE) {
                    printf("only one output file allowed - aborting\n");
                    exit(-1);
                }
                set_file_out = TRUE;
                argc--; argv++;
                filename_out = argv[0];
                break;
            case 'I':
                use_improve = TRUE;
                break;
            case 'w':
                argc--; argv++;
                use_weight = TRUE;
                weight = atof(argv[0]);
                break;
            case 'r':
                use_recursion = FALSE;
                break;
            case 'D':
                downgrade = TRUE;
                break;
            case 'A':
                all5_fit = TRUE;
                lms_fit = FALSE;
                break;
            case 'R':
                reg5_fit = TRUE;
                lms_fit = FALSE;
                break;
            case 'M':
                lms2_fit = TRUE;
                lms_fit = FALSE;
                break;
            default:
                printf("illegal option %c\n", *s);
                argc = 0;
                exit(-1);
                break;
            }
        }
    }

    if (set_file_in == FALSE) {
        printf("no input file specified - aborting\n");
        exit(-1);
    }
    if (set_file_out == FALSE) {
        printf("no output file specified - aborting\n");
        exit(-1);
    }

    if (set_sig_scale == TRUE)
        printf("using user defined sig_scale of %f\n",sig_scale_factor);
    else
        printf("using default sig_scale of %f\n",sig_scale_factor);

    if (use_improve == TRUE)
        printf("using improve_ellipses\n");
    else
        printf("not using improve_ellipses\n");
    if (use_recursion == TRUE)
        printf("using recursion\n");
    else
        printf("not using recursion\n");

    if (use_weight == TRUE)
        printf("using user defined weight value for biasing decision of %f\n",
                weight);
    else
        printf("using the default weight value of %f\n", weight);

    if (lms_fit)
        printf("using least squares ellipse fitting\n");
    else if (reg5_fit)
        printf("using regular median ellipse fitting\n");
    else if (all5_fit)
        printf("using all median ellipse fitting\n");

    if ((fp = fopen(filename_in, "r")) == NULL) {
        printf("cant open %s\n", filename_in);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp, "%s\n", file_type);
    if (strcmp(file_type, "super") == 0) {
        printf("super integer data file \n");
        floating_point = FALSE;
    }
    else if (strcmp(file_type, "super_float") == 0) {
        printf("super float data file \n");
        floating_point = TRUE;
    }
    else {
        printf("not super data file - aborting\n");
        exit(-1);
    }

    if ((fp1 = fopen(filename_out, "w")) == NULL) {
        printf("cant open %s\n", filename_out);
        exit(-1);
    }
    /* write magic word at top of file */
    if (floating_point == TRUE)
        fprintf(fp1, "super_float\n");
    else
        fprintf(fp1, "super\n");

    main2();
}

/*
 * most of the contents of main have been moved here so that they can be
 * called from the event handler
 */
void main2()
{
    float temp;
    long no_lines_0, no_lines_1, no_lines_2;
    long no_ellipses_1, no_ellipses_2;
    int i,j;
    int index;
    float sig;    /* not really used - just dummy param for segment */
    int no_segs, end_of_file, list_no;

    no_lines_0 = 0;
    no_lines_1 = 0;
    no_ellipses_1 = 0;
    no_lines_2 = 0;
    no_ellipses_2 = 0;

    do {
        read_line(&no_segs, &end_of_file, &list_no);

        if (end_of_file == 0) {
            /* check superdata file contains soft-breakpoints */
            if (!read_3_sbreaks) {
                fprintf(stderr,"ERROR: file must contain soft-break points\n");
                exit(-1);
            }
    
            /* give lines poor significances */
            if (downgrade) {
                for (i = 1; i <= no_segs; i++) {
                    sigs[i] = MEDIUM_LARGE;
                }
            }

            for (i = 1; i <= no_segs; i++) {
                x_start2[i] = x_start[i];
                y_start2[i] = y_start[i];
                x_end2[i] = x_end[i];
                y_end2[i] = y_end[i];
                sigs2[i] = sigs[i];
            };
            nseg = no_segs;
            no_lines_0 += nseg;
            number_arcs = 0;
            for (i = 1; i <= nseg; i++)
                flags[i] = LINE;

#if DEBUG
            printf("INITIALLY calling segment\n");
#endif
            segment(1, nseg, &sig);


            /* count number of lines and arcs */
            for (j = 1; j <= nseg; j++) {
                if (flags[j] == LINE)
                    no_lines_1++;
                else if (flags[j] == ARC)
                    no_ellipses_1++;
            }

            if (use_improve == TRUE)
                improve_ellipses(1, nseg);

            /* count number of lines and arcs */
            for (j = 1; j <= nseg; j++) {
                if (flags[j] == LINE)
                    no_lines_2++;
                else if (flags[j] == ARC)
                    no_ellipses_2++;
            }

            /* write out data in super data format */
            fprintf(fp1, "list: %d\n", list_no);
            for (j = 1; j <= nseg; j++) {
                if (flags[j] == LINE) {
                    if (floating_point == TRUE) {
                        fprintf(fp1, "line: %f %f %f %f %f\n",
                            sigs2[j], x_start2[j], y_start2[j], 
                            x_end2[j], y_end2[j]);
                    }
                    else {    
                        fprintf(fp1, "line: %f %6.0f %6.0f %6.0f %6.0f\n",
                            sigs2[j], x_start2[j], y_start2[j], 
                            x_end2[j], y_end2[j]);
                    }
                }
                else if (flags[j] == ARC) {
                    index = location[j];
                    /* !! HACK !! */
                    if (maj_axis[index] < min_axis[index]) {
                        temp = maj_axis[index];
                        maj_axis[index] = min_axis[index];
                        min_axis[index] = temp;
                        rot_ang[index] += PI/2.0;
                    }
                    if (floating_point == TRUE) {
                        fprintf(fp1, "ellipse: %f %f %f %f %f %f %f %f %f %f %d\n",
                            arc_sig[index],
                            arc_centre_x[index], arc_centre_y[index],
                            arc_start_x[index], arc_start_y[index],
                            arc_end_x[index], arc_end_y[index],
                            maj_axis[index], min_axis[index], rot_ang[index],
                            arc_dirs[index]);
                    }
                    else {
                        fprintf(fp1, "ellipse: %f %6.0f %6.0f %6.0f %6.0f %6.0f %6.0f %f %f %f %d\n",
                            arc_sig[index],
                            arc_centre_x[index], arc_centre_y[index],
                            arc_start_x[index], arc_start_y[index],
                            arc_end_x[index], arc_end_y[index],
                            maj_axis[index], min_axis[index], rot_ang[index],
                            arc_dirs[index]);
                    }
                }
            }
            fprintf(fp1, "endl:\n");
        }
    } while (end_of_file == 0);
    fprintf(fp1, "endf:\n");
    fclose(fp1);

    /* output statistics of the program */
    printf("no of lines originally:   %d\n", no_lines_0);
    printf("after first pass\n");
    printf("no of lines:              %d\n", no_lines_1);
    printf("no of ellipses:           %d\n", no_ellipses_1);
    printf("after second pass\n");
    printf("no of lines:              %d\n", no_lines_2);
    printf("no of ellipses:           %d\n", no_ellipses_2);

}


/*
 * For each arc in representation, tries to combine with each neighbour. Four
 * choices: Neighbour on right 
 *             Neighbour on left 
 *            Both neighbours 
 *            Neither neighbours 
 * Chooses best representation. Repeats until can do no more.
 */
void improve_ellipses(int start_in,int  finish_in)
{

    int loop1;
    int cont, cont2;
    int previous, current;

    /* first segment will always be either ARC of LINE */
    if ((flags[1] != ARC) && (flags[1] != LINE)) {
        printf("ERROR - first segment should always ARC or LINE\n");
        exit(-1);
    }
    do {
        loop1 = start_in;
        previous = start_in;
        cont = TRUE;
        cont2 = FALSE;
        do {
            if ((flags[loop1] == ARC) || (flags[loop1] == LINE)) {
                current = loop1;
                if (flags[current] == ARC) {
                    if ((flags[previous] == LINE) || (flags[previous] == ARC)) {
                        combine(previous, current, &cont2);
                        /* print_reps(); */
                    }
                }
                previous = current;
            }
            loop1++;
        } while ((loop1 <= finish_in) && (cont == TRUE));
        if (cont2 == FALSE)
            cont = FALSE;
    } while (cont == TRUE);
}

void combine(int previous,int current,int *flag)
{
    float major_axis1, minor_axis1, rot_angle1;
    float major_axis2, minor_axis2, rot_angle2;
    float major_axis3, minor_axis3, rot_angle3;
    float centre_x1, centre_y1;
    float centre_x2, centre_y2;
    float centre_x3, centre_y3;
    float arc_length;
    float max_dev, sig[4];
    float sigp, sigc, sign, sig1;
    int arc_dir1;
    int arc_dir2;
    int arc_dir3;
    int index1, index2;
    int next, next2;
    int current_end, next_end;
    int best[4];
    int i, j;
    int replaced;

#if DEBUG_COMBINE
    printf("\n\n*************** INTO COMBINE ***************\n");
#endif

    /* temp output   representations for diagnostics */

    /*
    printf("new significances: first %f second %f third %f\n", sig[1],sig[2],sig[3]);
     * for (i=1;i<=nseg;i++) { printf("i: %5d flags: %5d\n",i,flags[i]); }
     */


    /*
     * find location of the next representation also determine the end of
     * the current rep (lines an ellipse fits goes from current to
     * next-1) if there is no next segment, then current_end is nseg also
     * there is no next segment so set next to nseg+1
     */

    next = current;
    do {
        next++;
    } while ((flags[next] != LINE) && (flags[next] != ARC)
         && (next < nseg));
    if (next == nseg) {
        current_end = nseg;
        next++;
    }
    else {
        current_end = next - 1;
    }

    /* combine with previous representation? */

    if (previous == current)
        sig[1] = 9999.0;
    else {
#if DEBUG_COMBINE
        printf("\ncombining previous %d,%d current %d,%d current_end %d\n",
            previous,flags[previous],current,flags[current],current_end);
#endif
        determine_ellipse_fit(previous, current_end, &major_axis1, &minor_axis1,
                      &rot_angle1, &centre_x1, &centre_y1,
                      &max_dev, &arc_length, &arc_dir1, &sig1);
        if (representation_ok == FALSE) {
            max_dev = LARGE_DEV;
            sig1 = LARGE_SIG;
        }
#if DEBUG_COMBINE
        printf("ellipse? maj %2.2f min %2.2f rot %2.2f ctr %2.2f %2.2f dev %2.2f lgt %2.2f size %d\n",
                major_axis1,minor_axis1,rot_angle1,centre_x1,centre_y1,
                max_dev,arc_length,arc_dir1);
#endif        

        if (set_sig_scale) {
            sig1 /= sig_scale_factor;
        }
        sig[1] = sig1;

        if (flags[previous] == ARC)
            sigp = arc_sig[location[previous]];    /* arc significance */
        else
            sigp = sigs2[previous];    /* line significance */
        sigc = arc_sig[location[current]];    /* arc significance */
    }

    /* combine with next representation? */
    if (next == nseg + 1)
        sig[2] = 9999.0;
    else {
        if (flags[next] == ARC) {
            /*
             * find next representation to get last line segment
             * to use if line then it is just the next segment if
             * arc then it is the next representation-1 if next
             * is last segment then it is number_segments
             */
            next2 = next;
            do {
                next2++;
            } while ((flags[next2] != LINE) && (flags[next2] != ARC)
                 && (next2 < nseg));
            if (next2 == nseg) {
                next_end = nseg;
                next2++;
            }
            else {
                next_end = next2 - 1;
            }

        }
        else
            next_end = next;
#if DEBUG_COMBINE
             printf("\ncombining current %d,%d next %d,%d next_end %d\n",
                 current,flags[current],next,flags[next],next_end);
#endif
        determine_ellipse_fit(current, next_end, &major_axis2, &minor_axis2,
                      &rot_angle2, &centre_x2, &centre_y2,
                      &max_dev, &arc_length, &arc_dir2, &sig1);
        if (representation_ok == FALSE) {
            max_dev = LARGE_DEV;
            sig1 = LARGE_SIG;
        }
#if DEBUG_COMBINE
        printf("ellipse? maj %2.2f min %2.2f rot %2.2f ctr %2.2f %2.2f dev %2.2f lgt %2.2f size %d\n",
            major_axis2,minor_axis2,rot_angle2,centre_x2,centre_y2,
            max_dev,arc_length,arc_dir2);
#endif
        if (set_sig_scale) {
            sig1 /= sig_scale_factor;
        }
        sig[2] = sig1;
        if (flags[next] == ARC)
            sign = arc_sig[location[next]];    /* arc significance */
        else
            sign = sigs2[next];    /* line significance */
        sigc = arc_sig[location[current]];    /* arc significance */
    }

    /* combine with previous and next representation? */

    if ((sig[1] == 9999.0) || (sig[2] == 9999.0)) {
        sig[3] = 9999.0;
    }
    else {
#if DEBUG_COMBINE
        printf("\ncombining previous %d,%d next %d,%d next_end %d\n",
            previous,flags[previous],next,flags[next],next_end);
#endif
        determine_ellipse_fit(previous, next_end, &major_axis3, &minor_axis3,
                      &rot_angle3, &centre_x3, &centre_y3,
                      &max_dev, &arc_length, &arc_dir3, &sig1);
        if (representation_ok == FALSE) {
            max_dev = LARGE_DEV;
            sig1 = LARGE_SIG;
        }
#if DEBUG_COMBINE
        printf("ellipse? maj %2.2f min %2.2f rot %2.2f ctr %2.2f %2.2f dev %2.2f lgt %2.2f size %d\n",
                major_axis3,minor_axis3,rot_angle3,centre_x3,centre_y3,
                max_dev,arc_length,arc_dir3);
#endif
        if (set_sig_scale) {
            sig1 /= sig_scale_factor;
        }
        sig[3] = sig1;
    }

#if DEBUG_COMBINE
    printf("old sigs previous: %f current %f next %f\n",
            sigp,sigc,sign); 
    printf("new significances: first %f second %f third %f\n", 
            sig[1],sig[2],sig[3]);
#endif    


    /* rank significances */
    /*
     * temporary set significance of THIRD to 9999 to stop it being used
     */
    best[1] = FIRST;
    best[2] = SECOND;
    best[3] = THIRD;
    for (j = 1; j <= 2; j++)
        for (i = 1; i <= 2; i++)
            if (sig[i + 1] < sig[i]) {
                sig[0] = sig[i];
                sig[i] = sig[i + 1];
                sig[i + 1] = sig[0];
                best[0] = best[i];
                best[i] = best[i + 1];
                best[i + 1] = best[0];
            }
    /*
     * Replace original representation if this one better - Complex
     * decision rules: if the best sig is better than the old then
     * replace else try the next best significance This is continued
     * until run out of replacements.
     */
    i = 0;
    replaced = FALSE;
    do {
        i++;
        if (best[i] == THIRD) {
            if ((sig[i] * weight < sigp) && (sig[i] * weight < sigc) && (sig[i] * weight < sign)) {
                /* replace all three previous reps */
                /* replace previous, delete current and next */
#if DEBUG_COMBINE                     
                printf("replacing with THIRD\n");
#endif
                replaced = TRUE;
                /* delete previous and next, modify current */
                index1 = location[current];
                if (flags[previous] == LINE) {
                    /*
                     * delete previous line and modify
                     * current arc
                     */
#if DEBUG_COMBINE                     
                    printf("deleting line\n");
#endif
                    flags[previous] = IGNORE;
                    arc_start_x[index1] = x_start2[previous];
                    arc_start_y[index1] = y_start2[previous];
                }
                else {
                    /*
                     * delete previous arc and modify
                     * current arc
                     */
#if DEBUG_COMBINE                     
                    printf("deleting ellipse\n");
#endif
                    index2 = location[previous];
                    flags[previous] = IGNORE;
                    arc_start_x[index1] = arc_start_x[index2];
                    arc_start_y[index1] = arc_start_y[index2];
                }
                if (flags[next] == LINE) {
                    /*
                     * delete next line and modify
                     * current arc
                     */
#if DEBUG_COMBINE                     
                    printf("deleting line\n");
#endif                     
                    flags[next] = IGNORE;
                    arc_end_x[index1] = x_end2[next];
                    arc_end_y[index1] = y_end2[next];
                }
                else {
                    /*
                     * delete next arc and modify current
                     * arc
                     */
#if DEBUG_COMBINE                     
                     printf("deleting ellipse\n");
#endif
                    flags[next] = IGNORE;
                    index2 = location[next];
                    arc_end_x[index1] = arc_end_x[index2];
                    arc_end_y[index1] = arc_end_y[index2];
                }
                arc_sig[index1] = sig[i];
                arc_centre_x[index1] = centre_x3;
                arc_centre_y[index1] = centre_y3;
                arc_dirs[index1] = arc_dir3;
                maj_axis[index1] = major_axis3;
                min_axis[index1] = minor_axis3;
                rot_ang[index1] = rot_angle3;
            }
        }
        else if (best[i] == FIRST) {
            if ((sig[i] * weight < sigp) && (sig[i] * weight < sigc)) {
                /* replace previous and current */
#if DEBUG_COMBINE                     
                printf("replacing with FIRST\n");
#endif
                replaced = TRUE;
                /* delete previous and modify current */
                index1 = location[current];
                if (flags[previous] == LINE) {
                    /*
                     * delete previous line and modify
                     * current arc
                     */
#if DEBUG_COMBINE                     
                     printf("deleting line\n");
#endif                     
                    flags[previous] = IGNORE;
                    arc_start_x[index1] = x_start2[previous];
                    arc_start_y[index1] = y_start2[previous];
                }
                else {
                    /*
                     * delete previous arc and modify
                     * current arc
                     */
#if DEBUG_COMBINE                     
                     printf("deleting ellipse\n");
#endif                     
                    index2 = location[previous];
                    flags[previous] = IGNORE;
                    arc_start_x[index1] = arc_start_x[index2];
                    arc_start_y[index1] = arc_start_y[index2];
                }
                arc_sig[index1] = sig[i];
                arc_centre_x[index1] = centre_x1;
                arc_centre_y[index1] = centre_y1;
                arc_dirs[index1] = arc_dir1;
                maj_axis[index1] = major_axis1;
                min_axis[index1] = minor_axis1;
                rot_ang[index1] = rot_angle1;
            }
        }
        else {
            if ((sig[i] * weight < sigc) && (sig[i] * weight < sign)) {
                /* replace current and next */
#if DEBUG_COMBINE                     
                printf("replacing with SECOND\n");
#endif
                replaced = TRUE;
                /* delete next and modify current */
                index1 = location[current];
                if (flags[next] == LINE) {
                    /*
                     * delete next line and modify
                     * current arc
                     */
#if DEBUG_COMBINE                     
                     printf("deleting line\n");
#endif
                    flags[next] = IGNORE;
                    arc_end_x[index1] = x_end2[next];
                    arc_end_y[index1] = y_end2[next];
                }
                else {
                    /*
                     * delete next arc and modify current
                     * arc
                     */
#if DEBUG_COMBINE                     
                     printf("deleting ellipse\n");
#endif
                    flags[next] = IGNORE;
                    index2 = location[next];
                    arc_end_x[index1] = arc_end_x[index2];
                    arc_end_y[index1] = arc_end_y[index2];
                }
                arc_sig[index1] = sig[i];
                arc_centre_x[index1] = centre_x2;
                arc_centre_y[index1] = centre_y2;
                arc_dirs[index1] = arc_dir2;
                maj_axis[index1] = major_axis2;
                min_axis[index1] = minor_axis2;
                rot_ang[index1] = rot_angle2;
            }
        }
    } while ((replaced == FALSE) && (i < 3));
    *flag = replaced;
#if DEBUG_COMBINE                     
    if (replaced)
        printf("new ellipse: %f %f %f %f %f %f %f %f %f %f %d\n",
            arc_sig[index1], arc_centre_x[index1],arc_centre_y[index1],
            arc_start_x[index1],arc_start_y[index1],
            arc_end_x[index1],arc_end_y[index1],
            maj_axis[index1],min_axis[index1],rot_ang[index1],
            arc_dirs[index1]);
#endif
}

void segment(int start_in,int finish_in,float *sig_out)
{
    int i;
    int pos;
    float max_dev;
    float sig1, sig2, sig3, best_sig;
    float centre_x, centre_y;
    float major_axis, minor_axis, rot_angle;
    float arc_length;
    int arc_dir;

#if DEBUG
    printf("entering segment with limits %d %d\n", start_in, finish_in);
#endif
    if ((finish_in - start_in + 1) < MIN_LENGTH) {    /* don't subdivide */
        best_sig = LARGE_SIG;
        for (i = start_in; i <= finish_in; i++) {
            if (sigs2[i] < best_sig)
                best_sig = sigs2[i];
        }
        *sig_out = best_sig;
#if DEBUG
        printf("line sig %f\n", best_sig);
#endif
    }
    else {
        determine_ellipse_fit(start_in, finish_in, &major_axis, &minor_axis,
                      &rot_angle, &centre_x, &centre_y,
                      &max_dev, &arc_length, &arc_dir, &sig1);
#if DEBUG
        printf("best fit ellipse: maj %2.2f min %2.2f rot %2.2f ctr %2.2f %2.2f dev %2.2f lgt %2.2f size %d\n",
               major_axis, minor_axis, rot_angle, centre_x, centre_y, max_dev, arc_length, arc_dir);
#endif
        pos = global_pos + start_in - 1;
        if (representation_ok == FALSE) {
            max_dev = LARGE_DEV;
            sig1 = LARGE_SIG;
            pos = start_in + (finish_in - start_in) / 2;
        }
#if DEBUG
        printf("global pos: %d\n", global_pos);
        printf("ellipse sig: %f\n", sig1);
#endif
        if (set_sig_scale) {
            sig1 /= sig_scale_factor;
        }
#if DEBUG
        printf("rescaled ellipse sig: %f\n", sig1);
#endif
        /* need hack to avoid bad recursing if only 2 lines... */
        /* get best significance of underlying 2 lines directly */
        if (((finish_in - start_in) <= 1) || (use_recursion == FALSE)) {
            sig2 = sigs2[start_in];
            sig3 = sigs2[finish_in];
        }
        else {
            segment(start_in, pos - 1, &sig2);
            segment(pos, finish_in, &sig3);
        }
        if (sig2 < sig3)
            best_sig = sig2;
        else
            best_sig = sig3;
        if (best_sig < sig1)
            *sig_out = best_sig;
        else {
            *sig_out = sig1;
            number_arcs++;
            flags[start_in] = ARC;
            arc_sig[number_arcs] = *sig_out;
            arc_centre_x[number_arcs] = centre_x;
            arc_centre_y[number_arcs] = centre_y;
            arc_start_x[number_arcs] = x_start2[start_in];
            arc_start_y[number_arcs] = y_start2[start_in];
            arc_end_x[number_arcs] = x_end2[finish_in];
            arc_end_y[number_arcs] = y_end2[finish_in];
            arc_dirs[number_arcs] = arc_dir;
            maj_axis[number_arcs] = major_axis;
            min_axis[number_arcs] = minor_axis;
            rot_ang[number_arcs] = rot_angle;
            location[start_in] = number_arcs;
            for (i = start_in + 1; i <= finish_in; i++)
                flags[i] = IGNORE;
        }
    }
}


float angle(float x1, float y1, float x2, float y2)
{
    float angle_temp;
    float xx, yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if (xx == 0.0)
        angle_temp = PI / 2.0;
    else
        angle_temp = atan(fabs(yy / xx));
    if ((xx < 0.0) && (yy >= 0.0))
        angle_temp = PI - angle_temp;
    else if ((xx < 0.0) && (yy < 0.0))
        angle_temp = PI + angle_temp;
    else if ((xx >= 0.0) && (yy < 0.0))
        angle_temp = PI * 2.0 - angle_temp;
    return (angle_temp);
}

float euclid(float x1, float y1, float x2, float y2)
{
    float temp1, temp2;
    float dist;

    temp1 = fabs(x1 - x2);
    temp2 = fabs(y1 - y2);
    dist = sqrt(SQR(temp1) + SQR(temp2));
    return (dist);
}

void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2)
{
    /*
     * rotate polygon segment (x1,y1) -> (x2,y2) to lie along x axis,
     * compute the minimum distance between the line segment and a point
     * on the circle defined as (x_cir,y_cir). take perpendicular
     * distance if x_cir between end points else take euclidian distance
     * to nearest end point.
     */
    float angle1;
    float x_off, y_off, cosine, sine;
    float temp;
    float min1, min2;

    /*
     * printf("entered compute_minimum_diff\n"); printf("x_cir: %f y_cir
     * %f\n",x_cir,y_cir); printf("x1: %f y1 %f x2 %f y2
     * %f\n",x1,y1,x2,y2);
     */
    angle1 = angle(x1, y1, x2, y2);
    cosine = cos(-angle1);
    sine = sin(-angle1);
    x_off = x1;
    y_off = y1;
    /* offset points so x1,y1 at origin */
    x1 = 0;
    y1 = 0;
    x2 = x2 - x_off;
    y2 = y2 - y_off;
    x_cir = x_cir - x_off;
    y_cir = y_cir - y_off;
    /* rotate points with x2,y2 on x axis */
    temp = x2 * cosine - y2 * sine;
    y2 = x2 * sine + y2 * cosine;
    x2 = temp;
    temp = x_cir * cosine - y_cir * sine;
    y_cir = x_cir * sine + y_cir * cosine;
    x_cir = temp;
    /*
     * printf("x_cir: %f y_cir %f\n",x_cir,y_cir); printf("x1: %f y1 %f
     * x2 %f y2 %f\n",x1,y1,x2,y2);
     */
    min1 = euclid(x_cir, y_cir, x1, y1);
    min2 = euclid(x_cir, y_cir, x2, y2);
    if (x_cir < x1) {
        *deviation = min1;
    }
    else if (x_cir > x2) {
        *deviation = min2;
    }
    else {
        *deviation = fabs(y_cir);
    }
    /* printf("deviation: %f\n",*deviation,); */
}

/*
 * New version that walks around hypothesised ellipse finding minimum
 * distance to polygon at each step. Nearest point is either the
 * perpendicular distance, or the euclidian distance to the nearest end
 * point. For all cases the nearest end point is taken as the possible break
 * point. max_dev is the deviation, max_pos is the vertex for max_dev,
 * major_axis,minor_axis define the ellipse
 */
void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir)
{
    int l2;
    float l1, step;
    float s_ang, f_ang, temp;
    float x_cir, y_cir;
    float deviation;
    float min_dev;
    int min_pos;

    *max_dev = 0.0;

    /* determine angles */
    s_ang = angle(0.0, 0.0, x_trans3[1] / major_axis, y_trans3[1] / minor_axis);
    f_ang = angle(0.0, 0.0,
        x_trans3[nseg2] / major_axis, y_trans3[nseg2] / minor_axis);
#if DEBUG
    printf("start coords: %f %f\n", x_trans3[1], y_trans3[1]);
    printf("finish coords: %f %f\n", x_trans3[nseg2], y_trans3[nseg2]);
    printf("angles: %f %f\n", s_ang, f_ang);
#endif
    /* default is anticlockwise, swap if clockwise */
    if (arc_dir == CLOCKWISE) {
        temp = s_ang;
        s_ang = f_ang;
        f_ang = temp;
    }
    /* ang4 must be bigger than ang3 */
    if (f_ang < s_ang) {
        f_ang += PI * 2.0;
    }
#if DEBUG
    printf("start angle: %f finish angle %f\n", s_ang, f_ang);
    /* walk around circle from angle1 to angle2 */
    printf("walking around circle\n");
#endif
    step = (f_ang - s_ang) / 10.0;    /* use 11 steps presently */
    l1 = s_ang;
    do {
        min_dev = 1000000;
        x_cir = cos(l1) * major_axis;
        y_cir = sin(l1) * minor_axis;
        /* printf("\nl1: %f (x_cir,y_cir): %f %f\n",l1,x_cir,y_cir);  */
        l2 = 1;
        do {
            /* printf("for line %d\n",l2);   */
            compute_minimum_diff(&deviation, x_cir, y_cir, x_trans3[l2],
              y_trans3[l2], x_trans3[l2 + 1], y_trans3[l2 + 1]);
            if (deviation < min_dev) {
                min_dev = deviation;
                min_pos = l2;
            }
            l2++;
        } while (l2 <= nseg2 - 1);
        /*
         * printf("at this angle minimum deviation: %f at vertex:
         * %d\n", min_dev,pos1);
         */
        if (min_dev > *max_dev) {
            *max_dev = min_dev;
            *max_pos = min_pos;
        }
        l1 += step;
    } while (l1 <= f_ang);
#if DEBUG
    printf("maximum deviation: %f\n", *max_dev);
#endif
}

void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir)
{
    /*
     * computes length of arc works on temporary data from
     * determine_ellipse_fit i.e. data:
     * (x_trans3,y_trans3),major_axis,minor_axis. new version computes
     * start and finish angles, then arc length from angle and radius
     */

    float s_ang, f_ang, temp;
    float xold, yold, xnew, ynew;
    float step;

    s_ang = angle(0.0, 0.0, 
        x_trans3[1] / major_axis, y_trans3[1] / minor_axis);
    f_ang = angle(0.0, 0.0,
        x_trans3[nseg2] / major_axis, y_trans3[nseg2] / minor_axis);

    if (ABS(s_ang-f_ang) < 0.01) {
        representation_ok = FALSE;
        return;
    }

    /* default is anticlockwise, so swap angles if clockwise */
    if (arc_dir == CLOCKWISE) {
        temp = s_ang;
        s_ang = f_ang;
        f_ang = temp;
    }
    /* start angle must be less that f_ang */
    if (f_ang < s_ang)
        f_ang += PI * 2.0;
    *lgt = 0.0;
    xold = major_axis * cos(s_ang);
    yold = minor_axis * sin(s_ang);
    step = (f_ang - s_ang) / 20.0;
    temp = s_ang;
    do {
        temp += step;
        xnew = major_axis * cos(temp);
        ynew = minor_axis * sin(temp);
        *lgt = *lgt + distance(xold, yold, xnew, ynew);
        xold = xnew;
        yold = ynew;
    } while (temp <= f_ang);
}

/* debugged and working */
void compute_poly_lgt(float *lgt)
{
    int loop1;
    float dx, dy;
    float total, dist;

    total = 0.0;
    for (loop1 = 1; loop1 < nseg2; loop1++) {
        dx = x_trans3[loop1] - x_trans3[loop1 + 1];
        dy = y_trans3[loop1] - y_trans3[loop1 + 1];
        dist = sqrt(SQR(dx) + SQR(dy));
        total += dist;
    }
    *lgt = total;
}

int find_conic_type(double c1, double c2, double c3)
{
    float fx;
    int temp;

    fx = c1 * c3 - c2 * c2 / 4.0;
    if (fx > 0)
        temp = ELLIPSE;
    else if (fx < 0)
        temp = HYPERBOLA;
    else
        temp = PARABOLA;
    return (temp);
}

/*
 * Determine the best fit ellipse
 */
void determine_ellipse_fit(int st, int fi, float *final_major_axis, float *final_minor_axis, float *final_rot_angle, float *final_xc, float *final_yc, float *final_dev, float *final_lgt, int *arc_dir, float *sig)
{
    /* ellipse fitting variables */
    float m[7];        /* coefficients of best fit ellipse */

    /* new variables for lms fitting */
    float x_cent, y_cent;
    float c_ang;

    /* original variables */
    float xt, yt;     /* temp variables */
    float y_cent_t;   /* temp centre coords - after transformation */
    float sine, cosine;
    float max_dev, arc_length, poly_length;
    float sum, ratio;
    float temp;
    float x_off, y_off;
    float major_axis, minor_axis, rot_angle;
    float x_org, y_org;
    int arc_size;
    int max_pos;
    int loop1, loop2;
    float dummy;

    /* for flag insertion of extra points */
    int added_extra_points = FALSE;

#if DEBUG | DEBUG_COMBINE
    printf("\n\entering determine_ellipse_fit for data from: %d to %d\n",
           st, fi);
#endif

    /* get data into temp array */
    loop2 = 0;
    for (loop1 = st; loop1 <= fi; loop1++) {
        loop2++;
        x_trans3[loop2] = x_start2[loop1];
        y_trans3[loop2] = y_start2[loop1];
    }
    loop2++;
    x_trans3[loop2] = x_end2[fi];
    y_trans3[loop2] = y_end2[fi];
    orig_nseg2 = loop2;
    /* ADD EXTRA POINTS TO REDUCE 5 LINE LIMIT */
    if (loop2 < 3) {
        printf("ERROR: should have at least 2 line segments!!\n");
        exit(-1);
    }
    /* add two interior points for 2 line lists */
    else if (loop2 < 4) {
        for (loop1 = st; loop1 <= fi; loop1++) {
            loop2++;
            x_trans3[loop2] = x_extra2[loop1];
            y_trans3[loop2] = y_extra2[loop1];
        }
        for (loop1 = st; loop1 <= fi; loop1++) {
            loop2++;
            x_trans3[loop2] = x_extra3[loop1];
            y_trans3[loop2] = y_extra3[loop1];
        }
        added_extra_points = TRUE;
    }
    /* add one midpoint for 4 or 5 line lists */
    else if (loop2 < 6) {
        for (loop1 = st; loop1 <= fi; loop1++) {
            loop2++;
            x_trans3[loop2] = x_extra1[loop1];
            y_trans3[loop2] = y_extra1[loop1];
        }
        added_extra_points = TRUE;
    }
    nseg2 = loop2;

    /* shift data to the origin to minimise numerical errors */
    x_org = y_org = 0;
    for (loop1 = 1; loop1 <= nseg2; loop1++) {
        x_org += x_trans3[loop1];
        y_org += y_trans3[loop1];
    }
    x_org /= nseg2;
    y_org /= nseg2;
    for (loop1 = 1; loop1 <= nseg2; loop1++) {
        x_trans3[loop1] -= x_org;
        y_trans3[loop1] -= y_org;
    }

    /* scale values from 0 to 1 for ellipse fitting by dividing by 512 */
    for (loop1 = 1; loop1 <= nseg2; loop1++) {
        x_trans3[loop1] /= 512.0;
        y_trans3[loop1] /= 512.0;
    }

    if (lms_fit)
        determine_ellipse_lms(m,ALL_DATA);
    else if (lms2_fit)
        regular_5_fits_lms2(m,x_trans3,y_trans3,nseg2);
    else if (reg5_fit)
        regular_5_fits_lms(m,x_trans3,y_trans3,nseg2);
    else if (all5_fit)
        all_5_fits_lms(m,x_trans3,y_trans3,nseg2);

    /* eliminate extra soft breakpoints by resetting nseg2 */
    /*
     * this is to make the point of max. dev. correct when calculated
     * later
     */
    if (added_extra_points == TRUE)
        nseg2 = orig_nseg2;

#if DEBUG | DEBUG_COMBINE
    printf("coefficients for fitted ellipse:\n");
    printf("%2.3f %2.3f %2.3f %2.3f %2.3f %2.3f\n",
           m[1], m[2], m[3], m[4], m[5], m[6]);
#endif

    if (representation_ok == FALSE) {
        /* printf("REP != ELLIPSE!!!\n"); */
        /* save parameters for non-ellipse as floats */
        *final_major_axis = *final_minor_axis = *final_rot_angle
            = *final_xc = *final_yc = *final_lgt
            = *final_dev = 0.0;
        *sig = LARGE_SIG;
        /* set position of maximum deviation to be middle of curve */
        global_pos = nseg2 / 2;
        return;
    }
    /*
     * determine arc_size transform temp to lie along x axis, then
     * compute average displacement of y coords. If +ve then circle on
     * +ve side of axis else on -ve. This in combination with the
     * position of the centre will indicate if the are is large (>180
     * degrees) or small (<=180 degrees). Also can determine if arc is
     * clockwise or anticlockwise rotate and translate temp data. take
     * chord between points, rotate so that chord is along x axis -
     * rotate and translate all other points the same.
     */
    c_ang = angle(x_trans3[1], y_trans3[1], x_trans3[nseg2], y_trans3[nseg2]);
    sine = sin(-c_ang);
    cosine = cos(-c_ang);

    /* translate so first point is at origin */
    x_off = x_trans3[1];
    y_off = y_trans3[1];
    for (loop1 = 1; loop1 <= nseg2; loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - x_off;
        y_trans3[loop1] = y_trans3[loop1] - y_off;
    }
    /* rotate to align chord with x axis */
    for (loop1 = 1; loop1 <= nseg2; loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt * cosine - yt * sine;
        x_trans3[loop1] = temp;
        temp = xt * sine + yt * cosine;
        y_trans3[loop1] = temp;
    }
    /* do same for centre */
    x_cent = (-m[4]*m[3]/2.0+m[5]*m[2]/4.0)/(m[1]*m[3]-m[2]*m[2]/4.0);
    y_cent = (-m[1]*m[5]/2.0+m[4]*m[2]/4.0)/(m[1]*m[3]-m[2]*m[2]/4.0);

    xt = x_cent - x_off;
    yt = y_cent - y_off;
    temp = xt * cosine - yt * sine;
    temp = xt * sine + yt * cosine;
    y_cent_t = temp;

    /* compute average y coord of all points */
    sum = 0.0;
    for (loop1 = 1; loop1 <= nseg2; loop1++)
        sum += y_trans3[loop1];

    /* determine size and sense of arc */
    if ((sum >= 0.0) && (y_cent_t >= 0.0)) {
        arc_size = BIG;
        *arc_dir = CLOCKWISE;
    }
    else if ((sum < 0.0) && (y_cent_t < 0.0)) {
        arc_size = BIG;
        *arc_dir = ANTICLOCKWISE;
    }
    else if ((sum >= 0.0) && (y_cent_t < 0.0)) {
        arc_size = SMALL;
        *arc_dir = CLOCKWISE;
    }
    /* CHANGED Y_CENT TO Y_CENT_T - PLR */
    else if ((sum < 0.0) && (y_cent_t >= 0.0)) {
        arc_size = SMALL;
        *arc_dir = ANTICLOCKWISE;
    }
#if DEBUG | DEBUG_COMBINE
    if (arc_size == SMALL)
        printf("small arc ");
    else
        printf("big arc ");
    if (*arc_dir == CLOCKWISE)
        printf("direction clockwise\n");
    else
        printf("direction anticlockwise\n");
#endif

    /*
    for (loop2=1;loop2<=nseg2;loop2++) 
            printf("x_trans3: %f y_trans3: %f\n",
                x_trans3[loop2],y_trans3[loop2]);
    */ 

    /* convert coefficients to more meaningful parameters */
    conic_to_intuitive(m[1],m[2],m[3],m[4],m[5],m[6],
                       &dummy,&dummy,&major_axis,&minor_axis,&rot_angle);

    /* scale parameters to image space */
    major_axis *= 512.0;
    minor_axis *= 512.0;
    x_cent *= 512.0;
    y_cent *= 512.0;

    /* shift parameters back from origin */
    x_cent += x_org;
    y_cent += y_org;


#if DEBUG | DEBUG_COMBINE
    printf("parameters of ellipse:\n");
    printf("major_axis axis: %f minor_axis_axis %f\n", major_axis, minor_axis);
    printf("rotation angle of major_axis axis: %f\n", rot_angle);
    printf("centre: %f %f\n", x_cent, y_cent);
#endif

    /*
     * transform data so the major_axis axis of the ellipse is along the
     * x axis
     */
    /* get data into temp arrays */
    loop2 = 0;
    for (loop1 = st; loop1 <= fi; loop1++) {
        loop2++;
        x_trans3[loop2] = x_start2[loop1];
        y_trans3[loop2] = y_start2[loop1];
    }
    /* first translate */
    loop2++;
    x_trans3[loop2] = x_end2[fi];
    y_trans3[loop2] = y_end2[fi];
    nseg2 = loop2;
    for (loop1 = 1; loop1 <= nseg2; loop1++) {
        x_trans3[loop1] = x_trans3[loop1] - x_cent;
        y_trans3[loop1] = y_trans3[loop1] - y_cent;
    }
    /* now rotate */
    sine = sin(-rot_angle);
    cosine = cos(-rot_angle);
    for (loop1 = 1; loop1 <= nseg2; loop1++) {
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt * cosine - yt * sine;
        x_trans3[loop1] = temp;
        temp = xt * sine + yt * cosine;
        y_trans3[loop1] = temp;
    }
    y_cent_t = 0.0;

    /*
     * determine length of ellipse for this circle approx - use data
     * transformed to put major axis along x axis
     */
    compute_lgt(&arc_length, major_axis, minor_axis, *arc_dir);
    if (representation_ok == FALSE)
        return;

    /*
     * determine actual length of data - a polygon here
     */
    compute_poly_lgt(&poly_length);

    /*
     * determine position and value of the maximum deviation - use data
     * transformed to put major axis along x axis
     */
    compute_dev(&max_dev, &max_pos, major_axis, minor_axis, *arc_dir);

    /*
     * hack to stop breakpoint near ends - to be modified break at middle
     * of data if too close to end points
     */
    if ((max_pos <= MIN_LENGTH) || (max_pos > nseg2 - MIN_LENGTH))
        max_pos = nseg2 / 2;

#if DEBUG | DEBUG_COMBINE
    printf("arc length: %f\n", arc_length);
    printf("poly length: %f\n", poly_length);
    printf("maximum deviation: %f\n", max_dev);
    printf("point of maximum deviation: %d\n", max_pos);
#endif

    /*
     * ***** compute significance based on max_dev, arc_length and some
     * heuristics! ***
     */
    /* polygonal length should be similar to arc length */
    ratio = poly_length / arc_length;
    if (ratio < 1.0)
        ratio = arc_length / poly_length;

    /* save parameters for best ellipse as integers */
    *final_major_axis = major_axis;
    *final_minor_axis = minor_axis;
    *final_rot_angle = rot_angle;
    *final_xc = x_cent;
    *final_yc = y_cent;
    *final_lgt = arc_length;
    max_dev = max_dev * ratio;    /* temp to modify sig */
    *final_dev = max_dev;

    if ((max_dev != 0.0) && (arc_length != 0))
        *sig = max_dev / (float) arc_length;
    else
        *sig = LARGE_SIG;

    /* save position of maximum deviation */
    global_pos = max_pos;
}




/* LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void ludcmp(float a[6][6], int n, int indx[6], float *d)
{
    int i, imax, j, k;
    float big, dum, sum, temp;
    float vv[6];

    *d = 1.0;
    for (i = 1; i <= n; i++) {
        big = 0.0;
        for (j = i; j <= n; j++)
            if ((temp = fabs(a[i][j])) > big)
                big = temp;
        if (big == 0.0) {
            printf("Singular matrix in routine LUDCMP");
            representation_ok = FALSE;
            return;
        }
        vv[i] = 1.0 / big;
    }
    for (j = 1; j <= n; j++) {
        for (i = 1; i < j; i++) {
            sum = a[i][j];
            for (k = 1; k < i; k++)
                sum -= a[i][k] * a[k][j];
            a[i][j] = sum;
        }
        big = 0.0;
        for (i = j; i <= n; i++) {
            sum = a[i][j];
            for (k = 1; k < j; k++)
                sum -= a[i][k] * a[k][j];
            a[i][j] = sum;
            if ((dum = vv[i] * fabs(sum)) >= big) {
                big = dum;
                imax = i;
            }
        }
        if (j != imax) {
            for (k = 1; k <= n; k++) {
                dum = a[imax][k];
                a[imax][k] = a[j][k];
                a[j][k] = dum;
            }
            *d = -(*d);
            vv[imax] = vv[j];
        }
        indx[j] = imax;
        if (a[j][j] == 0.0)
            a[j][j] = TINY;
        if (j != n) {
            dum = 1.0 / (a[j][j]);
            for (i = j + 1; i <= n; i++)
                a[i][j] *= dum;
        }
    }
}

/* forward substitution & backsubstitution */
/* use with LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void lubksb(float a[6][6], int n, int indx[6], float b[6])
{
    int i, ii = 0, ip, j;
    float sum;

    for (i = 1; i <= n; i++) {
        ip = indx[i];
        sum = b[ip];
        b[ip] = b[i];
        if (ii)
            for (j = ii; j <= i - 1; j++)
                sum -= a[i][j] * b[j];
        else if (sum)
            ii = i;
        b[i] = sum;
    }
    for (i = n; i >= 1; i--) {
        sum = b[i];
        for (j = i + 1; j <= n; j++)
            sum -= a[i][j] * b[j];
        b[i] = sum / a[i][i];
    }
}

/*
 * standard least square fit ellipse
 * either fit to all data or just flagged data
 */
void determine_ellipse_lms(float m[7], int type)
{
    int j;
    float sx,sx2,sx3,sx4,sy,sy2,sy3,sy4,sxy,sx2y,sx3y,sx2y2,sxy2,sxy3;
    float x2,y2,x3,y3;
    float m1[6][6];
    float m2[6];
    int indx[6];
    float d;

    sx = 0;
    sx2 = 0;
    sx3 = 0;
    sx4 = 0;
    sy = 0;
    sy2 = 0;
    sy3 = 0;
    sy4 = 0;
    sxy = 0;
    sx2y = 0;
    sx3y = 0;
    sx2y2 = 0;
    sxy2 = 0;
    sxy3 = 0;

    representation_ok = TRUE;

    if (type == ALL_DATA) {
        for (j = 1; j <= nseg2; j++) {
            x2 = x_trans3[j] * x_trans3[j];
            x3 = x2 * x_trans3[j];
            y2 = y_trans3[j] * y_trans3[j];
            y3 = y2 * y_trans3[j];
    
            sx += x_trans3[j];
            sx2 += x2;
            sx3 += x3;
            sx4 += (x3 * x_trans3[j]);
            sy += y_trans3[j];
            sy2 += y2;
            sy3 += y3;
            sy4 += (y3 * y_trans3[j]);
            sxy += (x_trans3[j] * y_trans3[j]);
            sx2y = sx2y + x2 * y_trans3[j];
            sx3y = sx3y + x3 * y_trans3[j];
            sx2y2 = sx2y2 + x2 * y2;
            sxy2 = sxy2 + x_trans3[j] * y2;
            sxy3 = sxy3 + x_trans3[j] * y3;
        }
    }
    else {
        for (j = 1; j <= nseg2; j++)
        if (flags2[j]) {
            x2 = x_trans3[j] * x_trans3[j];
            x3 = x2 * x_trans3[j];
            y2 = y_trans3[j] * y_trans3[j];
            y3 = y2 * y_trans3[j];
    
            sx += x_trans3[j];
            sx2 += x2;
            sx3 += x3;
            sx4 += (x3 * x_trans3[j]);
            sy += y_trans3[j];
            sy2 += y2;
            sy3 += y3;
            sy4 += (y3 * y_trans3[j]);
            sxy += (x_trans3[j] * y_trans3[j]);
            sx2y = sx2y + x2 * y_trans3[j];
            sx3y = sx3y + x3 * y_trans3[j];
            sx2y2 = sx2y2 + x2 * y2;
            sxy2 = sxy2 + x_trans3[j] * y2;
            sxy3 = sxy3 + x_trans3[j] * y3;
        }
    }

    m1[1][1] = sx4;
    m1[2][1] = sx3y;
    m1[3][1] = sx2y2;
    m1[4][1] = sx3;
    m1[5][1] = sx2y;
    m1[1][2] = sx3y;
    m1[2][2] = sx2y2;
    m1[3][2] = sxy3;
    m1[4][2] = sx2y;
    m1[5][2] = sxy2;
    m1[1][3] = sx2y2;
    m1[2][3] = sxy3;
    m1[3][3] = sy4;
    m1[4][3] = sxy2;
    m1[5][3] = sy3;
    m1[1][4] = sx3;
    m1[2][4] = sx2y;
    m1[3][4] = sxy2;
    m1[4][4] = sx2;
    m1[5][4] = sxy;
    m1[1][5] = sx2y;
    m1[2][5] = sxy2;
    m1[3][5] = sy3;
    m1[4][5] = sxy;
    m1[5][5] = sy2;

    m2[1] = -sx2;
    m2[2] = -sxy;
    m2[3] = -sy2;
    m2[4] = -sx;
    m2[5] = -sy;

    /* solve simultaneous equations */
    ludcmp(m1, 5, indx, &d);
    if (representation_ok)
        lubksb(m1, 5, indx, m2);
    else
        return;

    m[1] = m2[1];
    m[2] = m2[2];
    m[3] = m2[3];
    m[4] = m2[4];
    m[5] = m2[5];
    m[6] = 1;

    if (find_conic_type(m[1], m[2], m[3]) != ELLIPSE)
        representation_ok = FALSE;
    else
        representation_ok = TRUE;
}

float distance(double x1, double y1, double x2, double y2)
{
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

void read_line(int *no_segs, int *end_of_file, int *list_no)
{
    int i, j, k;
    char data_type[40], ch;
    int d1,d2,d3,d4,d5,d6,d7,d8,d9;
    float f1,f2,f3,f4,f5,f6,f7,f8,f9;

    /*
     * check that superdata file contains soft-breakpoints
     * this doesn't really check properly - but it's better than nothing!
     */
    read_3_sbreaks = FALSE;
    k = 0;
    do {
        i = -1;
        do {
            fscanf(fp, "%c", &ch);
            data_type[++i] = ch;
        } while (ch != ':');
        data_type[++i] = '\0';
        j = curve_type(data_type);

        if (j == LISTS) {
            fscanf(fp, "%d\n", list_no);
        }
        else if (j == LINES) {
            k++;
            if (floating_point == TRUE) {
                fscanf(fp, "%f %f %f %f %f\n",
                   &sigs[k], &x_start[k], &y_start[k], &x_end[k], &y_end[k]);
            }
            else {
                fscanf(fp, "%f %d %d %d %d\n",&sigs[k],&d1,&d2,&d3,&d4);
                x_start[k] = d1;
                y_start[k] = d2;
                x_end[k] = d3;
                y_end[k] = d4;
            }
        }
        else if (j == SBREAK) {
            /* read 1st sbreak */
            if (floating_point == TRUE) {
                fscanf(fp, "%f %f\n", &x_extra1[k], &y_extra1[k]);
            }
            else {
                fscanf(fp, "%d %d\n",&d1,&d2);
                x_extra1[k] = d1;
                y_extra1[k] = d2;
            }

            /* read 2nd sbreak */
            do {
                fscanf(fp, "%c", &ch);
                data_type[++i] = ch;
            } while (ch != ':');
            data_type[++i] = '\0';
            j = curve_type(data_type);
            if (j != SBREAK) {
                fprintf(stderr,"ERROR: sbreak expected\n");
                exit(-1);
            }
            if (floating_point == TRUE) {
                fscanf(fp, "%f %f\n", &x_extra2[k], &y_extra2[k]);
            }
            else {
                fscanf(fp, "%d %d\n",&d1,&d2);
                x_extra2[k] = d1;
                y_extra2[k] = d2;
            }

            /* read 3rd sbreak */
            do {
                fscanf(fp, "%c", &ch);
                data_type[++i] = ch;
            } while (ch != ':');
            data_type[++i] = '\0';
            j = curve_type(data_type);
            if (j != SBREAK) {
                fprintf(stderr,"ERROR: sbreak expected\n");
                exit(-1);
            }
            if (floating_point == TRUE) {
                fscanf(fp, "%f %f\n", &x_extra3[k], &y_extra3[k]);
            }
            else {
                fscanf(fp, "%d %d\n",&d1,&d2);
                x_extra3[k] = d1;
                y_extra3[k] = d2;
            }

            read_3_sbreaks = TRUE;
        }
        else if (j == ARCS) {
            printf("warning! ARC in data - ignoring\n");
            if (floating_point == TRUE)
                fscanf(fp, "%f %f %f %f %f %f %f %f %f\n",
                   &f1, &f2, &f3, &f4, &f5, &f6, &f7, &f8, &f9);
            else
                fscanf(fp, "%f %d %d %d %d %d %d %d %d\n",
                   &f1, &d2, &d3, &d4, &d5, &d6, &d7, &d8, &d9);
        }
        else if (j == ENDL) {    /* read to end of line */
            fscanf(fp, "\n");
        }
    } while ((j != ENDL) && (j != ENDF));
    if (j == ENDF)
        *end_of_file = 1;
    else
        *end_of_file = 0;
    *no_segs = k;
}

int curve_type(char array[50])
{
    int i, j;

    if ((j = strcmp(array, "list:")) == 0)
        i = LISTS;
    else if ((j = strcmp(array, "line:")) == 0)
        i = LINES;
    else if ((j = strcmp(array, "arc:")) == 0)
        i = ARCS;
    else if ((j = strcmp(array, "endl:")) == 0)
        i = ENDL;
    else if ((j = strcmp(array, "endf:")) == 0)
        i = ENDF;
    else if ((j = strcmp(array, "sbreak:")) == 0)
        i = SBREAK;
    return (i);
}

/*
int
strcmp(s, t)
char s[], t[];
{
    int i;

    i = 0;
    while (s[i] == t[i])
        if (s[i++] == '\0')
            return (0);
    return (s[i] - t[i]);
}
*/

void error(char s[])
{
    printf("ERROR: %s\n", s);
    exit(-1);
}

void conic_to_intuitive(double a, double b, double c, double d, double e, double f, float *x_cent, float *y_cent, float *major_axis, float *minor_axis, float *rot_angle)
{
    float ca,sa;
    float t,u,v,w;

    if (a == c)
       *rot_angle = 0;
    else
       *rot_angle = atan(b/(a-c)) / 2.0;
    ca = cos(*rot_angle);
    sa = sin(*rot_angle);
    t = a*SQR(ca)+b*ca*sa+c*SQR(sa);
    u = a*SQR(sa)-b*ca*sa+c*SQR(ca);
    v = d*ca+e*sa;
    w = -d*sa+e*ca;
    *major_axis = sqrt(((SQR(v)/(4*t))+(SQR(w)/(4*u))-f)/t);
    *minor_axis = sqrt(((SQR(v)/(4*t))+(SQR(w)/(4*u))-f)/u);
    *x_cent = (-d*c/2.0 + e*b/4.0) / (a*c - b*b/4.0);
    *y_cent = (-a*e/2.0 + d*b/4.0) / (a*c - b*b/4.0);
}

void intuitive_to_conic(double x_cent, double y_cent, double major_axis, double minor_axis, double rot_angle, float *a, float *b, float *c, float *d, float *e, float *f)
{
    float sine,cosine;
    float s2,c2,a2b2;

    sine = sin(rot_angle);
    cosine = cos(rot_angle);
    s2 = sine*sine;
    c2 = cosine*cosine;

    a2b2 = SQR(major_axis) * SQR(minor_axis);

    *a = (SQR(major_axis)*s2 + SQR(minor_axis)*c2)/a2b2;
    *b = 2.0*(SQR(minor_axis)-SQR(major_axis))*sine*cosine /a2b2;
    *c = (SQR(major_axis)*c2 + SQR(minor_axis)*s2)/a2b2;
    *d = -2.0 * (*a * x_cent + (*b/2.0) * y_cent);
    *e = -2.0 * ((*b/2.0) * x_cent + *c * y_cent);
    *f = *a * SQR(x_cent) + *b * x_cent * y_cent + *c * SQR(y_cent) - 1;
}

/* ################### median ellipse fitting ############################ */

/* do a sort of least median of squares of all regularly spaced 5 point fits */
void regular_5_fits_lms(float m[7], float datax[], float datay[], int no_points)
{
   int i,sep,count;
   float save_xc,save_yc,save_maj,save_min,save_rot;
   float xc,yc,maj,mina,rot;
   //float do_lms();
   float param1[MAX_FITS],param2[MAX_FITS],param3[MAX_FITS];
   float param4[MAX_FITS],param5[MAX_FITS];
   float c1,c2,c3,c4,c5,c6;

   sep = 1;
   count = 0;
   do{
      i = 1;
      do{
         solve_conic(i,i+1*sep,i+2*sep,i+3*sep,i+4*sep,
                     &c1,&c2,&c3,&c4,&c5,&c6,
                     datax,datay);
         if (ellipse_type(c1,c2,c3)) {
            conic_to_intuitive(c1,c2,c3,c4,c5,c6,&xc,&yc,&maj,&mina,&rot);
            count++;
            param1[count] = xc;
            param2[count] = yc;
            param3[count] = maj;
            param4[count] = mina;
            param5[count] = rot;
            if (count >= MAX_FITS) {
               printf("ERROR: too many ellipse fits\n");
               exit(-1);
            }
         }
         i++;
      } while((i+4*sep) <= no_points);
      sep++;
   } while((1+4*sep <= no_points));

   if (count > 4) {
      sort(count,param1); save_xc = do_lms(count,param1);
      sort(count,param2); save_yc = do_lms(count,param2);
      sort(count,param3); save_maj = do_lms(count,param3);
      sort(count,param4); save_min = do_lms(count,param4);
      sort(count,param5); save_rot = do_lms(count,param5);

      representation_ok = TRUE;
      intuitive_to_conic(save_xc,save_yc,save_maj,save_min,save_rot,
                         &m[1],&m[2],&m[3],&m[4],&m[5],&m[6]);
   }
   else
      representation_ok = FALSE;
}

/* do least median of squares of ALL 5 point fits */
void all_5_fits_lms(float m[7], float datax[], float datay[], int no_points)
{
   int i1,i2,i3,i4,i5;
   int count;
   float xc,yc,maj,mina,rot;
   float save_xc,save_yc,save_maj,save_min,save_rot;
   //float do_lms();
   float param1[MAX_FITS],param2[MAX_FITS],param3[MAX_FITS];
   float param4[MAX_FITS],param5[MAX_FITS];
   float coeff1,coeff2,coeff3,coeff4,coeff5,coeff6;

   count = 0;
   for (i1=1;i1<=no_points-4;i1++)
      for (i2=i1+1;i2<=no_points-3;i2++)
         for (i3=i2+1;i3<=no_points-2;i3++)
            for (i4=i3+1;i4<=no_points-1;i4++)
               for (i5=i4+1;i5<=no_points;i5++) {
                  solve_conic(i1,i2,i3,i4,i5,
                              &coeff1,&coeff2,&coeff3,&coeff4,&coeff5,&coeff6,
                              datax,datay);
                  if (ellipse_type(coeff1,coeff2,coeff3)) {
                     conic_to_intuitive(coeff1,coeff2,coeff3,coeff4,coeff5,coeff6,
                                        &xc,&yc,&maj,&mina,&rot);
                     count++;
                     param1[count] = xc;
                     param2[count] = yc;
                     param3[count] = maj;
                     param4[count] = mina;
                     param5[count] = rot;
                     if (count >= MAX_FITS) {
                        printf("ERROR: %d is too many ellipses\n",count);
                        exit(-1);
                     }
                  }
               }

   if (count > 4) {
      sort(count,param1); save_xc = do_lms(count,param1);
      sort(count,param2); save_yc = do_lms(count,param2);
      sort(count,param3); save_maj = do_lms(count,param3);
      sort(count,param4); save_min = do_lms(count,param4);
      sort(count,param5); save_rot = do_lms(count,param5);

      representation_ok = TRUE;
      intuitive_to_conic(save_xc,save_yc,save_maj,save_min,save_rot,
                         &m[1],&m[2],&m[3],&m[4],&m[5],&m[6]);
   }
   else
      representation_ok = FALSE;
}

/*
 * do a modified version of the least median of squares
 * this requires finding the sequence of count/2 values with the minimum range
 * the result is the median of the values in this range
 */
float do_lms(int count, float param[])
{
    int i;
    int half = count/2;
    float range,min_range;
    int min_loc = 1;
    float result;

    i = 1;
    min_range = ABS(param[i]-param[i+half]);
    for (i = 2; i <= half; i++) {
        range = ABS(param[i]-param[i+half]);
        if (range < min_range) {
            min_loc = i;
            min_range = range;
        }
    }

    /* this is the real median of squares
    result = (param[min_loc] + param[min_loc+half]) / 2.0;
    */
    result = param[min_loc+half/2];

    return(result);
}

/* is conic an ellipse? */
int ellipse_type(double c1, double c2, double c3)
{
   float f;

   f = c1 * c3 - c2 * c2 / 4.0;
   return(f > 0);
}

/**********************************
 find unique conic through 5 points
 **********************************/
void solve_conic(int p1, int p2, int p3, int p4, int p5, float *coeff1, float *coeff2, float *coeff3, float *coeff4, float *coeff5, float *coeff6, float datax[], float datay[])
{
     float dx,m,c;
     int i1,i2;
     float x1,y1,c1;
     float x2,y2,c2;
     float x3,y3,c3;
     float x4,y4,c4;
     float xp,yp;
     float lambda;
     float x2c,y2c,xyc,xc,yc;
     float t1,t2;

     i1 = p1; i2 = p2;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x1 = -m; y1 = 1; c1 = -c;
     }
     else {
          x1 = 0; y1 = 1; c1 = -datax[i1];
     }

     i1 = p3; i2 = p4;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x2 = -m; y2 = 1; c2 = -c;
     }
     else {
          x2 = 0; y2 = 1; c2 = -datax[i1];
     }

     i1 = p1; i2 = p3;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x3 = -m; y3 = 1; c3 = -c;
     }
     else {
          x3 = 0; y3 = 1; c3 = -datax[i1];
     }

     i1 = p2; i2 = p4;
     dx = datax[i1] - datax[i2];
     if (dx != 0) {
          m = (datay[i1] - datay[i2]) / dx;
          c = datay[i1] - m * datax[i1];
          x4 = -m; y4 = 1; c4 = -c;
     }
     else {
          x4 = 0; y4 = 1; c4 = -datax[i1];
     }

     xp = datax[p5]; yp = datay[p5];

     t1 = ((x1*xp+y1*yp+c1)*(x2*xp+y2*yp+c2));
     t2 = ((x3*xp+y3*yp+c3)*(x4*xp+y4*yp+c4));
     if ((t1 == 0) || (t2 == 0)) {
     /*
        printf("ERROR: lambda is degenerate\n");
     */
        /* so just set coefficients to make conic non-elliptical */
        *coeff1 = *coeff3 = *coeff4 = *coeff5 = *coeff6 = 0;
        *coeff2 = 100;
        return;
     }
     lambda = t1 / t2;

     x2c = x1*x2 - lambda*x3*x4;
     xyc = x1*y2 + y1*x2 - lambda*(x3*y4 + y3*x4);
     y2c = y1*y2 - lambda*y3*y4;
     xc = x1*c2 + c1*x2 - lambda*(x3*c4 + c3*x4);
     yc = y1*c2 + c1*y2 - lambda*(y3*c4 + c3*y4);
     c = c1*c2 - lambda*c3*c4;

     /*
     printf("COEFFS: %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f\n",
             x2c,xyc,y2c,xc,yc,c);
     */

     *coeff1 = x2c;
     *coeff2 = xyc;
     *coeff3 = y2c;
     *coeff4 = xc;
     *coeff5 = yc;
     *coeff6 = c;
}

/* from numerical recipes in C */
void sort(int n, float ra[])
{
   int l,j,ir,i;
   float rra;

   l=(n >> 1)+1;
   ir=n;
   for (;;) {
      if (l > 1)
         rra=ra[--l];
      else {
         rra=ra[ir];
         ra[ir]=ra[1];
         if (--ir == 1) {
            ra[1]=rra;
            return;
         }
      }
      i=l;
      j=l << 1;
      while (j <= ir) {
         if (j < ir && ra[j] < ra[j+1]) ++j;
         if (rra < ra[j]) {
            ra[i]=ra[j];
            j += (i=j);
         }
         else j=ir+1;
      }
      ra[i]=rra;
   }
}

/* ################### new median ellipse fitting ############################ */

/*
 * only do regularly spaced 5 point fits - choose ellipse fit with least
 * median error
 */
void regular_5_fits_lms2(float m[7], float datax[], float datay[], int no_points)
{
   int i,sep;
   //float do_lms();
   float save_c1,save_c2,save_c3,save_c4,save_c5,save_c6;
   float c1,c2,c3,c4,c5,c6;
   float cur_err,best_err;//determine_errors();

   save_c1 = save_c2 = save_c3 = save_c4 = save_c5 = save_c6 = -1;
   best_err = 9e25;
   sep = 1;
   do{
      i = 1;
      do{
         solve_conic(i,i+1*sep,i+2*sep,i+3*sep,i+4*sep,
                     &c1,&c2,&c3,&c4,&c5,&c6,
                     datax,datay);
         if (ellipse_type(c1,c2,c3)) {
            cur_err = determine_errors(c1,c2,c3,c4,c5,c6,datax,datay,no_points);
            if (cur_err < best_err) {
                save_c1 = c1; save_c2 = c2; save_c3 = c3;
                save_c4 = c4; save_c5 = c5; save_c6 = c6;
                best_err = cur_err;
            }
         }
         i++;
      } while((i+4*sep) < no_points);
      sep++;
   } while((4*sep < no_points));

   /*
    * polish fit by performing a standard least squares fit after
    * eliminating outliers
    */
   flag_outliers(save_c1,save_c2,save_c3,save_c4,save_c5,save_c6,datax,datay,no_points);
   determine_ellipse_lms(m,FLAGGED);
}

/*
 * returns the median pixel deviation from the fitted ellipse
 * Euclidean distances are approximated by the algebraic distance
 */
float determine_errors(double c1, double c2, double c3, double c4, double c5, double c6, float datax[], float datay[], int no_points)
{
    int i;
    float x,y;
    float errors[NO_LINE_SEGS];

    for (i = 1; i <= no_points; i++) {
        x = datax[i]; y = datay[i];
        errors[i] = c1 * x*x + c2 * x*y + c3 * y*y + c4 * x + c5 * y + c6;
        errors[i] = ABS(errors[i]);
    }
   sort(no_points,errors);
   return(errors[no_points/2]);
}

/*
 * flag pixels as inliers/outliers wrt the fitted ellipse
 * outliers are those pixels who are more than
 * 1.48*3*median-absolute-deviations away from the ellipse
 *
 * use Q(x,y)/grad[Q(x,y)] as a reasonable approximation to Euclidean
 * distance of a point from the ellipse
 * actually calculates the squared distance, but that's just as good
 */
void flag_outliers(double c1, double c2, double c3, double c4, double c5, double c6, float datax[], float datay[], int no_points)
{
    int i;
    float x,y;
    double errors[NO_LINE_SEGS];
    float tmp[NO_LINE_SEGS];
    float median,mad;
    float gx,gy;

    /* calculate errors */
    for (i = 1; i <= no_points; i++) {
        x = datax[i]; y = datay[i];
        errors[i] = c1 * x*x + c2 * x*y + c3 * y*y +
                    c4 * x + c5 * y + c6;
        gx = 2 * c1 * x + c2 * y + c4;
        gy = c2 * x + 2 * c3 * y + c5;
        errors[i] = SQR(errors[i]) / (gx*gx+gy*gy);
        tmp[i] = errors[i];
    }
    sort(no_points,tmp);
    median = tmp[no_points/2];

    /* calculate median absolute deviation */
    for (i = 1; i <= no_points; i++) {
        tmp[i] = ABS(tmp[i] - median);
    }
    sort(no_points,tmp);
    mad = tmp[no_points/2];

    /* flag points outwith 3*sigma of mad */
    for (i = 1; i <= no_points; i++) {
        if (errors[i] < 3*mad*1.48) {
            flags2[i] = OK;
        }
        else {
            flags2[i] = BAD;
        }
    }
}

