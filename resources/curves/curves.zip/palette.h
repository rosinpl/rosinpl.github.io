/*
 * Definition of the colormap segment CMS_PALETTE,
 * a small collection of colors of the rainbow.
 *
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * altered by Paul Rosin to improve and extend colours
 * 8/10/90
 * I dont know how this all works!!
 * Basically colour 255 is the black for sunview
 *					1   is the white for sunview
 *					0   is set to 0,0,0
 *					254 is set t0 254,254,254
 * These settings stop sunview changing colours as you go in and out of
 * windows
 *
 * On the DEC Alpha
 *     1 = text
 *     2 = window border
 *     3 = window background
 *     4 = screen background
 *     5 = highlighted screen
 * PLR 9/93
 */

#define	CMS_PALETTE	"palette"
#define	CMS_PALETTESIZE	256

#define	TEXT	1
#define	BORDER	2
#define	BACKGND	3
#define	SCREEN	4
#define	HIGHLITE	5

#define	WHITE	255
#define	YELLOW	253
#define	GREEN	252
#define	BLUE	251
#define	PURPLE	250
#define	CYAN	249
#define	LIME	248
#define	RED		247
#define	ORANGE	246
#define	BLACK	0

#define	cms_palettesetup(r,g,b) \
{ int p_i; \
	for (p_i=0;p_i<256;p_i++) { \
		(r)[p_i] = p_i; (g)[p_i] = p_i; (b)[p_i] = p_i; \
	}\
	(r)[BLACK] = 0;		(g)[BLACK] = 0;		(b)[BLACK] = 0; \
	(r)[WHITE] = 255;	(g)[WHITE] = 255;	(b)[WHITE] = 255; \
	(r)[RED] = 255;		(g)[RED] = 0;		(b)[RED] = 0; \
	(r)[ORANGE] = 255;	(g)[ORANGE] = 200;	(b)[ORANGE] = 0; \
	(r)[YELLOW] = 250;	(g)[YELLOW] = 250;	(b)[YELLOW] = 0; \
	(r)[LIME] = 175;	(g)[LIME] = 255;	(b)[LIME] = 0; \
	(r)[BLUE] = 0;		(g)[BLUE] = 0;		(b)[BLUE] = 255; \
	(r)[CYAN] = 60;		(g)[CYAN] = 215;	(b)[CYAN] = 255; \
	(r)[PURPLE] = 200;	(g)[PURPLE] = 0;	(b)[PURPLE] = 255; \
	(r)[GREEN] = 0;		(g)[GREEN] = 170;	(b)[GREEN] = 0; \
	(r)[TEXT] = 0;		(g)[TEXT] = 0;		(b)[TEXT] = 0; \
	(r)[BACKGND] = 204;	(g)[BACKGND] = 165;	(b)[BACKGND] = 140; \
	(r)[SCREEN] = 64;	(g)[SCREEN] = 115;	(b)[SCREEN] = 102; \
	(r)[BORDER] = 180;	(g)[BORDER] = 145;	(b)[BORDER] = 120; \
	(r)[HIGHLITE] = 180;	(g)[HIGHLITE] = 145;	(b)[HIGHLITE] = 130; \
}
