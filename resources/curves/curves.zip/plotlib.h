/*
file of global variables for the plotting lines etc in a sun window
*/
extern float x_scale,y_scale;
extern float aspect_ratio;
extern char window_label[255];    /* text for top of sun window */
extern char current_colour[50];
extern int ps_dump;
extern int ps_raw;
extern FILE *fp_ps;
extern int border;
extern int mapping;
