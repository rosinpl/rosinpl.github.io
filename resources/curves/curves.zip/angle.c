#include <math.h>

#define PI 3.141592654

float angle(x1, y1, x2, y2)
float x1, y1, x2, y2;
{
	float angle_temp;
	float xx, yy;

	xx = x2 - x1;
	yy = y2 - y1;
	if (xx == 0.0)
		angle_temp = PI / 2.0;
	else
		angle_temp = atan(fabs(yy / xx));
	if ((xx < 0.0) && (yy >= 0.0))
		angle_temp = PI - angle_temp;
	else if ((xx < 0.0) && (yy < 0.0))
		angle_temp = PI + angle_temp;
	else if ((xx >= 0.0) && (yy < 0.0))
		angle_temp = PI * 2.0 - angle_temp;
	return (angle_temp);
}
