/*
	improve_ellipses.c

	Takes result of any of the ellipse fitting programs and
	for each ellipse computes the fit to the pixel data.
	Objective is to improve the ellipse fit over that for fitting
	ellipses to the vertices of the line data.
	Inefficient implementation because to determine which part of the
	pixel data to fit to, it searches through the pixel data for the
	particular list searching for the end points of the ellipse.
	All other representations in the super data are ignored.

	Modified 12-2-92 GAWW/PLR to incorporate Safaee-Rad bias correcting
	formula for ellipse fitting - now have two stages of lms ellipse
	fitting.

	Use an option on the command line to state if want the bias
	corrected or not.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define DEBUG 0            /* compile debug output if 1 */

#define LARGE_SIG 99999    /* significance always greater
                              that a computed one */
#define MIN_LENGTH 5       /* minimum length of data to fit to an ellipse
                              need at least 5 points to fit an ellipse */

#define FALSE 0
#define TRUE !FALSE

#define TINY 1.0e-20

#define sqr(x) ((x) * (x))

#define LISTS 1
#define LINES 2
#define ARCS 3
#define ELLIPSES 6
#define ENDL 4
#define ENDF 5

#define MAX_PIXEL 10000   /* max number of lines per list */
#define LINE 1
#define ARC 2
#define IGNORE 3
#define PI 3.141591
#define SMALL 1             /* type of arc */
#define BIG 2
#define CLOCKWISE 1         /* direction of arc from start to finish */
#define ANTICLOCKWISE 2

#define ELLIPSE 0
#define PARABOLA 1
#define HYPERBOLA 2


/* improve_ellipses definitions */
 
#define FIRST 1
#define SECOND 2
#define THIRD 3

/* pixel data */
int x_in[MAX_PIXEL],y_in[MAX_PIXEL];
int npix;

/* temp data in determine_ellipse */
float x_trans3[MAX_PIXEL],y_trans3[MAX_PIXEL];
float weight[MAX_PIXEL];				/* weight for each pixel for lms */
int nseg2;


FILE *fp_in,*fp_in2,*fp_out;

int representation_ok;  /* fitting algorithm can signal if cannot
                           fit at all to the data */

long no_lines_1,no_ellipses_1,no_ellipses_2;

int find_conic_type(double c1, double c2, double c3);
int curve_type(char array[50]);
void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir);
void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir);
void compute_poly_lgt(float *lgt);
float euclid(float x1, float y1, float x2, float y2);
float angle(float x1, float y1, float x2, float y2);
void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2);
float distance(double x1, double y1, double x2, double y2);
void error(char s[]);
void ludcmp(float a[6][6], int n, int indx[6], float *d);
void lubksb(float a[6][6], int n, int indx[6], float b[6]);
void determine_parameters(float m[], float *major_axis, float *minor_axis, float *rot_angle);
void read_pixels(int *number_pixels, int *end_of_file, int *list_no);
void improve_ellipses(int *no_segs,int *end_of_file,int corrected_bias);
void determine_weights(double xc, double yc, double maj, float m[], float weight[]);
void determine_ellipse_fit(int st, int fi, float *final_major_axis, float *final_minor_axis, float *final_rot_angle, int *final_xc, int *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig, int *ok, int corrected_bias);
void determine_ellipse_lms(float m[7]);

main(argc,argv)
int argc;
char *argv[];
{
    char ch;
	char file_type[50];
	char file_in[50],file_in2[50],file_out[50];
	int set_file_in,set_file_in2,set_file_out;
	int corrected_bias;
	int count;
	int i;
	int no_segs,end_of_file;
	char *temp;

	set_file_in = FALSE;
	set_file_in2 = FALSE;
	set_file_out = FALSE;
	corrected_bias = FALSE;


    if(argc > 1){
        /* use command line options */
        count = 0;
        do{
            count++;
            temp = argv[count];
            if(*argv[count] == '-'){
                ch = *(++temp);
                switch (ch) {
    				case 's':
    					count++;
    					strcpy(file_in,argv[count]);
    					printf("super input %s\n",file_in);
    					set_file_in = TRUE;
    					break;
    				case 'p':
    					count++;
    					strcpy(file_in2,argv[count]);
    					printf("pixel input %s\n",file_in2);
    					set_file_in2 = TRUE;
    					break;
    				case 'o':
    					count++;
    					strcpy(file_out,argv[count]);
    					printf("super output %s\n",file_out);
    					set_file_out = TRUE;
    					break;
    				case 'h':
    					printf("options:\n");
    					printf("    -s: input super data file name\n");
    					printf("    -p: input pixel data file name\n");
    					printf("    -o: output super data file name\n");
    					exit(1);
    					break;
					case 'c':
						corrected_bias = TRUE;
						break;
    				default:
                        printf("illegal option %c\n",ch);
                        argc = 0;
                        exit(1);
                        break;
				}
			}
			else{
				printf("error on command line\n");
				exit(1);
			}
        }while(count < argc-1);
    }
	else{
    	printf("    PROGRAM refine_ellipses\n\n");
		printf("options:\n");
    	printf("    -s: input super data file name\n");
    	printf("    -p: input pixel data file name\n");
    	printf("    -o: output super data file name\n");
		printf("    -c: correct bias for ellipse fitting\n");
		exit(1);
	}
    
	if(set_file_in == FALSE){
		printf("need an input file of super data - aborting\n");
		exit(1);
	}
	if(set_file_in2 == FALSE){
		printf("need an input file of pixel data - aborting\n");
		exit(1);
	}
	if(set_file_out == FALSE){
		printf("need an output super data file - aborting\n");
		exit(1);
	}
	if(corrected_bias == FALSE)
		printf("not correcting for bias in ellipses\n");
	else
		printf("correcting for bias in ellipses\n");
	
	printf("input super data file %s\n",file_in);
    if((fp_in = fopen(file_in,"r")) == NULL){
        printf("cant open %s\n",file_in);
        exit(1);
    }
	
	/* read magic word for format of file */
	fscanf(fp_in,"%s\n",file_type);
	i = strcmp(file_type,"super");
	if(i != 0){
		printf("not super data file - aborting\n");
		exit(1);
	}
	
	printf("input pixel data file %s\n",file_in2);
    if((fp_in2 = fopen(file_in2,"r")) == NULL){
        printf("cant open %s\n",file_in2);
        exit(1);
    }
	
	/* read magic word for format of file */
	fscanf(fp_in2,"%s\n",file_type);
	i = strcmp(file_type,"pixel");
	if(i != 0){
		printf("not super data file - aborting\n");
		exit(1);
	}

    printf("output super data file %s\n",file_out);
    if((fp_out = fopen(file_out,"w")) == NULL){
        printf("cant open %s\n",file_out);
        exit(-1);
    }
	
	/* write magic word at top of file */
	fprintf(fp_out,"super\n");

    /* read next line of super data */
	do{
        improve_ellipses(&no_segs,&end_of_file,corrected_bias);
    }while(end_of_file == 0);
    fclose(fp_in);
    fclose(fp_in2);
    fclose(fp_out);

	/* output stats of the program */
	printf("no of lines:              %d\n",no_lines_1);
	printf("no of ellipses:           %d\n",no_ellipses_1);
	printf("no of ellipses refined:   %d\n",no_ellipses_2);
}


void improve_ellipses(int *no_segs,int *end_of_file,int corrected_bias)
{
    int i,j,k;
    char dumstring[50],data_type[40],ch;
    int d1,d2,d3,d4,d5,d6,d7,d8,d9;
	float e1,e2,e3,e4;
    int tx1,ty1,tx2,ty2;
	float sig;
	int list_nop,list_no;
	float major_axis,minor_axis,rot_angle,max_dev;
	float temp;
	int centre_x,centre_y,start_x,start_y,end_x,end_y,arc_dir,arc_length;
	int end_of_file2;
	int st,fi;
	int found;
	int ok;

    k = 0;
    do{
        i = -1;
        do{
            fscanf(fp_in,"%c",&ch);
            data_type[++i] = ch;
        }while(ch != ':');
        data_type[++i] = '\0';
        j = curve_type(data_type);

/*        printf("data type: %s j: %d\n",data_type,j); */

        if(j == LISTS){
            fscanf(fp_in,"%d\n",&list_no);
            /* printf("list no: %d\n",list_no); */
			fprintf(fp_out,"list: %d\n",list_no);
			
			/* read pixel data for this list from a pixel data file */
			read_pixels(&npix,&end_of_file2,&list_nop);
			if(list_nop != list_no){
				printf("pixel list missing from the file - aborting\n");
				exit(1);
			}
        }
        else if(j == LINES){
            k++;
            fscanf(fp_in,"%f %d %d %d %d\n",
                &e1,&d1,&d2,&d3,&d4);
			no_lines_1++;
            fprintf(fp_out,"line: %f %d %d %d %d\n",
                e1,d1,d2,d3,d4);
        }
        else if(j == ARCS){
            printf("warning! ARC in data - ignoring\n");
            fscanf(fp_in,"%f %d %d %d %d %d %d %d %d\n",
                &e1,&d1,&d2,&d3,&d4,&d5,&d6,&d7,&d8);
            fprintf(fp_out,"arc: %f %d %d %d %d %d %d %d %d\n",
                e1,d1,d2,d3,d4,d5,d6,d7,d8);
        }
        else if(j == ELLIPSES){
            fscanf(fp_in,"%f %d %d %d %d %d %d %f %f %f %d\n",
                &e1,&d1,&d2,&start_x,&start_y,&end_x,&end_y,&e2,&e3,&e4,&d7);
            no_ellipses_1++;
			/*
			printf("original ellipse: %f %d %d %d %d %d %d %f %f %f %d\n",
                e1,d1,d2,start_x,start_y,end_x,end_y,e2,e3,e4,d7);
			*/
			/* compute ellipse fit to pixel data */
			
			/* search pixel data for first and last pixels */
			found = FALSE;
			i = 0;
			do{
				i++;
				if((x_in[i] == start_x) && (y_in[i] == start_y)){
					found = TRUE;
					st = i;
				}
			}while((found == FALSE) && ( i < npix));
			if((i == npix) && (found == FALSE)){
				printf("end of list reached before finding start pixel - aborting\n");
				exit(1);
			}
			found = FALSE;
			do{
				i++;
				if((x_in[i] == end_x) && (y_in[i] == end_y)){
					found = TRUE;
					fi = i;
				}
			}while((found == FALSE) && ( i < npix));
			if((i == npix) && (found == FALSE)){
				printf("end of list reached before finding end pixel - aborting\n");
				exit(1);
			}
			/* printf("start %d end %d\n",st,fi); */
        	
			determine_ellipse_fit(st,fi,&major_axis,&minor_axis,
			      				&rot_angle,&centre_x,&centre_y,
                              	&max_dev,&arc_length,&arc_dir,&sig,
								&ok,corrected_bias);
			if(ok == TRUE){
				no_ellipses_2++;
				/* save new ellipse */
				/*
				printf("new ellipse: %f %d %d %d %d %d %d %f %f %f %d\n",
                				sig,centre_x,centre_y,start_x,start_y,
								end_x,end_y,major_axis,minor_axis,rot_angle,
								arc_dir);
				*/
				/* HACK to make the major axis largest */
				if(major_axis < minor_axis){
					temp = minor_axis;
					minor_axis = major_axis;
					major_axis = temp;
					rot_angle += PI/2.0;
				}
            	fprintf(fp_out,"ellipse: %f %d %d %d %d %d %d %f %f %f %d\n",
                				sig,centre_x,centre_y,start_x,start_y,
								end_x,end_y,major_axis,minor_axis,rot_angle,
								arc_dir);
			}
			else{
				printf("list: %d\n",list_no);
				/* save original ellipse */
            	fprintf(fp_out,"ellipse: %f %d %d %d %d %d %d %f %f %f %d\n",
                				e1,d1,d2,start_x,start_y,end_x,end_y,
								e2,e3,e4,d7);
			}
        }
        else if(j == ENDL){  /* read to end of list */
            fscanf(fp_in,"\n");
			fprintf(fp_out,"endl:\n");
        }
    }while((j != ENDL) && (j != ENDF));
    if(j == ENDF){
        *end_of_file = 1;
		fprintf(fp_out,"endf:\n");
	}
    else
        *end_of_file = 0;
}


void read_pixels(int *number_pixels, int *end_of_file, int *list_no)
{
    char dumstring[50];
    int j;
    int tx,ty;

    fscanf(fp_in2,"%s %d\n",dumstring,list_no);
    /* printf("reading pixel list %d ",*list_no); */
    j = 0;
    do{
        j++;
        fscanf(fp_in2,"%d %d\n",&tx,&ty);
        x_in[j] = tx;
        y_in[j] = ty;
    }while(tx != -1);
    if(ty == -1)
        *end_of_file = 1;
    else
        *end_of_file = 0;
    *number_pixels = --j;
    /* printf("number of pixels %d\n",*number_pixels); */
}


/*
int round(value)
float value;
{
    int i;

    i = floor(value + 0.5);
    return(i);
}
*/

float angle(float x1, float y1, float x2, float y2)
{
    float angle_temp;
    float xx,yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if(xx == 0.0)
    	angle_temp = PI/2.0;
    else
        angle_temp = atan(fabs(yy/xx));
    if((xx < 0.0) && (yy >= 0.0))
       angle_temp = PI - angle_temp;
    else if((xx < 0.0) && (yy < 0.0))
       angle_temp = PI + angle_temp;
    else if((xx >= 0.0) && ( yy < 0.0))
       angle_temp = PI*2.0 - angle_temp;
    return(angle_temp);
}

float euclid(float x1, float y1, float x2, float y2)
{
    float temp1,temp2;
    float dist;

    temp1 = fabs(x1-x2);
    temp2 = fabs(y1-y2);
    dist = sqrt(sqr(temp1)+sqr(temp2));
    return(dist);
}

void compute_minimum_diff(float *deviation,float x_cir,float  y_cir,float  x1,float  y1,float  x2,float  y2)
{
    /* rotate polygon segment (x1,y1) -> (x2,y2) to lie along x axis,
       compute the minimum distance between the line segment and
       a point on the circle defined as (x_cir,y_cir).
       take perpendicular distance if x_cir between end points else
       take euclidian distance to nearest end point.
    */
    float angle1,angle2;
    float x_off,y_off,cosine,sine;
    float temp,x_pos,y_pos;
    float x_diff,y_diff;
    int flag1;
    float temp1,temp2;
    float min1,min2;

/*
    printf("entered compute_minimum_diff\n");
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    angle1 = angle(x1,y1,x2,y2);
    cosine = cos(-angle1);
    sine = sin(-angle1);
    x_off = x1;
    y_off = y1;
    /* offset points so x1,y1 at origin */
    x1 = 0;
    y1 = 0;
    x2 = x2 - x_off;
    y2 = y2 - y_off;
    x_cir = x_cir - x_off;
    y_cir = y_cir - y_off;
    /* rotate points with x2,y2 on x axis */
    temp = x2*cosine - y2*sine;
    y2 = x2*sine + y2*cosine;
    x2 = temp;
    temp = x_cir*cosine - y_cir*sine;
    y_cir = x_cir*sine + y_cir*cosine;
    x_cir = temp;
/*
    printf("x_cir: %f y_cir %f\n",x_cir,y_cir);
    printf("x1: %f y1 %f x2 %f y2 %f\n",x1,y1,x2,y2);
*/
    min1 = euclid(x_cir,y_cir,x1,y1);
    min2 = euclid(x_cir,y_cir,x2,y2);
    if(x_cir < x1){
        *deviation = min1;
    }else if(x_cir > x2){
        *deviation = min2;
    }else{
        *deviation = fabs(y_cir);
    }
/*    printf("deviation: %f\n",*deviation,); */
}

void compute_dev(float *max_dev, int *max_pos, double major_axis, double minor_axis, int arc_dir)
/*
New version that walks around hypothesised ellipse
finding minimum distance to polygon at each step.
Nearest point is either the perpendicular distance,
or the euclidian distance to the nearest end point.
For all cases the nearest end point is taken as the
possible break point. max_dev is the deviation,
max_pos is the vertex for max_dev,
major_axis,minor_axis define the ellipse
*/
{
    int l2;
    float l1,step;
    float s_ang,f_ang,temp;
    float x_cir,y_cir;
    float deviation;
    float min_dev;
    int min_pos;

    *max_dev = 0.0;

    /* determine angles */
    s_ang = angle(0.0,0.0,x_trans3[1]/major_axis,y_trans3[1]/minor_axis);
    f_ang = angle(0.0,0.0,
                  x_trans3[nseg2]/major_axis,y_trans3[nseg2]/minor_axis);
#if DEBUG
    printf("start coords: %f %f\n",x_trans3[1],y_trans3[1]);
    printf("finish coords: %f %f\n",x_trans3[nseg2],y_trans3[nseg2]);
    printf("angles: %f %f\n",s_ang,f_ang);
#endif
    /* default is anticlockwise, swap if clockwise */
    if(arc_dir == CLOCKWISE){
        temp = s_ang;
        s_ang = f_ang;
        f_ang = temp;
    }
/* ang4 must be bigger than ang3 */
    if(f_ang < s_ang){
        f_ang += PI*2.0;
    }
#if DEBUG
    printf("start angle: %f finish angle %f\n",s_ang,f_ang);
/* walk around circle from angle1 to angle2 */
    printf("walking around circle\n");
#endif
    step = (f_ang-s_ang)/10.0;    /* use 11 steps presently */
    l1 = s_ang;
    do{
        min_dev = 1000000;
        x_cir = cos(l1) * major_axis;
        y_cir = sin(l1) * minor_axis;
        /* printf("\nl1: %f (x_cir,y_cir): %f %f\n",l1,x_cir,y_cir);  */
        l2 = 1;
        do{
            /* printf("for line %d\n",l2);   */
            compute_minimum_diff(&deviation,x_cir,y_cir,x_trans3[l2],
                                 y_trans3[l2],x_trans3[l2+1],y_trans3[l2+1]);
            if(deviation < min_dev){
                min_dev = deviation;
				min_pos = l2;
            }
            l2++;
        }while(l2 <= nseg2-1);
        /* printf("at this angle minimum deviation: %f at vertex: %d\n",
        min_dev,pos1);  */
        if(min_dev > *max_dev){
            *max_dev = min_dev;
			*max_pos = min_pos;
        }
        l1 += step;
    }while (l1 <= f_ang);
#if DEBUG
    printf("maximum deviation: %f\n",*max_dev);
#endif
}

void compute_lgt(float *lgt, double major_axis, double minor_axis, int arc_dir)
{
    /* computes length of arc
    works on temporary data from determine_ellipse_fit
    i.e. data: (x_trans3,y_trans3),major_axis,minor_axis.
    new version computes start and finish angles, then
    arc length from angle and radius */

    float s_ang,f_ang,temp;
	float xold,yold,xnew,ynew;
    float step;

    s_ang = angle(0.0,0.0,x_trans3[1]/major_axis,y_trans3[1]/minor_axis);
    f_ang = angle(0.0,0.0,
                  x_trans3[nseg2]/major_axis,y_trans3[nseg2]/minor_axis);
    /* default is anticlockwise, so swap angles if clockwise */
    if(arc_dir == CLOCKWISE){
       temp = s_ang;
       s_ang = f_ang;
       f_ang = temp;
    }
    /* start angle must be less that f_ang */
    if (f_ang < s_ang)
       f_ang += PI*2.0;
	*lgt = 0.0;
	xold = major_axis * cos(s_ang);
	yold = minor_axis * sin(s_ang);
	step = (f_ang - s_ang) / 20.0;
	temp = s_ang;
	do{
		temp += step;
		xnew = major_axis * cos(temp);
		ynew = minor_axis * sin(temp);
		*lgt = *lgt + distance(xold,yold,xnew,ynew);
        xold = xnew;
        yold = ynew;
	}while(temp <= f_ang);
}

void compute_poly_lgt(float *lgt)
/* debugged and working */
{
    int loop1;
    float dx,dy;
    float total,dist;

    total = 0.0;
    for(loop1 = 1;loop1 < nseg2;loop1++){
        dx = x_trans3[loop1] - x_trans3[loop1+1];
        dy = y_trans3[loop1] - y_trans3[loop1+1];
        dist = sqrt(sqr(dx)+sqr(dy));
        total += dist;
    }
    *lgt = total;
}

int find_conic_type(double c1, double c2, double c3)
{
	float fx;
	int temp;

	fx = c1 * c3 - c2 * c2 / 4;
    if (fx > 0)
        temp = ELLIPSE;
	else if (fx < 0)
        temp = HYPERBOLA;
	else
        temp = PARABOLA;
	return(temp);
}

/*
 Determine the best fit ellipse
*/
void determine_ellipse_fit(int st, int fi, float *final_major_axis, float *final_minor_axis, float *final_rot_angle, int *final_xc, int *final_yc, float *final_dev, int *final_lgt, int *arc_dir, float *sig, int *ok, int corrected_bias)
{
    /* ellipse fitting variables */
    float m[7];   /* coefficients of best fit ellipse */

    /* new variables for lms fitting */
    float x_cent,y_cent;
    float c_ang;

    /* original variables */
    float xt,yt;   /* temp variables */
    float x_cent_t,y_cent_t; /* temp centre coords - after transformation */
    float sine,cosine;
    float max_dev,arc_length,poly_length;
    int loop1,loop2;
    int max_pos;
    float sum,ratio;
    int start_y,finish_y;
    float temp;
    int arc_size;
    float x_off,y_off;
    float major_axis,minor_axis,rot_angle;
    float xs,ys,xf,yf;
    float x_org,y_org;

#if DEBUG
    printf("\n\entering determine_ellipse_fit for data from: %d to %d\n",st,fi);
#endif

	*ok = TRUE;

    /* get data into temp array */
    nseg2=0;
    for(loop1 = st;loop1 <= fi;loop1++){
       nseg2++;
       x_trans3[nseg2] = x_in[loop1];
       y_trans3[nseg2] = y_in[loop1];
    }

    /* shift data to the origin to minimise numerical errors */
    x_org = y_org = 0;
    for(loop1=1;loop1<=nseg2;loop1++){
	    x_org += x_trans3[loop1];
	    y_org += y_trans3[loop1];
    }
    x_org /= nseg2; y_org /= nseg2;
    for(loop1=1;loop1<=nseg2;loop1++){
	    x_trans3[loop1] -= x_org;
	    y_trans3[loop1] -= y_org;
    }

    /* DON'T REALLY NEED THIS NOW !!!!!!!!!! */
    /* scale values from 0 to 1 for kalman filter by dividing by 512 */
    for(loop1=1;loop1<=nseg2;loop1++){
	    x_trans3[loop1] /= 512.0;
	    y_trans3[loop1] /= 512.0;
    }

    /* initialise weights */
	for(loop1=1;loop1<=nseg2;loop1++)
		weight[loop1] = 1.0;
			
	determine_ellipse_lms(m);
    
    if ((representation_ok == TRUE) && (corrected_bias == TRUE)){
	    determine_parameters(m,&major_axis,&minor_axis,&rot_angle);
	
	    x_cent = (-m[4]*m[3]/2.0 + m[5]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);
	    y_cent = (-m[1]*m[5]/2.0 + m[4]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);
	
		determine_weights(x_cent,y_cent,major_axis,m,weight);
	
		determine_ellipse_lms(m);
	}

#if DEBUG
    printf("coefficients for fitted ellipse:\n");
    printf("%2.3f %2.3f %2.3f %2.3f %2.3f %2.3f\n",
	m[1],m[2],m[3],m[4],m[5],m[6]);
#endif

    if (representation_ok == FALSE) {
         printf("REP != ELLIPSE!!! ");
         /* save parameters for non-ellipse as integers */
         *final_major_axis = *final_minor_axis = *final_rot_angle
                           = *final_xc = *final_yc = *final_lgt
                           = *final_dev = 0;
         *sig = LARGE_SIG;
         /* set position of maximum deviation to be middle of curve */
		 *ok = FALSE;
         return;
    }

    /* determine arc_size
     * transform temp to lie along x axis, then compute average displacement
     * of y coords. If +ve then circle on +ve side of axis else on -ve. This
     * in combination with the position of the centre will indicate if the are
     * is large (>180 degrees) or small (<=180 degrees). Also can determine if
     * arc is clockwise or anticlockwise
     * rotate and translate temp data.
     * take chord between points, rotate so that chord is
     * along x axis - rotate and translate all other points the same.
     */
    c_ang = angle(x_trans3[1],y_trans3[1],x_trans3[nseg2],y_trans3[nseg2]);
    sine = sin(-c_ang);
    cosine = cos(-c_ang);

    /* translate so first point is at origin */
    x_off = x_trans3[1];
    y_off = y_trans3[1];
    for(loop1 = 1;loop1 <= nseg2;loop1++){
        x_trans3[loop1] = x_trans3[loop1] - x_off;
        y_trans3[loop1] = y_trans3[loop1] - y_off;
    }
    /* rotate to align chord with x axis */
    for(loop1 = 1;loop1 <= nseg2;loop1++){
        xt = x_trans3[loop1];
        yt = y_trans3[loop1];
        temp = xt*cosine - yt*sine;
        x_trans3[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans3[loop1] = temp;
    }
    /* do same for centre */
    x_cent = (-m[4]*m[3]/2.0 + m[5]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);
    y_cent = (-m[1]*m[5]/2.0 + m[4]*m[2]/4.0) / (m[1]*m[3] - m[2]*m[2]/4.0);

    xt = x_cent - x_off;
    yt = y_cent - y_off;
    temp = xt*cosine - yt*sine;
    x_cent_t = temp;
    temp = xt*sine + yt*cosine;
    y_cent_t = temp;

    /* compute average y coord of all points */
    sum = 0.0;
    for(loop1=1;loop1<=nseg2;loop1++)
        sum += y_trans3[loop1];

    /* determine size and sense of arc */
    if((sum >= 0.0) && (y_cent_t >= 0.0)){
        arc_size = BIG;
        *arc_dir = CLOCKWISE;
    }
    else if((sum < 0.0) && (y_cent_t < 0.0)){
        arc_size = BIG;
        *arc_dir = ANTICLOCKWISE;
    }
    else if((sum >= 0.0) && (y_cent_t < 0.0)){
        arc_size = SMALL;
        *arc_dir = CLOCKWISE;
    }
    /* CHANGED Y_CENT TO Y_CENT_T - PLR */
    else if ((sum < 0.0) && (y_cent_t >= 0.0)){
        arc_size = SMALL;
        *arc_dir = ANTICLOCKWISE;
    }
#if DEBUG
    if(arc_size == SMALL)
        printf("small arc ");
    else
        printf("big arc ");
    if(*arc_dir == CLOCKWISE)
        printf("direction clockwise\n");
    else
        printf("direction anticlockwise\n");
#endif

    /*
    for(loop2=1;loop2<=nseg2;loop2++)
        printf("x_trans3: %f y_trans3: %f\n",x_trans3[loop2],y_trans3[loop2]);
    */

    /* convert coefficients to more meaningful parameters */
    determine_parameters(m,&major_axis,&minor_axis,&rot_angle);

    /* scale parameters to image space */
    major_axis *= 512.0;
    minor_axis *= 512.0;
    x_cent *= 512.0;
    y_cent *= 512.0;

    /* shift parameters back from origin */
    x_cent += x_org;
    y_cent += y_org;


#if DEBUG
	printf("parameters of ellipse:\n");
	printf("major_axis axis: %f minor_axis_axis %f\n",major_axis,minor_axis);
	printf("rotation angle of major_axis axis: %f\n",rot_angle);
	printf("centre: %f %f\n",x_cent,y_cent);
#endif

      xs = x_in[st];
      ys = y_in[st];
      xf = x_in[fi];
      yf = y_in[fi];


	/* transform data so the major_axis axis of the ellipse is along the x axis */
	/* get data into temp arrays */
    	loop2=0;
    	for(loop1 = st;loop1 <= fi;loop1++){
           loop2++;
           x_trans3[loop2] = x_in[loop1];
           y_trans3[loop2] = y_in[loop1];
    	}
	/* first translate */
    nseg2=loop2;
	for(loop1=1;loop1<=nseg2;loop1++){
		x_trans3[loop1] = x_trans3[loop1] - x_cent;
		y_trans3[loop1] = y_trans3[loop1] - y_cent;
	}
	/* now rotate */
	sine = sin(-rot_angle);
	cosine = cos(-rot_angle);
	for(loop1=1;loop1<=nseg2;loop1++){
            xt = x_trans3[loop1];
            yt = y_trans3[loop1];
            temp = xt*cosine - yt*sine;
            x_trans3[loop1] = temp;
            temp = xt*sine + yt*cosine;
            y_trans3[loop1] = temp;
	}
	x_cent_t = 0.0;
	y_cent_t = 0.0;

	/*
    determine length of ellipse for this circle approx - use data
    transformed to put major axis along x axis
    */
	compute_lgt(&arc_length,major_axis,minor_axis,*arc_dir);

    /*
    determine actual length of data - a polygon here
    */
    compute_poly_lgt(&poly_length);

    /*
    determine position and value of the maximum deviation - use data
    transformed to put major axis along x axis
    */
	compute_dev(&max_dev,&max_pos,major_axis,minor_axis,*arc_dir);

    /*
    hack to stop breakpoint near ends - to be modified
    break at middle of data if too close to end points
    */
    if((max_pos <= MIN_LENGTH) || (max_pos > nseg2-MIN_LENGTH))
       max_pos = nseg2 / 2;

#if DEBUG
    printf("arc length: %f\n",arc_length);
    printf("poly length: %f\n",poly_length);
    printf("maximum deviation: %f\n",max_dev);
    printf("point of maximum deviation: %d\n",max_pos);
#endif

    /* *****
    compute significance based on max_dev, arc_length and
    some heuristics!
    **** */
    /* polygonal length should be similar to arc length */
    ratio = poly_length / arc_length;
    if(ratio < 1)
       ratio = arc_length / poly_length;

    /* save parameters for best ellipse as integers */
    *final_major_axis = major_axis;
    *final_minor_axis = minor_axis;
    *final_rot_angle = rot_angle;
    *final_xc = round(x_cent);
    *final_yc = round(y_cent);
    *final_lgt = arc_length;
    max_dev = max_dev * ratio;        /* temp to modify sig */
    *final_dev = max_dev;

    if((max_dev != 0.0) && (arc_length != 0))
        *sig = max_dev / (float)arc_length;
    else
        *sig = LARGE_SIG;

    /* save position of maximum deviation */
}

/* LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void ludcmp(float a[6][6], int n, int indx[6], float *d)
{
        int i,imax,j,k;
        float big,dum,sum,temp;
        float vv[6];

        *d = 1.0;
        for (i = 1; i <= n; i++){
                big = 0.0;
                for (j = i; j <= n; j++)
                        if ((temp = fabs(a[i][j])) > big) big = temp;
                if (big == 0.0) error("Singular matrix in routine LUDCMP");
                vv[i] = 1.0/big;
        }
        for (j = 1; j <= n; j++) {
                for (i = 1; i < j; i++) {
                        sum = a[i][j];
                        for (k = 1; k < i; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                }
                big = 0.0;
                for (i = j; i <= n;i++) {
                        sum = a[i][j];
                        for (k = 1; k < j; k++) sum -= a[i][k] * a[k][j];
                        a[i][j] = sum;
                        if ( (dum = vv[i]*fabs(sum)) >= big) {
                                big = dum;
                                imax = i;
                        }
                }
                if (j != imax) {
                        for (k = 1; k <= n; k++) {
                                dum = a[imax][k];
                                a[imax][k] = a[j][k];
                                a[j][k] = dum;
                        }
                        *d = -(*d);
                        vv[imax] = vv[j];
                }
                indx[j] = imax;
                if (a[j][j] == 0.0) a[j][j] = TINY;
                if (j != n) {
                        dum = 1.0/(a[j][j]);
                        for (i = j+1; i <= n ;i++) a[i][j] *= dum;
                }
        }
}

/* forward substitution & backsubstitution */
/* use with LU Decomposition - from Numerical Recipes in C */
/* not-dynamic - assumes n=5; i.e. a[1..5][1..5], indx[1..5] */
void lubksb(float a[6][6], int n, int indx[6], float b[6])
{
        int i,ii=0,ip,j;
        float sum;

        for (i=1;i<=n;i++) {
                ip = indx[i];
                sum = b[ip];
                b[ip] = b[i];
                if (ii)
                        for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
                else if (sum) ii = i;
                b[i] = sum;
        }
        for (i=n;i>=1;i--) {
                sum = b[i];
                for (j=i+1;j<=n;j++) sum -= a[i][j]*b[j];
                b[i] = sum/a[i][i];
        }
}

/*
	albano ellipse fitting - no bias correction for high curvature
*/
void determine_ellipse_lms(float m[7])
{
	float x_cent,y_cent,radius2,factor;
	float c1,c2,c4,c5,c6;
	float dum1,dum2,dum3;
	float cc2,cc4,cc5;
    int i,j;
    char ch;
    float sx,sx2,sx3,sx4,sy,sy2,sy3,sy4,sxy,sx2y,sx3y,sx2y2,sxy2,sxy3;
    float x2,y2,x3,y3;
    float m1[6][6];
    float m2[6];
    int indx[6];
    float d;

   sx = 0;
   sx2 = 0;
   sx3 = 0;
   sx4 = 0;
   sy = 0;
   sy2 = 0;
   sy3 = 0;
   sy4 = 0;
   sxy = 0;
   sx2y = 0;
   sx3y = 0;
   sx2y2 = 0;
   sxy2 = 0;
   sxy3 = 0;

   for(j = 1; j <= nseg2; j++) {
      x2 = x_trans3[j] * x_trans3[j];
      x3 = x2 * x_trans3[j];
      y2 = y_trans3[j] * y_trans3[j];
      y3 = y2 * y_trans3[j];

      sx += x_trans3[j] / weight[j];
      sx2 += x2 / weight[j];
      sx3 += x3 / weight[j];
      sx4 += (x3 * x_trans3[j]) / weight[j];
      sy += y_trans3[j] / weight[j];
      sy2 += y2 / weight[j];
      sy3 += y3 / weight[j];
      sy4 += (y3 * y_trans3[j]) / weight[j];
      sxy += (x_trans3[j] * y_trans3[j]) / weight[j];
      sx2y += (x2 * y_trans3[j]) / weight[j];
      sx3y += (x3 * y_trans3[j]) / weight[j];
      sx2y2 += (x2 * y2) / weight[j];
      sxy2 += (x_trans3[j] * y2) / weight[j];
      sxy3 += (x_trans3[j] * y3) / weight[j];
   }

   m1[1][1] = sx4;
   m1[2][1] = sx3y;
   m1[3][1] = sx2y2;
   m1[4][1] = sx3;
   m1[5][1] = sx2y;
   m1[1][2] = sx3y;
   m1[2][2] = sx2y2;
   m1[3][2] = sxy3;
   m1[4][2] = sx2y;
   m1[5][2] = sxy2;
   m1[1][3] = sx2y2;
   m1[2][3] = sxy3;
   m1[3][3] = sy4;
   m1[4][3] = sxy2;
   m1[5][3] = sy3;
   m1[1][4] = sx3;
   m1[2][4] = sx2y;
   m1[3][4] = sxy2;
   m1[4][4] = sx2;
   m1[5][4] = sxy;
   m1[1][5] = sx2y;
   m1[2][5] = sxy2;
   m1[3][5] = sy3;
   m1[4][5] = sxy;
   m1[5][5] = sy2;

   m2[1] = -sx2;
   m2[2] = -sxy;
   m2[3] = -sy2;
   m2[4] = -sx;
   m2[5] = -sy;

   /* solve simultaneous equations */
   ludcmp(m1,5,indx,&d);
   lubksb(m1,5,indx,m2);

   m[1] = m2[1];
   m[2] = m2[2];
   m[3] = m2[3];
   m[4] = m2[4];
   m[5] = m2[5];
   m[6] = 1;

   if (find_conic_type(m[1],m[2],m[3]) != ELLIPSE)
       representation_ok = FALSE;
   else
       representation_ok = TRUE;

#if DEBUG
/* right parameters for these coefficients????? */
    printf("conic type: %d\n",find_conic_type(m[1],m[2],m[3]));
    do{
    }while(kbhit() == 0);
    ch = getch();
#endif
}


float distance(double x1, double y1, double x2, double y2)
{
	return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

/* new improved version that works analytically thanks to Alah */
void determine_parameters(float m[], float *major_axis, float *minor_axis, float *rot_angle)
{
    float x_cent,y_cent;
    float a,b,c,d,e,f;
    float ca,sa;
    float t,u,v,w;

    a = m[1];
    b = m[2];
    c = m[3];
    d = m[4];
    e = m[5];
    f = m[6];

    if (a == c)
       *rot_angle = 0;
    else
       *rot_angle = atan(b/(a-c)) / 2.0;
    ca = cos(*rot_angle);
    sa = sin(*rot_angle);
    t = a*sqr(ca)+b*ca*sa+c*sqr(sa);
    u = a*sqr(sa)-b*ca*sa+c*sqr(ca);
    v = d*ca+e*sa;
    w = -d*sa+e*ca;
    *major_axis = sqrt(((sqr(v)/(4*t))+(sqr(w)/(4*u))-f)/t);
    *minor_axis = sqrt(((sqr(v)/(4*t))+(sqr(w)/(4*u))-f)/u);
}

void determine_weights(double xc, double yc, double maj, float m[], float weight[])
{

	int i;
	double centre_to_point,centre_to_ellipse,ellipse_to_point;
	double a,b,c,m1,c1;
	double x1,y1,temp1,w;

	for(i=1;i<=nseg2;i++) {
		if ((x_trans3[i] - xc) == 0) {
			/* if gradient infinite */ 
			a = m[3];
			b = m[2]*x_trans3[i] + m[5];
			c = m[1]*x_trans3[i]*x_trans3[i] + m[4]*x_trans3[i] + m[6];
			temp1 = b*b - 4*a*c;
#if DEBUG
			printf("(1) xc: %f yc: %f x: %d y: %d\n",xc,yc,x_trans3[i],y_trans3[i]); 
			printf("(1) a: %f b %f c %f temp1: %f\n",a,b,c,temp1);
#endif
			if(temp1 < 0.0){
				printf("sqrt error - aborting\n");
				printf("(1) xc: %f yc: %f x: %.1f y: %.1f\n",xc,yc,x_trans3[i],y_trans3[i]); 
				printf("(1) a: %f b %f c %f temp1: %f\n",a,b,c,temp1);
				exit(1);
			}
			y1 = (float)(-b + sqrt(b*b - 4*a*c)) / (2.0*a);
			x1 = x_trans3[i];
		}
		else {
			m1 = (float)(y_trans3[i]-yc) / (float)(x_trans3[i]-xc);
			c1 = - m1*xc + yc;
			a = m[1] + m[2]*m1 + m[3]*m1*m1;
			b = m[2]*c1 + m[3]*2*m1*c1 + m[4] + m[5]*m1;
			c = m[3]*c1*c1 + m[5]*c1 + m[6];
			temp1 = b*b - 4*a*c;
#if DEBUG
			printf("(2) xc: %f yc: %f x: %.1f y: %.1f\n",xc,yc,x_trans3[i],y_trans3[i]);
			printf("(2) a: %f b %f c %f temp1: %f\n",a,b,c,temp1);
#endif
			if(temp1 < 0.0){
				printf("sqrt error - aborting\n");
				printf("(2) xc: %f yc: %f x: %.1f y: %.1f\n",xc,yc,x_trans3[i],y_trans3[i]);
				printf("(2) a: %f b %f c %f temp1: %f\n",a,b,c,temp1);
				exit(1);
			}
			x1 = (-b + sqrt(b*b - 4*a*c)) / (2.0*a);
			y1 = m1*x1 + c1;
		}
		centre_to_point = sqr(x_trans3[i]-xc)+sqr(y_trans3[i]-yc);
		centre_to_point = sqrt(centre_to_point);
		centre_to_ellipse = sqr(x1-xc) + sqr(y1-yc);
		centre_to_ellipse = sqrt(centre_to_ellipse);
		ellipse_to_point = fabs(centre_to_point - centre_to_ellipse);
	
		w = centre_to_ellipse;
		w = w * (1 + ellipse_to_point/(2.0 * maj));
		w = w / (1 + ellipse_to_point/(2.0 * centre_to_ellipse));
		weight[i] = w;
	}
}
	
int curve_type(char array[50])
{
    int i,j;

    if((j = strcmp(array,"list:")) == 0)
        i = LISTS;
    else if((j = strcmp(array,"line:")) == 0)
        i = LINES;
    else if((j = strcmp(array,"arc:")) == 0)
        i = ARCS;
    else if((j = strcmp(array,"endl:")) == 0)
        i = ENDL;
    else if((j = strcmp(array,"endf:")) == 0)
        i = ENDF;
    else if((j = strcmp(array,"ellipse:")) == 0)
        i = ELLIPSES;
    return(i);
}

/*
int strcmp(s,t)
char s[],t[];
{
    int i;

    i = 0;
    while(s[i] == t[i])
        if(s[i++] == '\0')
            return(0);
    return(s[i] - t[i]);
}
*/

void error(char s[])
{
   printf("ERROR: %s\n",s);
   exit(-1);
}
