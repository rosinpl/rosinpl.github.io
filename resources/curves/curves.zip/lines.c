/*
    LINES.C

    A  P.L. Rosin / G.A.W.West production. Copyright 1987 / 1988.

    May 1988:-
    Processes one connected set of pixels at a time to reduce
    memory requirements.
    Outputs data in super format (as for arcs) to allow extendability.

    November 1988:-
    Changed dev threshold to 2

    March 1989:-
    Now uses euclidean length of straight line, not length of list for
    significance calculation

    April 1989:-
    Compiler option to disable tail recursion in segment routine, to
    investigate affect of comparing significances - option RECURSION

    February 1990:-
    Horrible heuristic! - if deviation is 0 make it 1 - compiler option
    MAKE_ONE

    August 1990:-
    Outputs soft (non-break) points
    pixel flags stored in "flags" instead of x_c

    December 1990:-
    Outputs 0->4 soft break-points

    October 1991:-
    Added second stage - improve_lines
    Geoff

    July 1992:-
    Deals with floating point and integer input/output data.
    If integer pixel values generates integer line output
    If float pixel values generates float line output
    Geoff

    October 1993:-
    discard pixels lists with less than 2 pixels - avoid crashes!
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define RECURSION 1     /* compile tail recursion if 1 in function segment */
#define MAKE_ONE 1       /* compile heuristic if 1 in function deviation */

#define SIZE 50000    /* used to be 2048 - not enough for racer image */
#define NINETY 1.570796327

#define MIN_DEV 1.9   /* minimum allowable deviation  ad hoc value! */

#define OK 0
#define NULL_BRKPT -3
#define NULL_SIG -9999
#define ALL_SBREAK 0      /* all non-endpoints as soft breakpoints */
#define SBREAK_1 1        /* 1 soft breakpoint at middle of curve */
#define SBREAK_2 2        /* 2 soft breakpoints in curve */
#define SBREAK_3 3        /* 2 soft breakpoints + middle breakpoint */
#define SBREAK_4 4        /* 0 up to 4 soft breakpoints */
#define NO_SBREAK 5       /* no soft breakpoints */

#define FALSE 0
#define TRUE !FALSE

#define FIRST 1           /* three constants used in improve_lines */
#define SECOND 2
#define THIRD 3

#define sqr(x) ((x)*(x))
/* our version of abs for all number representations */
#define Abs(x) (x)<0?(-(x)):(x)

/* one list of pixels */
float x_c[SIZE],y_c[SIZE];
float sigs[SIZE],sums[SIZE];
int flags[SIZE];
int number_pixels;
int list_no;

/* x_c2/y_c2 transformed and rotated */
float x_c2[SIZE],y_c2[SIZE];
int end2;        /* end of segments in x_c2/y_c2 */

FILE *fp, *fp_out;

int sbreak = NO_SBREAK;
int use_improve;        /* use second stage */
int use_weight;
float weight;           /* if weight = 1.0, no effect, choose best sig */
                        /* < 1.0, favours new longer lines */

float min_dev;    /*  minimum deviation for a line - default MIN_DEV but can
                      be set by user */

int floating_point;   /* if TRUE - pixel_float file, FALSE - pixel int file */

void segment(int start_in,int finish_in, float *sig_out,float *sum_out);
void transform(int start,int finish);
void deviation(int *pos,float *dev,int *ok,float *sum);
void read_pixels( int *number_pixels, int *end_of_file, int *list_no);
void print_sbreaks(int start,int finish);
void improve_lines(int start_in,int finish_in);
void combine(int v1,int v2,int v3,int v4,int *flag);

main(argc,argv)
int argc;
char *argv[];
{
    int i,j;
    float sig;  /* not really used - just dummy param for segment */
    float sum;  /* as for sig above */
    char *file_name_in;
    char *file_name_out;
    int end_of_file;
    int line_start_index;
    char *ch;
    char file_type[50];
    long no_pixels,no_lines_1,no_lines_2;
    long no_lines_temp;
    int use_min_dev;
    int set_input_file = FALSE;
    int set_output_file = FALSE;
    int printed_endf = FALSE;

    use_improve = FALSE;
    use_weight = FALSE;
    use_min_dev = FALSE;
    
    weight = 1.0;
    min_dev = MIN_DEV;

    if (argc == 1) {
        printf("Usage: %s -i file -o file [options]\n",argv[0]);
        printf("options:\n");
        printf(" -a  all non-endpoints as breakpoints\n");
        printf(" -1  1 soft breakpoint at middle of curve\n");
        printf(" -2  2 soft breakpoints in curve\n");
        printf(" -3  2 soft breakpoints + middle breakpoint\n");
        printf(" -4  0 up to 4 soft breakpoints\n");
        printf(" -I     use improve_lines stage\n");
        printf(" -w (val) weight longer lines in improve_lines\n");
        printf(" -m  (val)set minimum deviation\n");
        exit(1);
    }

    while (--argc > 0 && (*++argv)[0] == '-') {
        for (ch = argv[0] + 1; *ch != '\0'; ch++) {
            switch (*ch) {
                case 'a':
                    sbreak = ALL_SBREAK;
                    break;
                case '1':
                    sbreak = SBREAK_1;
                    break;
                case '2':
                    sbreak = SBREAK_2;
                    break;
                case '3':
                    sbreak = SBREAK_3;
                    break;
                case '4':
                    sbreak = SBREAK_4;
                    break;
                case 'I':
                    use_improve = TRUE;
                    break;
                case 'i':
                    set_input_file = TRUE;
                    argc--; argv++;
                    file_name_in = argv[0];
                    break;
                case 'o':
                    set_output_file = TRUE;
                    argc--; argv++;
                    file_name_out = argv[0];
                    break;
                case 'm':
                    use_min_dev = TRUE;
                    argc--; argv++;
                    min_dev = atof(argv[0]);
                    break;
                case 'w':
                    use_weight = TRUE;
                    argc--; argv++;
                    weight = atof(argv[0]);
                    break;
                default:
                    printf("illegal option %c\n",*ch);
                    argc = 0;
                    exit(1);
                    break;
            }
        }
    }

#if RECURSION
    printf("using tail recursion\n");
#else
    printf("no tail recursion\n");
#endif
#if MAKE_ONE
    printf("using heuristic to make deviation = 1 if = 0\n");
#endif
    if (set_input_file == FALSE) {
        printf("no input file specified - aborting\n");
        exit(1);
    }
    if (set_output_file == FALSE) {
        printf("no output file specified - aborting\n");
        exit(1);
    }
    if (use_improve == TRUE)
        printf("using improve_lines\n");
    else
        printf("not using improve_lines\n");
    if (use_weight == TRUE)
        printf("user set weight\n");
    printf("weight for biasing decision in improve_lines: %f\n",weight);
    
    if (use_min_dev == TRUE)
        printf("user set minimum deviation: ");
    printf("minimum deviation from a line: %f\n",min_dev);

    if ((fp = fopen(file_name_in,"r")) == NULL) {
        printf("cant open %s\n",file_name_out);
        exit(1);
    }
    
    /* read magic word for format of file */
    fscanf(fp,"%s\n",file_type);
    if (strcmp(file_type,"pixel") == 0) {
        printf("pixel integer data file \n");
        floating_point = FALSE;
    }
    else if (strcmp(file_type,"pixel_float") == 0) {
        printf("pixel float data file \n");
        floating_point = TRUE;
    }
    else{
        printf("not pixel data file - aborting\n");
        exit(1);
    }

    if ((fp_out = fopen(file_name_out,"w")) == NULL) {
          printf("cant open %s\n",file_name_out);
        exit(1);
    }

    /* write magic word at top of file */
    if (floating_point == TRUE)
        fprintf(fp_out,"super_float\n");
    else
        fprintf(fp_out,"super\n");

    /* variables for statistics */
    no_pixels = 0;
    no_lines_1 = 0;
    no_lines_2 = 0;
    
    do {
        read_pixels(&number_pixels,&end_of_file,&list_no);

        if (number_pixels < 2) {
            printf("WARNING: skipping pixel list with only %d pixels\n",number_pixels);
            continue;
        }

        /* count number of pixels */
        no_pixels += number_pixels;

        for (i = 1; i<= number_pixels; i++) {
            sigs[i] = NULL_SIG;
            flags[i] = OK;
        }

        segment(1,number_pixels,&sig,&sum);

        /* count number of lines after first stage */
        for (i=1;i<number_pixels;i++)
            if (flags[i] != NULL_BRKPT)
                no_lines_1++;

        if (use_improve == TRUE)
            improve_lines(1,number_pixels);

        /* count number of lines after improvement */
        for (i=1;i<number_pixels;i++)
            if (flags[i] != NULL_BRKPT)
                no_lines_2++;

        /* super data output format */
        fprintf(fp_out,"list: %d\n",list_no);
        if (floating_point == FALSE)
            fprintf(fp_out,"line: %f %6.0f %6.0f ",sigs[1],x_c[1],y_c[1]);
        else
            fprintf(fp_out,"line: %f %f %f ",sigs[1],x_c[1],y_c[1]);
        line_start_index = 1;
        for (j = 2; j <= number_pixels - 1; j++) {
            if (flags[j] != NULL_BRKPT) {
                if (floating_point == FALSE)
                       fprintf(fp_out,"%6.0f %6.0f\n",x_c[j],y_c[j]);
                   else
                    fprintf(fp_out,"%f %f\n",x_c[j],y_c[j]);
                print_sbreaks(line_start_index,j);
                if (floating_point == FALSE)
                    fprintf(fp_out,"line: %f %6.0f %6.0f ",sigs[j],x_c[j],y_c[j]);
                else
                    fprintf(fp_out,"line: %f %f %f ",sigs[j],x_c[j],y_c[j]);
                line_start_index = j;
            }
        }
        if (floating_point == FALSE)
            fprintf(fp_out,"%6.0f %6.0f\n",x_c[number_pixels],y_c[number_pixels]);
        else
            fprintf(fp_out,"%f %f\n",x_c[number_pixels],y_c[number_pixels]);
        print_sbreaks(line_start_index,j);
        fprintf(fp_out,"endl:\n");
        if (end_of_file) {
            fprintf(fp_out,"endf:\n");
            printed_endf = TRUE;
        }
    } while (end_of_file == 0);

    if (!printed_endf)
        fprintf(fp_out,"endf:\n");

    /* print out statistics */
    printf("number of pixels processed:   %d\n",no_pixels);
    printf("after first pass\n");
    printf("number of lines:              %d\n",no_lines_1);
    printf("after second pass\n");
    printf("number of lines:              %d\n",no_lines_2);
}

void segment(int start_in,int finish_in, float *sig_out,float *sum_out)
{
    int i;
    int pos;
    float dev;
    float sig1,sig2,sig3,max_sig,sum1,sum2,sum3,best_sum;
    int ok;
    float length;

    /* compute significance at this level */

    transform(start_in,finish_in);
    deviation(&pos,&dev,&ok,&sum1);
/*
printf("POS %d\n",pos);
exit(1);
*/
    /*
    if (ok == FALSE)
        printf("F");
    else
        printf("T");
    */
#if MAKE_ONE
    if (dev == 0)
       dev = min_dev;
#endif
    pos = pos + start_in - 1;
    /* euclidean length */
    length = sqr(x_c2[1]-x_c2[end2]);
    length += sqr(y_c2[1]-y_c2[end2]);
    length = sqrt(length);
    sig1 = dev / length;
/***
printf("%3d -> %3d (%3d); sig = %6.2f\n",start_in,finish_in,finish_in-start_in,sig1);
***/
    sum1 = sum1 / length;
    if (((finish_in - start_in) < 3) || (dev < min_dev) || (ok == FALSE)) {
        /* save line match at this lowest of levels */
        /* modify x_c,y_c data to delete unused coordinates */
        /* save significance */
        sigs[start_in] = sig1;
        sums[start_in] = sum1;
        *sig_out = sig1;
        *sum_out = sum1;
        /* delete breakpoints between end points */
        if ((finish_in - start_in) >= 2)
            for (i = start_in + 1; i < finish_in;i++)
                flags[i] = NULL_BRKPT;
    }
    else{
        /* recurse to next level down */
        segment(start_in,pos,&sig2,&sum2);
        segment(pos,finish_in,&sig3,&sum3);
#if RECURSION
        /* get best significance from lower level */
        if (sig2 < sig3) {
            max_sig = sig2;
            best_sum = sum2;
        }
        else{
            max_sig = sig3;
            best_sum = sum3;
        }
        if (max_sig < sig1) {
            /* return best significance, keep lower level description */
            *sig_out = max_sig;
            *sum_out = best_sum;
        }
        else{
            /* line at this level is more significant so remove coords
               at lower levels */
            /*
			printf("JUST REPLACED LOWER LEVEL LINES\n");
			*/
            *sig_out = sig1;
            *sum_out = sum1;
            sigs[start_in] = *sig_out;
            sums[start_in] = *sum_out;
            if ((finish_in - start_in) >= 2)
                for (i = start_in + 1;i < finish_in;i++)
                    flags[i] = NULL_BRKPT;
        }
#endif
    }
}


void transform(int start,int finish)
{
    int i,j;
    float x_offset,y_offset,x_end,y_end;
    double angle,sine,cosine;
    double temp;

    x_offset = x_c[start];
    y_offset = y_c[start];
    x_end = x_c[finish];
    y_end = y_c[finish];
    if ((x_end - x_offset) == 0.0) {
        if ((y_end - y_offset) > 0.0)
            angle = -NINETY;
        else
            angle = NINETY;
    }
    else{
        temp = ((float)(y_end-y_offset) / (float)(x_end-x_offset));
        angle = -atan(temp);
    }
    cosine = cos(angle);
    sine = sin(angle);
    j = 0;
    for (i=start;i<=finish;i++) {
        j++;
        x_c2[j] = x_c[i] - x_offset;
        y_c2[j] = y_c[i] - y_offset;
        temp = (float)(cosine * x_c2[j]) - (float)(sine * y_c2[j]);
        y_c2[j] = (float)(sine * x_c2[j]) + (float)(cosine * y_c2[j]);
        x_c2[j] = temp;
    }
    end2 = j;
}

void deviation(int *pos,float *dev,int *ok,float *sum)
{
    int i;
    int pos1;
    float max1,temp;  /* temp used for abs deviation - dont change!! */

    pos1 = 0;
    max1 = 0.0;
    *sum = 0.0;
    for (i = 1;i <= end2;i++) {
       temp = Abs(y_c2[i]);
       if (temp > max1) {
          max1 = temp;
          pos1 = i;
       }
       *sum += temp;
    }
    /* if no peak found - signal with ok */
    if (max1 == 0.0)
       *ok = FALSE;
    else
        *ok = TRUE;
    *pos = pos1;
    *dev = max1;
}

void read_pixels( int *number_pixels, int *end_of_file, int *list_no)
{
    char dumstring[50];
    int j;
    int tx,ty;

    fscanf(fp,"%s %d\n",dumstring,list_no);
    /* printf("list: %d ",*list_no); */
    if (floating_point == FALSE) {
        /* read integer data */
        j = 0;
        do {
               j++;
            fscanf(fp,"%d %d\n",&tx,&ty);
            x_c[j] = tx;
            y_c[j] = ty;
            if (j > SIZE) {
                printf("ERROR: too many pixels\n");
                exit(1);
            }
        } while (x_c[j] != -1);
        if (y_c[j] == -1)
               *end_of_file = 1;
        else
               *end_of_file = 0;
        *number_pixels = --j;
        /* printf("pixels: %d\n",*number_pixels); */
    }
    else{
        /* read float data */
        j = 0;
        do {
               j++;
            fscanf(fp,"%f %f\n",&x_c[j],&y_c[j]);
            if (j > SIZE) {
                printf("ERROR: too many pixels\n");
                exit(1);
            }
        } while (x_c[j] != -1);
        if (y_c[j] == -1)
               *end_of_file = 1;
        else
               *end_of_file = 0;
        *number_pixels = --j;
        /* printf("pixels: %d\n",*number_pixels); */
    }
}

void print_sbreaks(int start,int finish)
{
   int i,j,k;
   int inc;

   if (sbreak == ALL_SBREAK)
   for (i = start+1; i <= finish-1; i++) {
      if (floating_point == TRUE)
        fprintf(fp_out,"sbreak: %f %f\n",x_c[i],y_c[i]);
      else
        fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[i],y_c[i]);
   }
   else if (sbreak == SBREAK_1) {
      i = (finish + start) / 2;
      if (floating_point == TRUE)
          fprintf(fp_out,"sbreak: %f %f\n",x_c[i],y_c[i]);
      else
        fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[i],y_c[i]);
   }
   else if (sbreak == SBREAK_2) {
      j = (finish - start) / 3;
      i = start + j;
      if (floating_point == TRUE)
          fprintf(fp_out,"sbreak: %f %f\n",x_c[i],y_c[i]);
      else
        fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[i],y_c[i]);
      j = (finish - start) / 3;
      i = start + 2 * j;
      if (floating_point == TRUE)
          fprintf(fp_out,"sbreak: %f %f\n",x_c[i],y_c[i]);
      else
        fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[i],y_c[i]);
   }
   else if (sbreak == SBREAK_3) {
      i = (finish + start) / 2;
      if (floating_point == TRUE)
        fprintf(fp_out,"sbreak: %f %f\n",x_c[i],y_c[i]);
      else
        fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[i],y_c[i]);
      j = (finish - start) / 3;
      i = start + j;
      if (floating_point == TRUE)
          fprintf(fp_out,"sbreak: %f %f\n",x_c[i],y_c[i]);
      else
        fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[i],y_c[i]);
      j = (finish - start) / 3;
      i = start + 2 * j;
      if (floating_point == TRUE)
          fprintf(fp_out,"sbreak: %f %f\n",x_c[i],y_c[i]);
      else
        fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[i],y_c[i]);
   }
   else if (sbreak == SBREAK_4) {
      for (i = 1; i <= 4; i++) {
         /* if there enough distinct internal breakpoints */
         if ((finish - start) >= (i + 1)) {
               inc = (finish - start) / (i + 1);
            for (j = 1; j <= i; j++) {
               k = start + j * inc;
                  if (floating_point == TRUE)
                       fprintf(fp_out,"sbreak: %f %f\n",x_c[k],y_c[k]);
                   else
                    fprintf(fp_out,"sbreak: %6.0f %6.0f\n",x_c[k],y_c[k]);
               }
         }
         /* otherwise flag unavailable breakpoints by -1 */
         else
            for (j = 1; j <= i; j++)
               fprintf(fp_out,"sbreak: -1 -1\n");
      }
   }
}

/* second stage after initial segmentation */

void improve_lines(int start_in,int finish_in)
/*
    For each line in representation, tries to combine with each neighbour.
    Four choices:
        Neighbour on right
        Neighbour on left
        Both neighbours
        Neither neighbours
    Chooses best representation.
    Repeats until can do no more.
*/
{

    int loop1,loop2,loop3,loop4;
    int cont,flag;

    /* 
        repeatedly scan the list of vertices until cannot alter anymore.
        for each scan generate all combinations of adjacent vertices, 
        i.e. find four vertices that form three lines in the data 
        (1) find a vertex that is flagged OK - start of first line
        (2) find next vertex flagged as OK - finish of first line/start of second
        (3) find next vertex flagged as OK - finish of second line/start of third
        (4) find next vertex flagged as OK - finish of third line
        Then pass info to combine.
    */
    do {
        cont = FALSE;
        loop1 = start_in-1;
        do {
            do {
                loop1++;
            } while ((flags[loop1] != OK) && (loop1 < finish_in));
            loop2 = loop1;
            do {
                loop2++;
            } while ((flags[loop2] != OK) && (loop2 < finish_in));
            loop3 = loop2;
            do {
                loop3++;
            } while ((flags[loop3] != OK) && (loop3 < finish_in));
            loop4 = loop3;
            do {
                loop4++;
            } while ((flags[loop4] != OK) && (loop4 < finish_in));
            /* 
                check to make sure the four vertices are different 
                some will be identical if reach end of list before all four
                vertices determined - call combine if they are different
            */
            if ((loop2 > loop1) && (loop3 > loop2) && (loop4 > loop3)) { 
                combine(loop1,loop2,loop3,loop4,&flag);
                if (cont == FALSE)
                    if (flag == TRUE)
                        cont = TRUE;
                /* print_reps(); */
            }
        } while (loop4 < finish_in);
    } while (cont == TRUE);
}

void combine(int v1,int v2,int v3,int v4,int *flag)
{
    float sig[4];
    int best[4];
    float sigp,sigc,sign;
    int i,j;
    int replaced;
    int ok,pos;
    float dev,sum;

    /* printf("\ninto combine\n"); */

    /* printf("number of pixels: %d\n",number_pixels); */
    /*
    for (i=1;i<=number_pixels;i++)
        printf("i: %3d flag: %6.1f sig: %10.3f coords: %3u %3u\n",
                i,flags[i],sigs[i],x_c[i],y_c[i]);
    */

    /*
    printf("vertex v1: %4d flag: %6.1f sig: %10.3f coords: %4d %4d\n",
            v1,flags[v1],sigs[v1],x_c[v1],y_c[v1]);
    printf("vertex v2: %4d flag: %6.1f sig: %10.3f coords: %4d %4d\n",
            v2,flags[v2],sigs[v2],x_c[v2],y_c[v2]);
    printf("vertex v3: %4d flag: %6.1f sig: %10.3f coords: %4d %4d\n",
            v3,flags[v3],sigs[v3],x_c[v3],y_c[v3]);
    printf("vertex v4: %4d flag: %6.1f sig: %10.3f coords: %4d %4d\n",
            v4,flags[v4],sigs[v4],x_c[v4],y_c[v4]);
    */
    
    sigp = sigs[v1];
    sigc = sigs[v2];
    sign = sigs[v3];

    /*
    printf("old sigs previous: %f current %f next %f\n",
        sigp,sigc,sign);
    */
    
    /* determine significances of combinations */
    /* only need the significance values from deviation() */
    
    /* combine with previous representation? */
    transform(v1,v3);
    deviation(&pos,&dev,&ok,&sum);
    sig[1] = dev / (float)end2;
    
    /* combine with next representation? */
    if (v4 > number_pixels)
        sig[2] = 9999;
    else{
        transform(v2,v4);
        deviation(&pos,&dev,&ok,&sum);
        sig[2] = dev / (float)end2;
    }
    
    /* combine with previous and next representation? */
    if (v4 > number_pixels)
        sig[3] = 9999;
    else{
        transform(v1,v4);
        deviation(&pos,&dev,&ok,&sum);
        sig[3] = dev / (float)end2;
    }

    /*
    printf("new significances: first %f second %f third %f\n",
        sig[1],sig[2],sig[3]);
    */
    
    /* rank significances */
    /* temporary set significance of THIRD to 9999 to stop it being used */
    
    best[1] = FIRST;
    best[2] = SECOND;
    best[3] = THIRD;
    for (j=1;j<=2;j++)
        for (i=1;i<=2;i++)
            if (sig[i+1] < sig[i]) {
                sig[0] = sig[i];
                sig[i] = sig[i+1];
                sig[i+1] = sig[0];
                best[0] = best[i];
                best[i] = best[i+1];
                best[i+1] = best[0];
            }


    /* 
    Replace original representation if this one better - 
    Complex decision rules:
        if the best sig is better than the old then 
            replace
        else 
            try the next best significance
    This is continued until run out of replacements.
    */
    i = 0;
    replaced = FALSE;
    do {
        i++;
        if (best[i] == THIRD) { 
            if ((sig[i]*weight<sigp) && (sig[i]*weight<sigc) && (sig[i]*weight<sign)) {
                /* replace all three previous reps */
                /* replace previous, delete current and next */
                /* printf("replacing with THIRD %d\n",list_no); */
                replaced = TRUE;
                /* delete current and next, modify previous */
                flags[v2] = NULL_BRKPT;
                flags[v3] = NULL_BRKPT;
                sigs[v1] = sig[i];
            }
        }
        else if (best[i] == FIRST) {
            if ((sig[i]*weight<sigp) && (sig[i]*weight<sigc)) {
                /* replace previous and current */
                /* printf("replacing with FIRST %d\n",list_no); */
                replaced = TRUE;
                /* delete current and modify prvious */
                flags[v2] = NULL_BRKPT;
                sigs[v1] = sig[i];
            }
        }
        else{
            if ((sig[i]*weight<sigc) && (sig[i]*weight<sign)) {
                /* replace current and next */
                /* printf("replacing with SECOND %d\n",list_no); */
                replaced = TRUE;
                /* delete next and modify current */
                flags[v3] = NULL_BRKPT;
                sigs[v2] = sig[i];
            }
        }
    } while ((replaced == FALSE) && (i<3));
    *flag = replaced;
}
