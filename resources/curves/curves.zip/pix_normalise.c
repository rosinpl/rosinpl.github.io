/*
 *    normalise closed pixel lists (open lists are unaltered)
 *    the furthest point from the list centroid is made the head of the list
 *
 *    Paul Rosin
 *    Joint Research Centre
 *    Ispra, Italy
 *    November 1994
 *    paul.rosin@jrc.it
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define ABS(x) ((x) < 0 ? -(x) : (x))
#define SQR(a) ((a)*(a))

#define MAX_PIXELS 10000

int no_pixels,no_new_pixels;
int x[MAX_PIXELS],y[MAX_PIXELS];
int xn[MAX_PIXELS],yn[MAX_PIXELS];

int read_link_data(FILE *fp, int *endoffile);
void store_link_data(FILE *fp, int endoffile, int list, int x[], int y[]);
void process();

main(argc,argv)
int argc;
char *argv[];
{
    FILE *fp1,*fp2;
    char file_type[50];
    int j;
    int endoffile;
    int list;
    int dx,dy;

    if (argc != 3) {
        printf("usage: %s input_file output_file\n",argv[0]);
        exit(-1);
    }

    if ((fp1=fopen(argv[1],"r")) == NULL) {
        printf("cant open %s\n",argv[1]);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp1,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0) {
        printf("not link data file - aborting\n");
        exit(-1);
    }

    if ((fp2=fopen(argv[2],"w")) == NULL) {
        printf("cant open %s\n",argv[2]);
        exit(-1);
    }
    fprintf(fp2,"pixel\n");

    do {
        list = read_link_data(fp1,&endoffile);
        dx = ABS(x[0] - x[no_pixels-1]);
        dy = ABS(y[0] - y[no_pixels-1]);
        /* closed pixel list */
        if ((dx <= 1) && (dy <= 1)) {
            process();
            store_link_data(fp2,endoffile,list,xn,yn);
        }
        /* open pixel list */
        else {
            store_link_data(fp2,endoffile,list,x,y);
        }
    } while (!endoffile);
    fclose(fp1);
    fclose(fp2);
}

void process()
{
    int j,jj;
    double cx,cy;
    double dx,dy,dist,max_dist;
    int location;

    cx = cy = 0;
    for (j = 0; j < no_pixels; j++) {
        cx += x[j];
        cy += y[j];
    }
    cx /= no_pixels; cy /= no_pixels;
    max_dist = 0;
    location = -1;
    for (j = 0; j < no_pixels; j++) {
        dx = cx - x[j];
        dy = cy - y[j];
        dist = SQR(dx) + SQR(dy);
        if (dist > max_dist) {
            max_dist = dist;
            location = j;
        }
    }

    if (location == -1) {
        fprintf(stderr,"ERROR: cannot find furthest point\n");
        exit(-1);
    }

    for (j = 0; j < no_pixels; j++) {
        jj = (j + location) % no_pixels;
        xn[j] = x[jj]; yn[j] = y[jj];
    }
}

int read_link_data(FILE *fp, int *endoffile)
{
    char dumstring[50];
    int j;
    int list;

    fscanf(fp,"%s %d\n",dumstring,&list);
    j = -1;
    do{
       j++;
       fscanf(fp,"%d %d\n",&x[j],&y[j]);
    } while(x[j] != -1);
    *endoffile = (y[j] == -1);
    if (feof(fp) && !(*endoffile)) {
        fprintf(stderr,"Incorrectly terminated file - assuming end of list\n");
        *endoffile = TRUE;
    }
    no_pixels = j;
    if (no_pixels >= MAX_PIXELS) {
        fprintf(stderr,"ERROR: Too many pixels\n");
        exit(-1);
    }
    return(list);
}

void store_link_data(FILE *fp, int endoffile, int list, int x[], int y[])
{
    int j;

    fprintf(fp,"list: %d\n",list);
    for (j = 0; j < no_pixels; j++)
        fprintf(fp,"%d %d\n",x[j],y[j]);
    if (endoffile)
        fprintf(fp,"-1 -1\n");
    else
        fprintf(fp,"-1 0\n");
}

