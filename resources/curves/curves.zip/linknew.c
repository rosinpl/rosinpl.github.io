/*
 * Reads in an image and then links adjacent pixels to forms lists which it
 * then stores in a file. An improved version of link.c adaptef from link.pas
 * as run on the Viglen PC To save memory, writes to a file each pixel as it
 * is found. erases pixel from screen so it cannot be used again.
 *
 * July 1992 Added -f option to output floating point instead of integer pixel
 * values - slows up the process but useful for correct aspect ratio
 * correction - GAWW
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "malloc_image.h"

#define MAX_PIX 100000
#define BLACK 0
#define WHITE 255
#define TRUE 1
#define FALSE !TRUE


int loop1, loop2;
int list_no;
float xpix[MAX_PIX], ypix[MAX_PIX];
int index1;
int thresh_sig;
double weight;
int flag;
int no_lists_written;
float aspect_ratio;        /* defined as y/x and divide y value by this */
int set_aspect, set_threshold, set_file_out, set_file_in;
int closed_only;
int floating_point;
FILE *fp_out;
unsigned char **image;
int height, width,depth;
char file_out[255], file_in[255];
int do_delete_t = FALSE;
int lowe = FALSE;    /* threshold on average edge magnitude rather than sum */
FILE *fp_in;

void link_and_save(int option);
void delete_T();
void clean();
void counting_pixels();
void remove_isolated();
void link_open(int option);
void link_closed(int option);
//int round(float x);

void read_image_body(unsigned char **image, int width,int height);
void read_pgm_header(char *filename, int *width,int *height);

main(argc, argv)
int argc;
char *argv[];
{

    char *temp;
    int count;
    char ch;

    set_aspect = FALSE;
    set_file_out = FALSE;
    set_file_in = FALSE;
    set_threshold = FALSE;
    closed_only = FALSE;
    aspect_ratio = 1.0;
    thresh_sig = 1000;
    floating_point = FALSE;

    if (argc > 1) {
        count = 0;
        do {
            count++;
            temp = argv[count];
            if (*argv[count] == '-') {
                ch = *(++temp);
                switch (ch) {
                case 'o':
                    count++;
                    strcpy(file_out, argv[count]);
                    set_file_out = TRUE;
                    break;
                case 'i':
                    count++;
                    strcpy(file_in, argv[count]);
                    set_file_in = TRUE;
                    break;
                case 'd':
                    do_delete_t = TRUE;
                    break;
                case 'a':
                    count++;
                    aspect_ratio = atof(argv[count]);
                    set_aspect = TRUE;
                    break;
                case 't':
                    count++;
                    thresh_sig = atoi(argv[count]);
                    set_threshold = TRUE;
                    break;
                case 'c':
                    closed_only = TRUE;
                    break;
                case 'f':
                    floating_point = TRUE;
                    break;
                case 'l':
                    lowe = TRUE;
                    break;
                default:
                    printf("error on command line\n");
                }
            }
            else {
                printf("error on command line\n");
                exit(-1);
            }
        } while (count < argc - 1);
		/***
        if (floating_point == TRUE)
            printf("output is floating point\n");
        else
            printf("output is integer\n");
        if (set_threshold == FALSE)
            printf("using default threshold %d\n", thresh_sig);
        if (set_aspect == FALSE)
            printf("using default aspect_ratio %f\n", aspect_ratio);
        ***/
        link_and_save(1);
    }
    else {
        printf("                PROGRAM LINKNEW\n");
        printf("reads in an image with background set to 1 and edge pixels\n");
        printf("set to values between 2 and 254\n");
        printf("traces around the pixels storing the lists in a file as\n");
        printf("lists of pixels\n");
        printf("\n\n");
        printf("   linknew -i file_in -o file_out -a aspect ratio -t threshold -c\n");
        printf("\noptions:\n");
        printf("     c    find closed lists only\n");
        printf("     a    input aspect ratio (y/x)\n");
        printf("     d    delete T junctions\n");
        printf("     t    threshold - lists below not saved\n");
        printf("     i    input image file name \n");
        printf("     o    output list file name\n");
        printf("     f    floating point outputs (default is integers)\n");
        printf("     l    Lowe type threshold on average edge magnitude\n");
        printf("\n");
        printf("options a and t have defaults\n");
        exit(-1);
    }
}



void link_and_save(int option)
/*
 * option used to determine if all lists (0) or only the strongest (1) are
 * saved to disk
 *
 */
{
    flag = FALSE;        /* at start only - no lists */
    no_lists_written = 0;
    read_pgm_header(file_in,&width,&height);
    image = malloc_char_image(width,height);
    read_image_body(image,width,height);

    if (do_delete_t)
        delete_T();
    /* clean up image, make all object 8 connected */
    clean();

    /* remove isolated points - of no interest to us here */
    remove_isolated();

    if ((fp_out = fopen(file_out, "w")) == NULL) {
        printf("file %s cannot be created - aborting\n", file_out);
        exit(-1);
    }

    /* put magic name at top of file */
    if (floating_point == TRUE)
        fprintf(fp_out, "pixel_float\n");
    else
        fprintf(fp_out, "pixel\n");


    /* link open edges */
    list_no = 0;
	/***
    printf("generating open lists...\n");
	***/
    link_open(option);

    /* remove isolated points - of no interest to us here */
    remove_isolated();

    /* link closed edges */
	/***
    printf("generating closed lists...\n");
	***/
    link_closed(option);

    /* remove isolated points - of no interest to us here */
    remove_isolated();

    fprintf(fp_out, "  -1   -1\n");
    fclose(fp_out);
    printf("total number of lists: %d\n", list_no);
    if (option == 1)
        printf("number written to disk: %d\n", no_lists_written);
}

/* delete 4-way T junctions - prevents  2 sides of a Y fork joining later */
void delete_T()
{
    int loop1, loop2;
    int loop3, loop4;
    unsigned char i1, i2, i3, i4;
    int number;

    counting_pixels();
    /***
    printf("deleting 2X2 spots...\n\n");
    for (loop1 = 2; loop1 < height-1; loop1++)
        for (loop2 = 2; loop2 < width-1; loop2++)
            if ((image[loop1][loop2] != BLACK) &&
                (image[loop1-1][loop2] != BLACK) &&
                (image[loop1][loop2-1] != BLACK) &&
                (image[loop1-1][loop2-1] != BLACK))
            {
                for (loop3 = -2; loop3 <= 1; loop3++)
                    for (loop4 = -2; loop4 <= 1; loop4++)
                    image[loop1+loop3][loop2+loop4] = BLACK;
            }
    ***/

    printf("deleting 4-way T junctions...\n\n");
    for (loop1 = 1; loop1 < height - 1; loop1++)
        for (loop2 = 1; loop2 < width - 1; loop2++) {
            if ((image[loop1][loop2] != BLACK) &&
                (image[loop1-1][loop2] != BLACK) &&
                (image[loop1+1][loop2] != BLACK) &&
                (image[loop1][loop2+1] != BLACK))
                {
                    image[loop1][loop2] = BLACK;
                    image[loop1-1][loop2] = BLACK;
                    image[loop1+1][loop2] = BLACK;
                    image[loop1][loop2+1] = BLACK;
                }
            else if ((image[loop1][loop2] != BLACK) &&
                (image[loop1][loop2-1] != BLACK) &&
                (image[loop1][loop2+1] != BLACK) &&
                (image[loop1+1][loop2] != BLACK))
                {
                    image[loop1][loop2] = BLACK;
                    image[loop1][loop2-1] = BLACK;
                    image[loop1][loop2+1] = BLACK;
                    image[loop1+1][loop2] = BLACK;
                }
            else if ((image[loop1][loop2] != BLACK) &&
                (image[loop1-1][loop2] != BLACK) &&
                (image[loop1+1][loop2] != BLACK) &&
                (image[loop1][loop2-1] != BLACK))
                {
                    image[loop1][loop2] = BLACK;
                    image[loop1-1][loop2] = BLACK;
                    image[loop1+1][loop2] = BLACK;
                    image[loop1][loop2-1] = BLACK;
                }
            else if ((image[loop1][loop2] != BLACK) &&
                (image[loop1][loop2-1] != BLACK) &&
                (image[loop1][loop2+1] != BLACK) &&
                (image[loop1-1][loop2] != BLACK))
                {
                    image[loop1][loop2] = BLACK;
                    image[loop1][loop2-1] = BLACK;
                    image[loop1][loop2+1] = BLACK;
                    image[loop1-1][loop2] = BLACK;
                }
        }

    counting_pixels();
}

void clean()
{
    int loop1, loop2;
    unsigned char i1, i2, i3, i4;
    int number;

    /* clear border */
    for (loop1 = 0; loop1 < height; loop1++) {
        image[loop1][0] = BLACK;
        image[loop1][width - 1] = BLACK;
    }
    for (loop1 = 0; loop1 < width; loop1++) {
        image[0][loop1] = BLACK;
        image[height - 1][loop1] = BLACK;
    }
    counting_pixels();
    for (loop1 = 1; loop1 < height - 1; loop1++)
        for (loop2 = 1; loop2 < width - 1; loop2++)
            if (image[loop1][loop2] != BLACK) {
                i1 = image[loop1 - 1][loop2];
                i2 = image[loop1][loop2 - 1];
                i3 = image[loop1 + 1][loop2];
                i4 = image[loop1][loop2 + 1];
                if ((i1 != BLACK) && (i2 != BLACK)) {
                    image[loop1][loop2] = BLACK;
                }
                else if ((i2 != BLACK) && (i3 != BLACK)) {
                    image[loop1][loop2] = BLACK;
                }
                else if ((i3 != BLACK) && (i4 != BLACK)) {
                    image[loop1][loop2] = BLACK;
                }
                else if ((i4 != BLACK) && (i1 != BLACK)) {
                    image[loop1][loop2] = BLACK;
                }
            }
    counting_pixels();
}


void counting_pixels()
{
    int loop1, loop2;
    long number;

    number = 0;
    for (loop1 = 0; loop1 < height; loop1++)
        for (loop2 = 0; loop2 < width; loop2++)
            if (image[loop1][loop2] != BLACK)
                number++;
	/***
    printf("number: %d\n", number);
	***/
}


void remove_isolated()
{
    int loop1, loop2;
    unsigned char i1, i2, i3, i4, i6, i7, i8, i9;
    long number;

	/***
    printf("removing isolated points...\n");
	***/
    number = 0;
    for (loop1 = 1; loop1 < height - 1; loop1++)
        for (loop2 = 1; loop2 < width - 1; loop2++)
            if (image[loop1][loop2] != BLACK) {
                i1 = image[loop1 - 1][loop2 - 1];
                i2 = image[loop1][loop2 - 1];
                i3 = image[loop1 + 1][loop2 - 1];
                i4 = image[loop1 - 1][loop2];
                i6 = image[loop1 + 1][loop2];
                i7 = image[loop1 - 1][loop2 + 1];
                i8 = image[loop1][loop2 + 1];
                i9 = image[loop1 + 1][loop2 + 1];
                if ((i1 + i2 + i3 + i4 + i6 + i7 + i8 + i9) == (8 * BLACK)) {
                    image[loop1][loop2] = BLACK;
                    number++;
                }
            }
	/***
    printf("number of points removed: %d\n", number);
	***/
}


void link_open(int option)
/*
 * option = 0  write list to disk option = 1  write significant lines to disk
 */

{
    int loop1, loop2, loop3;
    unsigned char i1, i2, i3, i4, i6, i7, i8, i9;
    int xp, yp;
    int end_of_line;

    for (loop1 = 0; loop1 < height; loop1++)    /* for each row y */
        for (loop2 = 0; loop2 < width; loop2++) {    /* for each column x */
            /* find pixel at end of line */
            if (image[loop1][loop2] != BLACK) {
                i1 = 0;
                i2 = 0;
                i3 = 0;
                i4 = 0;
                i6 = 0;
                i7 = 0;
                i8 = 0;
                i9 = 0;
                if (image[loop1 - 1][loop2 - 1] != BLACK)
                    i1 = 1;
                if (image[loop1][loop2 - 1] != BLACK)
                    i2 = 1;
                if (image[loop1 + 1][loop2 - 1] != BLACK)
                    i3 = 1;
                if (image[loop1 - 1][loop2] != BLACK)
                    i4 = 1;
                if (image[loop1 + 1][loop2] != BLACK)
                    i6 = 1;
                if (image[loop1 - 1][loop2 + 1] != BLACK)
                    i7 = 1;
                if (image[loop1][loop2 + 1] != BLACK)
                    i8 = 1;
                if (image[loop1 + 1][loop2 + 1] != BLACK)
                    i9 = 1;
                if ((i1 + i2 + i3 + i4 + i6 + i7 + i8 + i9) == 1) {
                    weight = 0;
                    index1 = 0;
                    list_no++;
                    end_of_line = FALSE;
                    /* track to end of line */
                    xp = loop2;
                    yp = loop1;
                    do {
                        weight = weight + (unsigned char) image[yp][xp];
                        index1++;
                        xpix[index1] = (float) xp;
                        ypix[index1] = (float) yp / aspect_ratio;
                        image[yp][xp] = BLACK;
                        /* goto next pixel if an edge
                           pixel */
                        i1 = image[yp - 1][xp - 1];
                        i2 = image[yp][xp - 1];
                        i3 = image[yp + 1][xp - 1];
                        i4 = image[yp - 1][xp];
                        i6 = image[yp + 1][xp];
                        i7 = image[yp - 1][xp + 1];
                        i8 = image[yp][xp + 1];
                        i9 = image[yp + 1][xp + 1];
                        if (i1 != BLACK) {
                            xp--;
                            yp--;
                        }
                        else if (i2 != BLACK) {
                            xp--;
                        }
                        else if (i3 != BLACK) {
                            yp++;
                            xp--;
                        }
                        else if (i4 != BLACK) {
                            yp--;
                        }
                        else if (i6 != BLACK) {
                            yp++;
                        }
                        else if (i7 != BLACK) {
                            yp--;
                            xp++;
                        }
                        else if (i8 != BLACK) {
                            xp++;
                        }
                        else if (i9 != BLACK) {
                            xp++;
                            yp++;
                        }
                        else
                            end_of_line = TRUE;
                    } while (end_of_line == FALSE);

                    if (lowe) weight /= (float)index1;

                    if (option == 1) {
                        /* only write if significant */
                        if (weight < 0)
                            printf("weight: %f\n",weight);
                        if (weight > thresh_sig) {
                            if (closed_only == FALSE) {
                                no_lists_written++;
                                /*
                                   printf("writing list %d weight %f\n",
                                           list_no,weight);
                                */
                                if (flag == TRUE)
                                    fprintf(fp_out, "  -1    0\n");
                                flag = TRUE;
                                fprintf(fp_out, "list:  %d\n", list_no);
                                if (floating_point == TRUE) {
                                    for (loop3 = 1; loop3 <= index1; loop3++)
                                        fprintf(fp_out, "%f %f\n",
                                            xpix[loop3], ypix[loop3]);
                                }
                                else {
                                    for (loop3 = 1; loop3 <= index1; loop3++)
                                        fprintf(fp_out, "%4.0f %4.0f\n",
                                            xpix[loop3], ypix[loop3]);
                                }
                            }
                        }
                    }
                    else {    /* option = 0 */
                        /* write all lines */
                        if (closed_only == FALSE) {
                            no_lists_written++;
                            /*
                                printf("writing list %d  weight %f\n",
                                list_no,weight);
                            */
                            if (flag == TRUE)
                                fprintf(fp_out, "  -1    0\n");
                            flag = TRUE;
                            fprintf(fp_out, "list:   %d\n", list_no);
                            if (floating_point == TRUE) {
                                for (loop3 = 1; loop3 <= index1; loop3++)
                                    fprintf(fp_out, "%f %f\n",
                                        xpix[loop3], ypix[loop3]);
                            }
                            else {
                                for (loop3 = 1; loop3 <= index1; loop3++)
                                    fprintf(fp_out, "%4.0f %4.0f\n",
                                        xpix[loop3], ypix[loop3]);
                            }
                        }
                    }
                }
            }
        }
}


void link_closed(int option)
/*
 * option = 0  write list to disk option = 1  write significant lines to disk
 */
{
    int loop1, loop2, loop3;
    unsigned char i1, i2, i3, i4, i6, i7, i8, i9;
    int xp, yp;
    int end_of_line;

    for (loop1 = 0; loop1 < height; loop1++)    /* for each row */
        for (loop2 = 0; loop2 < width; loop2++) {    /* for each column */
            /* find any remaining pixel */
            if (image[loop1][loop2] != BLACK) {
                /* at beginning of a line */
                weight = 0;
                index1 = 0;
                list_no++;
                end_of_line = FALSE;
                /* track to end of line */
                xp = loop2;
                yp = loop1;
                do {
                    index1++;
                    xpix[index1] = xp;
                    ypix[index1] = round(yp / aspect_ratio);
                    weight = weight + (unsigned char) image[yp][xp];
                    image[yp][xp] = BLACK;
                    /* goto next edge pixel */
                    i1 = image[yp - 1][xp - 1];
                    i2 = image[yp][xp - 1];
                    i3 = image[yp + 1][xp - 1];
                    i4 = image[yp - 1][xp];
                    i6 = image[yp + 1][xp];
                    i7 = image[yp - 1][xp + 1];
                    i8 = image[yp][xp + 1];
                    i9 = image[yp + 1][xp + 1];
                    if (i1 != BLACK) {
                        xp--;
                        yp--;
                    }
                    else if (i2 != BLACK) {
                        xp--;
                    }
                    else if (i3 != BLACK) {
                        yp++;
                        xp--;
                    }
                    else if (i4 != BLACK) {
                        yp--;
                    }
                    else if (i6 != BLACK) {
                        yp++;
                    }
                    else if (i7 != BLACK) {
                        yp--;
                        xp++;
                    }
                    else if (i8 != BLACK) {
                        xp++;
                    }
                    else if (i9 != BLACK) {
                        xp++;
                        yp++;
                    }
                    else
                        end_of_line = TRUE;
                } while (end_of_line != TRUE);

                if (lowe) weight /= (float)index1;

                if (option == 1) {
                    /* only write if signoficant */
                    if (weight < 0)
                        printf("weight: %f\n",weight);
                    if (weight > thresh_sig) {
                        no_lists_written++;
                        /* printf("writing list %d weight %f\n",
                            list_no,weight);
                        */
                        if (flag == TRUE)
                            fprintf(fp_out, "  -1    0\n");
                        flag = TRUE;
                        fprintf(fp_out, "list:   %d\n", list_no);
                        if (floating_point == TRUE) {
                            for (loop3 = 1; loop3 <= index1; loop3++)
                                fprintf(fp_out, "%f %f\n",
                                    xpix[loop3], ypix[loop3]);
                        }
                        else {
                            for (loop3 = 1; loop3 <= index1; loop3++)
                                fprintf(fp_out, "%4.0f %4.0f\n",
                                    xpix[loop3], ypix[loop3]);
                        }
                    }
                }
                else {    /* option = 0 */
                    /* write all lines */
                    no_lists_written++;
                    /* printf("writing list %d weight %f\n",
                        list_no,weight); */
                    if (flag == TRUE)
                        fprintf(fp_out, "  -1    0\n");
                    flag = TRUE;
                    fprintf(fp_out, "list:   %d\n", list_no);
                    if (floating_point == TRUE) {
                        for (loop3 = 1; loop3 <= index1; loop3++)
                            fprintf(fp_out, "%f %f\n",
                                xpix[loop3], ypix[loop3]);
                    }
                    else {
                        for (loop3 = 1; loop3 <= index1; loop3++)
                            fprintf(fp_out, "%4.0f %4.0f\n",
                                xpix[loop3], ypix[loop3]);
                    }
                }
            }
        }
}

/*
int round(float x)
{
    return floor(x + 0.5);
}
*/
