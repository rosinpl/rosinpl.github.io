/*
    xplotdata - an X version of plotdata.c - GAWW 2/92
    
        a Geoff West/Paul Rosin production
        all rights reserved

        various modifications by PLR 1990 include:
        ellipse step size now a function of ellipse size
        added soft breaks

        modifications to enable the multiple plotting of
        various types of files
        - GAWW April 1991

        modified September 1991 to accommodate variable sized images
        - GAWW/Rafidzal Rafiq
    
        modification by Mike Robey 31st jan 1992 so
        that display program becomes a background process automatically
        Use fork to create a child process and let the parent simply exit

        various mods by Geoff West 16th June 1992 to make aspect ratio
        a command line argument correctly

        modified to be able to read floating point values for pixel data
        (usually after scaling), line data and the pixel coordinated of the
        centre etc for ellipses/arcs
        - GAWW June 1992

        addition to output Postscript files
        PLR August 1992

        addition for codons
        PLR September 1992

        plot_ellipse, cross, etc moved to plotting_routines.c
        improves modularity!
        PLR October 1992

        addition for pixel_curvature
        PLR December 1992

        addition for superellipses
        PLR April 1993

        determines the endpoints of the superellipses correctly
        GAWW May 1993

        reads and displays sun raster format files
        GAWW August 1993

        SUN stuff removed
        border & zoom options added
        PLR October 93

        image mapping added
        PLR April 1994

        2 byte/pixel added
        PLR July 1994

        box & triangle superdata types added
        PLR August 1994

        Encapsulated PostScript option - ONLY LINK DATA SO FAR
        PLR September 1994

        option to select with mouse & output list numnbers
        PLR Match 1995

        Some updates (additions and deletions) to get the X11 stuff working on linux
        PLR December 2003

*/

#include <stdio.h>
#include <math.h>
#include "plotlib.h"
#include "palette.h"
#include "plotstuff.h"
#include "angle.h"

#define ABS(x)       (((x)<0.0)? (-(x)): (x))

#define SMALL 1
#define BIG 2
#define CLOCKWISE 1
#define ANTICLOCKWISE 2

#define PI 3.141591
#define TWO_PI 6.283182

#define MIN(a,b)  ((a)<(b)?(a):(b))
#define MAX(a,b)  ((a)>(b)?(a):(b))

int number_pixels,number_lists,number_arcs;
int crosses,lines_l,arcs_a,arcs_b,arcs_c,image_plot,quadrant,plot_device;
int textout,points,bold_arcs,ellipses,full_arcs;
int super_data,pause,sbreak,dump,corner_plot,use_all_colours;
int child_window,graphics;
int plot_singular_pts,show_start,thick;
int startx=0, starty=0;
float zoom=1;

/* types of data in files */
#define LISTS 1
#define LINES 2
#define ARCS 3
#define ENDL 4
#define ENDF 5
#define ELLIPSES 6
#define SBREAK 7
#define CORNERS 8
#define PIXELS 9
#define CIRCLES 10
#define CODONS 11
#define CROSSES 12
#define VERTEX 13
#define SUPERELLIPSES 14
#define DTRIANGLE 15
#define UTRIANGLE 16
#define BOX 17
#define DIAMOND 18

/* types of files */
#define SUPER 1
#define IMAGE 3
#define LIST 4
#define CORNER 5
#define IMAGE_DUMP 6
#define PS_DUMP 7
#define IMAGE2 8

/* format used for data in pixel lists */
#define INTEGER 0
#define FLOAT 1
#define CURVATURE 2

/* curvature labels */
#define PosMax        1        /* positive curvature maximum */
#define PosMin        2        /* positive curvature minimum */
#define NegMax        3        /* negative curvature maximum */
#define NegMin        4        /* negative curvature minimum */
#define StartZero     5        /* start of zero curvature section */
#define EndZero       6        /* end of zero curvature section */
#define PosEnd        7        /* curve end has positive curvature */
#define NegEnd        8        /* curve end has negative curvature */
#define Zero          9        /* zero crossing point */

/* vertex colours */
#define LIGHT         0
#define DARK          255

#define MAX_FILES 50

int curve_type();
int strcmp();

#define NO_PS 0
#define PS    1
#define EPS   2

int xmin,xmax,ymin,ymax;
double qx,qy;    /* ellipse centre - used to determine plotting quadrant */
extern int xoff,yoff;            /* offset plotting in window */

char *pixel_file;
int do_output_list_numbers;
int ps_fill = FALSE;              /* colour in pixel list regions */

int  use_old_plot = FALSE;

int height,width;

FILE *fp_in;    /* for compatability with malloc_image */

main(argc,argv)
int argc;
char *argv[];
{
    int  i;
    char *s;
    char *super_file_name,*list_file_name,*corner_file_name;
    char *image_file_name,*dump_name,*ps_dump_name;
    FILE *fp;
    int  max_dimension;
    float scale;
    int  no_images;
    int  super_filename_follows = FALSE;
    int  lut = GREY_COLOUR;

    /* variables in which to hold files */
    char *names[MAX_FILES];
    int no_files,file_type[MAX_FILES];
    int plot_type[MAX_FILES];

    if (argc == 1) {
        printf("            XPLOTDATA - VERSION 1.0\n\n");
        printf("Usage: plot [options] filename\n");
        printf("options:\n");
        printf("   -A postscript plot - output all ellipse points\n");
        printf("   -a plot arcs or ellipses (super data)\n");
        printf("   -b plot lines (super data)\n");
        printf("   -B plot border\n");
        printf("   -c plot circles (super data)\n");
        printf("   -C forks off a child for the window\n");
        printf("   -d plot super data\n");
        printf("   -D dump image (give filename)\n");
        printf("   -e plot with enhanced arcs\n");
        printf("   -E dump to Encapsulated PostScript file\n");
        printf("   -f plot full arcs dotted\n");
        printf("   -F use all colours to display image\n");
        printf("   -g list colours for each curve type\n");
        printf("   -G LUT (0: grey/colour; 1: grey/more-colour; 2: random colour; 3: grey)\n");
        printf("   -h height of image/plot window (default 512)\n");
        printf("   -i plot raw 1 byte/pixel image\n");
        printf("   -I plot raw 2 byte/pixel image\n");
        printf("   -k plot soft break points\n");
        printf("   -l plot lists (as lines) (from link program)\n");
        printf("   -L plot lists (as circles) (from link program)\n");
        printf("   -m image mapping (0: none; 1: log; 2: rescale)\n");
        printf("   -M select pixel list numbers with mouse\n");
        printf("   -n dont wait for prompt at end of plotting\n");
        printf("   -o X and Y plotting offsets\n");
        printf("   -p plot points (white) at end of lines\n");
        printf("   -P dump to PostScript file\n");
        printf("   -q plot 1st quadrant only\n");
        printf("   -r set aspect ratio (default 1.0)\n");
        printf("   -R dump raw PostScript file (no scaling/trans)\n");
        printf("   -s plot singular points\n");
        printf("   -S cross start and end of list\n");
        printf("   -t plot feature number\n");
        printf("   -T thick lines (pixels & segments)\n");
        printf("   -v plot vertices detected by corner\n");
        printf("   -w width of image/plot window (default 512)\n");
        printf("   -x plot crosses (white) at end of lines\n");
        printf("   -X position of window\n");
        printf("   -y pause after each line\n");
        printf("   -Y position of window\n");
        printf("   -z zoom factor\n");
        printf("   -Z fill pixel regions\n");
        printf("\n");
        printf("note multiple file plots into one image\n");
        exit(-1);
    }
    graphics = TRUE;
    child_window = 0;
    crosses = 0;
    points = 0;
    lines_l = 0;
    arcs_a = 0;
    arcs_b = 0;
    arcs_c = 0;
    ellipses = 0;
    full_arcs = 0;
    image_plot = 0;
    super_data = 0;
    textout = 0;
    bold_arcs = 0;
    pause = 0;
    sbreak = 0;
    dump = 0;
    corner_plot = 0;
    use_all_colours = 0;
    no_files = 0;
    ps_dump = NO_PS;
    ps_raw = FALSE;
    border = 0;
    height = 512;
    width = 512;
    plot_singular_pts = 0;
    show_start = 0;
    thick = 0;
    mapping = NONE;
    xmin = ymin = 9999;
    xmax = ymax = -9999;
    qx = qy = 0;
    do_output_list_numbers = FALSE;
    quadrant = FALSE;

    for (i = 1; i < argc; i++) {
        /* read in super data filename */
        if (super_filename_follows) {
            super_file_name = argv[i];
            no_files++;
            names[no_files] = argv[i];
            file_type[no_files] = SUPER;
            super_filename_follows = FALSE;
        }
        else {
            for (s = argv[i] + 1; *s != '\0'; s++) {
                switch (*s) {
                    case 'A':
                        use_old_plot = TRUE;
                        break;
                    case 'a':         /* super data format */ 
                        arcs_a = 1;
                        ellipses = 1;
                        super_data = 1;
                        super_filename_follows = TRUE;
                        break;
                    case 'b':         /* super data format */
                        arcs_b = 1;
                        super_data = 1;
                        super_filename_follows = TRUE;
                        break;
                    case 'B':
                        border = TRUE;
                        break;
                    case 'c':
                        arcs_c = 1;
                        super_data = 1;
                        super_filename_follows = TRUE;
                        break;
                    case 'C':
                        child_window = TRUE;
                        break;
                    case 'd':         /* super data format */
                        arcs_a = 1;
                        arcs_b = 1;
                        ellipses = 1;
                        super_data = 1;
                        super_filename_follows = TRUE;
                        break;
                    case 'D':
                        dump = 1;
                        i++;
                        dump_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = IMAGE_DUMP;
                        break;
                    case 'e':
                        bold_arcs = 1;
                        break;
                    case 'E':
                        ps_dump = EPS;
                        i++;
                        ps_dump_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = PS_DUMP;
                        break;
                    case 'f':
                        full_arcs = 1;
                        break;
                    case 'F':
                        use_all_colours = 1;
                        break;
                    case 'g':
                        printf("colours for curve types\n");
                        printf("pixels:   light cyan - 11\n");
                        printf("crosses:  white - 15\n");
                        printf("ellipses: light blue - 9\n");
                        printf("arcs:     light red - 12\n");
                        printf("lines:    light magenta - 13\n");
                        printf("points:   white - 15\n");
                        printf("vertices: white - 15\n");
                        break;
                    case 'G':
                        i++;
                        lut = atoi(argv[i]);
                        break;
                    case 'h':
                        i++;
                        height = atoi(argv[i]);
                        printf("image height: %d\n",height);
                        break;
                    case 'i':         /* raw image */
                        image_plot = 1;
                        i++;
                        image_file_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = IMAGE;
                        break;
                    case 'I':         /* 2 byte/pixel raw image */
                        image_plot = 1;
                        i++;
                        image_file_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = IMAGE2;
                        break;
                    case 'k':
                        sbreak = 1;
                        break;
                    case 'l':        /* pixel data format */
                        lines_l = 1;
                        i++;
                        list_file_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = LIST;
                        plot_type[no_files] = LINES;
                        break;
                    case 'L':        /* pixel data format */
                        lines_l = 1;
                        i++;
                        list_file_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = LIST;
                        plot_type[no_files] = CIRCLES;
                        break;
                    case 'm':
                        i++;
                        mapping = atoi(argv[i]);
                        break;
                    case 'M':
                        do_output_list_numbers = TRUE;
                        break;
                    case 'n':
                        graphics = FALSE;
                        break;
                    case 'o':
                        i++;
                        xoff = atoi(argv[i]);
                        i++;
                        yoff = atoi(argv[i]);
                        break;
                    case 'p':
                        points = 1;
                        break;
                    case 'P':
                        ps_dump = PS;
                        i++;
                        ps_dump_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = PS_DUMP;
                        break;
                    case 'q':
                        quadrant = TRUE;
                        break;
                    case 'r':
                        i++;
                        sscanf(argv[i],"%f",&aspect_ratio);
                        printf("aspect ratio: %8.2f\n",aspect_ratio);
                        break;
                    case 'R':
                        ps_dump = PS;
                        ps_raw = TRUE;
                        i++;
                        ps_dump_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = PS_DUMP;
                        break;
                    case 's':
                        plot_singular_pts = 1;
                        break;
                    case 'S':
                        show_start = 1;
                        break;
                    case 't':
                        textout = 1;
                        break;
                    case 'T':
                        thick = 1;
                        break;
                    case 'v':        /* super data format */
                        corner_plot = 1;
                        i++;
                        corner_file_name = argv[i];
                        no_files++;
                        names[no_files] = argv[i];
                        file_type[no_files] = CORNER;
                        break;
                    case 'w':
                        i++;
                        width = atoi(argv[i]);
                        printf("image width: %d\n",width);
                        break;
                    case 'x':
                        crosses = 1;
                        break;
                    case 'X':
                        i++;
                        startx = atoi(argv[i]);
                        break;
                    case 'y':
                        pause = 1;
                        break;
                    case 'Y':
                        i++;
                        starty = atoi(argv[i]);
                        break;
                    case 'z':
                        i++;
                        sscanf(argv[i],"%f",&zoom);
                        break;
                    case 'Z':
                        ps_fill = TRUE;
                        break;
                    default:
                        printf("illegal option %c\n",*s);
                        exit(-1);
                        break;
                }
            }
        }
    }

    if (no_files == 0) {
        printf("must plot at least one file\n");
        exit(-1);
    }
    if (no_files >= MAX_FILES) {
        printf("%d is too many files; maximum number: %d\n",no_files,MAX_FILES);
        exit(-1);
    }
    /* check to see if plotting only one image */
    no_images = 0;
    for (i = 1; i <= no_files; i++) {
        if ((file_type[i] == IMAGE) || (file_type[i] == IMAGE2)) {
            no_images++;
        }
    }
    if (no_images > 1) {
        printf("can only plot one image at a time - aborting\n");
        exit(-1);
    }
    /* modification by Mike Robey 31st jan 1992 so
        that display program becomes a background process automatically
        Use fork to create a child process and let the parent simply exit
        */

    /* generate title for plotdata window */
    window_label[0] = '\0';
    for (i = 1; i <= no_files; i++) {
        if (file_type[i] == SUPER) {
            strcopy(window_label," SUPER DATA file: ",window_label);
            strcopy(window_label,names[i],window_label);
        }
        else if (file_type[i] == LIST) {
            strcopy(window_label," LIST DATA file: ",window_label);
            strcopy(window_label,names[i],window_label);
        }
        else if (file_type[i] == CORNER) {
            strcopy(window_label," CORNER DATA file: ",window_label);
            strcopy(window_label,names[i],window_label);
        }
        else if (file_type[i] == IMAGE) {
            strcopy(window_label," IMAGE file: ",window_label);
            strcopy(window_label,names[i],window_label);
        }
        else if (file_type[i] == IMAGE2) {
            strcopy(window_label," 2 B/P IMAGE file: ",window_label);
            strcopy(window_label,names[i],window_label);
        }
    }
    
    /* start of plotting sequence */
    /* 
        first determine if an image is being plotted and what size it is
        before opening the X window
    */

    if (zoom != 1) {
        x_scale = y_scale = zoom;
        /****
        width *= zoom;
        height *= zoom;
        *****/
    }

    open_device(startx,starty,(int)(width*zoom),(int)(height*zoom),lut);
    /* 
        plot image file(s) first - note will overwrite each image with each
        successive image
    */
    for (i = 1; i <= no_files; i++) {
        if (file_type[i] == IMAGE) {
            read_plot_image(names[i],TRUE,width,height,use_all_colours,zoom,1,lut);
        }
        else if (file_type[i] == IMAGE2) {
            read_plot_image(names[i],TRUE,width,height,use_all_colours,zoom,2,lut);
        }
    }

    /*
        open Postscript file if necessary
        rather clumsy making it a global file pointer I know
    */
    if (ps_dump != NO_PS) {
        if ((fp_ps=fopen(ps_dump_name,"w")) == NULL) {
            printf("cant open %s\n",ps_dump_name);
            exit(-1);
        }
        if (ps_dump == EPS) {
            fprintf(fp_ps,"%%!PS-Adobe-2.0 EPSF-2.0\n");
            fprintf(fp_ps,"%%%%Title: %s\n",names[1]);
            fprintf(fp_ps,"%%%%Title: %s\n",names[1]);
            fprintf(fp_ps,"%%%%Creator: %s\n",argv[0]);
            /* fprintf(fp_ps,"%%%%CreationDate: now\n"); */
            fprintf(fp_ps,"%%%%For: Paul Rosin\n");
            fprintf(fp_ps,"%%%%Orientation: Portrait\n");
            fprintf(fp_ps,"%%%%BoundingBox: (atend)\n");
            fprintf(fp_ps,"%%%%Pages: 1\n");
            fprintf(fp_ps,"%%%%EndComments\n");
        }
        else {
            fprintf(fp_ps,"%%!\ngsave\ninitgraphics\n");
            if (width > height)
                max_dimension = width*zoom;
            else
                max_dimension = height*zoom;
            scale = (double)height/max_dimension;
            if (!ps_raw) {
                fprintf(fp_ps,"%f %f scale\n",scale,scale);
                /* fprintf(fp_ps,"20 150 translate\n"); */
                fprintf(fp_ps,"%f %f translate\n",20.0/scale,height*zoom-height+120);
            }
        }

        fprintf(fp_ps,"/DrawEllipse {\n");
        fprintf(fp_ps,"   /orient exch def\n");
        fprintf(fp_ps,"   /width exch def\n");
        fprintf(fp_ps,"   /endangle exch def\n");
        fprintf(fp_ps,"   /startangle exch def\n");
        fprintf(fp_ps,"   /yrad exch def\n");
        fprintf(fp_ps,"   /xrad exch def\n");
        fprintf(fp_ps,"   /y exch def\n");
        fprintf(fp_ps,"   /x exch def\n");
        fprintf(fp_ps,"   gsave\n");
        fprintf(fp_ps,"   /cmtx matrix currentmatrix def\n");
        fprintf(fp_ps,"   newpath\n");
        fprintf(fp_ps,"   width setlinewidth\n");
        fprintf(fp_ps,"   x y translate\n"),
        fprintf(fp_ps,"   0 orient sub rotate\n");
        fprintf(fp_ps,"   xrad yrad scale 0 0 1 startangle endangle arc\n");
        fprintf(fp_ps,"   closepath\n");
        fprintf(fp_ps,"   cmtx setmatrix\n");
        fprintf(fp_ps,"   stroke\n");
        fprintf(fp_ps,"   grestore\n");
        fprintf(fp_ps,"   } def\n");

        fprintf(fp_ps,"1 setlinejoin\n1 setlinecap\nnewpath\n");
        fprintf(fp_ps,"1 setlinewidth\n");
        fprintf(fp_ps,"/Helvetica findfont 10 scalefont setfont\n");
        fprintf(fp_ps,"/Lcirc 1.5 def\n");
        fprintf(fp_ps,"/Mcirc 3 def\n");
        if (border) {
            fprintf(fp_ps,"0 height moveto\n");
            fprintf(fp_ps,"0 %.0f lineto\n",height-height*zoom);
            fprintf(fp_ps,"%.0f %d lineto\n",width*zoom,height-height);
            fprintf(fp_ps,"%.0f height lineto\n",width*zoom);
            fprintf(fp_ps,"0 height lineto\n");
            fprintf(fp_ps,"stroke\n");
            xmax = width*zoom;
            ymin = height-height*zoom; ymax = height;
        }
        if (ps_dump == PS)
            outtextxy(0,height+50,window_label);
    }

    /*
        plot all the representations
    */
    for (i = 1; i <= no_files; i++) {
        if (file_type[i] == LIST) {
            process_link_data(names[i],plot_type[i]);
            if (ps_dump == EPS)
                bb_link_data(names[i]);
            pixel_file = names[i];
        }
        else if (file_type[i] == SUPER) {
            process_super_data(names[i],arcs_a,arcs_b,
                               ellipses,arcs_c,bold_arcs);
        }
        else if (file_type[i] == CORNER) {
            process_super_data(names[i],arcs_a,arcs_b,
                               ellipses,arcs_c,bold_arcs);
        }
    }

    /*
        plot border in same colour as first data type
    */
    if (border) {
        plot_border(file_type[1],width*zoom,height*zoom);
    }

    /*
        now check to see if want to dump the image
    */
    for (i = 1; i <= no_files; i++) {
        if (file_type[i] == IMAGE_DUMP) {
            flush_buffer();
            dump_image(names[i],(int)(width*zoom),(int)(height*zoom));
        }
    }

    if (ps_dump != NO_PS) {
        if (ps_dump == EPS) {
            if (ps_fill)
                fprintf(fp_ps,"closepath\nfill\n");
            else
                fprintf(fp_ps,"stroke\n");

            if (quadrant) {
                /* CLIPPING DOESN'T WORK UNLESS MOVED TO TOP OF eps FILE! */
                qy = height - qy;
                fprintf(fp_ps,"%.0f %.0f moveto\n",qx-1,qy-1);
                fprintf(fp_ps,"%d %.0f lineto\n",xmax+1,qy-1);
                fprintf(fp_ps,"%d %d lineto\n",xmax+1,ymax+1);
                fprintf(fp_ps,"%.0f %d lineto\n",qx-1,ymax+1);
                fprintf(fp_ps,"closepath clip\n");
                fprintf(fp_ps,"%%%%Trailer\n");
                fprintf(fp_ps,"%%%%BoundingBox: %.0f %.0f %d %d\n",
                    qx-1,qy-1,xmax+1,ymax+1);
            }
            else {
                fprintf(fp_ps,"%%%%Trailer\n");
                fprintf(fp_ps,"%%%%BoundingBox: %d %d %d %d\n",
                    xmin-1,ymin-1,xmax+1,ymax+1);
                    /*
                    xmin-10,ymin-10,xmax+10,ymax+10);
                    */
            }

            /*
            fprintf(fp_ps,"%%scale by data height - need to move to start of file to take effect\n");
            fprintf(fp_ps,"%f setlinewidth\n",(ymax-ymin)/100.0);
            fprintf(fp_ps,"%%scale by data width - need to move to start of file to take effect\n");
            fprintf(fp_ps,"%f setlinewidth\n",(xmax-xmin)/100.0);
            */
            fprintf(fp_ps,"%%%%EOF\n");
        }
        else {
            fprintf(fp_ps,"stroke\nshowpage\n");
        }
        printf("closing ps file\n");
        fclose(fp_ps);
    }
    /* 
        allow program to finish if 
        graphics = FALSE - for use in a shell prog 
    */
    if (graphics == TRUE) {
        if (child_window) {
            switch(fork()) {
                case -1:    printf("error - no child process - aborting\n");
                    exit(-1);
                    break;
                case 0:    close_graph();
                    break;
            }
        }
        else{
            close_graph();
        }
    }
    else{
        kill_graph();
    }
}


/*
 *  reads in pixel data that is output of link program,
 *  plots each pixel as it reads it
 */
process_link_data(file_name,plot_type)
char file_name[];
int plot_type;
{
    FILE *fp;
    char dumstring[50];
    int i,j,k;
    int x_pix,y_pix;
    float x,y;
    float xo,yo;
    int list_no;
    char ch;
    char file_type[50];
    int file_data_type;
    float curvature,sigma;
    int label;
    char number[50];

    if ((fp=fopen(file_name,"r")) == NULL) {
        printf("cant open %s\n",file_name);
        exit(-1);
    }
    fscanf(fp,"%s\n",file_type);
    printf("%s\n",file_type);
    i = strcmp(file_type,"pixel");
    if (strcmp(file_type,"pixel") == 0) {
        printf("integer pixel data file\n");
        file_data_type = INTEGER;
    }
    else if (strcmp(file_type,"pixel_float") == 0) {
        printf("float pixel data file\n");
        file_data_type = FLOAT;
    }
    else if (strcmp(file_type,"pixel_curvature") == 0) {
        printf("curvature pixel data file\n");
        file_data_type = CURVATURE;
    }
    else{
        printf("input file not pixel, pixel_float or pixel_curvature type - aborting\n");
        exit(-1);
    }
    set_colour("cyan");
    i = k = 0;
    if (file_data_type == INTEGER) {
        /* process integer pixel data */
        do{
            fscanf(fp,"%s %d\n",dumstring,&list_no);
            j = 0;
            do{
                j++; k++;
                fscanf(fp,"%d %d\n",&x_pix,&y_pix);
                x = x_pix;
                y = y_pix;
                if (textout && (j == 1)) {
                    sprintf(number,"%d",list_no);
                    set_colour("pink");
                    outtextxy((int)x,(int)y,number);
                }
                if (x != -1) {
                    if (plot_type == CIRCLES)
                        plot_circle(x,y,LITTLE_CIRCLE,0.0,TWO_PI,0.0,TWO_PI,0);
                    else if (j == 1) {
                        move(x,y);
                        if (crosses == 1)
                            cross(x,y,2,"green");
                        if (show_start == 1)
                            cross(x,y,5,"green");
                    }
                    else {
                        draw(thick,x,y);
                        xo = x;
                        yo = y;
                    }
                }
            } while ((x != -1) && !feof(fp));
            /* added cross at end - PLR 2/97 */
            if (show_start == 1)
                cross(xo,yo,5,"green");
            if (crosses == 1)
                cross(xo,yo,2,"green");
            k--;
            if (pause) {
                flush_buffer();
                printf("list: %d\n",list_no);
                scanf("%c",&ch);
            }
        } while ((y != -1) && !feof(fp));
        if (x != -1 || y != -1) {
            printf("ERROR: pixel list not correctly terminated\n");
        }
    }
    else if (file_data_type == FLOAT) {
        /* process floating point pixel data */
        printf("plotting float pixel data\n");
        i = k = 0;
        do{
            fscanf(fp,"%s %d\n",dumstring,&list_no);
            j = 0;
            do{
                j++; k++;
                fscanf(fp,"%f %f\n",&x,&y);
                if (x != -1) {
                    if (plot_type == CIRCLES)
                        plot_circle(x,y,LITTLE_CIRCLE,0.0,TWO_PI,0.0,TWO_PI,0);
                    else if (j == 1) {
                        move(x,y);
                        if (crosses == 1)
                            cross(x,y,2,"green");
                        if (show_start == 1)
                            cross(x,y,5,"green");
                    }
                    else {
                        draw(thick,x,y);
                        xo = x;
                        yo = y;
                    }
                }
            } while ((x != -1) && !feof(fp));
            if (crosses == 1)
                cross(xo,yo,2,"green");
            k--;
            if (pause) {
                flush_buffer();
                printf("list: %d\n",list_no);
                scanf("%c",&ch);
            }
        } while ((y != -1) && !feof(fp));
        if (x != -1 || y != -1) {
            printf("ERROR: pixel list not correctly terminated\n");
        }
    }
    else {
        /* process curvature pixel data */
        printf("plotting curvature pixel data\n");
        i = k = 0;
        do{
            fscanf(fp,"%s %d\n",dumstring,&list_no);
            fscanf(fp,"%s %f\n",dumstring,&sigma);
            j = 0;
            do{
                j++; k++;
                fscanf(fp,"%f %f %f %d\n",&x,&y,&curvature,&label);
                if (x != -1) {
                    if (plot_singular_pts) {
                        switch(label) {
                            case PosMax:
                                box(x,y,3,"red");
                                break;
                            case PosMin:
                                set_colour("red");
                                plot_circle(x,y,MEDIUM_CIRCLE,0.0,TWO_PI,0.0,TWO_PI,0);
                                break;
                            case NegMax:
                                box(x,y,3,"green");
                                break;
                            case NegMin:
                                set_colour("green");
                                plot_circle(x,y,MEDIUM_CIRCLE,0.0,TWO_PI,0.0,TWO_PI,0);
                                break;
                            case Zero:
                            case StartZero:
                            case EndZero:
                                cross(x,y,3,"red");
                                break;
                        }
                        set_colour("cyan");
                        move(x,y);
                    }
                    if (j == 1) {
                        move(x,y);
                        if (crosses == 1)
                            cross(x,y,2,"green");
                        if (show_start == 1)
                            cross(x,y,5,"green");
                    }
                    else {
                        draw(thick,x,y);
                        xo = x;
                        yo = y;
                    }
                }
            } while ((x != -1) && !feof(fp));
            if (crosses == 1)
                cross(xo,yo,2,"green");
            k--;
            if (pause) {
                flush_buffer();
                printf("list: %d\n",list_no);
                scanf("%c",&ch);
            }
        } while ((y != -1) && !feof(fp));
        if (x != -1 || y != -1) {
            printf("ERROR: pixel list not correctly terminated\n");
        }
    }
    fclose(fp);
}

/*
 *  reads in pixel data that is output of link program,
 *  saves bounding box co-ordinates
 */
bb_link_data(file_name)
char file_name[];
{
    FILE *fp;
    char dumstring[50];
    int i,j,k;
    int x_pix,y_pix;
    float x,y;
    float xo,yo;
    int list_no;
    char ch;
    char file_type[50];
    int file_data_type;
    float curvature,sigma;
    int label;

    if ((fp=fopen(file_name,"r")) == NULL) {
        printf("cant open %s\n",file_name);
        exit(-1);
    }
    fscanf(fp,"%s\n",file_type);
    i = strcmp(file_type,"pixel");
    if (strcmp(file_type,"pixel") == 0)
        file_data_type = INTEGER;
    else if (strcmp(file_type,"pixel_float") == 0)
        file_data_type = FLOAT;
    else if (strcmp(file_type,"pixel_curvature") == 0)
        file_data_type = CURVATURE;
    else
        exit(-1);

    i = k = 0;
    if (file_data_type == INTEGER) {
        /* process integer pixel data */
        do{
            fscanf(fp,"%s %d\n",dumstring,&list_no);
            j = 0;
            do{
                j++; k++;
                fscanf(fp,"%d %d\n",&x_pix,&y_pix);
                x = x_pix;
                y = y_pix;
                if (x != -1) {
                    xmin = MIN(xmin,x); xmax = MAX(xmax,x);
                    ymin = MIN(ymin,height-y); ymax = MAX(ymax,height-y);
                }
            } while ((x != -1) && !feof(fp));
            k--;
        } while ((y != -1) && !feof(fp));
    }
    else if (file_data_type == FLOAT) {
        /* process floating point pixel data */
        printf("plotting float pixel data\n");
        i = k = 0;
        do{
            fscanf(fp,"%s %d\n",dumstring,&list_no);
            j = 0;
            do{
                j++; k++;
                fscanf(fp,"%f %f\n",&x,&y);
                if (x != -1) {
                    xmin = MIN(xmin,x); xmax = MAX(xmax,x);
                    ymin = MIN(ymin,height-y); ymax = MAX(ymax,height-y);
                }
            } while ((x != -1) && !feof(fp));
            k--;
        } while ((y != -1) && !feof(fp));
    }
    else {
        /* process curvature pixel data */
        printf("plotting curvature pixel data\n");
        i = k = 0;
        do{
            fscanf(fp,"%s %d\n",dumstring,&list_no);
            fscanf(fp,"%s %f\n",dumstring,&sigma);
            j = 0;
            do{
                j++; k++;
                fscanf(fp,"%f %f %f %d\n",&x,&y,&curvature,&label);
                if (x != -1) {
                    xmin = MIN(xmin,x); xmax = MAX(xmax,x);
                    ymin = MIN(ymin,height-y); ymax = MAX(ymax,height-y);
                }
            } while ((x != -1) && !feof(fp));
            k--;
        } while ((y != -1) && !feof(fp));
    }
    fclose(fp);
}


process_super_data(file_name,plot_a,plot_l,plot_e,plot_c,bold)
char file_name[];
int plot_l,plot_a,plot_e,plot_c,bold;
/* reads super data and plots each curve type as it reads it */
{
    char data_type[40];
    char ch;
    int i,j;
    int x_s,y_s,x_f,y_f,arc_dir;
    float x_c,y_c,radius;
    float as_x,as_y,af_x,af_y;
    int old_list_no,list_no;
    int xx,yy;
    int xp,yp;
    float x1,y1,x2,y2;
    float x_cent,y_cent;
    int int_radius;
    FILE *fp;
    float temp,ang1,ang2,step,arc_length,l1;
    float signif;
    float x,y,x11,y11,x22,y22,x33,y33;
    int x11d,y11d,x22d,y22d,x33d,y33d;
    float maj_axis,min_axis,squareness,rot_angle;
    char file_type[50];
    int file_data_type;
    float xv,yv,x_1,y_1,x_2,y_2,x_3,y_3;        /* corner plotting variables */
    int type,xvd,yvd;
    int count;
    char label[10];
    float sum_x,sum_y;
    int prevx,prevy;
    int size;
    int line_no,arc_no,ellipse_no,vertex_no;
    char number[50];
    int colour,ang;
    char use_colour[50];

    line_no = ellipse_no = arc_no = vertex_no = 0;

    if ((fp = fopen(file_name,"r")) == NULL) {
        printf("cannot open file: %s\n",file_name);
        exit(-1);
    }
    fscanf(fp,"%s\n",file_type);
    if (strcmp(file_type,"super") == 0) {
        printf("integer super data file\n");
        file_data_type = INTEGER;
    }
    else if (strcmp(file_type,"super_float") == 0) {
        printf("float super data file\n");
        file_data_type = FLOAT;
    }
    else{
        printf("input file not super or super_float type - aborting\n");
        exit(-1);
    }
    list_no = -1;
    do{
        i = -1;
        do{
            fscanf(fp,"%c",&ch);
            data_type[++i] = ch;
        } while (ch != ':');
        data_type[++i] = '\0';
        j = curve_type(data_type);
        if (j == LISTS) {
            old_list_no = list_no;
            fscanf(fp,"%d\n",&list_no);
            if (pause && (old_list_no != -1)) {
                flush_buffer();
                printf("list: %d\n",old_list_no);
                scanf("%c",&ch);
            }
        }
        else if (j == ENDL) {
            fscanf(fp,"\n");
        }
        else if (j == PIXELS) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%f %d %d\n",&signif,&x_s,&y_s);
                x = x_s;
                y = y_s;
            }
            else{
                fscanf(fp,"%f %f %f\n",&signif,&x,&y);
            }
            set_colour("cyan");
            move(x,y);
            draw(thick,x,y);
        }
        else if (j == CROSSES) {
            fscanf(fp,"%d %d %d\n",&xx,&yy,&size);
            cross((float)xx,(float)yy,size,"red");
            xmin = MIN(xmin,xx); xmax = MAX(xmax,xx);
            ymin = MIN(ymin,height-yy); ymax = MAX(ymax,height-yy);
        }
        else if (j == DTRIANGLE) {
            fscanf(fp,"%d %d %d\n",&xx,&yy,&size);
            dtriangle((float)xx,(float)yy,size,"red");
        }
        else if (j == UTRIANGLE) {
            fscanf(fp,"%d %d %d\n",&xx,&yy,&size);
            utriangle((float)xx,(float)yy,size,"red");
        }
        else if (j == BOX) {
            fscanf(fp,"%d %d %d\n",&xx,&yy,&size);
            box((float)xx,(float)yy,size,"purple");
        }
        else if (j == DIAMOND) {
            fscanf(fp,"%d %d %d\n",&xx,&yy,&size);
            diamond((float)xx,(float)yy,size,"red");
        }
        else if (j == LINES) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%f %d %d %d %d\n",&signif,&x_s,&y_s,&x_f,&y_f);
                x11 = x_s;
                y11 = y_s;
                x = x_f;
                y = y_f;
            }
            else{
                fscanf(fp,"%f %f %f %f %f\n",&signif,&x11,&y11,&x,&y);
            }
            xmin = MIN(xmin,x); xmax = MAX(xmax,x);
            ymin = MIN(ymin,height-y); ymax = MAX(ymax,height-y);
            xmin = MIN(xmin,x11); xmax = MAX(xmax,x11);
            ymin = MIN(ymin,height-y11); ymax = MAX(ymax,height-y11);
            line_no++;
            if (plot_l == 1) {
                set_colour("brown");
                move(x11,y11);
                draw(thick,x,y);
                if (crosses == 1)
                    cross(x11,y11,2,"purple");
                if (points == 1)
                    point(x11,y11);
                if (crosses == 1)
                    cross(x,y,2,"purple");
                if (points == 1)
                    point(x,y);
                if (textout) {
                    sprintf(number,"%d",line_no);
                    set_colour("blue");
                    outtextxy((int)x11,(int)y11,number);
                }
            }
        }
        else if (j == SBREAK) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%d %d\n",&x_s,&y_s);
                x = x_s;
                y = y_s;
            }
            else{
                fscanf(fp,"%f %f\n",&x,&y);
            }
            if (sbreak == 1)
                cross(x,y,1,"blue");
        }
        else if (j == CORNERS) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%d %d %d %d %d %d %d %d %d\n",
                        &type,&xvd,&yvd,
                        &x11d,&y11d,&x22d,&y22d,&x33d,&y33d);
                xv = xvd;
                yv = yvd;
                x_1 = x11d;
                y_1 = y11d;
                x_2 = x22d;
                y_2 = y22d;
                x_3 = x33d;
                y_3 = y33d;
            }
            else{
                fscanf(fp,"%d %f %f %f %f %f %f %f %f\n",
                        &type,&xv,&yv,
                        &x_1,&y_1,&x_2,&y_2,&x_3,&y_3);
            }
            printf("%d %f %f %f %f %f %f\n",
                    type,xv,yv,x_1,y_1,x_2,y_2,x_3,y_3);
            if (corner_plot == 1) {
                cross(xv,yv,1,"blue");
                move(xv,yv);
                draw(0,x_1,y_1);
                move(xv,yv);
                draw(0,x_2,y_2);
                if (type == 3) {
                    move(xv,yv);
                    draw(0,x_3,y_3);
                }
            }
        }
        else if (j == CIRCLES) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%f %d %d %d\n",&signif,&x11d,&y11d,&int_radius);
                x_cent = x11d;
                y_cent = y11d;
                radius = int_radius;
            }
            else{
                fscanf(fp,"%f %f %f %f\n",&signif,&x_cent,&y_cent,&radius);
            }

            if (plot_c == 1) {
                /* doesn't seem to dump green, yellow, orange or red!
                 * cyan, blue, brown, purple, pink are ok
                 */
                set_colour("pink");
                plot_circle(x_cent,y_cent,radius,0.0,TWO_PI,0.0,TWO_PI,bold);
            }
        }
        else if (j == ARCS) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%f %d %d %d %d %d %d %d %d\n",&signif,
                    &x11d,&y11d,&x22d,&y22d,&x33d,&y33d,&int_radius,&arc_dir);
                x_cent = x11d;
                y_cent = y11d;
                as_x = x22d;
                as_y = y22d;
                af_x = x33d;
                af_y = y33d;
                radius = int_radius;
            }
            else{
                fscanf(fp,"%f %f %f %f %f %f %f %f %d\n",&signif,
                    &x_cent,&y_cent,&as_x,&as_y,&af_x,&af_y,&radius,&arc_dir);
            }
            arc_no++;
            if (plot_a == 1) {
                float iang1,iang2;

                if (textout) {
                    printf("%f %f %f %f\n",as_x,as_y,af_x,af_y);
                    printf("centre: %f %f\n",x_cent,y_cent);
                    printf("radius: %f\n",radius);
                    printf("arc_dir: %d\n",arc_dir);
                }

                set_colour("blue");
                if (full_arcs)
                    plot_circle(x_cent,y_cent,radius,0.0,TWO_PI,0.0,TWO_PI,2);

                set_colour("purple");
                ang1 = angle(x_cent,y_cent,as_x,as_y);
                ang2 = angle(x_cent,y_cent,af_x,af_y);
                iang1 = angle(x_cent,height-y_cent,as_x,height-as_y);
                iang2 = angle(x_cent,height-y_cent,af_x,height-af_y);
                /*
                the code below is a hack to compute the correct angle for 
                the arc drawing from knowing the arc_dir (clockwise or 
                anticlockwise) from the start node
                initially works out the correct angle going clockwise
                */
                if (arc_dir == CLOCKWISE) {
                    temp = ang1; ang1 = ang2; ang2 = temp;
                    temp = iang1; iang1 = iang2; iang2 = temp;
                }
                /* ang2 must be bigger than ang1 */
                if (ang2 < ang1) ang2 += PI * 2.0;
                if (iang2 < iang1) iang2 += PI * 2.0;

                plot_circle(x_cent,y_cent,radius,ang1,ang2,iang2,iang1,2);

                if (crosses == 1) {
                    x = af_x; y = af_y;
                    move(x,y);
                    cross(x,y,2,"purple");
                }
                if (points == 1) {
                    x = af_x; y = af_y;
                    move(x,y);
                    point(x,y);
                }
                if (textout) {
                    sprintf(number,"%d",arc_no);
                    set_colour("pink");
                    outtextxy((int)x11,(int)y11,number);
                }
            }
        }
        else if (j == ELLIPSES) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%f %d %d %d %d %d %d %f %f %f %d\n",&signif,
                    &x11d,&y11d,&x22d,&y22d,&x33d,&y33d,&maj_axis,
                    &min_axis,&rot_angle,&arc_dir);
                x_cent = x11d;
                y_cent = y11d;
                as_x = x22d;
                as_y = y22d;
                af_x = x33d;
                af_y = y33d;
            }
            else{
                fscanf(fp,"%f %f %f %f %f %f %f %f %f %f %d\n",&signif,
                    &x_cent,&y_cent,&as_x,&as_y,&af_x,&af_y,&maj_axis,
                    &min_axis,&rot_angle,&arc_dir);
            }
            qx = x_cent;
            qy = y_cent;
            ellipse_no++;
            if (plot_e == 1) {
                set_colour("blue");
                if (use_old_plot)
                    oldplot_ellipse(as_x,as_y,af_x,af_y,x_cent,y_cent,
                             maj_axis,min_axis,rot_angle,arc_dir,
                             bold,full_arcs);
                else
                    plot_ellipse(as_x,as_y,af_x,af_y,x_cent,y_cent,
                             maj_axis,min_axis,rot_angle,arc_dir,
                             bold,full_arcs);
                x11 = as_x;
                y11 = as_y;
                if (crosses == 1)
                    cross(x11,y11,2,"purple");
                if (points == 1)
                    point(x11,y11);
                x11 = af_x;
                y11 = af_y;
                if (crosses == 1)
                    cross(x11,y11,2,"purple");
                if (points == 1)
                    point(x11,y11);
                if (textout) {
                    sprintf(number,"%d",ellipse_no);
                    set_colour("pink");
                    outtextxy((int)x11,(int)y11,number);
                }
            }
        }
        else if (j == SUPERELLIPSES) {
            if (file_data_type == INTEGER) {
                fscanf(fp,"%f %d %d %d %d %d %d %f %f %f %f %d\n",&signif,
                    &x11d,&y11d,&x22d,&y22d,&x33d,&y33d,&maj_axis,
                    &min_axis,&squareness,&rot_angle,&arc_dir);
                x_cent = x11d;
                y_cent = y11d;
                as_x = x22d;
                as_y = y22d;
                af_x = x33d;
                af_y = y33d;
            }
            else{
                fscanf(fp,"%f %f %f %f %f %f %f %f %f %f %f %d\n",&signif,
                    &x_cent,&y_cent,&as_x,&as_y,&af_x,&af_y,&maj_axis,
                    &min_axis,&squareness,&rot_angle,&arc_dir);
            }
            qx = x_cent;
            qy = y_cent;
            ellipse_no++;
            if (plot_e == 1) {
                set_colour("blue");
                plot_superellipse(as_x,as_y,af_x,af_y,x_cent,y_cent,
                             maj_axis,min_axis,squareness,rot_angle,arc_dir,
                             bold,full_arcs);
                x11 = as_x;
                y11 = as_y;
                if (crosses == 1)
                    cross(x11,y11,2,"purple");
                    /* box(x11,y11,4,"purple"); */
                if (points == 1)
                    point(x11,y11);
                x11 = af_x;
                y11 = af_y;
                if (crosses == 1)
                    cross(x11,y11,2,"purple");
                    /* box(x11,y11,4,"purple"); */
                if (points == 1)
                    point(x11,y11);
                if (textout) {
                    sprintf(number,"%d",ellipse_no);
                    set_colour("pink");
                    outtextxy((int)x11,(int)y11,number);
                }
            }
        }
        else if (j == CODONS) {
            fscanf(fp,"%s",label);
            count = sum_x = sum_y = 0;
            set_colour("blue");
            fscanf(fp,"%f %f",&x1,&y1);
            while (x1 != -1) {
                sum_x += x1;
                sum_y += y1;
                if (count == 0) {
                    move(x1,y1);
                    if (plot_singular_pts)
                        /* box(x1,y1,3,"purple"); */
                        cross(x1,y1,2,"purple");
                }
                else
                    draw(thick,x1,y1);
                count++;

                prevx = x1; prevy = y1;
                fscanf(fp,"%f %f",&x1,&y1);
            }
            if (count > 0 && plot_singular_pts) {
                outtextxy((int)(sum_x/count+5),(int)(sum_y/count+5),label);
                /* box((float)prevx,(float)prevy,3,"purple"); */
                cross((float)prevx,(float)prevy,2,"purple");
            }
            fscanf(fp,"\n");
        }
        else if (j == VERTEX) {
            fscanf(fp,"%d %d %d %d\n",&xp,&yp,&colour,&ang);
            if (colour == DARK)
                strcpy(use_colour,"purple");
            else
                strcpy(use_colour,"cyan");
            if (ang < 67)
                plus((float)xp,(float)yp,3,use_colour);
            else if (ang < 112)
                box((float)xp,(float)yp,3,use_colour);
            else
                cross((float)xp,(float)yp,3,use_colour);
            if (textout) {
                sprintf(number,"%d",vertex_no);
                set_colour("pink");
                outtextxy((int)xp,(int)yp,number);
            }
            vertex_no++;
        }
    } while (j != ENDF);
    if (pause) {
        flush_buffer();
        scanf("%c",&ch);
        printf("list: %d\n",list_no);
    }
    close(fp);
}

int curve_type(array)
char array[];
{
    int i,j;

    if ((j = strcmp(array,"list:")) == 0)
        i = LISTS;
    else if ((j = strcmp(array,"line:")) == 0)
        i = LINES;
    else if ((j = strcmp(array,"arc:")) == 0)
        i = ARCS;
    else if ((j = strcmp(array,"endl:")) == 0)
        i = ENDL;
    else if ((j = strcmp(array,"endf:")) == 0)
        i = ENDF;
    else if ((j = strcmp(array,"ellipse:")) == 0)
        i = ELLIPSES;
    else if ((j = strcmp(array,"sbreak:")) == 0)
        i = SBREAK;
    else if ((j = strcmp(array,"corner:")) == 0)
        i = CORNERS;
    else if ((j = strcmp(array,"pixel:")) == 0)
        i = PIXELS;
    else if ((j = strcmp(array,"circle:")) == 0)
        i = CIRCLES;
    else if ((j = strcmp(array,"codon:")) == 0)
        i = CODONS;
    else if ((j = strcmp(array,"cross:")) == 0)
        i = CROSSES;
    else if ((j = strcmp(array,"vertex:")) == 0)
        i = VERTEX;
    else if ((j = strcmp(array,"superellipse:")) == 0)
        i = SUPERELLIPSES;
    else if ((j = strcmp(array,"dtriangle:")) == 0)
        i = DTRIANGLE;
    else if ((j = strcmp(array,"utriangle:")) == 0)
        i = UTRIANGLE;
    else if ((j = strcmp(array,"box:")) == 0)
        i = BOX;
    else if ((j = strcmp(array,"diamond:")) == 0)
        i = DIAMOND;
    return(i);
}

/* copies string i2 onto end of i1 and returns result in i3 */
strcopy(i1,i2,i3)
char i1[],i2[],i3[];
{
    int i,j;

    i = 0;
    while (i1[i] != '\0') {
        i3[i] = i1[i];
        i++;
    }
    j = 0;
    while (i2[j] != '\0') {
        i3[i] = i2[j];
        i++;
        j++;
    }
    i3[i] = '\0';
}

int strcmp(s,t)
char s[],t[];
{
    int i;

    i = 0;
    while (s[i] == t[i])
        if (s[i++] == '\0')
            return(0);
    return(s[i] - t[i]);
}

plot_border(type,width,height)
int type,width,height;
{
    if (type == SUPER)
        set_colour("green");
    else
        set_colour("cyan");
    move(0.0,0.0);
    draw(0,(float)width-1,0.0);
    draw(0,(float)width-1,(float)height-1);
    draw(0,0.0,(float)height-1);
    draw(0,0.0,0.0);
}

/* selects pixel lists and outputs their list numbers */
output_list_numbers(x,y)
int x,y;
{
    FILE *fp;
    char dumstring[50];
    int i,j,k;
    int xx,yy,dx,dy;
    int list_no;
    int got_list = -1;
    char file_type[50];

    x /= zoom; y /= zoom;

    if ((fp=fopen(pixel_file,"r")) == NULL) {
        printf("cant open %s\n",pixel_file);
        exit(-1);
    }
    fscanf(fp,"%s\n",file_type);
    i = strcmp(file_type,"pixel");
    if (strcmp(file_type,"pixel") != 0) {
        printf("input file not pixel type - aborting\n");
        exit(-1);
    }

    i = k = 0;
    do {
        fscanf(fp,"%s %d\n",dumstring,&list_no);
        j = 0;
        do {
            j++; k++;
            fscanf(fp,"%d %d\n",&xx,&yy);
            if (xx != -1) {
                dx = ABS(x - xx);
                dy = ABS(y - yy);
                if ((dx < 2) && (dy < 2)) {
                    printf("GOT list: %d\n",list_no);
                    got_list = list_no;
                }
            }
        } while ((xx != -1) && !feof(fp) && (got_list == -1));
    } while ((yy != -1) && !feof(fp) && (got_list == -1));
    fclose(fp);

    if (got_list == -1) {
        printf("NOT FOUND\n");
        return;
    }

    if ((fp=fopen(pixel_file,"r")) == NULL) {
        printf("cant open %s\n",pixel_file);
        exit(-1);
    }
    fscanf(fp,"%s\n",file_type);
    set_colour("green");
    i = k = 0;
    do {
        fscanf(fp,"%s %d\n",dumstring,&list_no);
        j = 0;
        do {
            j++; k++;
            fscanf(fp,"%d %d\n",&xx,&yy);
            if (list_no == got_list) {
                if (xx != -1) {
                    if (j == 1) {
                        move((float)xx,(float)yy);
                    }
                    else {
                        draw(thick,(float)xx,(float)yy);
                    }
                }
            }
        } while ((xx != -1) && !feof(fp));
    } while ((yy != -1) && !feof(fp) && (list_no != got_list));
    fclose(fp);
    flush_buffer();
}
