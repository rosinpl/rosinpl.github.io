#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define NONE     0
#define LOG      1
#define RESCALE  2

#define GREY_COLOUR  0
#define GREY_COLOUR2 1
#define RANDOM       2

#define LITTLE_CIRCLE -1.5
#define MEDIUM_CIRCLE -3.0
