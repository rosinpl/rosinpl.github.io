/*
 *    matches codon models to curves
 *
 *    chooses best smoothing levels - i.e. natural scales of curve
 *    parses each contour into the extended set of codons
 *    combines scales to create codon-tree
 *    matches codons from model to the codon-tree
 *
 *    for details see:
 *    Multi-scale representation and matching of curves using codons
 *    Paul Rosin
 *    CVGIP: Graphical Models and Image Processing, Vol 55 pp. 286-310, 1993
 *
 *    input:  pixel list data
 *    output: Postscript
 *
 *    Unfortunately there are still a number of hacks and unfinished portions
 *    in this code. Hopefully I may have a chance in the future to rectify
 *    this - but don't hold your breath!
 *
 *    updated - matches more than 3 codons now
 *
 *    updated to use Fdez-Valdivia at al.'s ambiguity function as an
 *    alternative to the normalised number of zero crossings
 *
 *    Paul Rosin
 *    Institute of Remote Sensing Applications
 *    Joint Research Centre
 *    Ispra (VA), Italy
 *    rosin@jrc.it
 *    March 1995
 */

#include <stdio.h>
#include <math.h>

#ifndef FALSE
#define FALSE 0
#define TRUE (!FALSE)
#endif

#define MIN(a,b)    (((a) < (b)) ? (a) : (b))
#define MAX(a,b)    (((a) > (b)) ? (a) : (b))

#define HEIGHT 768
#define WIDTH 768

#define PI 3.141591
#define TWO_PI 6.2831852

#define MAX_PIXELS 10000
#define MAX_WIN 2000
#define MAX_SCALES 100

#define FORWARD 0
#define REVERSE 1
#define START 0
#define FINISH 1

#define S_INC (sqrt(2.0))   /* sigma increment between smoothing scales */

#define MIN_K 0.001         /* curvature equivalent to zero */
#define MIN_LENGTH 4        /* smallest straight line detected */

#define SQR(a)    ((a)*(a))
#define CUBE(a)   ((a)*(a)*(a))

/* curvature labels */
#define PosMax        1     /* positive curvature maximum */
#define PosMin        2     /* positive curvature minimum */
#define NegMax        3     /* negative curvature maximum */
#define NegMin        4     /* negative curvature minimum */
#define StartZero     5     /* start of zero curvature section */
#define EndZero       6     /* end of zero curvature section */
#define PosEnd        7     /* curve end has positive curvature */
#define NegEnd        8     /* curve end has negative curvature */

/* codon labels */
#define Error        -1
#define ZeroPlus      1        /* 0+ */
#define ZeroMinus     2        /* 0- */
#define OnePlus       3        /* 1+ */
#define OneMinus      4        /* 1- */
#define Two           5        /* 2 */
#define Zero          6        /* zero curvature section */
#define APlus         7        /* A+ */
#define AMinus        8        /* A- */
#define BPlus         9        /* B+ */
#define BMinus       10        /* B- */
#define C            11        /* C */
#define DPlus        12        /* D+ */
#define DMinus       13        /* D- */
#define ZeroA        14        /* 0a */
#define OneA         15        /* 1a */
#define OneB         16        /* 1b */
#define OneC         17        /* 1c */
#define TwoA         18        /* 2a */
#define TwoB         19        /* 2b */
#define TwoC         20        /* 2c */
#define TwoD         21        /* 2d */
#define Ea           22        /* Ea */
#define Eb           23        /* Eb */
#define Ec           24        /* Ec */
#define Ed           25        /* Ed */
#define Fa           26        /* Fa */
#define Fb           27        /* Fb */
#define Fc           28        /* Fc */
#define Fd           29        /* Fd */
#define Fe           30        /* Fe */
#define Ff           31        /* Ff */
#define Fg           32        /* Fg */

#define ROOT_NODE -999

#define  WHITE      255
#define  YELLOW     253
#define  GREEN      252
#define  BLUE       251
#define  PURPLE     250
#define  CYAN       249
#define  LIME       248
#define  RED        247
#define  ORANGE     246
#define  BLACK        0

extern unsigned char current_colour;

/* structure definition for storing codon-tree */
typedef struct tree_node {
    int codon_id;             /* index into codons array */
    int codon_type;           /* codon label */
    int codon_start;          /* start of codon in curve path */
    int codon_finish;         /* finish of codon in curve path */
    struct tree_node *parent; /* pointer to parent codon */
    struct tree_node *prev;   /* pointer to adjacent previous codon */
    struct tree_node *next;   /* pointer to adjacent next codon */
    int no_codons;            /* number of codons at this natural scale */
    struct tree_node *codonChildren[50];     /* pointers to each codon's subcodons */
    float length,roundness,compactness,skew; /* codon attributes */
} TREE_NODE;

int x[MAX_PIXELS],y[MAX_PIXELS];             /* pixel data */
/* smoothed pixel data */
int xsmooth[MAX_SCALES][MAX_PIXELS],ysmooth[MAX_SCALES][MAX_PIXELS];
int no_pixels;                               /* number of original pixels */
int closed_loop;                             /* is data closed? */
int x_trans[MAX_PIXELS],y_trans[MAX_PIXELS]; /* transformed pixels */
float curvature[MAX_SCALES][MAX_PIXELS];     /* curvature of pixels */
float curvature2[MAX_PIXELS];    /* difference of curvature of pixels */
float energy[MAX_SCALES];                    /* summed squared curvature  */
/* start and finish of original data within extended curve */
int start_pixel[MAX_SCALES],finish_pixel[MAX_SCALES];
int flags[MAX_PIXELS];      /* curvature extrema labels for each pixel */
int flags2[MAX_PIXELS];     /* squeezed contents of flags - no non-extrema */
int no_flags;               /* number of elements in flags2 */
int flags2_pos[MAX_SCALES][MAX_PIXELS];    /* corresponding pixel for each extrema flag */
int codons[MAX_SCALES][MAX_PIXELS];        /* list of extracted codons */
int codons_pos[MAX_SCALES][MAX_PIXELS];    /* position in flags2 list of codons */
int no_codons[MAX_SCALES];                 /* number of codons extracted */

float num_curv_zeros[50];
int minima[50],minima_loc[50];
int no_minima;
float sigmas[50];        /* all the sigmas used for smoothing */
int index = 0;           /* index to which sigma to use */
int nscale = 0;          /* index to natural scale */

TREE_NODE *tree_root;    /* node at root of codon-tree */

double G[MAX_WIN];       /* convolution mask for Gaussian smoothing */
double G1[MAX_WIN];      /* convolution mask for first derivative of Gaussian */
double G2[MAX_WIN];      /* convolution mask for second derivative of Gaussian */
float cor_table[197];    /* correction factors for Gaussian smoothing */
int masksize,halfmask;   /* full and half size of Gaussian mask */
int store_halfmasks[MAX_SCALES];  /* store halfmask sizes at each scale */
int store_masks[MAX_SCALES];      /* store mask sizes at each scale */

int model[50];           /* codons & attributes for model */
float model_length[50];
float model_round[50];
float model_compact[50];
float model_skew[50];
int no_model_elems;      /* number of codons in model */
int longest_model_codon; /* index to the longest model codon */

int colour;
int stop_smoothing = FALSE;    /* flag to terminate smoothing */

int Yoffset;
int width;
int Xoffset1;
int Xgap = 45;

char *ps_file = NULL;

main(argc,argv)
int argc;
char *argv[];
{
    float sigma;
    int i,t;
    float minval,maxval;
    int Xoffset = 50;
    int Xoffset2;
    int Xinc;
    int Yfactor = 45;
    float max_sigma;
    int xmin,xmax;
    int ymax;
    float calc_diff();
    char *model_file = NULL;
    char *pix_file = NULL;
    int plot_tree_links = FALSE;
    int use_ambiguity = FALSE;

    /* parse command line arguments */
    for (i = 1; i < argc; i++) {
       if (argv[i][0] == '-')
          switch (argv[i][1]) {
              case 'a':
                   use_ambiguity = TRUE;
                   break;
              case 't':
                   plot_tree_links = TRUE;
                   break;
              case 'i':
                   i++;
                   pix_file = argv[i];
                   break;
              case 'p':
                   i++;
                   ps_file = argv[i];
                   break;
              case 'm':
                   i++;
                   model_file = argv[i];
                   break;
              default:
                   printf("illegal option -%c\n",argv[i][1]);
                   print_usage(argv[0]);
          }
        else {
           printf("illegal option %c\n",argv[i][0]);
           print_usage(argv[0]);
        }
    }

    if (pix_file == NULL)
        print_usage(argv[0]);

    if (model_file != NULL) {
        read_model_data(model_file);
        printf("read model codons:\n");
        for (i = 0; i < no_model_elems; i++) {
            print_codon(model[i]);
            printf(" length: %4.1f  roundness: %4.1f  compactness: %4.1f  skew: %4.1f\n",
                model_length[i],model_round[i],model_compact[i],model_skew[i]);
        }
        printf("\n");
    }

    open_device(0,0,WIDTH,HEIGHT,pix_file);

    read_link_data(pix_file);

    /* start the plot at right of frame */
    Xoffset2 = x[0];
    for (i = 1; i < no_pixels; i++)
       if (Xoffset2 > x[i]) Xoffset2 = x[i];
    Xoffset2 = -Xoffset2 + 10;
    Xoffset1 = Xoffset2;

    xmin = 9999; xmax = -9999; ymax = -9999;
    for (i = 0; i < no_pixels-1; i++) {
        if (x[i] < xmin) xmin = x[i];
        if (x[i] > xmax) xmax = x[i];
        if (y[i] > ymax) ymax = y[i];
    }
    width = xmax - xmin;

    set_colour(CYAN);
    plot_link_data();

    max_sigma = no_pixels / 3;
    i = 0;
    printf("smoothing at sigmas: ");
    for (sigma = 1.0; sigma <= max_sigma && !stop_smoothing; sigma *= S_INC) {
        sigmas[index] = sigma;
        printf("%.1f ",sigma);
        read_link_data(pix_file);
        do_smoothing1(sigma);
        if (num_curv_zeros[index] == 0) stop_smoothing = TRUE;
        index++;
    }
    printf("\n");

    /* use Fdez-Valdivia at al.'s ambiguity function rather than
     * normalised number of zero crossings
     */
    if (use_ambiguity)
        calc_ambiguity();

    /* find minima of num_curv_zeros plot */
    for (i=1;i<index-1;i++) {
        minima[i] = ((num_curv_zeros[i] < num_curv_zeros[i-1]) && 
                     (num_curv_zeros[i] < num_curv_zeros[i+1]));
    }
    if (num_curv_zeros[0] < num_curv_zeros[1]) minima[0] = TRUE;
    if (num_curv_zeros[index-1] < num_curv_zeros[index-2]) minima[index-1] = TRUE;

    /* plot num_curv_zeros */
    Yoffset = ymax + 30;
    Xinc = 10;
    for (i=0;i<index;i++) num_curv_zeros[i] = -num_curv_zeros[i];
    minval=9999;for (i=0;i<index;i++)
        if (num_curv_zeros[i]<minval) minval=num_curv_zeros[i];
    for (i=0;i<index;i++) num_curv_zeros[i] -= minval;
    maxval=0;
    for (i=0;i<index;i++)
        if (num_curv_zeros[i]>maxval) maxval=num_curv_zeros[i];
    cross((0)*Xoffset+Xinc,(int)(num_curv_zeros[0]/maxval*Yfactor+Yoffset),5,RED);
    set_colour(BLUE);
    for (i = 0; i < index-1; i++) {
        moveto(i*Xoffset+Xinc,(int)(num_curv_zeros[i]/maxval*Yfactor+Yoffset));
        lineto((i+1)*Xoffset+Xinc,(int)(num_curv_zeros[i+1]/maxval*Yfactor+Yoffset),0);
        cross((i+1)*Xoffset+Xinc,(int)(num_curv_zeros[i+1]/maxval*Yfactor+Yoffset),5,RED);
        if (minima[i])
            plot_circle((i)*Xoffset+Xinc,(int)(num_curv_zeros[i]/maxval*Yfactor+Yoffset),8,RED);
    }
    i = index - 1;
    if (minima[i])
        plot_circle((i)*Xoffset+Xinc,(int)(num_curv_zeros[i]/maxval*Yfactor+Yoffset),8,RED);

    /* calculate difference measure */
    no_minima = 0;
    for (i = 0; i < index; i++)
        if (minima[i]) {
            minima_loc[no_minima] = i;
            no_minima++;
        }

    /*** currently I don't bother ranking the natural scales
    for (i=0; i<no_minima-1; i++)
        calc_diff(minima_loc[i],minima_loc[i+1]);
    ***/

    /* regenerate all curves at natural scales */
    /* store all the necessary data */
    /* segment into codons and create codon-tree */
    /* I know that this is very inefficient - but that's how things are! */
    for (i = 0; i < index; i++)
        if (minima[i]) {
            printf("\nnatural scale at sigma = %.1f\n",sigmas[i]);
            read_link_data(pix_file);
            do_smoothing2(nscale,sigmas[i]);
            determine_codons(nscale,sigmas[i]);
            nscale++;
        }

    /* plot codons */
    Yoffset += (Yfactor + 30);
    for (i = 0; i < nscale; i++) {
        set_colour(GREEN);
        /* plot smoothed curve */
        moveto((int)(xsmooth[i][start_pixel[i]]+Xoffset2),
               (int)(ysmooth[i][start_pixel[i]]+Yoffset));
        for (t = start_pixel[i]; t < finish_pixel[i]; t++)
            lineto((int)(xsmooth[i][t]+Xoffset2),
                   (int)(ysmooth[i][t]+Yoffset),0);

        /* plot codon ends */
        set_colour(RED);
        plot_codons_ends(i,Xoffset2,Yoffset);

        /* plot codon labels */
        set_colour(CYAN);
        plot_codons_labels(i,Xoffset2,Yoffset);

        Xoffset2 += width;
        Xoffset2 += Xgap;
    }

    generate_codon_tree();

    generate_codon_attributes(tree_root,nscale);

    if (plot_tree_links)
        plot_codon_tree(tree_root,nscale);

    if (model_file != NULL)
        match2(tree_root,nscale,model);

    close_graph();
}

/* calculate Fdez-Validivia et al.'s ambiguity function */
calc_ambiguity()
{
    int i,t;
    int point;
    float a;

    for (i = 0; i < index-1; i++) {
        a = 0;
        for (t = 0; t < no_pixels-store_masks[i]; t++) {
            point = t + store_halfmasks[i];
            a += curvature[i][point] * curvature[i+1][point];
        }
        a /= energy[i] * energy[i+1];
        num_curv_zeros[i] = a;
    }
}

/* generate the codon-tree data structure */
generate_codon_tree()
{
    if ((tree_root = (TREE_NODE *)malloc(sizeof(TREE_NODE))) == NULL) {
        printf("ERROR: can't allocate memory\n");
        exit(-1);
    }
    tree_root->codon_start = start_pixel[nscale-1] - 9999;
    tree_root->codon_finish = finish_pixel[nscale-1] + 9999;
    tree_root->parent = NULL;
    tree_root->prev = NULL;
    tree_root->next = NULL;
    tree_root->no_codons = 0;
    tree_root->codon_id = ROOT_NODE;
    tree_root->codon_type = ROOT_NODE;

    /* generate most of codon-tree */
    generate_node(tree_root,nscale-1);
    /* generate remaining prev/next links between cousins in codon-tree */
    generate_links(tree_root,nscale-1);
}

/* generate nodes in the codon-tree data structure */
generate_node(node,nscale)
TREE_NODE *node;
int nscale;
{
    int j;
    int start,finish;
    int st1,fi1,st2,fi2;
    int within1(),within2();

    /* at last natural scale so stop recursion */
    if (nscale < 0) {
        node->no_codons = 0;
        return;
    }

    /* !!!!!! CHECK THIS - PROBABLY DODGY !!!!!! */
    /* store locations of each codon */
    /* !!!!!! STOP WHEN PASSED OVERLAP !!!!!! */
    for (j = 0; j < no_codons[nscale]; j++) {
        switch(codons[nscale][j]) {
        case ZeroPlus: case ZeroMinus: case OnePlus: case OneMinus:
        case Two: case APlus: case AMinus: case BPlus: case BMinus:
        case C: case ZeroA: case OneA: case OneB: case TwoA: case TwoB:
        case Ea: case Eb: case Fa: case Fb: case Fc: case Fd: case Fe:
        case Ff: case Fg:
            start = flags2_pos[nscale][codons_pos[nscale][j]-1];
            finish = flags2_pos[nscale][codons_pos[nscale][j]+1];
            break;
        case Zero: case DPlus: case DMinus: case OneC: case TwoC:
        case TwoD: case Ec: case Ed:
            start = flags2_pos[nscale][codons_pos[nscale][j]];
            finish = flags2_pos[nscale][codons_pos[nscale][j]+1];
            break;
        case Error:
            break;
        }

        /* adjust codon positions to ignore curve extension */    
        st1 = start - start_pixel[nscale];
        fi1 = finish - start_pixel[nscale];
        if (node->codon_id != ROOT_NODE) {
            st2 = node->codon_start - start_pixel[nscale+1];
            fi2 = node->codon_finish - start_pixel[nscale+1];
        }
        else {
            st2 = node->codon_start;
            fi2 = node->codon_finish;
        }
        /* link codons - create node for child codon */
        if (within2(st1,fi1,st2,fi2)) {
            if ((node->codonChildren[node->no_codons] =
                (TREE_NODE *)malloc(sizeof(TREE_NODE))) == NULL) {
                printf("ERROR: can't allocate memory\n");
                exit(-1);
            }
            node->codonChildren[node->no_codons]->parent = node;
            node->codonChildren[node->no_codons]->codon_id = j;
            node->codonChildren[node->no_codons]->codon_type =
                codons[nscale][j];
            node->codonChildren[node->no_codons]->codon_start = start;
            node->codonChildren[node->no_codons]->codon_finish = finish;
            node->codonChildren[node->no_codons]->no_codons = 0;
            (node->no_codons)++;
        }
    }

    /* add pointers to adjacent siblings of children codons */
    for (j = 0; j < node->no_codons; j++) {
        if (j == 0)                                    /* don't know cousin yet */
            node->codonChildren[0]->prev = NULL;
        else
            node->codonChildren[j]->prev = node->codonChildren[j-1];
        if (j == node->no_codons-1)                    /* don't know cousin yet */
            node->codonChildren[j]->next = NULL;
        else
            node->codonChildren[j]->next = node->codonChildren[j+1];
    }

    /* recursively generate lower level nodes */
    for (j = 0; j < node->no_codons; j++)
        generate_node(node->codonChildren[j],nscale-1);
}

/* generate adjacency links for cousins in codon-tree */
generate_links(node,nscale)
TREE_NODE *node;
int nscale; /* not used - but useful for tracking when debugging */
{
    int i;
    TREE_NODE *prev,*next;
    int no_codons;

    if (node->codon_id != ROOT_NODE) {
        if (node->no_codons > 0) {
            prev = node->prev;    /* node's brother - i.e. children's uncle */
            /* chain through preceeding brothers until one with children is found */
            while (prev != NULL && prev->no_codons == 0)
                prev = prev->prev;
            if (prev != NULL) {
                no_codons = prev->no_codons;
                /* add adjacency link between 1st child + brother's last child */
                if (no_codons > 0)
                    node->codonChildren[0]->prev =
                        prev->codonChildren[no_codons-1];
                else 
                    node->codonChildren[0]->prev = NULL;
            }

            next = node->next;
            /* chain through succeeding sisters until one with children is found */
            while (next != NULL && next->no_codons == 0)
                next = next->next;
            if (next != NULL) {
                no_codons = next->no_codons; /* node's sister - children's aunt */
                /* add adjacency link between last child + sister's 1st child */
                if (no_codons > 0)
                    node->codonChildren[node->no_codons-1]->next =
                        next->codonChildren[0];
                else
                    node->codonChildren[node->no_codons-1]->next = NULL;
            }
        }
    }

    /* recursively generate lower level node links */
    for (i = 0; i < node->no_codons; i++)
        generate_links(node->codonChildren[i],nscale-1);
}

/* is the first codon within the second? */
int within1(st1,fi1,st2,fi2)
int st1,fi1,st2,fi2;
{
    int s,f;
    float overlap;

    s = MAX(st1,st2);
    if (s > fi1)
        overlap = 0;
    else {
        f = MIN(fi1,fi2);
        if (f < st1)
            overlap = 0;
        else {
            overlap = f - s;
        }
    }

    /* percentage (0->1) of first codon overlapped by second codon */
    overlap /= (fi1 - st1);

    if (overlap >= 0.5)
        return(TRUE);
    else
        return(FALSE);
}

/* is the centre of the first codon within the second? */
int within2(st1,fi1,st2,fi2)
int st1,fi1,st2,fi2;
{
    int c;

    c = (st1 + fi1) / 2;
    /* a problem if the midpoint is exactly on an end of the parent */
    /* just arbitrarly choose to include if at top end but not bottom */
    if ((c > st2) && (c <= fi2))
        return(TRUE);
    else
        return(FALSE);
}

/* traverse and plot the codon-tree data structure */
plot_codon_tree(node,nscale)
TREE_NODE *node;
int nscale;
{
    int j;
    int st,fi;
    int Xoffset;
    int Yoffset2 = 0;
    int p1,p2,mid;
    char text[50];

    Xoffset = nscale * (width + Xgap) + Xoffset1;

    if (node->codon_id != ROOT_NODE) {
        st = node->codon_start;
        fi = node->codon_finish;
        mid = (st + fi) / 2;

        /* plot codon */
        set_colour(RED);
        moveto((int)(xsmooth[nscale][st])+Xoffset,
               (int)(ysmooth[nscale][st])+Yoffset+Yoffset2);
        for (j = st; j < fi; j++)
            lineto((int)(xsmooth[nscale][j])+Xoffset,
                   (int)(ysmooth[nscale][j])+Yoffset+Yoffset2,0);

        /* print codon attribites */
        /***
        sprintf(text,"L: %2.1f R: %2.1f C: %2.1f S %2.1f\n",
            node->length,node->roundness,node->compactness,node->skew);
        outtextxy((int)(xsmooth[nscale][mid])+Xoffset+2,
                  (int)(ysmooth[nscale][mid])+Yoffset+Yoffset2,
                  text);
        ****/
        /***
        sprintf(text,"L: %4.1f R: %4.1f\n",
            node->length,node->roundness);
        outtextxy((int)(xsmooth[nscale][mid])+Xoffset+2,
                  (int)(ysmooth[nscale][mid])+Yoffset+Yoffset2,
                  text);
        sprintf(text,"C: %4.1f S: %4.1f\n",
            node->compactness,node->skew);
        outtextxy((int)(xsmooth[nscale][mid])+Xoffset+2,
                  (int)(ysmooth[nscale][mid])+Yoffset+Yoffset2+8,
                  text);
        ****/

        /* plot parent link */
        if (node->parent->codon_id != ROOT_NODE) {
            set_colour(BLUE);
            p1 = (st + fi) / 2;
            p2 = (node->parent->codon_start + node->parent->codon_finish) / 2;
            moveto((int)(xsmooth[nscale][p1])+Xoffset+4,
                   (int)(ysmooth[nscale][p1])+Yoffset+Yoffset2);
            Xoffset = (nscale+1) * (width + Xgap) + Xoffset1;
            lineto((int)(xsmooth[nscale+1][p2])+Xoffset-4,
                   (int)(ysmooth[nscale+1][p2])+Yoffset+Yoffset2,0);
        }
    }

    /* recursively plot lower level nodes */
    for (j = 0; j < node->no_codons; j++) {
        plot_codon_tree(node->codonChildren[j],nscale-1);
    }
}

/* match model to codon tree */
match2(node,nscale,model)
TREE_NODE *node;
int nscale;
int model[];
{
    TREE_NODE *best_node;
    float best_value;
    int best_scale;
    long best_node_addr;
    TREE_NODE *focus_node;
    float focus_value;
    int focus_scale;
    long focus_node_addr;
    float overall_score = 0;

    /* match the focus codon */
    find_focus_match(node,nscale,longest_model_codon,
        &focus_value,&focus_node_addr,&focus_scale);
    focus_node = (TREE_NODE *) focus_node_addr;
    if (focus_node->codon_type != model[longest_model_codon])
        printf("can't match focus codon!\n");
    else
        overall_score = focus_value;
 
    plot_a_codon(focus_node,focus_scale,CYAN);

    /* match codons previous to the focus codon */
    match_prev_codons(focus_node,focus_scale,longest_model_codon-1,
                      &overall_score);

    /* match codons after to the focus codon */
    match_next_codons(focus_node,focus_scale,longest_model_codon+1,
                      &overall_score);

    printf("overall match score: %.2f\n",overall_score);
}

match_prev_codons(start_node,start_scale,model_codon_index,match_value)
TREE_NODE *start_node;
int start_scale;
int model_codon_index;
float *match_value;
{
    TREE_NODE *best_Lnode,*best_Hnode;
    float best_Lvalue,best_Hvalue;
    int best_Lscale,best_Hscale;
    long best_Lnode_addr,best_Hnode_addr;

    if (start_node->prev != NULL) {
        /* look below the starting node in the tree */
        find_lower_prev_match(start_node->prev,start_scale,
            model_codon_index,&best_Lvalue,&best_Lnode_addr,&best_Lscale);
        best_Lnode = (TREE_NODE *) best_Lnode_addr;

        /* and look above the starting node in the tree */
        find_higher_prev_match(start_node->prev,start_scale,
            model_codon_index,&best_Hvalue,&best_Hnode_addr,&best_Hscale);
        best_Hnode = (TREE_NODE *) best_Hnode_addr;

        if ((best_Lnode->codon_type != model[model_codon_index]) &&
            (best_Hnode->codon_type != model[model_codon_index]))
        {
            printf("can't match prev codon!\n");
        }
        else {
            if (best_Lvalue > best_Hvalue) {
                plot_a_codon(best_Lnode,best_Lscale,PURPLE);
                (*match_value) += best_Lvalue;
                if (model_codon_index > 0)
                    match_prev_codons(best_Lnode,best_Lscale,model_codon_index-1,
                                      &match_value);
            }
            else {
                plot_a_codon(best_Hnode,best_Hscale,PURPLE);
                (*match_value) += best_Hvalue;
                if (model_codon_index > 0)
                    match_prev_codons(best_Hnode,best_Hscale,model_codon_index-1,
                                      &match_value);
            }
        }
    }
    else
        printf("can't find previous codon in codon-tree!\n");
}

match_next_codons(start_node,start_scale,model_codon_index,match_value)
TREE_NODE *start_node;
int start_scale;
int model_codon_index;
float *match_value;
{
    TREE_NODE *best_Lnode,*best_Hnode;
    float best_Lvalue,best_Hvalue;
    int best_Lscale,best_Hscale;
    long best_Lnode_addr,best_Hnode_addr;

    if (start_node->next != NULL) {
        /* look below the starting node in the tree */
        find_lower_next_match(start_node->next,start_scale,
            model_codon_index,&best_Lvalue,&best_Lnode_addr,&best_Lscale);
        best_Lnode = (TREE_NODE *) best_Lnode_addr;

        /* and look above the starting node in the tree */
        find_higher_next_match(start_node->next,start_scale,
            model_codon_index,&best_Hvalue,&best_Hnode_addr,&best_Hscale);
        best_Hnode = (TREE_NODE *) best_Hnode_addr;

        if ((best_Lnode->codon_type != model[model_codon_index]) &&
            (best_Hnode->codon_type != model[model_codon_index]))
        {
            printf("can't match next codon!\n");
        }
        else {
            if (best_Lvalue > best_Hvalue) {
                plot_a_codon(best_Lnode,best_Lscale,PURPLE);
                (*match_value) += best_Lvalue;
                if (model_codon_index > 0)
                    match_next_codons(best_Lnode,best_Lscale,model_codon_index+1,
                                      &match_value);
            }
            else {
                plot_a_codon(best_Hnode,best_Hscale,PURPLE);
                (*match_value) += best_Hvalue;
                if (model_codon_index < no_model_elems-1)
                    match_next_codons(best_Hnode,best_Hscale,model_codon_index+1,
                                      &match_value);
            }
        }
    }
    else
        printf("can't find next codon in codon-tree!\n");
}

/* plot a codon from the codon tree */
plot_a_codon(node,scale,colour)
TREE_NODE *node;
int scale,colour;
{
    int Xoffset;
    int Yoffset2 = 0;
    int st,fi;
    int j;

    Xoffset = scale * (width + Xgap) + Xoffset1;
    st = node->codon_start;
    fi = node->codon_finish;
    current_colour = colour;
    moveto((int)(xsmooth[scale][st])+Xoffset,
           (int)(ysmooth[scale][st])+Yoffset+Yoffset2);
    for (j = st; j < fi; j++)
        lineto((int)(xsmooth[scale][j])+Xoffset,
               (int)(ysmooth[scale][j])+Yoffset+Yoffset2,1);
    box((int)(xsmooth[scale][st]+Xoffset),
        (int)(ysmooth[scale][st]+Yoffset+Yoffset2),4,current_colour);
    box((int)(xsmooth[scale][fi]+Xoffset),
        (int)(ysmooth[scale][fi]+Yoffset+Yoffset2),4,current_colour);
}

/* evaluate match between a model codon & a codon in the codon-tree */
float evaluate_match(model_codon_index,node)
int model_codon_index;
TREE_NODE *node;
{
    float l1,r1,c1,s1;
    float l2,r2,c2,s2;
    float t1,t2,t3,t4;
    float ratio();

    l1 = model_length[model_codon_index];
    r1 = model_round[model_codon_index];
    c1 = model_compact[model_codon_index];
    s1 = model_skew[model_codon_index];
    l2 = node->length;
    r2 = node->roundness;
    c2 = node->compactness;
    s2 = node->skew;

/***
printf("level: %d)  %3.2f %3.2f %3.2f %3.2f - %3.2f %3.2f %3.2f %3.2f\n",
nscale,l1,r1,c1,s1,l2,r2,c2,s2);
***/

    t1 = ratio(l1,l2);
    t2 = ratio(r1,r2);
    t3 = ratio(c1,c2);
    t4 = ratio(s1,s2);

/***
printf("ratios: %3.2f %3.2f %3.2f %3.2f  SUM: %3.2f\n",t1,t2,t3,t4,
t1+t2+t3+t4);
***/

    return(t1+t2+t3+t4);
}

/* return the ratio of a to b - make it < 1 & > -1 */
float ratio(a,b)
float a,b;
{
    int sign = 0;
    float r;

    /* major weakness is that it can't handle 0 */
    /* should use a better measure sometime */
    /* currently just hack it! */
    if (a == 0) a += 0.01;
    if (b == 0) b += 0.01;

    if (a < 0) {
        a = -a;
        sign++;
    }
    if (b < 0) {
        b = -b;
        sign++;
    }

    if (a < b)
        r = a/b;
    else
        r = b/a;

    if (sign == 1) r = -r;

    return(r);
}

/* HACK - I HAD TO RETURN THE ADDRESS OF THE BEST NODE RATHER THAN A
   POINTER. I COULDN'T GET THE THING TO WORK OTHERWISE!!
*/
/* find the best match to the major model (i.e. focus) codon */
find_focus_match(node,nscale,model_codon_index,best_value,best_node_addr,best_scale)
TREE_NODE *node;
int nscale;
int model_codon_index;
float *best_value;
long *best_node_addr;
int *best_scale;
{
    int i;
    int type;
    TREE_NODE *best_Cnode,*best_node_so_far;
    float best_Cvalue = -1;
    float best_value_so_far = -1;
    long best_Cnode_addr;
    int best_Cscale;
    int best_scale_so_far;
    float evaluate_match();

    if (node->codon_id == ROOT_NODE) {
        printf("\nfocussing matching on codon #%d = ",model_codon_index);
        print_codon(model[model_codon_index]);
        printf("\n");
    }

    /* evaluate the codon match at this node */
    /* ONLY TEMPORARY */
    *best_value = -1;
    if (node->codon_id != ROOT_NODE) {
        type = node->codon_type;
        if (type == model[model_codon_index]) {
        /***
            *best_value = 10 * nscale;
        ***/
            *best_value = evaluate_match(model_codon_index,node);
        }
        else
            *best_value = 0;
    }

    /* recursively find the best match of descendents */
    for (i = 0; i < node->no_codons; i++) {
        find_focus_match(node->codonChildren[i],
            nscale-1,model_codon_index,&best_Cvalue,&best_Cnode_addr,&best_Cscale);
        best_Cnode = (TREE_NODE *) best_Cnode_addr;
        if (best_Cvalue > best_value_so_far) {
            best_node_so_far = best_Cnode;
            best_value_so_far = best_Cvalue;
            best_scale_so_far = best_Cscale;
        }
    }

    /* propagate the best match upwards */
    if (best_value_so_far > *best_value) {
        *best_value = best_value_so_far;
        *best_node_addr = (long) best_node_so_far;
        *best_scale = best_scale_so_far;
    }
    else {
        *best_node_addr = (long) node;
        *best_scale = nscale;
    }
}

/* HACK - I HAD TO RETURN THE ADDRESS OF THE BEST NODE RATHER THAN A
   POINTER. I COULDN'T GET THE THING TO WORK OTHERWISE!!
*/
/* find the best adjacent left match lower down the codon-tree */
find_lower_prev_match(node,nscale,model_codon_index,best_value,best_node_addr,best_scale)
TREE_NODE *node;
int nscale;
int model_codon_index;
float *best_value;
long *best_node_addr;
int *best_scale;
{
    int type;
    float best_Cvalue = -2;
    long best_Cnode_addr;
    int best_Cscale;
    float evaluate_match();

    /* evaluate the codon match at this node */
    /* ONLY TEMPORARY */
    *best_value = -1;
    if (node != NULL) {
        type = node->codon_type;
        if (type == model[model_codon_index])
        /****
            *best_value = 10 * nscale;
        ****/
            *best_value = evaluate_match(model_codon_index,node);
        else
            *best_value = 0;

        /* recursively find the best match of descendents */
        if (node->no_codons > 0)
            find_lower_prev_match(node->codonChildren[node->no_codons-1],
                nscale-1,model_codon_index,&best_Cvalue,&best_Cnode_addr,&best_Cscale);

        /* propagate the best match upwards */
        if (best_Cvalue > *best_value) {
            *best_value = best_Cvalue;
            *best_node_addr = best_Cnode_addr;
            *best_scale = best_Cscale;
        }
        else {
            *best_node_addr = (long) node;
            *best_scale = nscale;
        }
    }
}

/* HACK - I HAD TO RETURN THE ADDRESS OF THE BEST NODE RATHER THAN A
   POINTER. I COULDN'T GET THE THING TO WORK OTHERWISE!!
*/
/* find the best adjacent left match lower down the codon-tree */
find_lower_next_match(node,nscale,model_codon_index,best_value,best_node_addr,best_scale)
TREE_NODE *node;
int nscale;
int model_codon_index;
float *best_value;
long *best_node_addr;
int *best_scale;
{
    int type;
    float best_Cvalue = -2;
    long best_Cnode_addr;
    int best_Cscale;
    float evaluate_match();

    /* evaluate the codon match at this node */
    /* ONLY TEMPORARY */
    *best_value = -1;
    if (node != NULL) {
        type = node->codon_type;
        if (type == model[model_codon_index])
            *best_value = evaluate_match(model_codon_index,node);
        /***
            *best_value = 10 * nscale;
        ***/
        else
            *best_value = 0;

        /* recursively find the best match of descendents */
        if (node->no_codons > 0)
            find_lower_prev_match(node->codonChildren[0],
                nscale-1,model_codon_index,&best_Cvalue,&best_Cnode_addr,&best_Cscale);

        /* propagate the best match upwards */
        if (best_Cvalue > *best_value) {
            *best_value = best_Cvalue;
            *best_node_addr = best_Cnode_addr;
            *best_scale = best_Cscale;
        }
        else {
            *best_node_addr = (long) node;
            *best_scale = nscale;
        }
    }
}

/* HACK - I HAD TO RETURN THE ADDRESS OF THE BEST NODE RATHER THAN A
   POINTER. I COULDN'T GET THE THING TO WORK OTHERWISE!!
*/
/* find the best adjacent previous match higher up the codon-tree */
find_higher_prev_match(node,nscale,model_codon_index,best_value,best_node_addr,best_scale)
TREE_NODE *node;
int nscale;
int model_codon_index;
float *best_value;
long *best_node_addr;
int *best_scale;
{
    int type;
    float best_Cvalue = -2;
    long best_Cnode_addr;
    int best_Cscale;
    TREE_NODE *parent,*uncle;
    float evaluate_match();

    /* evaluate the codon match at this node */
    /* ONLY TEMPORARY */
    *best_value = -1;
    nscale++;
    if (node != NULL) {
        parent = node->parent;
        if (parent != NULL) {
            /* check that the node is the last of its parent's children */
            if (parent->codonChildren[parent->no_codons-1] == node) {
                uncle = parent->prev;
                if ((uncle != NULL) && (uncle->codon_type == model[model_codon_index]))
                    *best_value = evaluate_match(model_codon_index,node);
                /***
                    *best_value = 100 / nscale;
                ***/
                else
                    *best_value = 0;

                /* recursively find the best match of descendents */
                if (node->no_codons > 0)
                    find_higher_prev_match(uncle,nscale,
                        model_codon_index,&best_Cvalue,&best_Cnode_addr,&best_Cscale);

                /* propagate the best match upwards */
                if (best_Cvalue > *best_value) {
                    *best_value = best_Cvalue;
                    *best_node_addr = best_Cnode_addr;
                    *best_scale = best_Cscale;
                }
                else {
                    *best_node_addr = (long) node;
                    *best_scale = nscale;
                }
        }
        }
    }
}

/* HACK - I HAD TO RETURN THE ADDRESS OF THE BEST NODE RATHER THAN A
   POINTER. I COULDN'T GET THE THING TO WORK OTHERWISE!!
*/
/* find the best adjacent next match higher up the codon-tree */
find_higher_next_match(node,nscale,model_codon_index,best_value,best_node_addr,best_scale)
TREE_NODE *node;
int nscale;
int model_codon_index;
float *best_value;
long *best_node_addr;
int *best_scale;
{
    int type;
    float best_Cvalue = -2;
    long best_Cnode_addr;
    int best_Cscale;
    TREE_NODE *parent;
    float evaluate_match();

    /* ONLY TEMPORARY evaluation */
    *best_value = -1;
    if (node != NULL) {
        parent = node->parent;
        if (parent != NULL) {
            /* check that the node is the first of its parent's children */
            /****** DOESN'T RESTRICT IT FOR THE MOMENT
            if ((parent->codonChildren[0] == node)
                || (parent->codon_id == ROOT_NODE)) {
            **************************************/ {
                type = node->codon_type;
                if (type == model[model_codon_index])
                    *best_value = evaluate_match(model_codon_index,node);
                /***
                    *best_value = 100 / nscale;
                ***/
                else
                    *best_value = 0;

                /* recursively find the best match of ancestors */
                find_higher_next_match(parent,nscale+1,
                    model_codon_index,&best_Cvalue,&best_Cnode_addr,&best_Cscale);

                /* propagate the best match upwards */
                if (best_Cvalue > *best_value) {
                    *best_value = best_Cvalue;
                    *best_node_addr = best_Cnode_addr;
                    *best_scale = best_Cscale;
                }
                else {
                    *best_node_addr = (long) node;
                    *best_scale = nscale;
                }
            }
        }
    }
}

/* traverse the codon-tree data structure */
/* generate attributes for all codons */
generate_codon_attributes(node,nscale)
TREE_NODE *node;
int nscale;
{
    int j;
    int st,fi;
    float length(),compactness(),roundness(),skew4();

    if (node->codon_id != ROOT_NODE) {
        st = node->codon_start;
        fi = node->codon_finish;

        node->length = length(st,fi,nscale);
        node->compactness = compactness(st,fi,nscale);
        node->roundness = roundness(st,fi,nscale);
        node->skew = skew4(st,fi,nscale);
    }

    /* recursively traverse lower level nodes */
    for (j = 0; j < node->no_codons; j++) {
        generate_codon_attributes(node->codonChildren[j],nscale-1);
    }
}

print_codon(c)
int c;
{
    switch(c) {
    case ZeroPlus:
        printf("0+ ");
        break;
    case ZeroMinus:
        printf("0- ");
        break;
    case OnePlus:
        printf("1+ ");
        break;
    case OneMinus:
        printf("1- ");
        break;
    case Two:
        printf("2  ");
        break;
    case Zero:
        printf("Z  ");
        break;
    case APlus:
        printf("A+ ");
        break;
    case AMinus:
        printf("A- ");
        break;
    case BPlus:
        printf("B+ ");
        break;
    case BMinus:
        printf("B- ");
        break;
    case C:
        printf("C  ");
        break;
    case DPlus:
        printf("D+ ");
        break;
    case DMinus:
        printf("D- ");
        break;
    case ZeroA:
        printf("0a ");
        break;
    case OneA:
        printf("1a ");
        break;
    case OneB:
        printf("1b ");
        break;
    case OneC:
        printf("1c ");
        break;
    case TwoA:
        printf("2a ");
        break;
    case TwoB:
        printf("2b ");
        break;
    case TwoC:
        printf("2c ");
        break;
    case TwoD:
        printf("2d ");
        break;
    case Ea:
        printf("Ea ");
        break;
    case Eb:
        printf("Eb ");
        break;
    case Ec:
        printf("Ec ");
        break;
    case Ed:
        printf("Ed ");
        break;
    case Fa:
        printf("Fa ");
        break;
    case Fb:
        printf("Fb ");
        break;
    case Fc:
        printf("Fc ");
        break;
    case Fd:
        printf("Fd ");
        break;
    case Fe:
        printf("Fe ");
        break;
    case Ff:
        printf("Ff ");
        break;
    case Fg:
        printf("Fg ");
        break;
    case Error:
        printf("?  ");
        break;
    default:
        printf("?##? ");
        break;
    }
}

print_flag(f)
int f;
{
    switch(f) {
    case PosMax:
        printf("Mx+ ");
        break;
    case NegMax:
        printf("Mx- ");
        break;
    case PosMin:
        printf("Mn+ ");
        break;
    case NegMin:
        printf("Mn- ");
        break;
    case StartZero:
        printf("SZ ");
        break;
    case EndZero:
        printf("EZ ");
        break;
    case PosEnd:
        printf("E+ ");
        break;
    case NegEnd:
        printf("E- ");
        break;
    default:
        printf("? ");
        break;
    }
}

/* plot labels of codons */
plot_codons_labels(nscale,Xoffset,Yoffset)
int nscale,Xoffset,Yoffset;
{
    int t;
    int inc = 0;
    int xo;
    int p1,p2,mid_p;
    int x_inc = 10;
    int y_inc = -2;
    char text[10];

    for (t = 0; t < no_codons[nscale]; t++) {
        xo = Xoffset + (10*inc);

        /* setup the codon label */
        switch(codons[nscale][t]) {
        case ZeroPlus:
            sprintf(text,"0+");
            break;
        case ZeroMinus:
            sprintf(text,"0-");
            break;
        case OnePlus:
            sprintf(text,"1+");
            break;
        case OneMinus:
            sprintf(text,"1-");
            break;
        case Two:
            sprintf(text,"2");
            break;
        case Zero:
            sprintf(text,"Z");
            break;
        case APlus:
            sprintf(text,"A+");
            break;
        case AMinus:
            sprintf(text,"A-");
            break;
        case BPlus:
            sprintf(text,"B+");
            break;
        case BMinus:
            sprintf(text,"B-");
            break;
        case C:
            sprintf(text,"C");
            break;
        case DPlus:
            sprintf(text,"D+");
            break;
        case DMinus:
            sprintf(text,"D-");
            break;
        case ZeroA:
            sprintf(text,"0a");
            break;
        case OneA:
            sprintf(text,"1a");
            break;
        case OneB:
            sprintf(text,"1b");
            break;
        case OneC:
            sprintf(text,"1c");
            break;
        case TwoA:
            sprintf(text,"2a");
            break;
        case TwoB:
            sprintf(text,"2b");
            break;
        case TwoC:
            sprintf(text,"2c");
            break;
        case TwoD:
            sprintf(text,"2d");
            break;
        case Ea:
            sprintf(text,"Ea");
            break;
        case Eb:
            sprintf(text,"Eb");
            break;
        case Ec:
            sprintf(text,"Ec");
            break;
        case Ed:
            sprintf(text,"Ed");
            break;
        case Fa:
            sprintf(text,"Fa");
            break;
        case Fb:
            sprintf(text,"Fb");
            break;
        case Fc:
            sprintf(text,"Fc");
            break;
        case Fd:
            sprintf(text,"2d");
            break;
        case Fe:
            sprintf(text,"Fe");
            break;
        case Ff:
            sprintf(text,"Ff");
            break;
        case Fg:
            sprintf(text,"Fg");
            break;
        case Error:
            sprintf(text,"?");
            break;
        }

        /* plot the codon label */
        switch(codons[nscale][t]) {
        case ZeroPlus: case ZeroMinus: case OnePlus: case OneMinus:
        case Two: case APlus: case AMinus: case BPlus: case BMinus:
        case C: case ZeroA: case OneA: case OneB: case TwoA: case TwoB:
        case Ea: case Eb: case Fa: case Fb: case Fc: case Fd: case Fe:
        case Error:
            outtextxy(
               (int)(xsmooth[nscale][flags2_pos[nscale][codons_pos[nscale][t]]])+x_inc+xo,
               (int)(ysmooth[nscale][flags2_pos[nscale][codons_pos[nscale][t]]])+y_inc+Yoffset,
               text);
            break;
        case Zero: case DPlus: case DMinus: case OneC: case TwoC:
        case TwoD: case Ec: case Ed:
        case Ff: case Fg:
            p1 = flags2_pos[nscale][codons_pos[nscale][t]];
            p2 = flags2_pos[nscale][codons_pos[nscale][t]+1];
            mid_p = (p1 + p2) / 2;
            outtextxy(
               (int)(xsmooth[nscale][mid_p])+x_inc+xo,
               (int)(ysmooth[nscale][mid_p])+y_inc+Yoffset,
               text);
            break;
        }
    }
}

/* plot endpoints of codons */
plot_codons_ends(nscale,Xoffset,Yoffset)
int nscale,Xoffset,Yoffset;
{
    int j,t;

    for (t = 0; t < no_codons[nscale]; t++) {
        switch(codons[nscale][t]) {
        case ZeroPlus: case ZeroMinus: case OnePlus: case OneMinus:
        case Two: case APlus: case AMinus: case BPlus: case BMinus:
        case C: case ZeroA: case OneA: case OneB: case TwoA: case TwoB:
        case Ea: case Eb: case Fa: case Fb: case Fc: case Fd: case Fe:
            j = flags2_pos[nscale][codons_pos[nscale][t]-1];
            box((int)(xsmooth[nscale][j]+Xoffset),
                (int)(ysmooth[nscale][j]+Yoffset),2,GREEN);
            break;
        case Zero: case DPlus: case DMinus: case OneC: case TwoC:
        case TwoD: case Ec: case Ed:
        case Ff: case Fg:
            j = flags2_pos[nscale][codons_pos[nscale][t]];
            box((int)(xsmooth[nscale][j]+Xoffset),
                (int)(ysmooth[nscale][j]+Yoffset),2,GREEN);
            break;
        case Error:
            break;
        }
    }
    if (!closed_loop) {
        j = flags2_pos[nscale][codons_pos[nscale][t-1]+1];
        box((int)(xsmooth[nscale][j]+Xoffset),(int)(ysmooth[nscale][j]+Yoffset),2,GREEN);
    }
}

float calc_diff(s,f)
int s,f;
{
    int i;
    float ytmps[50],diffs[50],m;
    float diff;
    float tmp;

    m = (float)(num_curv_zeros[f] - num_curv_zeros[s]) / (float)(f-s);

    for (i=s;i<=f;i++) 
        ytmps[i] = m * (i - s) + num_curv_zeros[s];

    diff = 0;
    for (i=s;i<f;i++) {
        tmp = 1*(num_curv_zeros[i+1]+num_curv_zeros[i]-ytmps[i+1]-ytmps[i])/2;
        printf("%2.2f  ",tmp);
        tmp = fabs(tmp);
        diff += tmp;
    }
    printf("\n");

    printf("diff from %d -> %d: %f\n",s,f,diff);

    return(diff);
}

print_usage(progname)
char *progname;
{
    printf("ERROR: require input filename\n");
    printf("usage: %s -i infile [options]\n",progname);
    printf(" -m file    match model\n");
    printf(" -p file    dump postscript\n");
    printf(" -t         plot links of codon tree\n");
    printf(" -a         use ambiguity rather than normalised zero-crossings\n");
    exit(-1);
}

read_model_data(file_name)
char file_name[];
{
    FILE *fp;
    int i = 0;
    char str[10];

    if ((fp=fopen(file_name,"r")) == NULL) {
        printf("cant open %s\n",file_name);
        exit(-1);
    }
    longest_model_codon = 0;
    while (fscanf(fp,"%s",str) != EOF) {
        if (!strcmp(str,"0+"))
               model[i] = ZeroPlus;
        else if (!strcmp(str,"0-"))
               model[i] = ZeroMinus;
        else if (!strcmp(str,"1+"))
               model[i] = OnePlus;
        else if (!strcmp(str,"1-"))
               model[i] = OneMinus;
        else if (!strcmp(str,"2"))
               model[i] = Two;
        else if (!strcmp(str,"Z"))
               model[i] = Zero;
        else if (!strcmp(str,"A+"))
               model[i] = APlus;
        else if (!strcmp(str,"A-"))
               model[i] = AMinus;
        else if (!strcmp(str,"B+"))
               model[i] = BPlus;
        else if (!strcmp(str,"B-"))
               model[i] = BMinus;
        else if (!strcmp(str,"C-"))
               model[i] = C;
        else if (!strcmp(str,"D+"))
               model[i] = DPlus;
        else if (!strcmp(str,"D-"))
               model[i] = DMinus;
        else if (!strcmp(str,"0a"))
               model[i] = ZeroA;
        else if (!strcmp(str,"1a"))
               model[i] = OneA;
        else if (!strcmp(str,"1b"))
               model[i] = OneB;
        else if (!strcmp(str,"1c"))
               model[i] = OneC;
        else if (!strcmp(str,"2a"))
               model[i] = TwoA;
        else if (!strcmp(str,"2b"))
               model[i] = TwoB;
        else if (!strcmp(str,"2c"))
               model[i] = TwoC;
        else if (!strcmp(str,"2d"))
               model[i] = TwoD;
        else
            printf("ERROR: in reading <%s> codon model\n",str);
        fscanf(fp,"%f %f %f %f",&model_length[i],&model_round[i],
            &model_compact[i],&model_skew[i]);
        if (model_length[i] > model_length[longest_model_codon])
            longest_model_codon = i;
       i++;
    }
    no_model_elems = i;
    fclose(fp);
}

int strcmp(s,t)
char s[],t[];
{
    int i;

    i = 0;
    while(s[i] == t[i])
        if (s[i++] == '\0')
            return(0);
    return(s[i] - t[i]);
}

read_link_data(file_name)
char file_name[];
{
    FILE *fopen(), *fp;
    char file_type[50];
    char dumstring[50];
    int j;
    int xd,yd;

    if ((fp=fopen(file_name,"r")) == NULL) {
        printf("cant open %s\n",file_name);
        exit(-1);
    }
    /* read magic word for format of file */
    fscanf(fp,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if (j != 0) {
        printf("not pixel data file - aborting\n");
        exit();
    }
    fscanf(fp,"%s %d\n",dumstring,&j);
    j = -1;
    do{
       j++;
       fscanf(fp,"%d %d\n",&x[j],&y[j]);
    } while(x[j] != -1);
    no_pixels = j;
    fclose(fp);
    xd = abs(x[0] - x[j-1]);
    yd = abs(y[0] - y[j-1]);
    closed_loop = ((xd <= 1) && (yd <= 1));
}

plot_link_data()
{
    int i;

    moveto(x[0],y[0]);
    for (i = 0; i < no_pixels-1; i++)
       lineto(x[i+1],y[i+1],0);
}

double gaussian(sigma,t)
double sigma;
int t;
{
    double g;

    g = exp(-(t*t)/(2*sigma*sigma)) / (sigma * sqrt(2*PI));

    return(g);
}

/* first derivative */
double gaussian1(sigma,t)
double sigma;
int t;
{
    double g;

    g = exp(-(t*t)/(2*sigma*sigma)) * (-t)
        / (sigma * sigma * sigma * sqrt(2*PI));

    return(g);
}

/* second derivative */
double gaussian2(sigma,t)
double sigma;
int t;
{
    double g;

    g = exp(-(t*t)/(2*sigma*sigma)) * (t*t/(sigma*sigma)-1)
        / (sigma * sigma * sigma * sqrt(2*PI));

    return(g);
}

float angle(x1,y1,x2,y2)
float x1,y1,x2,y2;
{

    float angle_temp;
    float xx,yy;

    xx = x2 - x1;
    yy = y2 - y1;
    if (xx == 0.0)
        angle_temp = PI/2.0;
    else
        angle_temp = atan(fabs(yy/xx));
    if ((xx < 0.0) && (yy >= 0.0))
       angle_temp = PI - angle_temp;
    else if ((xx < 0.0) && (yy < 0.0))
       angle_temp = PI + angle_temp;
    else if ((xx >= 0.0) && ( yy < 0.0))
       angle_temp = PI*2.0 - angle_temp;
    return(angle_temp);
}

do_smoothing1(sigma)
double sigma;
{
    int j,t;
    double sum = 0.0;
    double sum_p = 0.0;
    double sum_n = 0.0;
    int point;
    float xG1,yG1,xG2,yG2;
    int xpoint,ypoint;
    float dist;
    float shrink_correct();
    float k_now;
    int count;
    int negative,positive,zero;

    masksize = 5 * sigma;
    if ((masksize % 2) == 0) masksize++;
    if (masksize >= MAX_WIN) masksize = MAX_WIN-1;
    if (masksize >= 2*no_pixels) {
        masksize = 2*no_pixels-1;
        printf("truncated masksize due to lack of pixel data!\n");
    }
    halfmask = masksize / 2;
    store_halfmasks[index] = halfmask;
    store_masks[index] = masksize;

    if (closed_loop) {
        wraparound_data(halfmask);
    }
    else {
        extend_data(halfmask,FINISH);
        extend_data(halfmask,START);
    }

    /* generate masks for Gaussians & derivatives */
    for (t = -halfmask; t <= halfmask; t++)
        G[halfmask+t] = gaussian(sigma,t);
    for (t = 0; t < masksize; t++) sum += G[t];
    for (t = 0; t < masksize; t++) G[t] /= sum;

    for (t = -halfmask; t <= halfmask; t++)
        G1[halfmask+t] = gaussian1(sigma,t);

    for (t = -halfmask; t <= halfmask; t++)
        G2[halfmask+t] = gaussian2(sigma,t);

    for (t = 0; t < masksize; t++)
        if (G2[t] > 0)
            sum_p += G2[t];
        else
            sum_n -= G2[t];
    for (t = 0; t < masksize; t++)
        if (G2[t] < 0)
            G2[t] = G2[t]*sum_p/sum_n;

    /* generate shrinkage correction table */
    make_cor_table(sigma);

    energy[index] = 0;
    for (t = 0; t < no_pixels-masksize; t++) {
        xG1 = yG1 = xG2 = yG2 = 0;
        for (j = 0; j < masksize; j++) {
            xpoint = x[t+j];
            ypoint = y[t+j];
            xG1 += (G1[j]*xpoint);
            yG1 += (G1[j]*ypoint);
            xG2 += (G2[j]*xpoint);
            yG2 += (G2[j]*ypoint);
        }
        dist = sqrt(SQR(xG1)+SQR(yG1));
        point = t + halfmask;
        curvature[index][point] = ((xG1*yG2)-(yG1*xG2))/CUBE(dist);
        energy[index] += curvature[0][point] * curvature[index][point];
    }

    count = 0;

    /* zeros of curvature */
    negative = positive = FALSE;
    for (t = 1; t < no_pixels-masksize-1; t++) {
       k_now = curvature[index][t+halfmask];
       zero = FALSE;
       if (k_now > 0) {
          positive = TRUE;
          if (negative) zero = TRUE;
          negative = FALSE;
       }
       if (k_now < 0) {
          negative = TRUE;
          if (positive) zero = TRUE;
          positive = FALSE;
       }
       if (zero) {
           count++;
       }
    }
    num_curv_zeros[index] = count;
    num_curv_zeros[index] *= sigma;
}

/* do smoothing and also codon stuff */
do_smoothing2(nscale,sigma)
int nscale;
double sigma;
{
    int j,t;
    double sum = 0.0;
    double sum_p = 0.0;
    double sum_n = 0.0;
    int point;
    float xG,yG,xG1,yG1,xG2,yG2;
    int xpoint,ypoint;
    float dist;
    float shrink_correct();
    float k_prev,k_now,k_next;
    int decreasing,increasing,extrema;
    int negative,positive,zero;
    int lgth_zero;

    masksize = 5 * sigma;
    if ((masksize % 2) == 0) masksize++;
    if (masksize >= MAX_WIN) masksize = MAX_WIN-1;
    if (masksize >= 2*no_pixels) {
        masksize = 2*no_pixels-1;
        printf("truncated masksize due to lack of pixel data!\n");
    }
    halfmask = masksize / 2;

    if (closed_loop) {
        wraparound_data(halfmask);
    }
    else {
        extend_data(halfmask,FINISH);
        extend_data(halfmask,START);
    }
    start_pixel[nscale] = halfmask;
    finish_pixel[nscale] = no_pixels - masksize + halfmask;

    /* generate masks for Gaussians & derivatives */
    for (t = -halfmask; t <= halfmask; t++)
        G[halfmask+t] = gaussian(sigma,t);
    for (t = 0; t < masksize; t++) sum += G[t];
    for (t = 0; t < masksize; t++) G[t] /= sum;

    for (t = -halfmask; t <= halfmask; t++)
        G1[halfmask+t] = gaussian1(sigma,t);

    for (t = -halfmask; t <= halfmask; t++)
        G2[halfmask+t] = gaussian2(sigma,t);

    for (t = 0; t < masksize; t++)
        if (G2[t] > 0)
            sum_p += G2[t];
        else
            sum_n -= G2[t];
    for (t = 0; t < masksize; t++)
        if (G2[t] < 0)
            G2[t] = G2[t]*sum_p/sum_n;

    /* generate shrinkage correction table */
    make_cor_table(sigma);

    for (t = 0; t < no_pixels-masksize; t++) {
        xG = yG = xG1 = yG1 = xG2 = yG2 = 0;
        for (j = 0; j < masksize; j++) {
            xpoint = x[t+j];
            ypoint = y[t+j];
            xG += (G[j]*xpoint);
            yG += (G[j]*ypoint);
            xG1 += (G1[j]*xpoint);
            yG1 += (G1[j]*ypoint);
            xG2 += (G2[j]*xpoint);
            yG2 += (G2[j]*ypoint);
        }
        dist = sqrt(SQR(xG1)+SQR(yG1));
        point = t + halfmask;
        xsmooth[nscale][point] = shrink_correct(sigma,xG,xG2);
        ysmooth[nscale][point] = shrink_correct(sigma,yG,yG2);
        curvature[nscale][point] = ((xG1*yG2)-(yG1*xG2))/CUBE(dist);
    }

    /* extrema of curvature */
    k_prev = curvature[nscale][halfmask-1];
    k_now =  curvature[nscale][halfmask];
    k_next = curvature[nscale][halfmask+1];
    increasing = decreasing = FALSE;
    flags[halfmask] = 0;
    for (t = 1; t < no_pixels-masksize-1; t++) {
       k_prev = k_now;
       k_now = k_next;
       k_next = curvature[nscale][t+halfmask+1];
       flags[t+halfmask] = 0;
       extrema = FALSE;
       if (k_now > k_prev) {
          increasing = TRUE;
          if (decreasing) extrema = TRUE;
          decreasing = FALSE;
          if (extrema)
            /* position of extrema detection lags by one */
            if (k_prev > 0)
                flags[t+halfmask] = PosMin;
            else
                flags[t+halfmask] = NegMin;
       }
       if (k_now < k_prev) {
          decreasing = TRUE;
          if (increasing) extrema = TRUE;
          increasing = FALSE;
          if (extrema)
            if (k_prev > 0)
                flags[t+halfmask] = PosMax;
            else
                flags[t+halfmask] = NegMax;
       }
    }

    /* zeros of curvature */
    negative = positive = FALSE;
    for (t = 1; t < no_pixels-masksize-1; t++) {
       k_now = curvature[nscale][t+halfmask];
       zero = FALSE;
       if (k_now > 0) {
          positive = TRUE;
          if (negative) zero = TRUE;
          negative = FALSE;
       }
       if (k_now < 0) {
          negative = TRUE;
          if (positive) zero = TRUE;
          positive = FALSE;
       }
    }

    /* sections of zero curvature */
    zero = FALSE;
    lgth_zero = 0;
    for (t = 1; t < no_pixels-masksize-1; t++) {
       k_now = fabs(curvature[nscale][t+halfmask]);
       if (k_now < MIN_K) {
            zero = TRUE;
            lgth_zero++;
       }
       else {
            if ((zero) && (lgth_zero > MIN_LENGTH)) {
                  flags[t+halfmask-lgth_zero] = StartZero;
                  flags[t+halfmask] = EndZero;
                /* remove any intermediate zero-crossing flags */
                for (j = t+halfmask-lgth_zero+1; j < t+halfmask; j++)
                    flags[j] = 0;
            }
            zero = FALSE;
            lgth_zero = 0;
       }
    }
}

/* parse a list of curvature flags into codon labels */
determine_codons(nscale,sigma)
int nscale;
float sigma;
{
    if (closed_loop)
        determine_codons_closed(nscale,sigma);
    else
        determine_codons_open(nscale,sigma);
}

/* parse an open list of curvature flags into codon labels */
determine_codons_open(nscale,sigma)
int nscale;
float sigma;
{
    int i,j,k,t;
    int codon;
    int first_flag,last_flag;

    masksize = 5 * sigma;
    if ((masksize % 2) == 0) masksize++;
    if (masksize >= MAX_WIN) masksize = MAX_WIN-1;
    halfmask = masksize / 2;

    /* copy & squeeze curvature flags from "flags" into "flags2" */
    no_flags = 0;
    t = 0;
    /* add flag for start of open curve */
    if (curvature[nscale][t+halfmask] > MIN_K) {
        flags2[no_flags] = PosEnd;
        no_flags++;
    }
    else if (curvature[nscale][t+halfmask] < -MIN_K) {
        flags2[no_flags] = NegEnd;
        no_flags++;
    }
    /* curve starts with zero curvature */
    else {
        /* find first flag */
        j = 0;
        while ((j < no_pixels-masksize-1) && (flags[j+halfmask] == 0))
            j++;
        first_flag = flags[j+halfmask];
        /* do nothing if SZ has already been added */
        if (first_flag != StartZero) {
            if (curvature[nscale][t+halfmask] > 0.0)
                flags2[no_flags] = PosEnd;
            else
                flags2[no_flags] = NegEnd;
            no_flags++;
        }
    }
    flags2_pos[nscale][no_flags-1] = t+halfmask;
    for (; t < no_pixels-masksize-1; t++)
        if (flags[t+halfmask] != 0) {
            flags2[no_flags] = flags[t+halfmask];
            flags2_pos[nscale][no_flags] = t + halfmask;
            no_flags++;
        }
    /* add flag for end of open curve */
    if (curvature[nscale][t+halfmask] > MIN_K) {
        flags2[no_flags] = PosEnd;
        no_flags++;
    }
    else if (curvature[nscale][t+halfmask] < -MIN_K) {
        flags2[no_flags] = NegEnd;
        no_flags++;
    }
    /* curve ends with zero curvature */
    else {
        /* find last flag */
        j = no_pixels-masksize-1;
        while ((j > 0) && (flags[j+halfmask] == 0))
            j--;
        last_flag = flags[j+halfmask];
        /* do nothing if EZ has already been added */
        if (last_flag != EndZero) {
            if (curvature[nscale][t+halfmask] > 0.0)
                flags2[no_flags] = PosEnd;
            else
                flags2[no_flags] = NegEnd;
            no_flags++;
        }
    }
    flags2_pos[nscale][no_flags-1] = t+halfmask;

    /* print curvature flags */
    /*****************
    for (t = 0; t < no_flags; t++)
        print_flag(flags2[t]);
    printf("\n");
    *****************/

    /* initialise codon area */
    for (t = 0; t < no_flags; t++) codons[nscale][t] = 0;
    no_codons[nscale] = 0;
    printf("codons: ");

    t = 1;
    i = flags2[t-1];
    j = flags2[t];
    k = flags2[t+1];
    /* parse codon at start of open curve */
    if ((i == NegEnd) && (j == NegMax) && (k == NegMin)) {
        codon = ZeroA;
        t += 2;
    }
    else if ((i == NegEnd) && (j == PosMax) && (k == PosMin)) {
        codon = OneA;
        t += 2;
    }
    else if ((i == PosEnd) && (j == PosMax) && (k == PosMin)) {
        codon = OneB;
        t += 2;
    }
    else if ((i == PosEnd) && (j == PosMin)) {
        codon = OneC;
        t++;
    }
    else if ((i == NegEnd) && (j == PosMax) && (k == NegMin)) {
        codon = TwoA;
        t += 2;
    }
    else if ((i == PosEnd) && (j == PosMax) && (k == NegMin)) {
        codon = TwoB;
        t += 2;
    }
    else if ((i == PosEnd) && (j == NegMin)) {
        codon = TwoC;
        t++;
    }
    else if ((i == NegEnd) && (j == NegMin)) {
        codon = TwoD;
        t++;
    }
    else if ((i == PosEnd) && (j == PosMax) && (k == StartZero)) {
        codon = Ea;
        t += 2;
    }
    else if ((i == NegEnd) && (j == PosMax) && (k == StartZero)) {
        codon = Eb;
        t += 2;
    }
    else if ((i == PosEnd) && (j == StartZero)) {
        codon = Ec;
        t++;
    }
    else if ((i == NegEnd) && (j == StartZero)) {
        codon = Ed;
        t++;
    }
    else if ((i == PosEnd) && (j == PosMax) && (k == PosEnd)) {
        codon = Fa;
        t += 2;
    }
    else if ((i == PosEnd) && (j == PosMax) && (k == NegEnd)) {
        codon = Fb;
        t += 2;
    }
    else if ((i == NegEnd) && (j == PosMax) && (k == PosEnd)) {
        codon = Fc;
        t += 2;
    }
    else if ((i == NegEnd) && (j == PosMax) && (k == NegEnd)) {
        codon = Fd;
        t += 2;
    }
    else if ((i == NegEnd) && (j == NegMax) && (k == NegEnd)) {
        codon = Fe;
        t += 2;
    }
    else if ((i == PosEnd) && (j == PosEnd)) {
        codon = Ff;
        t++;
    }
    else if ((i == NegEnd) && (j == NegEnd)) {
        codon = Fg;
        t++;
    }
    else if ((i == StartZero) && (j == EndZero)) {
        codon = Zero;
        t++;
    }
    else
        codon = Error;
    /* store codon */
    codons[nscale][no_codons[nscale]] = codon;
    codons_pos[nscale][no_codons[nscale]] = t-2;
    no_codons[nscale]++;
    print_codon(codon);

    /* skip further processing if whole curve is represented by 1 codon */
    if ((codon != Fa) && (codon != Fb) && (codon != Fc) &&
        (codon != Fd) && (codon != Fe) && (codon != Ff) && (codon != Fg)) {
    for (; t < no_flags; t += 2) {
            i = flags2[t-1];
            j = flags2[t];
            k = flags2[t+1];

            /* check for the extended codon set first */
            if ((i == PosMin) && (j == PosMax) && (k == StartZero))
                codon = APlus;
            else if ((i == EndZero) && (j == PosMax) && (k == PosMin))
                codon = AMinus;
            else if ((i == NegMin) && (j == PosMax) && (k == StartZero))
                codon = BPlus;
            else if ((i == EndZero) && (j == PosMax) && (k == NegMin))
                codon = BMinus;
            else if ((i == EndZero) && (j == PosMax) && (k == StartZero))
                codon = C;
            else if ((i == StartZero) && (j == EndZero)) {
                codon = Zero;
                t--;    /* zeros only require 2 flags not 3, so step back 1 */
            }
            else if ((i == NegMin) && (j == StartZero)) {
                codon = DPlus;
                t--;    /* D+ only requires 2 flags not 3, so step back 1 */
            }
            else if ((i == EndZero) && (j == NegMin)) {
                codon = DMinus;
                t--;    /* D- only requires 2 flags not 3, so step back 1 */
            }

            /* parse codon at end of open curve */
            else if ((i == NegMin) && (j == NegMax) && (k == NegEnd))
                codon = ZeroA;
            else if ((i == PosMin) && (j == PosMax) && (k == NegEnd))
                codon = OneA;
            else if ((i == PosMin) && (j == PosMax) && (k == PosEnd))
                codon = OneB;
            else if ((i == PosMin) && (j == PosEnd)) {
                codon = OneB;
                t--;
            }
            else if ((i == NegMin) && (j == PosMax) && (k == NegEnd))
                codon = TwoA;
            else if ((i == NegMin) && (j == PosMax) && (k == PosEnd))
                codon = TwoB;
            else if ((i == NegMin) && (j == PosEnd)) {
                codon = TwoC;
                t--;
            }
            else if ((i == NegMin) && (j == NegEnd)) {
                codon = TwoD;
                t--;
            }
            else if ((i == EndZero) && (j == PosMax) && (k == PosEnd)) {
                codon = Ea;
            }
            else if ((i == EndZero) && (j == PosMax) && (k == NegEnd)) {
                codon = Eb;
            }
            else if ((i == EndZero) && (j == PosEnd)) {
                codon = Ec;
                t--;
            }
            else if ((i == EndZero) && (j == NegEnd)) {
                codon = Ed;
                t--;
            }
            else if ((i == StartZero) && (j == EndZero)) {
                codon = Zero;
                t--;
            }

            /* now check for the standard 5 codons */
            else if (i == NegMin)
                if (j == NegMax)
                    if (k == NegMin)
                        codon = ZeroMinus;
                    else
                        codon = Error;
                else if (j == PosMax)
                    if (k == NegMin)
                        codon = Two;
                    else if (k == PosMin)
                        codon = OneMinus;
                    else
                        codon = Error;
                else
                    codon = Error;
            else if (i == PosMin)
                if (j == PosMax)
                    if (k == NegMin)
                        codon = OnePlus;
                    else if (k == PosMin)
                        codon = ZeroPlus;
                    else
                        codon = Error;
                else
                    codon = Error;
            else
                codon = Error;

            /* store codon */
            codons[nscale][no_codons[nscale]] = codon;
            codons_pos[nscale][no_codons[nscale]] = t;
            no_codons[nscale]++;
            print_codon(codon);
        }
    }

    printf("\n");
}

/* parse a closed list of curvature flags into codon labels */
determine_codons_closed(nscale,sigma)
int nscale;
float sigma;
{
    int i,j,k,t;
    int codon;
    int first_flag = TRUE;
    int first_flag_pos;

    masksize = 5 * sigma;
    if ((masksize % 2) == 0) masksize++;
    if (masksize >= MAX_WIN) masksize = MAX_WIN-1;
    halfmask = masksize / 2;

    /* copy & squeeze curvature flags from "flags" into "flags2" */
    no_flags = 0;
    t = 0;
    for (; t < no_pixels-masksize-1; t++)
        if (flags[t+halfmask] != 0) {
            flags2[no_flags] = flags[t+halfmask];
            flags2_pos[nscale][no_flags] = t + halfmask;
            if (first_flag) {
                first_flag = FALSE;
                first_flag_pos = t + halfmask;
            }
            no_flags++;
        }

    /* print curvature flags */
    /*****************
    for (t = 0; t < no_flags; t++)
        print_flag(flags2[t]);
    printf("\n");
    *****************/

    /* initialise codon area */
    for (t = 0; t < no_flags; t++) codons[nscale][t] = 0;
    no_codons[nscale] = 0;
    printf("codons: ");

    t = 0;

    /* don't start on a maximum */
    if ((flags2[t] == PosMax) || (flags2[t] == NegMax)) {
        if (flags2[no_flags-1] != flags2[t]) {
            flags2[no_flags] = flags2[t];
            flags2_pos[nscale][no_flags] = first_flag_pos;
            no_flags++;
        }
        t++;
    }

    /* !!!!! SHOULD CHANGE THIS SOMETIME !!!!! */
    if (flags2[t] != flags2[no_flags-1]) {
        flags2[no_flags] = flags2[t];
        flags2_pos[nscale][no_flags] = t;    /* !! WRONG !! */
        no_flags++;
    }

    t++;

    for (; t < no_flags; t += 2) {
        i = flags2[t-1];
        j = flags2[t];
        k = flags2[t+1];

        /* check for the extended codon set first */
        if ((i == PosMin) && (j == PosMax) && (k == StartZero))
            codon = APlus;
        else if ((i == EndZero) && (j == PosMax) && (k == PosMin))
            codon = AMinus;
        else if ((i == NegMin) && (j == PosMax) && (k == StartZero))
            codon = BPlus;
        else if ((i == EndZero) && (j == PosMax) && (k == NegMin))
            codon = BMinus;
        else if ((i == EndZero) && (j == PosMax) && (k == StartZero))
            codon = C;
        else if ((i == StartZero) && (j == EndZero)) {
            codon = Zero;
            t--;    /* zeros only require 2 flags not 3, so step back 1 */
        }
        else if ((i == NegMin) && (j == StartZero)) {
            codon = DPlus;
            t--;    /* D+ only requires 2 flags not 3, so step back 1 */
        }
        else if ((i == EndZero) && (j == NegMin)) {
            codon = DMinus;
            t--;    /* D- only requires 2 flags not 3, so step back 1 */
        }
        /* now check for the standard 5 codons */
        else if (i == NegMin)
            if (j == NegMax)
                if (k == NegMin)
                    codon = ZeroMinus;
                else
                    codon = Error;
            else if (j == PosMax)
                if (k == NegMin)
                    codon = Two;
                else if (k == PosMin)
                    codon = OneMinus;
                else
                    codon = Error;
            else
                codon = Error;
        else if (i == PosMin)
            if (j == PosMax)
                if (k == NegMin)
                    codon = OnePlus;
                else if (k == PosMin)
                    codon = ZeroPlus;
                else
                    codon = Error;
            else
                codon = Error;
        else
            codon = Error;

        /* store codon */
        codons[nscale][no_codons[nscale]] = codon;
        codons_pos[nscale][no_codons[nscale]] = t;
        no_codons[nscale]++;
        print_codon(codon);
    }

    printf("\n");
}

/* test the various attributes */
test_attributes()
{
    int i,j,t1,t2;
    int nscale = 0;
    float s1,s2,s3,s4;
    int Xoffset;

    current_colour = GREEN;

    printf("test skew measures\n");
    do {
        printf("input a scale (-1 to terminate) and codon offset: ");
        scanf("%d %d",&nscale,&i);
        if (nscale < 0) ;
        else if (i >= no_codons[nscale]) {
            printf("ERROR: codon offset too big\n"); 
        }
        else {
            t1 = flags2_pos[nscale][codons_pos[nscale][i]-1];
            t2 = flags2_pos[nscale][codons_pos[nscale][i]+1];
            Xoffset = nscale * (width + Xgap) + Xoffset1;
            moveto((int)(xsmooth[nscale][t1])+Xoffset,
                   (int)(ysmooth[nscale][t1])+Yoffset);
            for (j = t1; j < t2; j++)
                lineto((int)(xsmooth[nscale][j])+Xoffset,
                       (int)(ysmooth[nscale][j])+Yoffset,0);

            print_codon(codons[nscale][i]);
            printf(" L %2.2f C %2.2f R %2.2f S %2.2f\n",
                length(t1,t2,nscale),
                compactness(t1,t2,nscale),
                roundness(t1,t2,nscale),
                skew4(t1,t2,nscale));
        }
    } while (nscale >= 0);
    printf("finished testing skew measures\n");
}

/* test the various skew measures */
test_skews()
{
    int i,j,t1,t2;
    int nscale = 0;
    float skew1(),skew2(),skew3(),skew4();
    float s1,s2,s3,s4;
    int Xoffset;

    current_colour = GREEN;

    printf("test skew measures\n");
    do {
        printf("input a scale (-1 to terminate) and codon offset: ");
        scanf("%d %d",&nscale,&i);
        if (nscale < 0) ;
        else if (i >= no_codons[nscale]) {
            printf("ERROR: codon offset too big\n"); 
        }
        else {
            t1 = flags2_pos[nscale][codons_pos[nscale][i]-1];
            t2 = flags2_pos[nscale][codons_pos[nscale][i]+1];
            Xoffset = nscale * (width + Xgap) + Xoffset1;
            moveto((int)(xsmooth[nscale][t1])+Xoffset,
                   (int)(ysmooth[nscale][t1])+Yoffset);
            for (j = t1; j < t2; j++)
                lineto((int)(xsmooth[nscale][j])+Xoffset,
                       (int)(ysmooth[nscale][j])+Yoffset,0);

            s1 = skew1(t1,t2,nscale);
            s2 = skew2(t1,t2,nscale);
            s3 = skew3(t1,t2,nscale);
            s4 = skew4(t1,t2,nscale);
            printf("skFu: %2.2f  skIJCAI: %2.2f  skPLR: %2.2f\n",
                s1,s2,s4);
        }
    } while (nscale >= 0);
    printf("finished testing skew measures\n");
}

/* skew measurement based on You & Fu */
float skew1(t1,t2,nscale)
int t1,t2,nscale;
{
    int i,j;
    float roundness = 0;
    float skew = 0;

    /* calculate roundness */
    for (i = t1; i < t2; i++)
        roundness += fabs(curvature[nscale][i]);

    for (i = t1; i < t2; i++) {
        for (j = t1; j < i; j++)
            skew += curvature[nscale][j];
        skew -= (roundness / 2.0);
    }

    return(skew);
}

/* skew measurement based on Shimaya & Yoroizawa, IJCAI-91 */
float skew2(t1,t2,nscale)
int t1,t2,nscale;
{
    int i,j;
    float skew = 0;
    float k1,k2,k3;

    k3 = 0;
    /* calculate roundness */
    for (i = t1; i < t2; i++)
        k3 += curvature[nscale][i];

    for (i = t1; i < t2; i++) {
        k1 = k2 = 0;
        for (j = t1; j < i; j++)
            k1 += curvature[nscale][j];
        for (j = t1; j < t2-i; j++)
            k2 += curvature[nscale][j];
        skew += fabs(k1 + k2 - k3);
    }

    return(skew);
}

/* skew measurement based on Geoff West */
float skew3(t1,t2,nscale)
int t1,t2,nscale;
{
    int x1,y1,x2,y2,x3,y3,x4,y4;
    float a1,a2,diff_a;

    x1 = xsmooth[nscale][t1];
    y1 = ysmooth[nscale][t1];
    x2 = xsmooth[nscale][t2];
    y2 = ysmooth[nscale][t2];
    x3 = xsmooth[nscale][(t1+t2)/2];
    y3 = ysmooth[nscale][(t1+t2)/2];
    x4 = (x1 + x2) / 2;
    y4 = (y1 + y2) / 2;

    a1 = angle((float)x1,(float)y1,(float)x2,(float)y2);
    a2 = angle((float)x4,(float)y4,(float)x3,(float)y3);
    diff_a = a1 - a2;
    /* make angle between 0 and PI */
    if (diff_a < 0.0) diff_a += TWO_PI;
    if (diff_a > TWO_PI) diff_a -= TWO_PI;
    if (diff_a > PI) diff_a -= PI;
    diff_a *= (180.0/PI);

    return(diff_a);
}

/* skew measurement based on Geoff West - ammended by Paul Rosin */
/* based not just the angle but the sector */
/* normalised by curve length */
float skew4(t1,t2,nscale)
int t1,t2,nscale;
{
    int i;
    int x1,y1,x2,y2,x3,y3,x4,y4;
    float a1,a2,diff_a,dist,area,length;
    int dx,dy;

    /* start of codon */
    x1 = xsmooth[nscale][t1];
    y1 = ysmooth[nscale][t1];
    /* end of codon */
    x2 = xsmooth[nscale][t2];
    y2 = ysmooth[nscale][t2];
    /* midpoint of straight line between start & end */
    x3 = xsmooth[nscale][(t1+t2)/2];
    y3 = ysmooth[nscale][(t1+t2)/2];
    /* midpoint of codon */
    x4 = (x1 + x2) / 2;
    y4 = (y1 + y2) / 2;

    /* calculate length of codon */
    length = 0;
    for (i = t1; i < t2-1; i++) {
        dx = xsmooth[nscale][i] - xsmooth[nscale][i+1];
        dy = ysmooth[nscale][i] - ysmooth[nscale][i+1];
        dist = sqrt((double)(dx*dx+dy*dy));
        length += dist;
    }
    /* hack to catch undebugged errors that occurred in porting to Alpha */
    length = MAX(length,1);

    dist = (x3 - x4) * (x3 - x4) + (y3 - y4) * (y3 - y4);
    dist = sqrt((double)dist);

    a1 = angle((float)x1,(float)y1,(float)x2,(float)y2);
    a2 = angle((float)x4,(float)y4,(float)x3,(float)y3);
    diff_a = a1 - a2;
    /* make angle between 0 and PI */
    if (diff_a < 0.0) diff_a += TWO_PI;
    if (diff_a > TWO_PI) diff_a -= TWO_PI;
    if (diff_a > PI) diff_a -= PI;
    /* difference between the angle and 90 degrees */
    diff_a = (PI / 2) - diff_a;

    area = (dist * dist) * tan(diff_a) / 2.0;

    /* normalise area by curve length */
    area /= length;

    return(area);
}

/* an approximation to compactness */
/* the ratio of the Euclidean distance between the endpoints and the
   Euclidean distance between the midpoint of that line and the centre
   of the curve */
float compactness(t1,t2,nscale)
int t1,t2,nscale;
{
    int x1,y1,x2,y2,x3,y3,x4,y4;
    float dist1,dist2;

    x1 = xsmooth[nscale][t1];
    y1 = ysmooth[nscale][t1];
    x2 = xsmooth[nscale][t2];
    y2 = ysmooth[nscale][t2];
    x3 = xsmooth[nscale][(t1+t2)/2];
    y3 = ysmooth[nscale][(t1+t2)/2];
    x4 = (x1 + x2) / 2;
    y4 = (y1 + y2) / 2;

    dist1 = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
    dist1 = sqrt((double)dist1);

    dist2 = (x3 - x4) * (x3 - x4) + (y3 - y4) * (y3 - y4);
    dist2 = sqrt((double)dist2);

    return(dist2/dist1);
}

float length(st,fi,nscale)
int st,fi,nscale;
{
    int i;
    float dx,dy;
    float lgth = 0;

    for (i = st; i < fi; i++) {
        dx = xsmooth[nscale][i] - xsmooth[nscale][i+1];
        dy = ysmooth[nscale][i] - ysmooth[nscale][i+1];
        lgth += sqrt((double)(dx*dx+dy*dy));
    }
    return(lgth);
}

float roundness(st,fi,nscale)
int st,fi,nscale;
{
    int i;
    float r = 0;

    for (i = st; i < fi; i++)
        r += fabs(curvature[nscale][i]);
    return(r);
}

/* duplicate data for a closed boundary - extend each end by copying */
wraparound_data(length)
int length;
{
    int s,t;

    /* shift up the pixel data */
    for (t = no_pixels-1; t >= 0; t--) {
       x[t+length] = x[t];
       y[t+length] = y[t];
    }

    /* copy data to start of pixel list */
    no_pixels += length;
    for (s = length-1,t = no_pixels-1; t > no_pixels-1-length; s--,t--) {
       x[s] = x[t];
       y[s] = y[t];
    }

    /* copy data to end of pixel list */
    for (t = length; t < length*2; t++) {
       x[no_pixels] = x[t];
       y[no_pixels] = y[t];
       no_pixels++;
    }
}

/* the curve extension code is a messy hack - but it works! */

/* extend the ends of a curve by transforming and duplication */
extend_data(length,end)
int length,end;
{
    int t,v;
    double theta;
    int st,fi;
    int nseg,dir;

    if (end == START) {
       st = 0; fi= length;
       dir = FORWARD;
    }
    else {
       st = no_pixels-length-1; fi = no_pixels-1;
       dir = REVERSE;
    }
    theta = angle((float)x[st],(float)y[st],(float)x[fi],(float)y[fi]);
    /* get data into temp arrays */
    nseg = 0;
    if (dir == FORWARD)
       for (t = st;t < fi;t++) {
          x_trans[nseg] = x[t];
          y_trans[nseg] = y[t];
          nseg++;
       }
    else
       for (t= fi-1;t>= st;t--) {
          x_trans[nseg] = x[t];
          y_trans[nseg] = y[t];
          nseg++;
       }
    if (end == START)
       transform1(theta,nseg,x[st],y[st]);
    else
       transform1(theta,nseg,x[fi],y[fi]);

    for (t = 0; t < masksize; t++) {
       x_trans[t] = -x_trans[t];
       y_trans[t] = -y_trans[t];
    }

    if (end == START)
       transform2(theta,nseg,x[st],y[st]);
    else
       transform2(theta,nseg,x[fi],y[fi]);

    if (end == START) {
       for (t = no_pixels-1; t >= 0; t--) {
          x[t+length] = x[t];
          y[t+length] = y[t];
       }
       v = 0;
       for (t = length-1; t >= 0; t--) {
          x[v] = x_trans[t];
          y[v] = y_trans[t];
          v++; no_pixels++;
       }
    }
    else {
       for (t = 0; t < length; t++) {
          x[no_pixels] = x_trans[t];
          y[no_pixels] = y_trans[t];
          no_pixels++;
       }
    }
}

/* transform data curve onto X-axis */
transform1(theta,nseg,x1,y1)
float theta;
int nseg;
int x1,y1;
{
    int loop1;
    float temp,xt,yt;
    float sine,cosine;

    /* translate */
    for (loop1 = 0;loop1 < nseg;loop1++) {
        x_trans[loop1] -= x1;
        y_trans[loop1] -= y1;
    }
    /* rotate */
    sine = sin(-theta);
    cosine = cos(-theta);
    for (loop1 = 0;loop1 < nseg;loop1++) {
        xt = x_trans[loop1];
        yt = y_trans[loop1];
        temp = xt*cosine - yt*sine;
        x_trans[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans[loop1] = temp;
    }
}

/* transform extended data back from X-axis into the image */
transform2(theta,nseg,x1,y1)
float theta;
int nseg;
int x1,y1;
{
    int loop1;
    float temp,xt,yt;
    float sine,cosine;

    /* rotate */
    sine = sin(theta);
    cosine = cos(theta);
    for (loop1 = 0;loop1 < nseg;loop1++) {
        xt = x_trans[loop1];
        yt = y_trans[loop1];
        temp = xt*cosine - yt*sine;
        x_trans[loop1] = temp;
        temp = xt*sine + yt*cosine;
        y_trans[loop1] = temp;
    }
    /* translate */
    for (loop1 = 0;loop1 < nseg;loop1++) {
        x_trans[loop1] += x1;
        y_trans[loop1] += y1;
    }
}

/*====================== some plotting routines======================*/

cross(xs,ys,c_w,colour)
int xs,ys;
int c_w;
unsigned char colour;
{
    int x,y;
    unsigned char old_colour;

    old_colour = current_colour;
    set_colour(colour);
    x = xs - c_w;
    y = ys - c_w;
    moveto(x,y);
    x = xs + c_w;
    y = ys + c_w;
    lineto(x,y,0);
    x = xs + c_w;
    y = ys - c_w;
    moveto(x,y);
    x = xs - c_w;
    y = ys + c_w;
    lineto(x,y,0);
    x = xs;
    y = ys;
    moveto(x,y);
    set_colour(old_colour);
}

box(xs,ys,b_w,colour)
int xs,ys;
int b_w;
unsigned char colour;
{
    int x,y;
    unsigned char old_colour;

    old_colour = current_colour;
    set_colour(colour);

    x = xs - b_w;
    y = ys - b_w;
    moveto(x,y);
    x = xs + b_w;
    y = ys - b_w;
    lineto(x,y,0);
    x = xs + b_w;
    y = ys + b_w;
    lineto(x,y,0);
    x = xs - b_w;
    y = ys + b_w;
    lineto(x,y,0);
    x = xs - b_w;
    y = ys - b_w;
    lineto(x,y,0);

    x = xs;
    y = ys;
    moveto(x,y);
    set_colour(old_colour);
}

plot_circle(xc,yc,r,colour)
int xc,yc,r;
unsigned char colour;
{
    int i;
    float tx,ty;
    float angle;
    float factor;
    float x,y;
    unsigned char old_colour;

    old_colour = current_colour;
    set_colour(colour);

    factor = r * 0.3;
    /* do a few more points - especially for small circles */
    factor += 100 / r;
    tx = r * cos(0.0);
    ty = r * sin(0.0);
    x = xc + tx;
    y = yc + ty;
    moveto((int)x,(int)y);
    for (i=0; i < (factor+1); i++) {
        angle = i * 2 * PI / factor;
        tx = r * cos(angle);
        ty = r * sin(angle);
        x = xc + tx;
        y = yc + ty;
        lineto((int)x,(int)y,0);
    }
    set_colour(old_colour);
}

/* ##### ALL CODE BELOW IS TRANSLATED FROM DAVID LOWE'S LISP VERSION ##### */

/*********************************************************************
Produce a table giving shrinkage correction values as a function of
the second derivative convolution. 
The table goes from 1/G2 = sigma to 1/G2 = 50*sigma in intervals of 
0.25*sigma (197 values).  Good results could be achieved with a smaller
table, but play it safe.
*********************************************************************/
make_cor_table(sigma)
float sigma;
{
    float curRadius = 50.0;
    float curG,curG2i;
    float prevG,prevG2i;
    float desG2i;
    int i;
    int first=TRUE;

    G_G2inv_pair(sigma*curRadius,&curG,&curG2i);
    for (i=0;i<197;i++) {
        desG2i=sigma*(50-i*0.25);
        /* lower radius until we bracket desired value of G2 */
        while (first || (curG2i > desG2i)) {
            first = FALSE;
            prevG = curG;
            prevG2i = curG2i;
            curRadius -= 0.25;
            G_G2inv_pair(sigma*curRadius,&curG,&curG2i);
            /*  if G2i stops shrinking then fill rest of table
                with current value of G */
            if (curG2i>prevG2i) {
                curG2i = 0;
                curG = prevG;
            }
        }
        /* place interpolated shrinkage error in correction table */
        cor_table[196-i] = curG +
            ((desG2i-curG2i)*(prevG-curG))/(prevG2i-curG2i);
    }
}

/*********************************************************************
We compute the amount of shrinkage that occurs for a given value of
the G2 convolution by actually convolving the current masks with a
path-length parameterized circle of the given radius.  While this is
more time-consuming than simply calculating the formulas given in
my paper, it is more accurate because it compensates for the sampling
and truncation errors in the current convolution masks (these errors
can amount to 10% or more for the current mask size of 5*sigma).
Since this is done during precomputation, there is little need to worry
about efficiency.
*********************************************************************/
G_G2inv_pair(radius,curG,curG2i)
float radius;
float *curG,*curG2i;
{
    float s;    /* current path length parameter value */
    float x;    /* corresponding x coordinate value */
    float g,g2;
    int i;

    g = g2 = 0;
    for (i=0;i<=masksize;i++) {
        s = i - masksize/2;
        x = radius * (1 - cos(s/radius));
        g += (x*G[i]);
        g2 += (x*G2[i]);
    }
    *curG = g;
    *curG2i = 1.0/g2;
}

/*********************************************************************
Correct the Gaussian convolution value g according to the measure of
curvature g2.  Correction is computed using table lookup and linear
interpolation.
Efficiency is very important here, because this is executed for each
point that is smoothed.
*********************************************************************/
float shrink_correct(sigma,g,g2)
float sigma;
float g,g2;
{
    float ratio,index,sign,frac;
    int int1;

    if (fabs(g2*sigma) < 0.02) return(g);
    ratio = fabs(1.0/(g2*sigma));
    index = 4*(ratio-1);
    if (index > 195) index = 195;
    if (index < 0) index = 0;
    if (g2>0) sign = 1; else sign = -1;
    int1 = (int)index;
    frac = index - int1;
    return(g-sign*((1-frac)*(cor_table[int1])+(frac*cor_table[1+int1])));
}

