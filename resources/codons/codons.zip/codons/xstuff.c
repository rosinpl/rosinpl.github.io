/* 
    chopped-down version of xplotlib.c

    contains Xlib for the basic screen functions
    also includes Postscript stuff

    originally written by Geoff West, Curtin University, Perth, Australia

    Paul Rosin
    Institute of Remote Sensing Applications
    Joint Research Centre
    Ispra (VA), Italy
    paul.rosin@jrc.it
    October 1993
*/

#include <stdio.h>
#include <math.h>
#include <malloc.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>

#define TEXT         1
#define BORDER       2
#define BACKGND      3
#define SCREEN       4
#define HIGHLITE     5

#define WHITE      255
#define YELLOW     253
#define GREEN      252
#define BLUE       251
#define PURPLE     250
#define CYAN       249
#define LIME       248
#define RED        247
#define ORANGE     246
#define BLACK        0

#define    cms_palettesetup(r,g,b) \
{ int p_i; \
    for (p_i=0;p_i<256;p_i++) { \
        (r)[p_i] = p_i; (g)[p_i] = p_i; (b)[p_i] = p_i; \
    }\
    (r)[BLACK] = 0;      (g)[BLACK] = 0;      (b)[BLACK] = 0; \
    (r)[WHITE] = 255;    (g)[WHITE] = 255;    (b)[WHITE] = 255; \
    (r)[RED] = 255;      (g)[RED] = 0;        (b)[RED] = 0; \
    (r)[ORANGE] = 255;   (g)[ORANGE] = 200;   (b)[ORANGE] = 0; \
    (r)[YELLOW] = 250;   (g)[YELLOW] = 250;   (b)[YELLOW] = 0; \
    (r)[LIME] = 175;     (g)[LIME] = 255;     (b)[LIME] = 0; \
    (r)[BLUE] = 0;       (g)[BLUE] = 0;       (b)[BLUE] = 255; \
    (r)[CYAN] = 60;      (g)[CYAN] = 215;     (b)[CYAN] = 255; \
    (r)[PURPLE] = 200;   (g)[PURPLE] = 0;     (b)[PURPLE] = 255; \
    (r)[GREEN] = 0;      (g)[GREEN] = 170;    (b)[GREEN] = 0; \
    (r)[TEXT] = 0;       (g)[TEXT] = 0;       (b)[TEXT] = 0; \
    (r)[BACKGND] = 204;  (g)[BACKGND] = 165;  (b)[BACKGND] = 140; \
    (r)[SCREEN] = 64;    (g)[SCREEN] = 115;   (b)[SCREEN] = 102; \
    (r)[BORDER] = 180;   (g)[BORDER] = 145;   (b)[BORDER] = 120; \
    (r)[HIGHLITE] = 180; (g)[HIGHLITE] = 145; (b)[HIGHLITE] = 130; \
}

/* X windows structures etc */
Display *display;
int screen;
Window win;
char *icon_name = "xmcodon3";
XSizeHints size_hints;
XEvent report;
GC gc;
XImage *xi;
XFontStruct *font_info;
char *display_name = NULL;
Colormap cmap;
XColor exact_def;
Visual *visual;

unsigned int border_width = 4;

unsigned int display_width,display_height,display_depth;

unsigned char current_colour;

#define  CMS_PALETTESIZE    256
unsigned char red[CMS_PALETTESIZE];
unsigned char green[CMS_PALETTESIZE];
unsigned char green[CMS_PALETTESIZE];
unsigned char blue[CMS_PALETTESIZE];

int current_x,current_y;   /* saves current plot point */
char *image;               /* array for plotting image etc. on Sun */
float x_scale,y_scale;

/* variables for implementing Postscript output */
int line_width = 0;     /* save as a global - save repetition */
extern char *ps_file;   /* file name for Postscript output */
FILE *fp_ps;            /* file to dump Postscript to */

moveto(xpix,ypix)
int xpix,ypix;
{
    current_x = floor(xpix * x_scale);
    current_y = floor(ypix * y_scale);

    if (ps_file != NULL) {
        /* finish off last line */
        fprintf(fp_ps,"stroke\n");

        fprintf(fp_ps,"%d %d moveto\n",xpix,512-ypix);
    }
}

lineto(xpix,ypix,option)
int xpix,ypix;
int option;
{
    int x,y;

    x = floor(xpix * x_scale);
    y = floor(ypix * y_scale);
    XDrawLine(display,win,gc,current_x,current_y,x,y);

    if (option == 1) {
        XDrawLine(display,win,gc,current_x-1,current_y,x-1,y);
        XDrawLine(display,win,gc,current_x-1,current_y-1,x-1,y-1);
        XDrawLine(display,win,gc,current_x,current_y-1,x,y-1);
    }
    current_x = x;
    current_y = y;

    if (ps_file != NULL) {
        if (option != line_width) {
            if (option == 0)
                fprintf(fp_ps,"1 setlinewidth\n");
            else
                fprintf(fp_ps,"5 setlinewidth\n");
        }
        fprintf(fp_ps,"%d %d lineto\n",xpix,512-ypix);
        /* save option as global */
        line_width = option;
    }
}

open_device(startx,starty,width,height,window_label)
int startx, starty,width,height;
char *window_label;
{
    float image_scale;
    int i;
    int argc = 0;        /* dummy - not needed */
    char **argv = NULL;  /* dummy - not needed */
    int max_dimension;
    float scale;

    /* set scale to 1.0 */
    x_scale = 1.0;
    y_scale = 1.0;

    /* malloc space for the image */
    image = (char *)malloc(width*height*sizeof(char));
    if (image == NULL) {
        printf("cannot malloc space for the image - aborting\n");
        exit();
    }

    /* connect to X server */

    if ((display = XOpenDisplay(display_name)) == NULL) {
        fprintf(stderr,"xplotdata: cannot connect to X server %s\n",
                        XDisplayName(display_name));
        exit(-1);
    }

    screen = DefaultScreen(display);

    display_depth = DisplayPlanes(display,screen);
    if (display_depth < 8) {
        printf("not enough colours to plot - aborting\n");
        exit();
    }
    display_width = width;
    display_height = height;
    
    visual = DefaultVisual(display,screen);
    cmap = DefaultColormap(display,screen);

    /* new version - can alter lut's etc */
    win = XCreateWindow(display,RootWindow(display,screen),
                        (unsigned int)startx,(unsigned int)starty,
                        display_width,display_height,
                        border_width,display_depth,InputOutput,
                        visual,0);

    
    size_hints.flags = PPosition | PSize | PMinSize;
    size_hints.x = startx;
    size_hints.y = starty;
    size_hints.width = width;
    size_hints.height = height;

    XSetStandardProperties(display,win,window_label,
                        icon_name,None,
                        argv,argc,&size_hints);

    XSelectInput(display,win,ExposureMask | KeyPressMask |
                    ButtonPressMask | StructureNotifyMask);

    XSetWindowBackground(display,win,0);
    
    load_font(&font_info);

    get_GC(win,&gc,font_info);
    
    /* new lut setup code - uses a virtual colormap */
    cmap = XCreateColormap(display,win,visual,AllocAll);
    XSetWindowColormap(display,win,cmap);
    
    /* define colour lut */
    exact_def.flags = DoRed | DoGreen | DoBlue;
    cms_palettesetup(red,green,blue);
    for(i=0;i<256;i++) {
        exact_def.pixel = i;
        exact_def.red = red[i] << 8;
        exact_def.green = green[i] << 8;
        exact_def.blue = blue[i] << 8;
        XStoreColor(display,cmap,&exact_def);
    }
    
    XClearWindow(display,win);

    XMapWindow(display,win);
    
    /* XFlush(display); */

    wait_for_server();

    create_image(width,height);

    /* set up Postscript file */
    if (ps_file != NULL) {
        if ((fp_ps = fopen(ps_file,"w")) == NULL) {
            printf("cant open %s\n",ps_file);
            exit(-1);
        }
        fprintf(fp_ps,"%%!\ngsave\ninitgraphics\n");
        if (width > height)
            max_dimension = width;
        else
            max_dimension = height;
        scale = 512.0/max_dimension;
        fprintf(fp_ps,"%f %f scale\n",scale,scale);
        fprintf(fp_ps,"%f %d translate\n",20.0/scale,height-512+120);
        fprintf(fp_ps,"1 setlinejoin\n1 setlinecap\nnewpath\n");
        fprintf(fp_ps,"1 setlinewidth\n");
        fprintf(fp_ps,"/Helvetica findfont 10 scalefont setfont\n");
        fprintf(fp_ps,"0 512 moveto\n");
        fprintf(fp_ps,"0 %d lineto\n",512-height);
        fprintf(fp_ps,"%d %d lineto\n",width,512-height);
        fprintf(fp_ps,"%d 512 lineto\n",width);
        fprintf(fp_ps,"0 512 lineto\n");
        fprintf(fp_ps,"stroke\n");
        outtextxy(0,height+50,window_label);
    }
}

set_colour(colour)
unsigned char colour;
{
    current_colour = colour;
    XSetForeground(display,gc,current_colour);
}

store_current_image()
{
    unsigned long plane_mask = 255;

    xi = XGetImage(display,win,0,0,
                    size_hints.width,size_hints.height,
                    plane_mask,ZPixmap);
}
    
close_graph()
{
    /* make sure all plotting done */
    
    XFlush(display);
    /* wait_for_server(); */
    
    store_current_image();

    /* finish off Postscript file */
    if (ps_file != NULL) {
        fprintf(fp_ps,"stroke\nshowpage\n");
        printf("closing Postscript file\n");
        fclose(fp_ps);
    }

    while(1) {
        XNextEvent(display,&report);
        switch(report.type) {
            case Expose:
                while(XCheckTypedEvent(display,Expose,&report));
                XPutImage(display,win,gc,xi,0,0,0,0,
                            size_hints.width,size_hints.height);
                /* printf("e: %d\n",report.type); */
                break;
            case ConfigureNotify:
                size_hints.width = report.xconfigure.width;
                size_hints.height = report.xconfigure.height;
                /* printf("c: %d\n",report.type); */
                break;
            case ButtonPress:
            case KeyPress:
                XUnloadFont(display,font_info->fid);
                XFreeGC(display,gc);
                XDestroyImage(xi);
                XCloseDisplay(display);
                /* printf("k: %d\n",report.type); */
                /* exit(1); */
            default:
                /* printf("d: %d\n",report.type); */
                break;
        }
    }
}

outtextxy(x,y,text)
int x,y;
char text[];
{
    int len1;
    
    XSetForeground(display,gc,current_colour);
    len1 = strlen(text);
    XDrawString(display,win,gc,x,y,text,len1);

    if (ps_file != NULL) {
        fprintf(fp_ps,"%d %d moveto\n",x,512-y);
        fprintf(fp_ps,"(%s) show\n",text);
    }
}

create_image(width,height)
unsigned int width,height;
{
    xi = XCreateImage(display,    /* the display */
                      visual,     /* default visual */
                      8,          /* bit depth */
                      ZPixmap,    /* image format */
                      0,          /* bit offset */
                      image,      /* image data */
                      width,      /* image width */
                      height,     /* image height */
                      8,          /* scan line quantum */
                      width);     /* bytes per scan line */
}


void clear_window()
{
    XClearWindow(display,win);
}

load_font(font_info)
XFontStruct **font_info;
{
    /* char *fontname ="9x15"; */
    char *fontname ="5x8";    /* works with X11 R5 and Sun Openwin 2 */

    if ((*font_info = XLoadQueryFont(display,fontname)) == NULL) {
        (void) fprintf(stderr,"Basic: Cannot open %s font\n",fontname);
        exit(-1);
    }
}

get_GC(win,gc,font_info)
Window *win;
GC *gc;
XFontStruct *font_info;
{
    unsigned long valuemask = 0;
    XGCValues values;
    unsigned int line_width = 1;
    int line_style = LineSolid;
    int cap_style = CapRound;
    int join_style = JoinRound;
    int dash_offset = 0;
    static char dash_list[] = { 12, 24};
    int list_length = 2;

    *gc = XCreateGC(display,win,valuemask,&values);

    XSetFont(display,*gc,font_info->fid);

    XSetForeground(display,*gc,255);

    XSetLineAttributes(display,*gc,line_width,line_style,cap_style,join_style);

    XSetDashes(display,*gc,dash_offset,dash_list,list_length);
}

/* loop until all the requests of the server have been completed */
wait_for_server()
{
    while (1) {
        XEvent      ev;
        XNextEvent(display, &ev);
        if (ev.type == Expose)
            break;
    }
}

/* send all plot instructions to the server - hope they get plotted */
flush_buffer()
{
    XFlush(display);
}
