/* "Real-time content-aware image resizing",
 * H. Huang, T.N. Fu, P.L. Rosin, C. Qi, 
 * Science in China Series F: Information Sciences, vol. 52, no. 2, pp. 172-182, 2009.
 *
 * code: Tiannan Fu
 * minor mods: Paul Rosin
 * December 2020
 */

#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

#define NEGATIVE_INFINITE -99999999

using namespace std;
using namespace cv;

Mat compute_energy(Mat &image) {
	int rows = image.rows;
	int cols = image.cols;
	Mat energy(rows, cols, CV_16UC1);
	Vec3b pixel1, pixel2;

	for (int i = 0; i < rows - 1; ++i) {
		for (int j = 0; j < cols - 1; ++j) {
			pixel1 = image.at<Vec3b>(i, j);
			pixel2 = image.at<Vec3b>(i, j + 1);
			short diff_x = abs(pixel2[0] - pixel1[0]) + abs(pixel2[1] - pixel1[1]) + abs(pixel2[2] - pixel1[2]);
			pixel2 = image.at<Vec3b>(i + 1, j);
			short diff_y = abs(pixel2[0] - pixel1[0]) + abs(pixel2[1] - pixel1[1]) + abs(pixel2[2] - pixel1[2]);
			energy.at<ushort>(i, j) = diff_x + diff_y;
		}

		pixel1 = image.at<Vec3b>(i, cols - 1);
		pixel2 = image.at<Vec3b>(i + 1, cols - 1);
		energy.at<ushort>(i, cols - 1) = abs(pixel2[0] - pixel1[0]) + abs(pixel2[1] - pixel1[1]) + abs(pixel2[2] - pixel1[2]);
	}
	
	for (int j = 0; j < cols - 1; ++j) {
		pixel1 = image.at<Vec3b>(rows - 1, j);
		pixel2 = image.at<Vec3b>(rows - 1, j + 1);
		energy.at<ushort>(rows - 1, j) = abs(pixel2[0] - pixel1[0]) + abs(pixel2[1] - pixel1[1]) + abs(pixel2[2] - pixel1[2]);
	}
	
	energy.at<ushort>(rows - 1, cols - 1) = 0;
	
	return energy;
}

Mat compute_M(Mat &energy) {
	int rows = energy.rows;
	int cols = energy.cols;
	Mat M(rows, cols, CV_16UC1);
	
	for (int j = 0; j < cols; ++j) {
		M.at<ushort>(rows - 1, j) = energy.at<ushort>(rows - 1, j);
	}

	for (int i = rows - 2; i >= 0; --i) {
		for (int j = 0; j < cols; ++j) {
			ushort tmp = M.at<ushort>(i + 1, j);
			if (j > 0 && M.at<ushort>(i + 1, j - 1) < tmp) {
				tmp = M.at<ushort>(i + 1, j - 1);
			}
			if (j < cols - 1 && M.at<ushort>(i + 1, j + 1) < tmp) {
				tmp = M.at<ushort>(i + 1, j + 1);
			}

			M.at<ushort>(i, j) = energy.at<ushort>(i, j) + tmp;
		}
	}

	return M;
}

int calc_edge_weight1(int k, int i, int j, Mat &energy, Mat &M, Mat &A) {
	int cols = energy.cols;

	if (i < 0 || j < 0 || i >= cols || j >= cols || abs(i - j) > 1) {
		return NEGATIVE_INFINITE;
	} else {
		return energy.at<ushort>(k, i) * energy.at<ushort>(k + 1, j);
	}
}

int calc_edge_weight2(int k, int i, int j, Mat &energy, Mat &M, Mat &A) {
	int cols = energy.cols;

	if (i < 0 || j < 0 || i >= cols || j >= cols || abs(i - j) > 1) {
		return NEGATIVE_INFINITE;
	} else {
		return A.at<ushort>(k, i) * M.at<ushort>(k + 1, j);
	}
}

int do_match(int k, Mat &energy, Mat &M, Mat &A, Mat &result) {
	int cols = energy.cols;
	int *F = new int[cols];
	int *F1 = new int[cols];
	int *F2 = new int[cols];
	
	for (int j = 0; j < cols; ++j) {
		int f1 = calc_edge_weight2(k, j, j, energy, M, A);
		int f2 = calc_edge_weight2(k, j, j - 1, energy, M, A) + calc_edge_weight2(k, j - 1, j, energy, M, A); 

		if (j - 1 >= 0) {
			f1 += F[j - 1];
		}
		if (j - 2 >= 0) {
			f2 += F[j - 2];
		}

		F[j] = max(f1, f2);
		F1[j] = f1;
		F2[j] = f2;
	}

	int j = cols - 1;
	while (j >= 0) {
		if (F[j] == F1[j]) {
			result.at<ushort>(k, j) = j;
			A.at<ushort>(k + 1, j) = A.at<ushort>(k, j) + energy.at<ushort>(k + 1, j);
			--j;
		} else if (F[j] == F2[j]) {
			result.at<ushort>(k, j) = j - 1;
			A.at<ushort>(k + 1, j - 1) = A.at<ushort>(k, j) + energy.at<ushort>(k + 1, j - 1);
			result.at<ushort>(k, j - 1) = j;
			A.at<ushort>(k + 1, j) = A.at<ushort>(k, j - 1) + energy.at<ushort>(k + 1, j);
			j -= 2;
		} else {
			delete [] F;
			delete [] F1;
			delete [] F2;
			return -1;
		}
	}
	
	delete [] F;
	delete [] F1;
	delete [] F2;
	return 0;
}

Mat match(Mat &energy) {
	int rows = energy.rows;
	int cols = energy.cols;

	Mat M = compute_M(energy);

	Mat A = Mat(rows, cols, CV_16UC1);
	for (int j = 0; j < cols; ++j) {
		A.at<ushort>(0, j) = energy.at<ushort>(0, j);
	}

	Mat result = Mat(rows, cols, CV_16UC1);

	for (int i = 0; i < rows - 1; ++i) {
		do_match(i, energy, M, A, result);
	}

	return result;
}

bool operator<(const pair<int, ushort> &a, const pair<int, ushort> &b) {
	return a.first < b.first;
}

Mat find_seam(Mat &edge, Mat &energy) {
	int rows = energy.rows;
	int cols = energy.cols;
	vector<pair<int, ushort> > seam_energy;
	Mat result = Mat(rows, cols, CV_16UC1);
	
	for (int j = 0; j < cols; ++j) {
		int total_energy = 0;
		int next = j;

		for (int i = 0; i < rows; ++i) {
			total_energy += energy.at<ushort>(i, next);
			next = edge.at<ushort>(i, next);
		}
		
		seam_energy.push_back(make_pair(total_energy, j));
	}

	sort(seam_energy.begin(), seam_energy.end());

	for (int k = 0; k < cols; ++k) {
		int next = seam_energy[k].second;
		for (int i = 0; i < rows; ++i) {
			result.at<ushort>(i, next) = k;
			next = edge.at<ushort>(i, next);
		}
	}
	
	return result;
}

Mat reduce_width(Mat &image, Mat &seam, int width) {
	int rows = image.rows;
	int diff = image.cols - width;
	if (diff < 0) {
		return Mat(image);
	}

	Mat result = Mat(rows, width, CV_8UC3);

	for (int i = 0; i < rows; ++i) {
		int next = 0;
		for (int j = 0; j < width; ++j) {
			while (seam.at<ushort>(i, next) < diff) {
				++next;
			}

			result.at<Vec3b>(i, j) = image.at<Vec3b>(i, next);
			++next;
		}
	}

	return result;
}

int main(int argc, char *argv[]) {
    // making this smaller will increase the frequency of recomputing the energy map
    // at the cost of extra computation
    int recomputeSeams = 10;

    if (argc == 4) {
        recomputeSeams = atoi(argv[3]);
    }
    else if (argc != 3) {
        fprintf(stderr,"usage: %s input_image output_image [number-of-seams-between-energy-updates]\n",argv[0]);
        exit(-1);
    }

    Mat energy, edge, seam;
    Mat img = imread(argv[1]);
    int target_width = img.cols / 2;

    // remove some seams and then recompute energy map
    while (img.cols > target_width + recomputeSeams) {
        energy = compute_energy(img);
        edge = match(energy);
        seam = find_seam(edge, energy);
        img = reduce_width(img, seam, img.cols - recomputeSeams);
    }
    // remove a few more seams to get the target image width
    energy = compute_energy(img);
    edge = match(energy);
    seam = find_seam(edge, energy);
    img = reduce_width(img, seam, target_width);

    imwrite(argv[2], img);
    
    return 0;
}

