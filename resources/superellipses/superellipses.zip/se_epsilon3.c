/*
 *    estimate value of epsilon for superellipse
 *    as initial estimate use median of 4 intersection points of diagonals
 *    then use Xiaoming Zhang's estimator
 *
 *    Paul Rosin
 *    March 1998
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define MAX_PIXELS 10000

#define MAX(a,b)     (((a) > (b)) ? (a) : (b))
#define MIN(a,b)     (((a) < (b)) ? (a) : (b))
#define ABS(x)       (((x)<0.0)? (-(x)): (x))

#define PI 3.1415927

int no_pixels;
int x[MAX_PIXELS],y[MAX_PIXELS];
double x2[MAX_PIXELS],y2[MAX_PIXELS];
double x_nor[MAX_PIXELS],y_nor[MAX_PIXELS];

void normalise_data(double xc,double yc,double theta);
void read_link_data(FILE *fp, int *endoffile);
void intersect(double xdata[],double ydata[], int no_points, double p,double q, double *xi1,double *yi1,double *xi2,double *yi2);
void mbr(double *xct,double *yct,double *a,double *b,double *rot);
void convex_hull(double *p, int n, int *ch, int *p_nch, char *directions, double epsilon);
void centroid(double *pts, int n, double *p_cen_x, double *p_cen_y);
void make_rotation_matrix(double cos_theta,double sin_theta,double *m);
void solve2(double a,double b,double c,double *r1,double *r2);
void solve3(double a,double b,double c,double d,double *r1,double *r2,double *r3);
int SolveCubic(double c[ 4 ], double s[ 3 ]);
int SolveQuadric(double c[ 3 ], double s[ 2 ]);
int SolveQuartic(double c[ 5 ], double s[ 4 ]);
double estimate_ep(int n, double x[],double  y[], double a,double b,double k);

main(argc,argv)
int argc;
char *argv[];
{
    FILE *fp1,*fp2;
    char file_type[50];
    int i,j;
    int endoffile;
    double a,b,xc,yc,xc2,yc2,area,epsilon,epsilon2,t,theta;
    int flag;
    char *outfile = NULL;
    double xi1,yi1,xi2,yi2;
    double eps[4];

    if (argc == 3) {
        outfile = argv[2];
    }
    else if (argc != 2) {
        printf("usage: %s input_file [output_file]\n",argv[0]);
        exit(-1);
    }

    if((fp1=fopen(argv[1],"r")) == NULL){
        printf("cant open %s\n",argv[1]);
        exit(-1);
    }
    if (outfile != NULL) {
        if((fp2=fopen(argv[2],"w")) == NULL){
            printf("cant open %s\n",argv[2]);
            exit(-1);
        }
        fprintf(fp2,"super\nlist: 0\n");
    }
    /* read magic word for format of file */
    fscanf(fp1,"%s\n",file_type);
    j = strcmp(file_type,"pixel");
    if(j != 0){
        printf("not link data file - aborting\n");
        exit(-1);
    }

    do {
        read_link_data(fp1,&endoffile);

        mbr(&xc,&yc,&a,&b,&theta);
        a /= 2.0;
        b /= 2.0;
        
        normalise_data(xc,yc,theta);

        intersect(x2,y2,no_pixels,b,a,&xi1,&yi1,&xi2,&yi2);
        eps[0] = 2 * log(a/ABS(xi1)) / log(2.0);
        eps[1] = 2 * log(a/ABS(xi2)) / log(2.0);

        intersect(x2,y2,no_pixels,-b,a,&xi1,&yi1,&xi2,&yi2);
        eps[2] = 2 * log(a/ABS(xi1)) / log(2.0);
        eps[3] = 2 * log(a/ABS(xi2)) / log(2.0);

        /* take median of estimates */
        for (i = 0; i < 3; i++) {
            for (j = i+1; j < 4; j++) {
                if (eps[i] < eps[j]) {
                    t = eps[i];
                    eps[i] = eps[j];
                    eps[j] = t;
                }
            }
        }
        epsilon = (eps[1] + eps[2]) / 2.0;
        epsilon = (eps[0]+eps[1] + eps[2]+eps[3])/4.0;

        epsilon2 = estimate_ep ( no_pixels, x2, y2, a, b, epsilon );

        if (outfile == NULL) {
            printf("ctr %f %f\n",xc,yc);
            printf("a b %f %f\n",MAX(a,b),MIN(a,b));
            printf("theta %f\n",theta);
            printf("epsilon %f\n",epsilon2);
        }
        else
            fprintf(fp2,"superellipse: 0.0 %.0f %.0f %d %d %d %d %f %f %f %f %d\n",
            xc,yc,
            0,0,0,0,
            a,b,epsilon2,theta,
            1);

    } while (!endoffile);
    fclose(fp1);
       if (outfile != NULL) {
        fprintf(fp2,"endl:\nendf:\n");
        fclose(fp2);
    }
}

/* shift and rotate to origin */
void normalise_data(double xc,double yc,double theta)
{
    double cosine2 = cos(-theta);
    double sine2 = sin(-theta);
    double tx,ty;
    int i;

    for (i = 0; i < no_pixels; i++) {
        tx = x[i] - xc;
        ty = y[i] - yc;

        x2[i] = (tx * cosine2 - ty * sine2);
        y2[i] = (tx * sine2 + ty * cosine2);
    }
}

void read_link_data(FILE *fp, int *endoffile)
{
    char dumstring[50];
    int j;

    fscanf(fp,"%s %d\n",dumstring,&j);
    j = -1;
    do{
       j++;
       fscanf(fp,"%d %d\n",&x[j],&y[j]);
    } while(x[j] != -1);
    *endoffile = (y[j] == -1);
    no_pixels = j;
}

/* return intersection points of ray "y = p/q x" and polygon */
void intersect(double xdata[],double ydata[], int no_points, double p,double q, double *xi1,double *yi1,double *xi2,double *yi2)
{
    int a,b,c,d,i;
    double t,xi,yi;

    for (i = 0; i < no_points; i++) {
        a = xdata[i]; b = ydata[i];
        c = xdata[(i+1)%no_points]; d = ydata[(i+1)%no_points];
        t = (q*b - p*a) / (p*(c-a)+q*(b-d));
        /* intersects */
        if ((t >= 0) && (t <= 1)) {
            xi = a + t*(c-a);
            yi = b + t*(d-b);
            /* store only 1 intersection on +ve X axis */
            if (xi > 0) {
                *xi1 = xi; *yi1 = yi;
            }
            /* store only 1 intersection on -ve X axis */
            else {
                *xi2 = xi; *yi2 = yi;
            }
        }
    }
}

void mbr(double *xct,double *yct,double *a,double *b,double *rot)
{
    double p[MAX_PIXELS*2];
    int n1,n2;
    int ch[MAX_PIXELS];
    int nch;
    static char directions[] = "norm";
    double epsilon = 0.001;
    int i,j,save_i;
    double dx,dy,theta,cosine,sine,x1,y1,x2,y2,x3,y3,x4,y4,xo,yo,xc,yc;
    double area,min_area;
    double min_x,min_y,max_x,max_y;

    for (i = 0; i < no_pixels; i++) {
        p[i*2] = x[i];
        p[i*2+1] = y[i];
    }
    n1 = no_pixels;

    convex_hull(p,n1,ch,&nch,directions,epsilon);

    /* go through all CH edges */
    save_i = 0;
    min_area = 9e9;
    for (i = 0; i < nch; i++) {
        n1 = ch[i];
        n2 = (ch[i+1] % no_pixels);
        if (n1 == n2) continue;
        x1 = x[n1];
        y1 = y[n1];
        x2 = x[n2];
        y2 = y[n2];
        dx = x2 - x1; dy = y2 - y1;
        theta = atan2(dy,dx);
        cosine = cos(-theta);
        sine = sin(-theta);

        /* transform CH and test MBR */
        min_x = min_y = 9e9;
        max_x = max_y = -9e9;
        for (j = 0; j < nch; j++) {
            n1 = ch[j];
            x3 = x[n1] - x1;
            y3 = y[n1] - y1;
            x4 = cosine*x3 - sine*y3;
            y4 = sine*x3 + cosine*y3;
            min_x = MIN(min_x,x4);
            min_y = MIN(min_y,y4);
            max_x = MAX(max_x,x4);
            max_y = MAX(max_y,y4);
        }
        area = (max_x - min_x) * (max_y - min_y);
        if (area < min_area) {
            min_area = area;
            save_i = i;
        }
    }

    /* again with correct index */
    n1 = ch[save_i];
    n2 = (ch[save_i+1] % no_pixels);
    x1 = x[n1];
    y1 = y[n1];
    x2 = x[n2];
    y2 = y[n2];
    dx = x2 - x1; dy = y2 - y1;
    theta = atan2(dy,dx);
    cosine = cos(-theta);
    sine = sin(-theta);
    min_x = min_y = 9e9;
    max_x = max_y = -9e9;
    for (i = 0; i < nch; i++) {
        n1 = ch[i];
        x3 = x[n1] - x1;
        y3 = y[n1] - y1;
        x4 = cosine*x3 - sine*y3;
        y4 = sine*x3 + cosine*y3;
        min_x = MIN(min_x,x4);
        min_y = MIN(min_y,y4);
        max_x = MAX(max_x,x4);
        max_y = MAX(max_y,y4);
    }
    cosine = cos(theta);
    sine = sin(theta);
    xo = x1; yo = y1;

    /*** co-ords of MBR
    x1 = cosine*min_x - sine*min_y;
    y1 = sine*min_x + cosine*min_y;

    x2 = cosine*max_x - sine*min_y;
    y2 = sine*max_x + cosine*min_y;

    x3 = cosine*max_x - sine*max_y;
    y3 = sine*max_x + cosine*max_y;

    x4 = cosine*min_x - sine*max_y;
    y4 = sine*min_x + cosine*max_y;

    x1 += xo; y1 += yo;
    x2 += xo; y2 += yo;
    x3 += xo; y3 += yo;
    x4 += xo; y4 += yo;
    ***/

    /* centre */
    xc = (min_x + max_x) / 2.0;
    yc = (min_y + max_y) / 2.0;

    *xct = cosine*xc - sine*yc + xo;
    *yct = sine*xc + cosine*yc + yo;

    *a = max_x - min_x;
    *b = max_y - min_y;

    if (*a > *b) {
        *rot = PI-theta;
    }
    else {
        *rot = theta+(PI/2.0);
    }
    /*
    if (*rot < 0) *rot += 2*PI; if (*rot < 0) *rot += 2*PI;
    if (*rot > PI) *rot -= PI; if (*rot > PI) *rot -= PI;
    */
    *rot = theta;
    if (*rot < 0) *rot += 2*PI; if (*rot < 0) *rot += 2*PI;
}

/* ############################################################ */

/* 
convexhull.c

Find the convex hull of a set of points.

The algorithm used is as describe in 

Shamos, Michael,  "Problems
in Computational Geometry"  May, 1975 (a set of photocopies -- 
QA 447.S52 1983 in Carlson).  

It originally appeared in a more complicated form in 

Jarvis, R.A., "On the Identification of the Convex Hull of a 
Finite Set of Points in the Plane", Info. Proc. Letters 2(1973),
pp. 18-21.

The algorithm is of complexity k*n, where n is the number of points in the
input and k the number of points in the convex hull.

usage:
convex_hull(p,n,ch,&nch,directions);
where p is an n*2 array of doubles containing the set of points,
n is the number of points,
ch is an array of size n integers to hold the list of points in the 
    convex hull, numbered 0 to nch-1;
In nch the number of points in the convex hull is returned.
directions is either "full" or "norm".  If directions="full" all the
possible points on the convex hull are returned.  If directions="norm"
a minimal set of points to describe the convex hull is returned.

epsilon is the angle tolerance in radians.  When two angles are closer than
PI radians they are considered equal.
*/

/* ### CONTENTS OF INCLUDE FILE INSERTED HERE ### */

/* incl.h */

#define boolean int
#define true 1
#define false 0

#define ERROR -1
#define OK 0

#define EPSILON 1.e-6
#define BIGNUM 1.e20

#define sqr(x) ((x)*(x))

/* ### -------------------------------------- ### */

static int debug=0;

void convex_hull(double *p, int n, int *ch, int *p_nch, char *directions, double epsilon)
{
    double phi, max_phi, dist, max_cen_dist, min_dist, max_dist, 
        x, y, cen_x, cen_y, xp, yp, 
    xx, yy, m[2][2];
    int i, i_keep, vertex, furthest, ch_vert;
    boolean full;

    if (!strcmp(directions,"full")) {
    full = true;
    }
    else if (!strcmp(directions,"norm")) {
    full = false;
    }
    else {
    fprintf(stderr,"convex_hull: invalid argument \"%s\"\n",directions);
    exit(ERROR);
    }
    centroid(p,n,&cen_x,&cen_y);
    /* find the point furthest from the centroid */
    max_cen_dist = 0.;
    for (i=0; i<n; i++) {
    x = p[2*i];
    y = p[2*i+1];
    dist = sqrt(sqr(x-cen_x) + sqr(y-cen_y));
    if (dist>max_cen_dist) {
        max_cen_dist = dist;
        furthest = i;
    }
    }

    /* 
    Determine rotation matrix so that coordinate system for determining
    the orientations of line segments is wrt the line from the point
    under consideration to the centroid.  Then all angles will be 
    < 90 degrees.  To maintain the strict inequality the furthest 
    point along the extreme ray will be used as the next point on 
    the convex hull.
    */

    make_rotation_matrix((cen_x-p[furthest*2])/max_cen_dist,
             (cen_y-p[furthest*2+1])/max_cen_dist,(double *)m);
    ch_vert = 0;
    vertex = furthest;
    do {
    ch[ch_vert] = vertex;
    /* Find the ray with the maximum and minimum angle in the new 
       coordinate system */
    if (debug) printf("vertex %d\n",vertex);
    max_phi = - BIGNUM;
    min_dist = BIGNUM;
    max_dist = 0.;
    for (i=0; i<n; i++) {
        /* calculate phi, the angle in the new coordinate system */
        x = p[2*i] - p[2*vertex];
        y = p[2*i+1] - p[2*vertex+1];
        xp = m[0][0]*x + m[0][1]*y;
        yp = m[1][0]*x + m[1][1]*y;
        if (debug) {
        printf("\ti %d x %f y %f xp %f yp %f\n", i,x,y,xp,yp);
        }
        if ((dist=sqrt(sqr(x)+sqr(y))) > EPSILON) {
        phi = atan2(yp,xp);
        if (debug) printf("\tphi %f\n", phi);
        if (phi > max_phi-epsilon) {
            if (full) {
            /* use the closest point */
            if (phi > max_phi + epsilon || dist < min_dist) {
                min_dist = dist;
                max_phi = phi;
                i_keep = i;
            }
            }
            else {
            /* use the furthest point */
            if (phi > max_phi + epsilon || dist > max_dist) {
                max_dist = dist;
                max_phi = phi;
                i_keep = i;
            }
            }
            if (debug) {
            printf("\t\tmax_phi %f i_keep %d\n", max_phi,i_keep);
            }
        }
        }
    } /* for */
        vertex = i_keep;
    xx = cen_x - p[vertex*2];
    yy = cen_y - p[vertex*2+1];
    dist = sqrt(sqr(xx) + sqr(yy));
    make_rotation_matrix(xx/dist,yy/dist,(double *)m);
    ch_vert++;
    } while (vertex != ch[0]);
    *p_nch = ch_vert;
}


void centroid(double *pts, int n, double *p_cen_x, double *p_cen_y)
/* 
Determines the centroid of the set of n points in the n*2 array of
doubles pts and returns its x-coordinate and y-coordinate in p_cen_x
and p_cen_y respectively.
*/
{
    double sumx, sumy;
    int i;

    sumx = sumy = 0;
    for (i=0; i<n; i++) {
    sumx += pts[2*i];
    sumy += pts[2*i+1];
    }
    *p_cen_x = sumx / n;
    *p_cen_y = sumy / n;
}


void make_rotation_matrix(double cos_theta,double sin_theta,double *m)
/* 
Given a unit vector (vx,vy) system, finds the matrix m that
corresponds to rotating the coordinate system so that its x-axis 
lies in the direction defined by (vx,vy).
*/
{
    *m = cos_theta;
    *(m+1) = sin_theta;
    *(m+2) = - sin_theta;
    *(m+3) = cos_theta;
}

/********** Xiaoming Zhang's estimator **********/

#define SMALL 1.0e-6

void
solve2 (double a,double b,double c,double *r1,double *r2)
{

double check;

    *r1 = *r2 = 100;
    check = b*b - 4.0 * a * c;
    if ( check >= 0.0 ) {
        check = sqrt(check);
        *r1 = ( - b + check )/(2.0*a);
        *r2 = ( - b - check )/(2.0*a);
    }
}

void
solve3 (double a,double b,double c,double d,double *r1,double *r2,double *r3)
{

double check, p, q, y, rr, theta;

    *r1 = *r2 = *r3 = 100;
    p = (c - b*b/3/a)/a;
    q = ((b*b*2/a/27-c/3)*b/a+d)/a;
    check = q*q /4 + p*p*p/27;
    if ( check>0.0) {
        check = sqrt (check);
        if (check-q/2<0.0) *r1 = -pow(-check+q/2,1.0/3);
        else *r1 = pow(check-q/2,1.0/3);
        if (-check-q/2<0.0) *r1 += -pow(check+q/2,1.0/3);
        else *r1 += pow(-check-q/2,1.0/3);
    } else if ((check<0.0)&&(p<0.0)) {
        rr = sqrt (-p/3);
        theta = acos(-q/2/rr/rr/rr)/3;
        rr *= 2.0;
        *r1 = rr*cos (theta);
        *r2 = rr*cos (theta+PI*2/3);
        *r3 = rr*cos (theta+PI*4/3);
    } else {
        *r2 = *r3 = pow(-q/2,1.0/3);
        *r1 = (*r2) * 2.0;
    }
    *r1 = *r1 - b/3/a;
    *r2 = *r2 - b/3/a;
    *r3 = *r3 - b/3/a;
/*printf ( "res %e %e %e\n", ((a*(*r1)+b)*(*r1)+c)*(*r1)+d,
((a*(*r2)+b)*(*r2)+c)*(*r2)+d,
((a*(*r3)+b)*(*r3)+c)*(*r3)+d);*/
}

double
estimate_ep ( int n, double x[],double  y[], double a,double b,double k)
{
int i, count=1;
double x_abs, y_abs;
double c0_sum, c1_sum, c2_sum, c3_sum, c0, c1, c2, c3, lgx, lgy, lgx2, lgy2;
double q, k2, k3, k4, k5, k6, check, x2k, y2k, r1, r2, r3, rng, x2klgx, y2klgy;
double c[4],s[3];
int num;

    for (i=0; i<n; i++) {
        x_nor[i] = fabs(x[i]/a);
        y_nor[i] = fabs(y[i]/b);
    }
    c0_sum = c1_sum = c2_sum = c3_sum = 0;
    for (i=0; i<n; i++) {
        x_abs = x_nor[i];
        y_abs = y_nor[i];
        x2k = pow (x_abs, 2.0/k);
        if (x_abs>SMALL) lgx = log(x_abs); else lgx = 0;
        lgx2 = lgx * lgx;
        y2k = pow (y_abs, 2.0/k);
        if (y_abs>SMALL) lgy = log(y_abs); else lgy = 0;
        lgy2 = lgy * lgy;
        k2 = k * k;
        k3 = k2 * k;
        k4 = k2 * k2;
        k5 = k2 * k3;
        k6 = k3 * k3;
        c0 = x2k + y2k - 1;
        x2klgx = x2k*lgx;
        y2klgy = y2k*lgy;
        c1 = -2.0*(x2klgx+y2klgy)/k2;
        c2 = 2.0*(x2klgx*(k+lgx)+y2klgy*(k+lgy))/k4;
        c3 = -2.0*(x2klgx*(3.0*k2+6.0*k*lgx+2.0*lgx2)+
            y2klgy*(3.0*k2+6.0*k*lgy+2.0*lgy2))/3/k6;
        c0_sum += c0*c1;
        c1_sum += c1*c1 + 2.0*c0*c2;
        c2_sum += 3.0*(c1*c2+c0*c3);
        c3_sum += 2.0*c2*c2+4.0*c1*c3;
    }
    /*
    solve3 ( c3_sum, c2_sum, c1_sum, c0_sum, &r1, &r2, &r3 );
    */
    c[0] = c0_sum;
    c[1] = c1_sum;
    c[2] = c2_sum;
    c[3] = c3_sum;
    num = SolveCubic(c, s);
    if (num != 1)
        printf("WARNING: # solutions: %d\n",num);
    r1 = s[0];

    printf("initial estimate: %f\n",k);
    printf ( "est %e  %e \n", r1+k,r1 );

    solve2 ( c2_sum, c1_sum, c0_sum, &r3, &r2 );
    printf ( "2nd order solution %e  (%e %e)\n", r3+k,r3,r2 );
    /*
    */
    r1 += k;
    return (r1);
}

/*
 *  Roots3And4.c
 *
 *  Utility functions to find cubic and quartic roots,
 *  coefficients are passed like this:
 *
 *      c[0] + c[1]*x + c[2]*x^2 + c[3]*x^3 + c[4]*x^4 = 0
 *
 *  The functions return the number of non-complex roots and
 *  put the values into the s array.
 *
 *  Author:         Jochen Schwarze (schwarze@isa.de)
 *
 *  Jan 26, 1990    Version for Graphics Gems
 *  Oct 11, 1990    Fixed sign problem for negative q's in SolveQuartic
 *                  (reported by Mark Podlipec),
 *                  Old-style function definitions,
 *                  IsZero() as a macro
 *  Nov 23, 1990    Some systems do not declare acos() and cbrt() in
 *                  <math.h>, though the functions exist in the library.
 *                  If large coefficients are used, EQN_EPS should be
 *                  reduced considerably (e.g. to 1E-30), results will be
 *                  correct but multiple roots might be reported more
 *                  than once.
 */

#ifndef M_PI
#define M_PI          3.14159265358979323846
#endif

/* epsilon surrounding for near zero values */

#define     EQN_EPS     1e-9
#define        IsZero(x)    ((x) > -EQN_EPS && (x) < EQN_EPS)

#ifdef NOCBRT
#define     cbrt(x)     ((x) > 0.0 ? pow((double)(x), 1.0/3.0) : \
                          ((x) < 0.0 ? -pow((double)-(x), 1.0/3.0) : 0.0))
#endif

int SolveQuadric(double c[ 3 ], double s[ 2 ])
{
    double p, q, D;

    /* normal form: x^2 + px + q = 0 */

    p = c[ 1 ] / (2 * c[ 2 ]);
    q = c[ 0 ] / c[ 2 ];

    D = p * p - q;

    if (IsZero(D))
    {
    s[ 0 ] = - p;
    return 1;
    }
    else if (D < 0)
    {
    return 0;
    }
    else if (D > 0)
    {
    double sqrt_D = sqrt(D);

    s[ 0 ] =   sqrt_D - p;
    s[ 1 ] = - sqrt_D - p;
    return 2;
    }
}


int SolveCubic(double c[ 4 ], double s[ 3 ])
{
    int     i, num;
    double  sub;
    double  A, B, C;
    double  sq_A, p, q;
    double  cb_p, D;

    /* normal form: x^3 + Ax^2 + Bx + C = 0 */

    A = c[ 2 ] / c[ 3 ];
    B = c[ 1 ] / c[ 3 ];
    C = c[ 0 ] / c[ 3 ];

    /*  substitute x = y - A/3 to eliminate quadric term:
    x^3 +px + q = 0 */

    sq_A = A * A;
    p = 1.0/3 * (- 1.0/3 * sq_A + B);
    q = 1.0/2 * (2.0/27 * A * sq_A - 1.0/3 * A * B + C);

    /* use Cardano's formula */

    cb_p = p * p * p;
    D = q * q + cb_p;

    if (IsZero(D))
    {
    if (IsZero(q)) /* one triple solution */
    {
        s[ 0 ] = 0;
        num = 1;
    }
    else /* one single and one double solution */
    {
        double u = cbrt(-q);
        s[ 0 ] = 2 * u;
        s[ 1 ] = - u;
        num = 2;
    }
    }
    else if (D < 0) /* Casus irreducibilis: three real solutions */
    {
    double phi = 1.0/3 * acos(-q / sqrt(-cb_p));
    double t = 2 * sqrt(-p);

    s[ 0 ] =   t * cos(phi);
    s[ 1 ] = - t * cos(phi + M_PI / 3);
    s[ 2 ] = - t * cos(phi - M_PI / 3);
    num = 3;
    }
    else /* one real solution */
    {
    double sqrt_D = sqrt(D);
    double u = cbrt(sqrt_D - q);
    double v = - cbrt(sqrt_D + q);

    s[ 0 ] = u + v;
    num = 1;
    }

    /* resubstitute */

    sub = 1.0/3 * A;

    for (i = 0; i < num; ++i)
    s[ i ] -= sub;

    return num;
}


int SolveQuartic(double c[ 5 ], double s[ 4 ])
{
    double  coeffs[ 4 ];
    double  z, u, v, sub;
    double  A, B, C, D;
    double  sq_A, p, q, r;
    int     i, num;

    /* normal form: x^4 + Ax^3 + Bx^2 + Cx + D = 0 */

    A = c[ 3 ] / c[ 4 ];
    B = c[ 2 ] / c[ 4 ];
    C = c[ 1 ] / c[ 4 ];
    D = c[ 0 ] / c[ 4 ];

    /*  substitute x = y - A/4 to eliminate cubic term:
    x^4 + px^2 + qx + r = 0 */

    sq_A = A * A;
    p = - 3.0/8 * sq_A + B;
    q = 1.0/8 * sq_A * A - 1.0/2 * A * B + C;
    r = - 3.0/256*sq_A*sq_A + 1.0/16*sq_A*B - 1.0/4*A*C + D;

    if (IsZero(r))
    {
    /* no absolute term: y(y^3 + py + q) = 0 */

    coeffs[ 0 ] = q;
    coeffs[ 1 ] = p;
    coeffs[ 2 ] = 0;
    coeffs[ 3 ] = 1;

    num = SolveCubic(coeffs, s);

    s[ num++ ] = 0;
    }
    else
    {
    /* solve the resolvent cubic ... */

    coeffs[ 0 ] = 1.0/2 * r * p - 1.0/8 * q * q;
    coeffs[ 1 ] = - r;
    coeffs[ 2 ] = - 1.0/2 * p;
    coeffs[ 3 ] = 1;

    (void) SolveCubic(coeffs, s);

    /* ... and take the one real solution ... */

    z = s[ 0 ];

    /* ... to build two quadric equations */

    u = z * z - r;
    v = 2 * z - p;

    if (IsZero(u))
        u = 0;
    else if (u > 0)
        u = sqrt(u);
    else
        return 0;

    if (IsZero(v))
        v = 0;
    else if (v > 0)
        v = sqrt(v);
    else
        return 0;

    coeffs[ 0 ] = z - u;
    coeffs[ 1 ] = q < 0 ? -v : v;
    coeffs[ 2 ] = 1;

    num = SolveQuadric(coeffs, s);

    coeffs[ 0 ]= z + u;
    coeffs[ 1 ] = q < 0 ? v : -v;
    coeffs[ 2 ] = 1;

    num += SolveQuadric(coeffs, s + num);
    }

    /* resubstitute */

    sub = 1.0/4 * A;

    for (i = 0; i < num; ++i)
    s[ i ] -= sub;

    return num;
}

