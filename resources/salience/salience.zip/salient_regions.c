/* salient region detection
 * image format: raw PPM or PGM
 * (the original program written for the Patt. Recog. paper used PGM,
 *  but I get better results using PPM colour images)
 *
 * described in:
 * A Simple Method for Detecting Salient Regions
 * Paul L. Rosin
 * Pattern Recognition, vol. 42, no. 11, pp. 2363-2371, 2009.
 *
 * Paul Rosin
 * September 2007
 *
 * -------------------------------------------------------------------------------------
 *
 * options for erosion of salience mask added
 *      two choices for padding image prior to erosion:
 *      1/ reflection will avoid/reduce shrinkage of regions butting up to image border
 *      2/ but actually simple padding with white (-E option) gave better results on
 *         Liu et al.'s CVPR 2007 dataset - this has been made the default setting
 * also, automatic erosion disk size selection (based on tests using CVPR 2007 dataset)
 * has been included
 *
 * Paul Rosin
 * April 2011
 *
 * -------------------------------------------------------------------------------------
 *
 * Sobel pyramid added [now default option]
 *
 * Paul Rosin
 * July 2013
 *
 * salience map now inverted
 *
 * Paul Rosin
 * October 2014
 *
 * central prior option added [now default option]
 *
 * Paul Rosin
 * May 2015
 *
 * -------------------------------------------------------------------------------------
 *
 * I tried post-processing the salience map using a few approaches
 * (close-fast, close-fast/erode-big-mean, min_gray_rectangle1)
 * and checked their correlations against GT density maps.
 * But none of these attempts provided a consistent improvement,
 * and are therefore not included here.
 *
 * Paul Rosin
 * July 2021
 *
 * update to sobel_pyramid (but results unchanged)
 * March 2023
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef FALSE
# define FALSE 0
# define TRUE (!FALSE)
#endif

#define SQR(x)          ((x)*(x))
#define MAX(a,b)        ((a) < (b) ? (b) : (a))
#define MIN(a,b)     (((a) < (b)) ? (a) : (b))
#define MAX3(x,y,z) ((x)>(y)?((x)>(z)?(x):(z)):((y)>(z)?(y):(z)))

#define MAX_SIZE 2000
#define MAX_LEVELS 6

#include "pgmio.h"
#include "ppmioNEW.h"

int kernel[3][3] = {{1,2,1}, {0,0,0}, {-1,-2,-1}};

unsigned char image[MAX_SIZE][MAX_SIZE];
int dt_image[MAX_SIZE][MAX_SIZE];
unsigned char tmp[MAX_SIZE][MAX_SIZE];
unsigned char tmp2[MAX_SIZE][MAX_SIZE];
unsigned char thresh[MAX_SIZE][MAX_SIZE];
unsigned char saliencyINV[MAX_SIZE][MAX_SIZE];

double edgesRGB[3][MAX_SIZE][MAX_SIZE];
double edges[MAX_SIZE][MAX_SIZE];
double summed_dt[MAX_SIZE][MAX_SIZE];
double prior[MAX_SIZE][MAX_SIZE];

// pyramid stuff
double pyramid[MAX_LEVELS][MAX_SIZE][MAX_SIZE];
double magnitude[MAX_LEVELS][MAX_SIZE][MAX_SIZE];
double new[MAX_SIZE][MAX_SIZE];

unsigned char colour[3][MAX_SIZE][MAX_SIZE];

int height,width,depth;

char *priorfile;
double priorFactor;

void apply_centralPrior(double image1[MAX_SIZE][MAX_SIZE], double priorFactor);
void sobel_pyramidRGB(unsigned char colour[3][MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE]);
void sobel_pyramid(unsigned char image[MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE]);
void sobel2(double image[MAX_SIZE][MAX_SIZE], double magnitude[MAX_SIZE][MAX_SIZE], int width, int height);
void sobelRGB(unsigned char colour[3][MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE]);
void sobel(unsigned char image[MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE]);
void interpolate(double image[MAX_SIZE][MAX_SIZE], double new[MAX_SIZE][MAX_SIZE], int width,int height,int *width2,int *height2, double factor);
void dt(unsigned char image1[MAX_SIZE][MAX_SIZE], int image2[MAX_SIZE][MAX_SIZE]);
void rescale(double image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE]);
void thresh_tsai(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE]);
void run_erode(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE], int diameter,int reflect);
void reflect_borders(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE], int border);
void pad255( unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE], int border);
void invert(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE]);
void options(char *progname);
double proportion(int t, unsigned char image[MAX_SIZE][MAX_SIZE]);
double moment( int i, unsigned char image[MAX_SIZE][MAX_SIZE]);

main(argc,argv)
int argc;
char *argv[];
{
    int i,t,x,y;
    char *infileRGB,*infileGRAY,*outfile,*maskfile,*saliencyfile;
    int erode_flag,reflect_flag,pyramid_flag,diameter,centralPrior_flag;

    infileRGB = infileGRAY = outfile = maskfile = saliencyfile = priorfile = NULL;
    erode_flag = TRUE;
    reflect_flag = FALSE;
    pyramid_flag = TRUE;
    centralPrior_flag = TRUE;
    priorFactor = 1;

    /* parse command line */
    for(i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            switch(argv[i][1]) {
                case 'c':
                    centralPrior_flag = TRUE;
                    i++;
                    priorFactor = atof(argv[i]);
                    break;
                case 'C':
                    i++;
                    priorfile = argv[i];
                    centralPrior_flag = TRUE;
                    break;
                case 'd':
                    erode_flag = FALSE;
                    break;
                case 'e':
                    erode_flag = TRUE;
                    reflect_flag = TRUE;
                    break;
                case 'E':
                    erode_flag = TRUE;
                    reflect_flag = FALSE;
                    break;
                case 'i':
                    i++;
                    infileRGB = argv[i];
                    break;
                case 'I':
                    i++;
                    infileGRAY = argv[i];
                    break;
                case 'm':
                    i++;
                    maskfile = argv[i];
                    break;
                case 'o':
                    i++;
                    outfile = argv[i];
                    break;
                case 'P':
                    pyramid_flag = FALSE;
                    break;
                case 's':
                    i++;
                    saliencyfile = argv[i];
                    break;
                default:
                    fprintf(stderr,"unknown option %s\n",argv[i]);
                    options(argv[0]);
            }
        }
        else {
            fprintf(stderr,"unknown option %s\n",argv[i]);
            options(argv[0]);
        }
    }

    if (((infileRGB == NULL) && (infileGRAY == NULL)) || (outfile == NULL))
        options(argv[0]);


    if (priorFactor == 0)
        centralPrior_flag = FALSE;
    else if (priorFactor < 0) {
        fprintf(stderr,"central prior spread factor should be >= 0\n");
        exit(-1);
    }

    if (infileRGB != NULL)
        read_ppm(colour,infileRGB,&width,&height,&depth);
    else
        read_pgm(image,infileGRAY,&width,&height,&depth);

    if (pyramid_flag) {
        if (infileRGB != NULL)
            sobel_pyramidRGB(colour,edges);
        else
            sobel_pyramid(image,edges);
    }
    else {
        if (infileRGB != NULL)
            sobelRGB(colour,edges);
        else
            sobel(image,edges);
    }

    /* for consistency with my original implementation
       I rescale and copy the edges into an 8 bit image
    */
    rescale(edges,tmp);

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            summed_dt[x][y] = 0;

    for (t = 4; t < 255; t += 4) {
        // threshold
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                if (tmp[x][y] > t)
                    thresh[x][y] = 0;
                else
                    thresh[x][y] = 255;

        // perform DT
        dt(thresh,dt_image);

        // running DT sum
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                summed_dt[x][y] += dt_image[x][y];
    }

    /* set corners to average for the time being */
    summed_dt[0][0] = (summed_dt[1][0] + summed_dt[0][1]) / 2;
    summed_dt[0][height-1] = (summed_dt[1][height-1] + summed_dt[0][height-2]) / 2;
    summed_dt[width-1][0] = (summed_dt[width-2][0] + summed_dt[width-1][1]) / 2;
    summed_dt[width-1][height-1] = (summed_dt[width-2][height-1] + summed_dt[width-1][height-2]) / 2;

    if (centralPrior_flag)
        apply_centralPrior(summed_dt,priorFactor);

    /* for consistency with my original implementation
       I rescale and copy the summed DT map into an 8 bit image
    */
    rescale(summed_dt,saliencyINV);

    if (saliencyfile != NULL) {
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                tmp2[x][y] = 255-saliencyINV[x][y];

        write_pgm(tmp2,saliencyfile,width,height);
    }

    thresh_tsai(saliencyINV,thresh);

    /* Often it is a good idea to erode the saliency mask since it tends to be too large
     * I have tried to automate the selection of the structuring element size. This was
     * done after my paper, and I have not evaluated the accuracy of the size selection.
     */
    if (erode_flag) {
        diameter = 54; // value that gave good results in my Patt. Recog. paper
        /* normalise structuring element size according to average image size
         * in Liu et al.'s CVPR 2007 dataset
         *
         * power 0.13 is chosen to match results from my paper in which
         * disk diameters 54 and 45 gave best results for full and quarter area images
         */
        diameter *= pow( (width * height) / 120000.0 , 0.13);
        printf("performing mask erosion; disk diameter = %d\n",diameter);

        run_erode(thresh,tmp,diameter,reflect_flag);

        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                thresh[x][y] = tmp[x][y];
    }

    if (maskfile != NULL)
        write_pgm(thresh,maskfile,width,height);

    // output image with salient mask overlaid
    if (infileRGB != NULL) {
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                for (i = 0; i < 3; i++)
                    colour[i][x][y] = 0.4 * thresh[x][y] + 0.6 * colour[i][x][y];
        write_ppm(colour,outfile,width,height);
    }
    else {
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++)
                image[x][y] = (thresh[x][y] + image[x][y]) / 2;
        write_pgm(image,outfile,width,height);
    }

}

// use formula from: Zhang et al, Interest Seam Image, CVPR, 2010
// but allow the spread to be modified as for some data (e.g. Liu
// et al.'s CVPR 2007 dataset) their value seems too concentrated
void apply_centralPrior(double image1[MAX_SIZE][MAX_SIZE], double priorFactor)
{
    int x,y,xc,yc;
    double max_val;
    double m = (width+height) / 2;   // use average rather than just one dimension
    double sigma = sqrt(2.0) / 7.0;

    /*
     * this seems a good idea as it will cope better with elongated images, but seems to give worse results
     * on Liu et al.'s CVPR 2007 dataset (which doesn't have very elongated images)
     */
    //m = MAX(width,height);

    // parameter to increase or decrease spread of central prior
    sigma /= priorFactor;

    printf("performing central weighting; factor = %.2f\n",priorFactor);

    // ############################################################################
    // hack - rescale and invert because my original DT is an inverted salience map
    // this is clumsy, and should really be modified sometime
    // ############################################################################

    // invert w.r.t. maximum
    max_val = image1[0][0];
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            if (image1[x][y] > max_val)
                max_val = image1[x][y];

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            image1[x][y] = max_val - image1[x][y];

    // calculate
    xc = width / 2;
    yc = height / 2;
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++) {
            image1[x][y] *= exp( -(SQR(x - xc) + SQR(y - yc)) / SQR(m * sigma));
            prior[x][y] = exp( -(SQR(x - xc) + SQR(y - yc)) / SQR(m * sigma));
        }

    // invert w.r.t. maximum
    max_val = image1[0][0];
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            if (image1[x][y] > max_val)
                max_val = image1[x][y];

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            image1[x][y] = max_val - image1[x][y];

    if (priorfile != NULL) {
        rescale(prior,tmp);
        write_pgm(tmp,priorfile,width,height);
    }
}

/* +++++++++++++++++++++++++ PYRAMID SOBEL +++++++++++++++++++++++++ */

void sobel_pyramidRGB(unsigned char colour[3][MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE])
{
    int i,x,y;

    for (i = 0; i < 3; i++)
        sobel_pyramid(colour[i],edgesRGB[i]);
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            //edges[x][y] = edgesRGB[0][x][y] + edgesRGB[1][x][y] + edgesRGB[2][x][y];
            edges[x][y] = MAX3(edgesRGB[0][x][y],edgesRGB[1][x][y],edgesRGB[2][x][y]);
}

// corrected March 2023 to avoid redundant processing
void sobel_pyramid(unsigned char image[MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE])
{
    int height0,width0;
    int no_levels;
    int i;
    int x,y,xx,yy;
    int width2,height2;
    int w[MAX_LEVELS],h[MAX_LEVELS];

    width0 = width; height0 = height;

    no_levels = log((double)(MIN(width,height) / 10)) / log(2.0);
    printf("no pyramid levels: %d\n",no_levels);
    if (no_levels > MAX_LEVELS) {
        fprintf(stderr,"ERROR: maximum number of levels = %d\n",MAX_LEVELS);
        exit(-1);
    }

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            pyramid[0][x][y] = image[x][y];
    w[0] = width;
    h[0] = height;

    // create pyramid
    for (i = 0; i < no_levels-1; i++) {
        width /= 2; height /= 2;
        for (y = 0; y < height; y++)
            for (x = 0; x < width; x++) {
                pyramid[i+1][x][y] = 0;
                for (xx = 0; xx < 2; xx++)
                    for (yy = 0; yy < 2; yy++)
                        pyramid[i+1][x][y] += pyramid[i][x*2+xx][y*2+yy];
                pyramid[i+1][x][y] /= 4.0;
            }
        w[i+1] = width;
        h[i+1] = height;
    }
    width = width0;
    height = height0;

    // run sobel
    for (i = 0; i < no_levels; i++)
        sobel2(pyramid[i],magnitude[i],w[i],h[i]);

    // sum pyramid levels
    for (i = no_levels-1; i > 0; i--) {
        interpolate(magnitude[i],new,w[i],h[i],&width2,&height2,2.0);
        for (y = 0; y < h[i-1]; y++)
            for (x = 0; x < w[i-1]; x++)
                magnitude[i-1][x][y] += new[x][y];
    }

    for (y = 1; y < height-1; y++)
        for (x = 1; x < width-1; x++)
            edges[x][y] = magnitude[0][x][y];
}

// this is the version of sobel used by the pyramid
void sobel2(double image[MAX_SIZE][MAX_SIZE], double magnitude[MAX_SIZE][MAX_SIZE], int width, int height)
{
    int x,y;
    double horiz,vert;

    /* perform magnitude */
    for (y = 1; y < height-1; y++)
    for (x = 1; x < width-1; x++) {
        horiz = image[x-1][y-1] + image[x][y-1] *2
              + image[x+1][y-1] -image[x-1][y+1]
              - image[x][y+1] *2 - image[x+1][y+1];
        vert =  image[x-1][y-1] + image[x-1][y] *2
              + image[x-1][y+1] -image[x+1][y-1]
              - image[x+1][y] *2 - image[x+1][y+1];
        magnitude[x][y] = sqrt(horiz*horiz+vert*vert);
    }
}

// this is the version of sobel used when there is no pyramid
void sobelRGB(unsigned char colour[3][MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE])
{
    int i,x,y;

    for (i = 0; i < 3; i++)
        sobel(colour[i],edgesRGB[i]);
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            //edges[x][y] = edgesRGB[0][x][y] + edgesRGB[1][x][y] + edgesRGB[2][x][y];
            edges[x][y] = MAX3(edgesRGB[0][x][y],edgesRGB[1][x][y],edgesRGB[2][x][y]);
}

// this is the version of sobel used when there is no pyramid
void sobel(unsigned char image[MAX_SIZE][MAX_SIZE], double edges[MAX_SIZE][MAX_SIZE])
{
    int x,y,xx,yy;
    float intensity;
    float convolution1,convolution2;

    for (x = 1; x < width-1; x++) {
        for (y = 1; y < height-1; y++) {
            convolution1 = convolution2 = 0;
            for (xx = -1; xx <= 1; xx++)
                for (yy = -1; yy <= 1; yy++)
                    convolution1 += (float)image[x+xx][y+yy] * kernel[xx+1][yy+1];
            for (xx = -1; xx <= 1; xx++)
                for (yy = -1; yy <= 1; yy++)
                    convolution2 += (float)image[x+xx][y+yy] * kernel[yy+1][xx+1];
            intensity = sqrt(convolution1*convolution1+convolution2*convolution2);

            edges[x][y] = intensity;
        }
    }
}

void interpolate(double image[MAX_SIZE][MAX_SIZE], double new[MAX_SIZE][MAX_SIZE], int width,int height,int *width2,int *height2, double factor)
{
    static double image2[MAX_SIZE][MAX_SIZE];
    int max_x,max_y;
    int x,y,x3,y3;
    double x2,y2;
    double p,q;

    // duplicate border first
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            new[x+1][y+1] = image[x][y];

    for (x = 0; x < width+2; x++) {
        new[x][0] = new[x][1];
        new[x][height+1] = new[x][height];
    }

    for (y = 0; y < height+2; y++) {
        new[0][y] = new[1][y];
        new[width+1][y] = new[width][y];
    }

    new[0][0] = new[1][1];
    new[width+1][0] = new[width][1];
    new[0][height+1] = new[1][height];
    new[width+1][height-1] = new[width-1][height];

    width += 2;
    height += 2;

    max_x = width*factor;
    max_y = height*factor;

    for (y = 0; y < max_y; y++)
        for (x = 0; x < max_x; x++) {
            x2 = x / factor; y2 = y / factor;
            x2 -= 0.5; y2 -= 0.5;
            x3 = floor(x2); y3 = floor(y2);

            q = x2 - x3; p = y2 - y3;

            if ((x3 >= 0) && (x3 < width-1) &&
                (y3 >= 0) && (y3 < height-1))
            {
                image2[x][y] =
                    (1 - p) * (1 - q) * new[x3][y3] +
                    q       * (1 - p) * new[x3+1][y3] +
                    p       * (1 - q) * new[x3][y3+1] +
                    p       * q       * new[x3+1][y3+1];
            }
        }

    width = max_x; height = max_y;

    // remove border
    for (y = 0; y < height-(int)factor; y++)
        for (x = 0; x < width-(int)factor; x++)
            new[x][y] = image2[x+(int)factor][y+(int)factor];
    width -= 2*factor; height -= 2*factor;

    *width2 = width; *height2 = height;
}

/* +++++++++++++++++++++++++ DISTANCE TRANSFORM +++++++++++++++++++++++++ */

/* perform chamfer 3-4 distance transform */
void dt(unsigned char image1[MAX_SIZE][MAX_SIZE], int image2[MAX_SIZE][MAX_SIZE])
{
    int i,x,y;
    int min_val,v[9];

    /* copy to integer image */
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            image2[x][y] = (unsigned char)image1[x][y];

    /* forward pass */
    for (y = 1; y < height-1; y++) {
        for (x = 1; x < width-1; x++) {
            v[0] = image2[x-1][y-1] + 4;
            v[1] = image2[x  ][y-1] + 3;
            v[2] = image2[x+1][y-1] + 4;
            v[3] = image2[x-1][y  ] + 3;
            v[4] = image2[x  ][y  ];

            min_val = v[0];
            for (i = 1; i < 5; i++)
                if (v[i] < min_val)
                    min_val = v[i];
            image2[x][y] = min_val;
        }
    }

    /* backward pass */
    for (y = height-2; y >= 1; y--) {
        for (x = width-2; x >= 1; x--) {
            v[0] = image2[x-1][y+1] + 4;
            v[1] = image2[x  ][y+1] + 3;
            v[2] = image2[x+1][y+1] + 4;
            v[3] = image2[x+1][y  ] + 3;
            v[4] = image2[x  ][y  ];

            min_val = v[0];
            for (i = 1; i < 5; i++)
                if (v[i] < min_val)
                    min_val = v[i];
            image2[x][y] = min_val;
        }
    }

    /* set corners low for the time being */
    image2[0][0] = image2[0][height-1] = 0;
    image2[width-1][0] = image2[width-1][height-1] = 0;

    /* do left edges too */
    x = 0;
    for (y = 1; y < height-1; y++) {
        v[0] = image2[x+1][y-1] + 4;
        v[1] = image2[x+1][y  ] + 3;
        v[2] = image2[x+1][y+1] + 4;

        min_val = 255;
        for (i = 0; i < 3; i++)
            if (v[i] < min_val)
                min_val = v[i];
        image2[x][y] = min_val;
    }

    /* do right edges too */
    x = width-1;
    for (y = 1; y < height-1; y++) {
        v[0] = image2[x-1][y-1] + 4;
        v[1] = image2[x-1][y  ] + 3;
        v[2] = image2[x-1][y+1] + 4;

        min_val = 255;
        for (i = 0; i < 3; i++)
            if (v[i] < min_val)
                min_val = v[i];
        image2[x][y] = min_val;
    }

    /* do top edges too */
    y = 0;
    for (x = 1; x < width-1; x++) {
        v[0] = image2[x-1][y+1] + 4;
        v[1] = image2[x  ][y+1] + 3;
        v[2] = image2[x+1][y+1] + 4;

        min_val = 255;
        for (i = 0; i < 3; i++)
            if (v[i] < min_val)
                min_val = v[i];
        image2[x][y] = min_val;
    }

    /* do bottom edges too */
    y = height-1;
    for (x = 1; x < width-1; x++) {
        v[0] = image2[x-1][y-1] + 4;
        v[1] = image2[x  ][y-1] + 3;
        v[2] = image2[x+1][y-1] + 4;

        min_val = 255;
        for (i = 0; i < 3; i++)
            if (v[i] < min_val)
                min_val = v[i];
        image2[x][y] = min_val;
    }
}

void rescale(double image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE])
{
    int x,y;
    double max_val;

    /* rescale */
    max_val = image1[0][0];
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            if (image1[x][y] > max_val)
                max_val = image1[x][y];

    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            image2[x][y] = (unsigned char)(image1[x][y] * 255 / max_val);
}

/* +++++++++++++++++++++++++ THRESHOLDING +++++++++++++++++++++++++ */

/* automatically threshold image using:
 *     Tsai, Moment-preserving thresholding: a new approach,
 *     CVGIP, vol 29, 377-393, 1985
 *
 * performs binary search on thresholds
 */
void thresh_tsai(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE])
{
    int x,y;
    int thr;
    //double moment(),proportion();
    double m1,m2,m3,c0,c1,z,p0;
    double val;
    int min,mid,max;

    m1 = moment(1,image1);
    m2 = moment(2,image1);
    m3 = moment(3,image1);
    c0 = (m1*m3 - SQR(m2)) / (m2 - SQR(m1));
    c1 = (m1*m2 - m3) / (m2 - SQR(m1));
    z = (sqrt(SQR(c1)-4*c0) - c1) / 2.0;
    p0 = (z-m1) / sqrt(SQR(c1)-4*c0);

    min = 0; max = 255;
    /* find appropriate threshold to produce p-tile p0 */
    do {
        mid = (max + min) / 2;
        val = proportion((int)mid,image1);
        if (val > p0)
            max = mid;
        else
            min = mid;
    } while (min < (max-1));
    thr = mid;

    /* actually threshold image now */
    for (y = 0; y < height; y++)
        for (x = 0; x < width; x++)
            if ((unsigned int)image1[x][y] < thr)
                image2[x][y] = 0;
            else
                image2[x][y] = 255;
}

/* return i'th grey-level moment of image */
double moment( int i, unsigned char image[MAX_SIZE][MAX_SIZE])
{
    int x,y;
    double sum;

    sum = 0;
    for (y = 0; y < height; y++) {
       for (x = 0; x < width; x++) {
          sum += pow((float)image[x][y],(float)i);
       }
    }

    return(sum / (double)(width*height));
}

/* return proportion of black in image thresholded at t */
double proportion(int t, unsigned char image[MAX_SIZE][MAX_SIZE])
{
    int x,y;
    int count1;

    count1 = 0;
    for (y = 0; y < height; y++) {
       for (x = 0; x < width; x++) {
          if ((unsigned int)image[x][y] < t)
             count1++;
       }
    }

    return(count1 / (double)(width*height));
}

/* +++++++++++++++++++++++++ EROSION +++++++++++++++++++++++++ */

/*
 * mathematical morphology - erosion
 * foreground = black (not white like my other code!)
 *
 * fast version using a histogram which is updated as disk shifts
 * could be faster if histogram updating was done on vertical translations
 * between rows rather than recomputing histogram for each row
 *
 * pads out image with 255 (white) or by reflection
 * reflection will avoid/reduce shrinkage of regions butting up to image border
 */

/* diameter of window for structuring element */
#define MAX_ELEM 501
unsigned char element[MAX_ELEM][MAX_ELEM];

int histogram[256];
int boundaryL_x[MAX_SIZE],boundaryL_y[MAX_SIZE];
int boundaryR_x[MAX_SIZE],boundaryR_y[MAX_SIZE];
int no_bdryL,no_bdryR;

unsigned char erode(unsigned char image[MAX_SIZE][MAX_SIZE], int sx,int sy, int diameter);
unsigned char erode2(unsigned char image[MAX_SIZE][MAX_SIZE], int sx,int sy);

void run_erode(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE], int diameter,int reflect)
{
    int x,y;
    int cx,cy,d2;
    static unsigned char tmp[MAX_SIZE][MAX_SIZE];

    if (diameter > MAX_ELEM) {
        fprintf(stderr,"ERROR: max allowable structuring element diameter: = %d\n",
            MAX_ELEM);
        exit(-1);
    }

    if (reflect)
        reflect_borders(image1,image2,diameter);
    else
        pad255(image1,image2,diameter);

    width = width + (2 * diameter);
    height = height + (2 * diameter);

    if ((width > MAX_SIZE) || (height > MAX_SIZE)) {
        fprintf(stderr,"ERROR: image too big for erosion\n");
        exit(-1);
    }

    /* set up structuring element */
    for (y = 0; y < diameter; y++)
        for (x = 0; x < diameter; x++)
            element[x][y] = 0;

    /* of structuring element */
    cx = (diameter - 1) / 2;
    cy = (diameter - 1) / 2;

    for (y = 0; y < diameter; y++)
        for (x = 0; x < diameter; x++) {
            d2 = SQR(cx - x) + SQR(cy - y);
            if (d2 <= SQR(cx))
                element[x][y] = 1;
        }

    /* find boundaries in structuring element */
    no_bdryL = no_bdryR = 0;
    for (y = 0; y < diameter; y++)
        for (x = 0; x < diameter; x++)
            if (element[x][y] == 1) {
                if ((x == 0) || (element[x-1][y] == 0)) {
                    boundaryL_x[no_bdryL] = x;
                    boundaryL_y[no_bdryL] = y;
                    no_bdryL++;
                }

                if ((x == diameter-1) || (element[x+1][y] == 0)) {
                    boundaryR_x[no_bdryR] = x;
                    boundaryR_y[no_bdryR] = y;
                    no_bdryR++;
                }
            }

    for (y = 0; y < height-diameter; y++) {
        x = 0;
        tmp[x+cx][y+cy] = erode(image2,x,y,diameter);
        for (x = 1; x < width-diameter; x++)
            tmp[x+cx][y+cy] = erode2(image2,x,y);
    }

    for (x = 0; x < width-2*diameter; x++)
        for (y = 0; y < height-2*diameter; y++)
            image2[x][y] = tmp[x+diameter][y+diameter];

    width = width - (2 * diameter);
    height = height - (2 * diameter);
}

// erode using all pixels in disk
// also set up the histogram
unsigned char erode(unsigned char image[MAX_SIZE][MAX_SIZE], int sx,int sy, int diameter)
{
    int max_val;
    int x,y;
    int i;

    max_val = -9999;

    for (i = 0; i < 256; i++)
        histogram[i] = 0;

    for (y = 0; y < diameter; y++)
        for (x = 0; x < diameter; x++)
            if (element[x][y] > 0) {
                max_val = MAX(max_val,image[x+sx][y+sy]);
                histogram[image[x+sx][y+sy]]++;
            }

    return((unsigned char)max_val);
}

// erode using boundary pixels in disk
// only copes with horizontal shifts at the moment
unsigned char erode2(unsigned char image[MAX_SIZE][MAX_SIZE], int sx,int sy)
{
    int x,y;
    int i;

    // remove histogram counts from trailing pixels
    for (i = 0; i < no_bdryL; i++) {
        x = boundaryL_x[i] - 1;
        y = boundaryL_y[i];

        histogram[image[x+sx][y+sy]]--;
    }

    // add histogram counts from leading pixels
    for (i = 0; i < no_bdryR; i++) {
        x = boundaryR_x[i];
        y = boundaryR_y[i];

        histogram[image[x+sx][y+sy]]++;
    }

    i = 255;
    while (histogram[i] == 0)
        i--;

    if (i < 0) {
        fprintf(stderr,"ERROR in histogram; index = %d\n",i);
        exit(-1);
    }

    return((unsigned char)i);
}

/* reflect the image about its borders */
void reflect_borders(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE], int border)
{
    int x,y;

    if ((2*border+width > MAX_SIZE) || (2*border+height > MAX_SIZE)) {
        fprintf(stderr,"ERROR: image too big after reflection\n");
        exit(-1);
    }

    for (x = 0; x < width; x++)
        for (y = 0; y < height; y++)
            image2[x+border][y+border] = image1[x][y];

    /* copy top & bottom sides */
    for (x = 0; x < width; x++)
        for (y = 0; y < border; y++) {
            image2[x+border][border+height+y] = image1[x][height-1-y];
            image2[x+border][border-y-1] = image1[x][y];
        }

    /* copy left & right sides */
    for (x = 0; x < border; x++)
        for (y = 0; y < height; y++) {
            image2[border+width+x][y+border] = image1[width-1-x][y];
            image2[border-x-1][y+border] = image1[x][y];
        }

    /* copy corners */
    for (x = 0; x < border; x++)
        for (y = 0; y < border; y++) {
            image2[border-x-1][y] = image2[border+x][y];
            image2[width+border+x][y] = image2[width-1+border-x][y];
            image2[border-x-1][y+height+border] = image2[border+x][y+height+border];
            image2[width+border+x][y+height+border] = image2[width-1+border-x][y+height+border];
        }

}

/* pad the image with 255 */
void pad255( unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE], int border)
{
    int x,y;

    for (x = 0; x < width; x++)
        for (y = 0; y < height; y++)
            image2[x+border][y+border] = image1[x][y];

    /* copy top & bottom sides */
    for (x = 0; x < width; x++)
        for (y = 0; y < border; y++) {
            image2[x+border][border+height+y] = 255;
            image2[x+border][border-y-1] = 255;
        }

    /* copy left & right sides */
    for (x = 0; x < border; x++)
        for (y = 0; y < height; y++) {
            image2[border+width+x][y+border] = 255;
            image2[border-x-1][y+border] = 255;
        }
}

void invert(unsigned char image1[MAX_SIZE][MAX_SIZE], unsigned char image2[MAX_SIZE][MAX_SIZE])
{
    int x,y;

    for (x = 0; x < width; x++)
        for (y = 0; y < height; y++)
            image2[x][y] = 255 - image1[x][y];
}

void options(char *progname)
{
    printf("usage: %s [options]\n",progname);
    printf("     -i file    input colour image\n");
    printf("     -I file    input gray-level image\n");
    printf("     -o file    output overlay image\n");
    printf("     -m file    output mask image\n");
    printf("     -s file    output saliency image\n");
    printf("     -C file    output central prior weighting as image\n");
    printf("     -E         erode saliency mask (simple mask padding at image boundary) [DEFAULT]\n");
    printf("     -e         erode saliency mask (reflecting mask at image boundary)\n");
    printf("     -c float   set central prior spread factor [default: %.2f]\n",priorFactor);
    printf("     -d         disable erosion of saliency mask\n");
    printf("     -P         disable pyramid: Sobel edges at single scale only\n");
    exit(-1);
}
